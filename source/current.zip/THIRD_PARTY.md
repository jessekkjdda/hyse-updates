# Componentes e serviços

| Componente | Uso | Aviso/origem |
| --- | --- | --- |
| GlassPlayer | Base nativa do aplicativo | GPL-3.0, LICENSE; https://github.com/Jonzu00/GlassPlayer |
| Liner | Renderer Canvas, rolagem, quebra, pintura, relógio e sliders originais | Autorização específica informada pelo usuário; licença original em licenses/Liner-LICENSE.txt e vendor/liner/LICENSE; https://github.com/tryliner/desktop |
| Spicy Lyrics | Parser TTML local original e validação de fronteiras de palavras | AGPL-3.0, licenses/Spicy-Lyrics-LICENSE.txt; https://github.com/Spikerko/spicy-lyrics |
| fast-xml-parser 5.11.0 | Leitura/validação local XML usada pelo Spicy | MIT, licenses/fast-xml-parser-LICENSE.txt; dependências fixadas no lock e avisos em licenses |
| Riff | Helpers de fade/cores retidos do hyse anterior | MIT, licenses/Riff-LICENSE.txt; https://github.com/rootscripts/riff |
| NAudio 2.2.1 | Medição de áudio local no Windows | MIT, licenses/NAudio-LICENSE.txt |
| YamlDotNet 18.1.0 | Importação Lyricsfile | MIT, licenses/YamlDotNet-LICENSE.txt |
| WebView2 | Interface e players oficiais | Termos do SDK; runtime instalado separadamente |
| React / React DOM 19.3.1 / Scheduler 0.28.0 | Hospedagem dos sliders originais | MIT, avisos individuais em licenses |
| Framer Motion / Motion DOM 14.7.1 / Motion Utils 14.7.0 | Animação do slider original | MIT, avisos individuais em licenses |
| Montserrat variável | Família das letras | SIL OFL 1.1, licenses/Montserrat-OFL.txt; https://github.com/google/fonts/tree/main/ofl/montserrat |
| Inter variável | Família da interface | SIL OFL 1.1, licenses/Inter-OFL.txt; https://github.com/rsms/inter |

A autorização do Liner foi declarada pelo usuário na conversa. A cópia preserva
a autoria, a licença e o código original. Não se afirma uma licença permissiva
geral para esse código nem autenticação em serviços oficiais.

Spotify Web Playback SDK e SoundCloud Widget são carregados dos domínios oficiais
em execução. Áudio, restrições regionais, prévias, contas e disponibilidade
continuam sob os respectivos serviços. Tokens e cookies pessoais não acompanham
a distribuição. O widget SoundCloud fica em https://w.soundcloud.com .

LRCLIB usa sua API HTTPS pública: https://lrclib.net/docs . AMLL TTML usa a API
oficial https://api.amll.dev , documentada em
https://amll.dev/reference/http-api/overview.html . O banco de contribuições
https://github.com/amll-dev/amll-ttml-db possui aviso CC0-1.0 para contribuições;
letras externas conservam os direitos de seus titulares. O pacote não contém
catálogo de letras nem músicas reais obtidas dos serviços.

O renderer original do Liner não concede acesso ao catálogo Wordly. Os endpoints,
a assinatura e a autenticação desse serviço não foram integrados ou emulados.

Ferramentas de desenvolvimento: esbuild 0.28.2, Happy DOM 21.0.4 e
@napi-rs/canvas 0.1.100. São usadas para bundle, DOM e rasterização de teste;
node_modules e binários de teste não são redistribuídos. Os locks fixam versões
e origens para reconstrução. Exemplos dos testes são artificiais.


O Spicy Lyrics é usado como parser local, de forma não oficial. O catálogo e os
serviços hospedados não são incorporados nem consultados. Os quatro arquivos
originais, o commit e os hashes estão em vendor/spicy/manifest.json. A licença
AGPL-3.0 do código é independente de acesso a serviços. O parser recebe somente
TTML validado já disponível pelos provedores existentes ou importado no hyse.


## NSIS

NSIS 3.11 gera o instalador Windows. Fonte oficial: https://nsis.sourceforge.io/ .
Ferramenta binária obtida do pacote Debian nsis 3.11-1. Avisos completos de
redistribuição em licenses/NSIS-NOTICES.txt. Nenhum componente NSIS foi modificado.
