using System.Diagnostics;
using System.Text.Json;
using GlassPlayer.Core;
using Microsoft.Win32;

if(!OperatingSystem.IsWindows())return 1;
string directory=AppContext.BaseDirectory;
// A single-file host executes outside the installed app, leaving its files unlocked.
directory=Path.GetDirectoryName(Environment.ProcessPath)!;
using var single=new Semaphore(1,1,UpdateHandoff.MutexName);
bool owns=single.WaitOne(0);if(!owns)return 2;
UpdatePlan? plan=null;string? backup=null;bool installationStarted=false;
try
{
    string cache=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"hyse","updates");
    if(!UpdateHandoff.SameDirectory(Path.GetDirectoryName(directory)!,cache))throw new IOException("Local da atualização inválido.");
    var planPath=Path.Combine(directory,"apply.json");if(new FileInfo(planPath).Length>8192)throw new IOException("Plano inválido.");
    plan=JsonSerializer.Deserialize<UpdatePlan>(await File.ReadAllTextAsync(planPath))??throw new IOException("Plano ausente.");
    string? registered=Registry.GetValue(@"HKEY_CURRENT_USER\Software\hyse","InstallDir",null) as string;
    if(registered==null||!UpdateHandoff.SameDirectory(registered,plan.InstallDirectory)||!File.Exists(Path.Combine(registered,"hyse.exe")))throw new IOException("Instale o hyse antes de usar as atualizações automáticas.");
    string actual=FileVersionInfo.GetVersionInfo(Path.Combine(registered,"hyse.exe")).ProductVersion?.Split('+')[0]??"";
    if(UpdateVerification.ParseVersion(actual)!=UpdateVerification.ParseVersion(plan.CurrentVersion))throw new IOException("A versão instalada mudou. Abra o hyse e verifique novamente.");
    var update=await UpdateHandoff.ReadAsync(directory,plan.CurrentVersion,CancellationToken.None);
    try
    {
        using var parent=Process.GetProcessById(plan.ParentId);
        if(parent.StartTime.ToUniversalTime().Ticks!=plan.ParentStarted||!string.Equals(parent.MainModule?.FileName,Path.Combine(registered,"hyse.exe"),StringComparison.OrdinalIgnoreCase))throw new IOException("A instância do hyse mudou.");
        using var timeout=new CancellationTokenSource(TimeSpan.FromMinutes(2));await parent.WaitForExitAsync(timeout.Token);
    }
    catch(ArgumentException){}
    catch(InvalidOperationException){} // Parent already saved and exited before the helper started.
    // Abort if another process reopened the player before the installer acquired its lock.
    if(Mutex.TryOpenExisting("Local\\hyse.desktop",out var running)){running.Dispose();throw new IOException("Feche o hyse e tente atualizar novamente.");}
    backup=Path.Combine(directory,"previous-install");if(Directory.Exists(backup))Directory.Delete(backup,true);
    CopyTree(registered,backup);
    using var installerLock=new FileStream(update.InstallerPath,FileMode.Open,FileAccess.Read,FileShare.Read);
    // Recheck immediately before execution; the file remains locked against writes.
    await UpdateVerification.VerifyInstallerAsync(update.InstallerPath,update.Manifest,CancellationToken.None);
    if(registered.IndexOfAny(['"','\r','\n'])>=0)throw new IOException("Pasta de instalação inválida.");
    installationStarted=true;
    using(var setup=Process.Start(new ProcessStartInfo(update.InstallerPath){UseShellExecute=false,Arguments="/S /D="+registered,WorkingDirectory=directory})??throw new IOException("O instalador não iniciou."))
    {
        await setup.WaitForExitAsync();if(setup.ExitCode!=0)throw new IOException("O instalador retornou "+setup.ExitCode+".");
    }
    var installed=FileVersionInfo.GetVersionInfo(Path.Combine(registered,"hyse.exe")).ProductVersion?.Split('+')[0];
    if(installed!=update.Manifest.Version)throw new IOException("A versão instalada não confere.");
    File.WriteAllText(Path.Combine(cache,"last-result.json"),JsonSerializer.Serialize(new{ok=true,version=installed,at=DateTimeOffset.UtcNow}));
    try{Directory.Delete(backup,true);}catch{}backup=null;
    single.Release();owns=false;
    if(plan.Restart)Process.Start(new ProcessStartInfo(Path.Combine(registered,"hyse.exe")){UseShellExecute=true,WorkingDirectory=registered});
    return 0;
}
catch(Exception ex)
{
    string failure=ex.Message;
    if(installationStarted&&backup!=null&&plan!=null)
    {
        try
        {
            CopyTree(backup,plan.InstallDirectory);
            using var key=Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Uninstall\hyse",true);key?.SetValue("DisplayVersion",plan.CurrentVersion);
            failure+=" A instalação anterior foi restaurada.";
        }
        catch(Exception restore){failure+=" Falha ao restaurar: "+restore.Message;}
    }
    try{File.WriteAllText(Path.Combine(Path.GetDirectoryName(directory)!,"last-result.json"),JsonSerializer.Serialize(new{ok=false,message=failure,at=DateTimeOffset.UtcNow}));}catch{}
    if(owns){single.Release();owns=false;}
    if(plan?.Restart==true)try{Process.Start(new ProcessStartInfo(Path.Combine(plan.InstallDirectory,"hyse.exe")){UseShellExecute=true,WorkingDirectory=plan.InstallDirectory});}catch{}
    return 1;
}
finally{if(owns)single.Release();}

static void CopyTree(string source,string target)
{
    if((File.GetAttributes(source)&FileAttributes.ReparsePoint)!=0)throw new IOException("A pasta contém um redirecionamento.");
    Directory.CreateDirectory(target);
    foreach(string file in Directory.GetFiles(source))
    {
        if((File.GetAttributes(file)&FileAttributes.ReparsePoint)!=0)throw new IOException("A pasta contém um redirecionamento.");
        File.Copy(file,Path.Combine(target,Path.GetFileName(file)),true);
    }
    foreach(string child in Directory.GetDirectories(source))CopyTree(child,Path.Combine(target,Path.GetFileName(child)));
}
