# hyse — avisos de autoria

hyse 0.16.0, atualização de 26 de novembro de 2026.

O aplicativo mantém código de GlassPlayer, por Jonzu00 e demais colaboradores,
commit 600c7efb378edb4fc08c6b35486f951ec71c2e62:
https://github.com/Jonzu00/GlassPlayer . O aviso GPL versão 3 original está em
LICENSE. O código correspondente desta distribuição acompanha a pasta source.

## Liner

O renderer Canvas e os componentes Slider e TimelineSlider foram incorporados
do Liner, copyright 2024–2026 Liner Project Contributors & feralbureau:
https://github.com/tryliner/desktop . Commit de origem:
54eaab9ade697b95756c68b6901a24b0a27949e4.

A autorização específica para esta integração foi informada pelo usuário nesta
conversa, em 24/11/2026. Isso não é apresentado como verificação independente,
autorização geral de distribuição pública ou relicenciamento do projeto Liner.
A licença original foi preservada integralmente em licenses/Liner-LICENSE.txt
e source/vendor/liner/LICENSE. Os arquivos originais e seus hashes Git estão
em source/vendor/liner/manifest.json. O adaptador hyse e a ligação de build estão
separados em source/integration e source/scripts/build-liner.cjs.

Nenhuma conta, token, código de assinatura ou backend oficial do Liner foi
incorporado. Wordly não está integrado; o renderer recebe os dados do hyse.
As referências e os limites de teste estão em docs/VALIDACAO-0.11.md.

## Riff

Os cálculos de pesos e progresso de fade utilizados na seleção estimada da
palavra em fontes por linha, e partes da paleta de cores, conservam adaptações
do Riff, copyright 2026 rootscripts, sob MIT:
https://github.com/rootscripts/riff , referência
5031a840fb50dbb53a5830329ed69363fe09d824.
Aviso integral em licenses/Riff-LICENSE.txt. Seu servidor, Electron, yt-dlp e
provedores privados não estão incluídos. A rolagem principal agora é do Liner.

## Outros componentes

NAudio 2.2.1 e YamlDotNet 18.1.0 conservam seus avisos MIT em licenses.
Microsoft WebView2 é usado sob os termos de seu SDK; o runtime WebView2 não é
redistribuído. Os locks NuGet e npm fazem parte do código correspondente.

React 19.3.1, React DOM 19.3.1 e Scheduler 0.28.0: Meta Platforms, Inc. and
affiliates, MIT. Framer Motion 14.7.1, Motion DOM 14.7.1 e Motion Utils 14.7.0:
Motion B.V., MIT. Os avisos individuais acompanham licenses e os comentários de
licença emitidos pelo bundle. Esses componentes são incluídos no bundle dos
sliders; Node não é necessário no computador do usuário.

Montserrat e Inter são arquivos originais dos respectivos projetos, sob SIL OFL
1.1; avisos em licenses/Montserrat-OFL.txt e licenses/Inter-OFL.txt. Não foram
extraídas de um pacote binário do Liner.

@napi-rs/canvas, Happy DOM e esbuild são ferramentas de
desenvolvimento/teste; node_modules e seus binários não integram o aplicativo.
Os fontes e avisos próprios permanecem disponíveis pelo lock npm.


## Atualização 0.11.1

O arquivo original src/features/player/hooks/mediaClock.ts do mesmo commit Liner
foi incorporado sem alterações, com o blob Git registrado no manifesto. O código
em integration/media-clock.ts e media-state.ts é a adaptação hyse ao transporte
SDK e ao fallback nativo. Um elemento sem src expõe somente o estado das amostras
para cumprir o contrato do módulo original; não reproduz áudio adicional.
A autorização informada cobre o código. O usuário informou que não recebeu acesso
ao serviço Wordly; esta distribuição não incorpora esse acesso nem afirma que
o backend está conectado.


## Atualização 0.11.2

A estimativa visual de partes por palavra para fontes por linha está em
integration/estimated-line.ts. Ela conserva os pesos de texto derivados do Riff
(MIT), sem modificar os arquivos originais do Liner ou os documentos de letras.
O adaptador mantém o shift nativo de cada tipo de fonte. A viewport sem margem,
os grips nativos de resize e a separação das animações de escala/drift da capa
são ajustes próprios. Clocks, fontes e leitores preservam os bytes da 0.11.1.


## Spicy Lyrics — integração local 0.11.3

Quatro arquivos originais (parser TTML, EmptyLines, StripZeroWidth e LICENSE)
foram incorporados de Spikerko/spicy-lyrics, commit
1c02f47cd64ed8c34bb76dd8ff00755db9d1d66f, copyright Spikerko e colaboradores:
https://github.com/Spikerko/spicy-lyrics . A licença AGPL-3.0 original está em
licenses/Spicy-Lyrics-LICENSE.txt e vendor/spicy/LICENSE. O manifesto Git registra
os bytes originais, conferidos no build. Esta é uma integração não oficial.

O adaptador hyse em integration/spicy-ttml.ts é distribuído sob AGPL-3.0;
o código correspondente completo acompanha source. A combinação conserva as
obrigações aplicáveis da AGPL-3.0, além dos avisos originais dos componentes.
O log do parser é ligado ao host por um adaptador separado de build.
Não há credenciais, catálogo, cache extraído, API ou serviço online Spicy no pacote.
O provedor original da letra é preservado; Spicy é apenas o parser local.

fast-xml-parser 5.11.0 e dependências de processamento XML: MIT, avisos em licenses
com as versões e origens fixadas por package-lock.json. As ferramentas de build
não são necessárias para usar o aplicativo Windows.


## Atualização 0.11.4

O adaptador Spicy agora valida e conserva o fallback por verso. Os arquivos
originais dos projetos Spicy e Liner não são editados. O pré-carregamento
cancelável, a reserva de próxima faixa, os menus de vidro, a persistência de
preferências e os diagnósticos de quadros são alterações próprias do hyse.


## Instalador 0.12.0

Instalador gerado com NSIS 3.11, https://nsis.sourceforge.io/ . Os avisos de
redistribuição do NSIS e de seus componentes acompanham licenses/NSIS-NOTICES.txt.
Atalhos, identificação da instância e ciclo da bandeja são alterações locais.
Diretórios internos anteriores continuam preservados por compatibilidade.


## Discord 0.12.1

Integração própria do protocolo IPC documentado pelo Discord:
https://docs.discord.com/developers/topics/rpc . Não foi incorporado código de
bibliotecas Discord de terceiros. Não há credenciais ou serviço remoto próprio.
O PNG do ícone é uma extração exata do ícone já distribuído no hyse 0.12.0.


## Spicy Lyrics — ondulação 0.15.0

A matemática original do modo Bloom (RefreshedEmphasis, RefreshedLift,
getRefreshedFlame e cubicBezier) foi incorporada do mesmo commit Spicy
1c02f47cd64ed8c34bb76dd8ff00755db9d1d66f. Sete arquivos completos e sem
alterações estão em vendor/spicy-wave/original, com origem e hashes Git em
vendor/spicy-wave/manifest.json. O build confere os hashes antes de extrair a
seção analítica de LyricsAnimator.ts; apenas a medição DOM é adaptada para Canvas.

SplitLetters e IsLetterCapable também são executados diretamente dos originais.
Emphasize e JoinSplitWords acompanham a origem para rastreabilidade; o adaptador
agrupa sílabas do modelo Canvas sem alterar seus tempos. As alterações e a
extração estão em integration/spicy-wave-canvas.ts, spicy-wave-style.ts,
spicy-wave-source.ts e scripts/build-wave-source.cjs, sob AGPL-3.0.
O código correspondente integral e a licença acompanham o Setup e o ZIP.
O relógio, fade, fonte e rolagem aprovados do hyse continuam como base.
Nenhum catálogo, chave, autenticação ou serviço online Spicy foi incorporado.


## Atualização 0.16.0

A ponte Canvas aplica a elevação original também às palavras curtas e às partes
já estimadas pelo fade por linha. O swell sustentado conserva a elegibilidade
Bloom original; o modo leve usa as mesmas curvas com swell desativado. Os
arquivos originais continuam sem alterações. Nenhum tempo musical foi alterado.

A paginação de descoberta, leitura da fila Spotify, continuação ao terminar uma
lista, manutenção do histórico de rádio e resiliência IPC são alterações próprias.
A imagem do RPC é o ícone já registrado no aplicativo Discord informado pelo
usuário, servido pela CDN pública do Discord. Não há bot, token novo ou servidor
adicional. Informações de licença continuam no App info recolhido.
