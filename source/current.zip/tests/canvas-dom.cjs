// Software Canvas 2D for engine pixel tests. This does not emulate browser CSS.
const path=require('node:path');
const native=require('@napi-rs/canvas');
native.GlobalFonts.registerFromPath(path.resolve(__dirname,'../GlassPlayer/Web/fonts/Montserrat-Variable.ttf'),'Montserrat');
module.exports=function installCanvas(w){
 const backing=new WeakMap(),contexts=new WeakMap();
 function canvas(el){if(!backing.has(el))backing.set(el,native.createCanvas(Math.max(1,el.width||300),Math.max(1,el.height||150)));const c=backing.get(el);if(c.width!==Math.max(1,el.width))c.width=Math.max(1,el.width);if(c.height!==Math.max(1,el.height))c.height=Math.max(1,el.height);return c;}
 w.Path2D=native.Path2D;
 w.HTMLCanvasElement.prototype.getContext=function(kind){if(kind!=='2d')return null;const el=this;if(contexts.has(el))return contexts.get(el);const proxy=new Proxy({}, {get(_,key){const c=canvas(el),ctx=c.getContext('2d');if(key==='canvas')return el;if(key==='drawImage')return(image,...args)=>ctx.drawImage(image instanceof w.HTMLCanvasElement?canvas(image):image,...args);const value=ctx[key];return typeof value==='function'?value.bind(ctx):value;},set(_,key,value){canvas(el).getContext('2d')[key]=value;return true;}});contexts.set(el,proxy);return proxy;};
 return{canvas,composite(base,live){const result=native.createCanvas(base.width,base.height),ctx=result.getContext('2d');ctx.drawImage(canvas(base),0,0);if(live.style.visibility==='visible'){const y=Number(live.style.transform.match(/translateY\(([-\d.]+)/)?.[1]||0);const dpr=base.width/(parseFloat(base.style.width)||base.width);ctx.drawImage(canvas(live),0,y*dpr);}return result;}};
};
