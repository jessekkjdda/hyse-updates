using System.Text.Json;
using GlassPlayer.Core;

if(args.Length!=1)throw new ArgumentException("Informe uma pasta temporária para o download verificado.");
using var client=new UpdateClient();
// Deliberately older than the first updater-enabled build. Never launches files.
var update=await client.CheckAndDownloadAsync("0.12.1",Path.GetFullPath(args[0]),null,CancellationToken.None)??throw new Exception("Nenhuma versão posterior à 0.12.1 no canal.");
Console.WriteLine(JsonSerializer.Serialize(new{verified=true,version=update.Manifest.Version,size=update.Manifest.SizeBytes,sha256=update.Manifest.Sha256,path=update.InstallerPath}));
