using System.Text.Json;
using GlassPlayer;
using GlassPlayer.Core;

var passed=0;
void Check(bool condition,string name){if(!condition)throw new Exception("FAIL: "+name);passed++;Console.WriteLine("PASS: "+name);}
void Throws(Action action,string name){try{action();}catch(ArgumentException){Check(true,name);return;}throw new Exception("FAIL: "+name);}
async Task Reject(Func<Task> action,string name){try{await action();}catch(Exception ex)when(ex is FormatException or ArgumentException or OperationCanceledException){Check(true,name);return;}throw new Exception("FAIL: "+name);}

var q=new PlaybackQueue<string>();var search=new List<string>{"a","b","c"};q.Start(search,0);search.Clear();search.Add("search replacement");
Check(q.Items.Count==3&&q.Current=="a","new search does not mutate active queue");
Check(q.Next()=="b"&&q.Next()=="c"&&q.Next()==null,"stop at end without repeat");
q.Repeat=RepeatMode.All;Check(q.Next()=="a"&&q.Previous()=="c","repeat queue wraps in both directions");
q.Repeat=RepeatMode.One;Check(q.Next(false)=="c","repeat one on natural completion");Check(q.Next()==null,"manual next ignores repeat one");
q.Start(new[]{"a","b"},0);Check(q.Next()=="b","manual skip repeat one advances");q.Clear();Check(q.Current==null&&q.Index==-1&&q.Next()==null,"empty queue navigation");
q.Append(new[]{"a","b"});Check(q.Current=="a"&&q.Items.Count==2,"append to empty queue");
Throws(()=>q.Start(new[]{"x"},3),"invalid start index rejected");Check(q.Current=="a","invalid start preserves old queue");
Throws(()=>q.Append(Enumerable.Repeat("x",10000)),"queue cap is atomic");Check(q.Items.Count==2,"overflow append preserves queue");
Throws(()=>q.Start(Enumerable.Repeat("x",10001),0),"oversize replacement rejected");
for(int seed=0;seed<40;seed++)
{
    var shuffle=new PlaybackQueue<string>(new Random(seed)){Shuffle=true};shuffle.Start(new[]{"a","b","c","d","e"},2);
    Check(shuffle.Previous()=="c","shuffle previous without history stays current #"+seed);
    var heard=new HashSet<string>{shuffle.Current!};string? next;while((next=shuffle.Next())!=null)if(!heard.Add(next))throw new Exception("duplicate shuffle");
    Check(heard.Count==5,"shuffle visits every track exactly once #"+seed);
    var last=shuffle.Current;Check(shuffle.Previous()!=last&&shuffle.Next()==last,"shuffle previous and next retain order #"+seed);
    shuffle.Repeat=RepeatMode.All;Check(shuffle.Next()!=null,"shuffle repeat starts a new cycle #"+seed);
}
var one=new PlaybackQueue<string>{Shuffle=true,Repeat=RepeatMode.All};one.Start(new[]{"solo"},0);Check(one.Next()=="solo","one-item shuffled repeat");
var dup=new PlaybackQueue<string>{Shuffle=true};dup.Start(new[]{"same","same"},0);Check(dup.Next()=="same"&&dup.Next()==null,"duplicate tracks remain distinct queue entries");
using(var gate=new LatestOperation())
{
    var first=gate.Begin();var second=gate.Begin();Check(first.Token.IsCancellationRequested&&!gate.IsCurrent(first.Version)&&gate.IsCurrent(second.Version),"latest request cancels superseded request");
    string output="";
    async Task Complete((long Version,CancellationToken Token) operation,string value,int delay){await Task.Delay(delay);if(gate.IsCurrent(operation.Version))output=value;}
    var slow=Complete(second,"old",25);var third=gate.Begin();await Complete(third,"new",1);await slow;Check(output=="new","late completion cannot replace newest track");
    gate.Cancel();Check(third.Token.IsCancellationRequested&&!gate.IsCurrent(third.Version),"explicit cancellation invalidates completion");
}
const string id="50xbldSSXimOhj9bpwsGlE";
Check(ImportLink.Parse("https://open.spotify.com/playlist/"+id+"?si=abc").PlaylistId==id,"Spotify playlist URL");
Check(ImportLink.Parse("spotify:playlist:"+id).PlaylistId==id,"Spotify playlist URI");
Check(ImportLink.Parse("https://open.spotify.com/intl-pt/playlist/"+id).PlaylistId==id,"localized Spotify URL");
Throws(()=>ImportLink.Parse("https://music.youtube.com/playlist?list=abc"),"removed YouTube source is rejected");
Throws(()=>ImportLink.Parse("https://on.soundcloud.com/test"),"removed SoundCloud source is rejected");
foreach(var link in new[]{"http://open.spotify.com/playlist/"+id,"https://open.spotify.com.evil.test/playlist/"+id,"https://user:password@open.spotify.com/playlist/"+id,"https://open.spotify.com:444/playlist/"+id,"file:///etc/passwd","https://evil.test/?youtube.com","https://youtube.com.evil.test/test","--help","https://open.spotify.com/track/"+id,"spotify:playlist:abc"})Throws(()=>ImportLink.Parse(link),"invalid import URL rejected: "+link);

object Item(int i)=>new{id=i.ToString().PadLeft(22,'0'),uri="spotify:track:"+i.ToString().PadLeft(22,'0'),name="Track "+i,artists=new[]{new{name="Artist A"},new{name="Artist B"}},album=new{images=Array.Empty<object>()},duration_ms=125000};
string Page(IEnumerable<int> entries,int total,string? next=null,bool legacy=false)=>JsonSerializer.Serialize(new{total,next,items=entries.Select(i=>legacy?(object)new{track=Item(i)}:new{item=Item(i)})});
Task<List<Track>> Read(Dictionary<string,string> pages,CancellationToken ct=default)=>SpotifyPlaylistReader.ReadAsync(id,(url,_)=>Task.FromResult(pages[url]),ct);
var start="/playlists/"+id+"/items?limit=50";var path="/playlists/"+id+"/items?offset=50&limit=50";var absolute="https://api.spotify.com/v1"+path;
var pages=new Dictionary<string,string>{{start,Page(Enumerable.Range(0,50),51,absolute)},{path,Page(new[]{50},51)}};
var imported=await Read(pages);Check(imported.Count==51&&imported[50].Title=="Track 50","playlist pagination includes the last page");
Check(imported[0].Artist=="Artist A, Artist B"&&imported[0].Art==null&&imported[0].DurationMs==125000,"multiple artists and absent artwork supported");
Check((await Read(new(){{start,Page(new[]{1},1,legacy:true)}})).Count==1,"legacy track field supported");
Check((await Read(new(){{start,Page(Array.Empty<int>(),0)}})).Count==0,"empty playlist accepted");
await Reject(()=>Read(new(){{start,Page(new[]{0},2)}}),"incomplete playlist rejected");
await Reject(()=>Read(new(){{start,Page(new[]{0},1,absolute)},{path,Page(new[]{1},2)}}),"playlist mutation rejected");
await Reject(()=>Read(new(){{start,Page(new[]{0},2,absolute)},{path,Page(new[]{1},2,absolute)}}),"pagination cycle rejected");
foreach(var next in new[]{"https://evil.test/v1/playlists/"+id+"/items","https://api.spotify.com.evil.test/v1/playlists/"+id+"/items","http://api.spotify.com/v1/playlists/"+id+"/items","https://api.spotify.com/v1/playlists/"+id+"/items-extra","https://api.spotify.com/v1/playlists/other/items","https://api.spotify.com:444/v1/playlists/"+id+"/items"})await Reject(()=>Read(new(){{start,Page(new[]{0},2,next)}}),"foreign or incorrect pagination URL rejected");
await Reject(()=>Read(new(){{start,"{\"total\":1,\"items\":[{\"item\":null}],\"next\":null}"}}),"unavailable track cannot silently disappear");
await Reject(()=>Read(new(){{start,"{\"items\":[],\"next\":null}"}}),"missing total rejected");
await Reject(()=>Read(new(){{start,Page(Array.Empty<int>(),10001)}}),"playlist cap rejected before allocation");
await Reject(()=>Read(new(){{start,Page(new[]{0,1},1)}}),"overfull response rejected");
using(var canceled=new CancellationTokenSource()){canceled.Cancel();await Reject(()=>Read(pages,canceled.Token),"playlist cancellation honored");}
const string stateToken="fixture-unpredictable-state";
Check(OAuthCallback.Parse("GET /callback?code=valid&state="+stateToken+" HTTP/1.1",stateToken).Code=="valid","OAuth valid callback accepted");
Check(OAuthCallback.Parse("GET /callback?state="+stateToken+"&code=ab%2Bcd HTTP/1.0",stateToken).Code=="ab+cd","OAuth query decoding preserves encoded plus");
Check(OAuthCallback.Parse("GET /callback?error=access_denied&state="+stateToken+" HTTP/1.1",stateToken).Error=="access_denied","OAuth denial returned without token exchange");
foreach(var line in new[]{"GET /favicon.ico HTTP/1.1","POST /callback?code=a&state="+stateToken+" HTTP/1.1","GET /callback?code=a&state=wrong HTTP/1.1","GET /callback?code=a HTTP/1.1","GET /callback?state="+stateToken+" HTTP/1.1","GET /callback?state="+stateToken+"&state="+stateToken+"&code=x HTTP/1.1","GET /callback-extra?code=x&state="+stateToken+" HTTP/1.1","GET https://evil.test/callback?code=x&state="+stateToken+" HTTP/1.1","GET /callback?code=&state="+stateToken+" HTTP/1.1"})await Reject(()=>Task.FromResult(OAuthCallback.Parse(line,stateToken)),"invalid OAuth callback rejected");
await LyricsChecks.Run(Check);
await CaptionSearchChecks.Run(Check);
await ReleaseChecks.Run(Check);
await PlaylistWorkflowChecks.Run(Check);
await Regression06Checks.Run(Check);
await Rework07Checks.Run(Check);
await Rework08Checks.Run(Check);
await Rework09Checks.Run(Check);
await Rework10Checks.Run(Check);
await SpicyIntegrationChecks.Run(Check);
await PrefetchChecks.Run(Check);
DesktopChecks.Run(Check);
await DiscordChecks.Run(Check);
await UpdateChecks.Run(Check);
Console.WriteLine($"\n{passed} checks passed.");
