using System.Text.Json;
using GlassPlayer;
using GlassPlayer.Core;

static class RadioTaskbarChecks
{
    static Track Song(int id,string title,string artist="Artist",string source="Spotify",bool available=true)=>new(source=="Spotify"?id.ToString().PadLeft(22,'0'):"sc:"+id,title,artist,null,null,source,source=="Spotify"?"spotify:track:"+id.ToString().PadLeft(22,'0'):"https://soundcloud.com/fixture/track-"+id,180000,Available:available);
    public static async Task Run(Action<bool,string> check)
    {
        var seed=Song(1,"Blue Hour","First Artist");
        var pool=new[]{seed,Song(2,"Blue Hour (Sped Up)"),Song(3,"Blue Hour - Slowed + Reverb"),Song(4,"Blue Hour [Cover]","Cover Artist"),Song(5,"Second Song","First Artist"),Song(6,"Second Song (Remastered)","First Artist"),Song(7,"Another Track","Other Artist"),Song(8,"Last Light","Third Artist"),Song(9,"Unavailable","Fourth",available:false),Song(10,"Other Source","Cloud","SoundCloud")};
        var planner=new RadioPlanner((_,_)=>Task.FromResult<IReadOnlyList<Track>>(Array.Empty<Track>()),(_,_,_)=>Task.FromResult<IReadOnlyList<Track>>(Array.Empty<Track>()),new Random(5));
        var selected=planner.Select(seed,pool,Array.Empty<Track>());
        check(selected.Count==3&&selected.All(t=>t.Id!=seed.Id&&RadioPlanner.Composition(t.Title)!="blue hour"),"radio excludes the chosen song and its sped-up, slowed and cover variations");
        check(selected.Select(t=>RadioPlanner.Composition(t.Title)).Distinct().Count()==selected.Count,"radio keeps a single composition even when remasters have different IDs");
        check(selected.All(t=>t.Source=="Spotify"&&t.Available),"radio preserves the selected provider and skips unavailable audio");
        var varied=Enumerable.Range(20,24).Select(i=>Song(i,"Composition "+i,"Artist "+(i%3))).ToArray();
        selected=planner.Select(seed,varied,Array.Empty<Track>(),20);
        check(selected.Count==20&&selected.Zip(selected.Skip(1)).All(pair=>pair.First.Artist!=pair.Second.Artist),"radio alternates artists rather than exhausting one artist's block");
        check(planner.Select(seed,pool,new[]{pool[4],pool[6]}).All(t=>t.Title=="Last Light"),"recently heard compositions are excluded across different versions");
        check(RadioPlanner.Composition("É Isso (Official Audio)")=="e isso"&&RadioPlanner.Composition("Exit Music (For a Film)")=="exit music for a film","composition matching removes delivery labels while preserving meaningful parentheses");
        check(RadioPlanner.Composition("Эй, я всегда буду один (slowed)")=="эи я всегда буду один","radio matching supports non-Latin names");
        int searches=0;
        var preferred=new RadioPlanner((_,_)=>Task.FromResult<IReadOnlyList<Track>>(varied),(_,_,_)=>{searches++;return Task.FromResult<IReadOnlyList<Track>>(pool);},new Random(2));
        check((await preferred.BuildAsync(seed,Array.Empty<Track>(),pool,CancellationToken.None)).Count==20&&searches==0,"real related-track results are used without extra fallback searches");
        var queries=new List<string>();var fallback=new RadioPlanner((_,_)=>throw new HttpRequestException("Recommendations unavailable"),(source,artist,_)=>{queries.Add(source+"|"+artist);return Task.FromResult<IReadOnlyList<Track>>(varied.Take(4).ToArray());},new Random(3));
        var result=await fallback.BuildAsync(seed,Array.Empty<Track>(),pool,CancellationToken.None);
        check(result.Count>0&&queries.Count<=8&&queries[0]=="Spotify|First Artist","restricted recommendation APIs fall back to a bounded artist/context lookup");
        var offline=new RadioPlanner((_,_)=>throw new HttpRequestException("offline"),(_,_,_)=>throw new HttpRequestException("offline"),new Random(4));
        check((await offline.BuildAsync(seed,Array.Empty<Track>(),pool,CancellationToken.None)).Count==3,"network failure can still continue with playable known tracks");
        using(var cancel=new CancellationTokenSource())
        {
            var release=new TaskCompletionSource<IReadOnlyList<Track>>(TaskCreationOptions.RunContinuationsAsynchronously);
            var slow=new RadioPlanner((_,_)=>release.Task,(_,_,_)=>throw new Exception("Canceled lookup searched again"));
            var pending=slow.BuildAsync(seed,Array.Empty<Track>(),pool,cancel.Token);cancel.Cancel();release.SetResult(varied);
            try{await pending;check(false,"canceled radio lookup");}catch(OperationCanceledException){check(true,"a late radio response after cancellation cannot become a replacement queue");}
        }
        var list=new PlaybackQueue<Track>(new Random(8));list.Start(pool.Take(5),2);check(list.RemainingCount==2,"list look-ahead counts original positions");list.Shuffle=true;check(list.RemainingCount==4,"shuffle look-ahead counts unheard slots");list.Next();check(list.HasPrevious,"shuffle previous remains available regardless of the randomized current index");check(list.RemainingCount==3,"shuffle consumes exactly one look-ahead slot");
        var saved=JsonSerializer.Deserialize<QueueSession>("{\"Queue\":[],\"Index\":0}");check(saved is{Radio:false},"legacy saved queues keep list playback rather than enabling radio");
        var session=new QueueSession(new(){seed,pool[4]},1,true);
        var restored=JsonSerializer.Deserialize<QueueSession>(JsonSerializer.Serialize(session))!;check(restored.Radio&&restored.Index==1&&restored.Queue.SequenceEqual(session.Queue),"radio continuation persists with the exact queue and position");
        var pages=new Queue<IReadOnlyList<Track>>(new[]{new[]{seed},new[]{seed},Enumerable.Range(100,20).Select(i=>Song(i,"Fresh "+i,"New Artist")).ToArray()});
        var paged=new RadioPlanner((_,_)=>Task.FromResult<IReadOnlyList<Track>>(Array.Empty<Track>()),(_,_,_)=>Task.FromResult(pages.Count>0?pages.Dequeue():Array.Empty<Track>()),new Random(4));
        check((await paged.BuildAsync(seed,new[]{seed},Array.Empty<Track>(),default)).Count==20,"duplicate-only initial search pages do not stop radio before later pages are checked");
        var radio=new PlaybackQueue<Track>(new Random(4));radio.Start(new[]{seed},0);radio.Shuffle=true;int generated=1000;bool continued=true;
        for(int i=0;i<1500;i++)
        {
            if(radio.RemainingCount<=4){radio.TrimPlayed(30);radio.Append(Enumerable.Range(generated,20).Select(n=>Song(n,"Unheard "+n,"Artist "+n%7)));generated+=20;}
            if(radio.Next(false)==null){continued=false;break;}
        }
        check(continued&&generated>2400,"continuous shuffled radio advances through 1500 transitions rather than stopping after four");
        check(radio.Items.Count<100&&radio.HasPrevious,"long radio sessions retain bounded queue and usable recent Back history");
        var planned=radio.PeekNext();radio.TrimPlayed(10);check(ReferenceEquals(planned,radio.PeekNext()),"trimming played radio history preserves the reserved next shuffle track");
        var seq=new PlaybackQueue<Track>();seq.Start(Enumerable.Range(1,100).Select(n=>Song(n,"Song "+n)),0);for(int i=0;i<70;i++)seq.Next();var current=seq.Current;var upcoming=seq.PeekNext();seq.TrimPlayed(10);
        check(ReferenceEquals(seq.Current,current)&&ReferenceEquals(seq.PeekNext(),upcoming)&&seq.Items.Count<=41,"sequential radio trimming preserves current and all upcoming tracks");
        using(var metadata=JsonDocument.Parse("{\"artists\":{\"items\":[{\"name\":\"Other\",\"genres\":[\"wrong\"]},{\"name\":\"First Artist\",\"genres\":[\"indie rock\",\"indie rock\",\"alt rock\"]}]}}"))check(RadioDiscovery.Genres(metadata.RootElement,"First Artist").SequenceEqual(new[]{"indie rock","alt rock"}),"genre discovery uses only matching artist metadata and removes duplicates");
        using(var metadata=JsonDocument.Parse("{}"))check(RadioDiscovery.Genres(metadata.RootElement,"First Artist").Length==0,"missing genre metadata safely falls through to artist discovery");
        var queuedTrack=new{name="Native next",id="0000000000000000000300",uri="spotify:track:0000000000000000000300",duration_ms=180000,artists=new[]{new{name="Next artist"}},album=new{name="Album",images=Array.Empty<object>()}};
        using(var native=JsonDocument.Parse(JsonSerializer.Serialize(new{currently_playing=new{id=seed.Id},queue=new[]{queuedTrack}})))check(RadioDiscovery.SpotifyQueue(native.RootElement,seed).Single().Title=="Native next","native Spotify queue is accepted only for the exact selected playing song");
        using(var other=JsonDocument.Parse(JsonSerializer.Serialize(new{currently_playing=new{id="another"},queue=new[]{queuedTrack}})))check(RadioDiscovery.SpotifyQueue(other.RootElement,seed).Count==0,"another device's unrelated Spotify context cannot replace the radio");
        check(planner.Select(seed,varied,Array.Empty<Track>(),20,preserveOrder:true).SequenceEqual(varied.Take(20)),"service-ranked related candidates retain their original order when requested");
        var empty=TaskbarPlayback.Create(null,false,false,false);check(!empty.CanToggle&&!empty.CanPrevious&&!empty.CanNext&&empty.Description=="hyse","taskbar controls are disabled when there is no playable song");
        var playing=TaskbarPlayback.Create(seed,true,true,true);check(playing.Playing&&playing.ToggleLabel=="Pausar"&&playing.CanPrevious&&playing.CanNext&&playing.Description=="Blue Hour · First Artist","taskbar playback exposes pause, navigation and current metadata");
        var paused=TaskbarPlayback.Create(seed,false,false,true);check(!paused.Playing&&paused.ToggleLabel=="Reproduzir"&&paused.CanToggle&&!paused.CanPrevious&&paused.CanNext,"taskbar pause changes only the toggle icon and label");
        check(!TaskbarPlayback.Create(seed,true,true,true,true).CanToggle&&!TaskbarPlayback.Create(pool[8],false,true,true).CanNext,"taskbar state honors busy and unavailable tracks");
        string sc="{\"collection\":[{\"id\":123,\"title\":\"Related\",\"kind\":\"track\",\"permalink_url\":\"https://soundcloud.com/artist/related\",\"duration\":120000,\"user\":{\"username\":\"Artist\"}}],\"next_href\":\"https://api-v2.soundcloud.com/tracks/111/related?offset=30\"}";
        check(SoundCloudCatalog.ParseRelated(sc).Single().Id=="sc:123","SoundCloud related tracks parse their own pagination without the search pagination contract");
    }
}
