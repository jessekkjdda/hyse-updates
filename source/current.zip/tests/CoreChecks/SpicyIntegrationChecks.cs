using System.Net;
using System.Text.Json;
using GlassPlayer;
using GlassPlayer.Core;

static class SpicyIntegrationChecks
{
    public static async Task Run(Action<bool,string> check)
    {
        const string id="0000000000000000000013";
        const string xml="<tt xmlns='http://www.w3.org/ns/ttml' xmlns:itunes='http://music.apple.com/lyric-ttml-internal' itunes:timing='Word'><body><div><p begin='1s' end='1s'><span begin='1s' end='2s'>Slow</span> <span begin='4s' end='5s'>finish</span></p><p begin='8s' end='10s'><span begin='8s' end='9s'>Second</span> <span begin='9s' end='10s'>verse</span></p></div></body></tt>";
        var track=new Track(id,"Local parser fixture","Fixture artist",null,null,"Spotify","spotify:track:"+id,12000);
        var handler=new Handler(JsonSerializer.Serialize(new{data=new{spotifyIds=new[]{id},format="ttml",lyrics=xml}}));
        using var http=new HttpClient(handler);
        using var provider=new WordLyricsProvider(http);
        var document=await provider.GetAsync(track,default);
        check(document?.SpicyTtml==xml,"production provider retains the original TTML bytes for Spicy local processing");
        check(handler.Calls==1&&handler.LastHost=="api.amll.dev","native TTML lookup still uses only the existing AMLL source, without a Spicy account or key");
        check(document!.Lines[0].Words==null&&document.Lines[1].Words?.Count==2,"fixture exposes a collapsed paragraph alongside valid native word timing");
        var options=new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase};
        string serialized=JsonSerializer.Serialize(document,options);
        using(var json=JsonDocument.Parse(serialized))
            check(json.RootElement.GetProperty("spicyTtml").GetString()==xml&&json.RootElement.GetProperty("source").GetString()=="AMLL TTML","WebView serialization includes native TTML and preserves its actual provider");
        var original=new LyricsDocument("Old song","Artist",new(){new(1000,"A line",8000)},null,false,"LRCLIB");
        check(!JsonSerializer.Serialize(original,options).Contains("spicyTtml"),"non-TTML documents do not gain a null payload or change their wire format");
        check(JsonSerializer.Deserialize<LyricsDocument>(JsonSerializer.Serialize(original))?.SpicyTtml==null,"older documents without native XML remain compatible");
        var folder=Path.Combine(Path.GetTempPath(),"cncx-spicy-"+Guid.NewGuid().ToString("N"));
        try
        {
            using var service=new LyricsService(cachePath:folder,requestSpacing:TimeSpan.Zero);
            var imported=document with{Source="Arquivo local"};
            await service.SaveOverrideAsync(track,imported,default);
            var restored=await service.GetAsync(track,default);
            check(restored?.SpicyTtml==xml&&restored.Source=="Arquivo local","local imported TTML survives save and reload with exact XML and override priority");
        }
        finally{if(Directory.Exists(folder))Directory.Delete(folder,true);}
        var output=Environment.GetEnvironmentVariable("CNCX_SPICY_FIXTURE_OUTPUT");
        if(!string.IsNullOrWhiteSpace(output))
        {
            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(output))!);
            await File.WriteAllTextAsync(output,serialized);
        }
    }
    sealed class Handler(string response):HttpMessageHandler
    {
        public int Calls{get;private set;}
        public string? LastHost{get;private set;}
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();Calls++;LastHost=request.RequestUri?.Host;
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK){Content=new StringContent(response)});
        }
    }
}
