using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using GlassPlayer.Core;

static class UpdateChecks
{
    public static async Task Run(Action<bool,string> check)
    {
        using var signer=RSA.Create(3072);string key=signer.ExportSubjectPublicKeyInfoPem();
        byte[] payload=new byte[16384];Random.Shared.NextBytes(payload);payload[0]=(byte)'M';payload[1]=(byte)'Z';
        var manifest=new UpdateManifest(1,"hyse","windows-x64","0.14.0",UpdateTrust.Repository+"/releases/download/v0.14.0/hyse-0.14.0-Setup.exe",payload.Length,Convert.ToHexString(SHA256.HashData(payload)).ToLowerInvariant());
        byte[] Bytes(UpdateManifest m)=>JsonSerializer.SerializeToUtf8Bytes(m,new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.CamelCase});
        byte[] Sign(byte[] b)=>signer.SignData(b,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
        byte[] raw=Bytes(manifest),signature=Sign(raw);
        async Task Reject(Func<Task> run,string name){try{await run();}catch(Exception ex)when(ex is CryptographicException or FormatException or IOException or OperationCanceledException or HttpRequestException){check(true,name);return;}throw new Exception("FAIL: "+name);}
        Task Verify(UpdateManifest m){var b=Bytes(m);UpdateVerification.Verify(b,Sign(b),key);return Task.CompletedTask;}
        check(UpdateVerification.Verify(raw,signature,key)==manifest,"updater verifies actual RSA signature and all signed manifest values");
        byte[] changed=(byte[])raw.Clone();changed[10]^=1;
        await Reject(()=>Task.FromResult(UpdateVerification.Verify(changed,signature,key)),"changed manifest fails signature verification");
        using(var foreign=RSA.Create(3072))await Reject(()=>Task.FromResult(UpdateVerification.Verify(raw,foreign.SignData(raw,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1),key)),"foreign signing key cannot publish updates");
        foreach(var bad in new[]{manifest with{Schema=2},manifest with{Product="other"},manifest with{Platform="linux-x64"},manifest with{SizeBytes=0},manifest with{SizeBytes=UpdateVerification.InstallerLimit+1},manifest with{Sha256="nope"},manifest with{DownloadUrl=manifest.DownloadUrl.Replace("github.com","evil.test")},manifest with{DownloadUrl=manifest.DownloadUrl.Replace("https:","http:")},manifest with{DownloadUrl=manifest.DownloadUrl+"?redirect=other"},manifest with{DownloadUrl=manifest.DownloadUrl.Replace("hyse-updates","other-repo")},manifest with{Version="0.14.0-beta"}})
            await Reject(()=>Verify(bad),"invalid signed update rejected: "+JsonSerializer.Serialize(bad));
        byte[] duplicate=Encoding.UTF8.GetBytes(Encoding.UTF8.GetString(raw).Replace("\"schema\":1","\"schema\":1,\"schema\":1"));
        await Reject(()=>Task.FromResult(UpdateVerification.Verify(duplicate,Sign(duplicate),key)),"duplicate signed JSON fields are rejected");
        foreach(string bad in new[]{"1.2","01.2.3","1.2.3.4","1.2.3-beta","1.2.-3","999999.1.1","../../../tmp","1.2.3\n"})await Reject(()=>Task.FromResult(UpdateVerification.ParseVersion(bad)),"version and cache path validated: "+bad);
        check(UpdateVerification.ParseVersion("0.14.0")>UpdateVerification.ParseVersion("0.9.99"),"versions compare numerically");
        foreach(string url in new[]{"http://github.com/jessekkjdda/hyse-updates/releases/", "https://github.com/another/releases/", "https://release-assets.githubusercontent.com.evil.test/a", "https://user:password@release-assets.githubusercontent.com/a", "https://release-assets.githubusercontent.com:444/a", "file:///tmp/update.exe"})check(!UpdateVerification.RedirectAllowed(new(url)),"untrusted redirect rejected: "+url);
        check(UpdateVerification.RedirectAllowed(new("https://release-assets.githubusercontent.com/github-production-release-asset/a?signature=test")),"official GitHub release CDN is accepted");
        string temp=Path.Combine(Path.GetTempPath(),"hyse-update-check-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(temp);
        try
        {
            var handler=new FixtureHandler(raw,signature,payload);using var client=new UpdateClient(handler,key);var progress=new List<int>();
            var ready=await client.CheckAndDownloadAsync("0.13.0",temp,(_,percent)=>progress.Add(percent),CancellationToken.None);
            check(ready!=null&&File.ReadAllBytes(ready.InstallerPath).SequenceEqual(payload),"verified installer is downloaded byte for byte");
            check(progress.Count>0&&progress.Last()==100&&!Directory.GetFiles(temp,"*.part",SearchOption.AllDirectories).Any(),"download progress finishes at 100 with no partial file");
            check(File.ReadAllBytes(Path.Combine(ready!.DirectoryPath,"hyse-update.json")).SequenceEqual(raw)&&File.ReadAllBytes(Path.Combine(ready.DirectoryPath,"hyse-update.sig")).SequenceEqual(signature),"raw signed bytes are preserved for independent helper validation");
            int downloads=handler.PayloadRequests;await client.CheckAndDownloadAsync("0.13.0",temp,null,CancellationToken.None);check(handler.PayloadRequests==downloads,"valid cached installer is rehashed and reused");
            await File.WriteAllBytesAsync(ready.InstallerPath,new byte[payload.Length]);await client.CheckAndDownloadAsync("0.13.0",temp,null,CancellationToken.None);check(handler.PayloadRequests==downloads+1,"corrupt cache is replaced with a freshly verified download");
            check(await client.CheckAndDownloadAsync("0.14.0",temp,null,CancellationToken.None)==null&&await client.CheckAndDownloadAsync("0.15.0",temp,null,CancellationToken.None)==null,"equal and older versions are never installed");
            using(var canceled=new CancellationTokenSource()){canceled.Cancel();await Reject(()=>client.CheckAndDownloadAsync("0.13.0",temp,null,canceled.Token),"canceled check never produces an update");}
            foreach(string mode in new[]{"tamper","short","oversize","redirect","loop","offline","bad-signature"})
            {
                string cache=Path.Combine(temp,mode);using var badClient=new UpdateClient(new FixtureHandler(raw,signature,payload){Mode=mode},key);
                await Reject(()=>badClient.CheckAndDownloadAsync("0.13.0",cache,null,CancellationToken.None),"download failure cannot become ready: "+mode);
                check(!Directory.Exists(cache)||!Directory.GetFiles(cache,"*.exe",SearchOption.AllDirectories).Any()&&!Directory.GetFiles(cache,"*.part",SearchOption.AllDirectories).Any(),"failed download leaves no executable or partial: "+mode);
            }
            var retry=new FixtureHandler(raw,signature,payload){Mode="offline"};using(var retryClient=new UpdateClient(retry,key))
            {
                string cache=Path.Combine(temp,"retry");await Reject(()=>retryClient.CheckAndDownloadAsync("0.13.0",cache,null,CancellationToken.None),"offline error is surfaced");retry.Mode="good";
                check(await retryClient.CheckAndDownloadAsync("0.13.0",cache,null,CancellationToken.None)!=null,"next check recovers after network failure");
            }
            var plan=new UpdatePlan(123,456,"C:\\Users\\Person\\AppData\\Local\\Programs\\hyse","0.13.0",true);UpdateHandoff.WritePlan(temp,plan);
            check(JsonSerializer.Deserialize<UpdatePlan>(File.ReadAllText(Path.Combine(temp,"apply.json")))==plan&&!File.Exists(Path.Combine(temp,"apply.json.tmp")),"helper plan is atomically written with parent identity and explicit restart intent");
        }
        finally{Directory.Delete(temp,true);}
        foreach(bool exit in new[]{false,true})foreach(bool session in new[]{false,true})foreach(bool automatic in new[]{false,true})foreach(bool ready in new[]{false,true})
            check(UpdateHandoff.ApplyOnExit(exit,session,automatic,ready)==(exit&&!session&&automatic&&ready),$"updates apply only on actual exit: exit={exit}, shutdown={session}, automatic={automatic}, ready={ready}");
    }
    sealed class FixtureHandler(byte[] manifest,byte[] signature,byte[] installer):HttpMessageHandler
    {
        public string Mode="good";
        public int PayloadRequests;
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();if(Mode=="offline")return Task.FromResult(new HttpResponseMessage(HttpStatusCode.ServiceUnavailable));
            string path=request.RequestUri!.AbsolutePath;
            if(path.EndsWith(".json"))return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK){Content=new ByteArrayContent(manifest)});
            if(path.EndsWith(".sig"))return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK){Content=new ByteArrayContent(Mode=="bad-signature"?new byte[384]:signature)});
            PayloadRequests++;
            if(Mode is "redirect" or "loop")
            {
                var r=new HttpResponseMessage(HttpStatusCode.Found);r.Headers.Location=new(Mode=="redirect"?"https://evil.test/update.exe":request.RequestUri.AbsoluteUri);return Task.FromResult(r);
            }
            var bytes=(byte[])installer.Clone();if(Mode=="tamper")bytes[^1]^=1;if(Mode=="short")Array.Resize(ref bytes,bytes.Length-1);if(Mode=="oversize")Array.Resize(ref bytes,bytes.Length+1);
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK){Content=new UnknownLengthContent(bytes)});
        }
    }
    sealed class UnknownLengthContent(byte[] bytes):HttpContent
    {
        protected override bool TryComputeLength(out long length){length=0;return false;}
        protected override Task SerializeToStreamAsync(Stream stream,System.Net.TransportContext? context)=>stream.WriteAsync(bytes).AsTask();
    }
}
