using System.Net;
using System.Text.Json;
using GlassPlayer;
using GlassPlayer.Core;
static class Rework08Checks
{
    public static async Task Run(Action<bool,string> check)
    {
        var tracks=Enumerable.Range(1,378).Select(i=>new Track(i.ToString().PadLeft(22,'0'),"Track "+i,"Artist",null,null,"Spotify","spotify:track:"+i.ToString().PadLeft(22,'0'),100000)).ToList();
        tracks[23]=tracks[22];var scan=new PlaylistScan(378);
        // Deliberately overlapping and out of order, like a virtualized page.
        for(int start=350;start>=0;start-=25)scan.Add(tracks.Skip(start).Take(35).Select((t,i)=>new PlaylistScanItem(start+i+1,t)));
        scan.Add(tracks.Take(30).Select((t,i)=>new PlaylistScanItem(i+1,t)));
        check(scan.Complete&&scan.Finish().Count==378,"session reader reconstructs all 378 indexed playlist occurrences from overlapping virtual pages");
        check(scan.Finish()[22].OpenUri==scan.Finish()[23].OpenUri,"duplicate songs retain separate positions in the imported playlist");
        var incomplete=new PlaylistScan(4);incomplete.Add(new[]{new PlaylistScanItem(1,tracks[0]),new PlaylistScanItem(3,tracks[2]),new PlaylistScanItem(4,tracks[3])});bool rejected=false;
        try{incomplete.Finish();}catch(FormatException){rejected=true;}check(rejected&&!incomplete.Complete,"a missing middle row cannot be declared a complete session import");
        rejected=false;try{scan.Add(new[]{new PlaylistScanItem(1,tracks[9])});}catch(FormatException){rejected=true;}check(rejected,"playlist mutation at an already scanned position stops the import");
        rejected=false;try{incomplete.Add(new[]{new PlaylistScanItem(5,tracks[0])});}catch(FormatException){rejected=true;}check(rejected,"session positions beyond the confirmed count are rejected");
        var unknown=new PlaylistScan(0);unknown.Add(new[]{new PlaylistScanItem(1,tracks[0])});check(!unknown.Complete,"unknown total is never inferred from one visible page");unknown.SetExpectedCount(1);check(unknown.Complete,"a trusted total can complete an initially unknown scan");
        rejected=false;try{unknown.SetExpectedCount(2);}catch(FormatException){rejected=true;}check(rejected,"changing a confirmed total cannot silently truncate a playlist");
        const string id="0000000000000000000008";
        var known=new LibraryPlaylist(id,"Saved","",null,"owner","Owner",false,false,2,null);
        string Html(int count=2,string? identity=null,int? total=null,int? status=null)
        {
            var entity=new Dictionary<string,object?>{{"uri","spotify:playlist:"+(identity??id)},{"name","Public example"},{"subtitle","Owner"},{"trackList",Enumerable.Range(1,count).Select(i=>new{uri="spotify:track:"+i.ToString().PadLeft(22,'0'),title="Song "+i,subtitle="Artist",duration=123000,isPlayable=true}).ToArray()}};
            if(total!=null)entity["totalCount"]=total;
            var props=new Dictionary<string,object?>{{"state",new{data=new{entity}}}};if(status!=null)props["status"]=status;
            return "<html><script type='application/json' id='__NEXT_DATA__'>"+JsonSerializer.Serialize(new{props=new{pageProps=props}})+"</script></html>";
        }
        var publicContent=SpotifyPublicPlaylistReader.Parse(id,Html(),known);
        check(publicContent.Tracks.Count==2&&publicContent.ReadOnly&&publicContent.Access=="public","public fallback opens matching Spotify tracks and keeps API editing disabled");
        check(publicContent.Tracks[0].OpenUri=="spotify:track:0000000000000000000001"&&publicContent.Tracks[0].DurationMs==123000,"public fallback keeps exact Spotify identities and millisecond durations");
        rejected=false;try{SpotifyPublicPlaylistReader.Parse(id,Html(1),known);}catch(FormatException){rejected=true;}check(rejected,"public fallback rejects a truncated list against the account's full count");
        rejected=false;try{SpotifyPublicPlaylistReader.Parse(id,Html(100));}catch(FormatException){rejected=true;}check(rejected,"public embed limits never masquerade as a full large playlist");
        rejected=false;try{SpotifyPublicPlaylistReader.Parse(id,Html(identity:"0000000000000000000009"),known);}catch(FormatException){rejected=true;}check(rejected,"public reader validates playlist identity before accepting track data");
        rejected=false;try{SpotifyPublicPlaylistReader.Parse(id,Html(status:404),known);}catch(HttpRequestException ex){rejected=ex.StatusCode==HttpStatusCode.NotFound;}check(rejected,"private or missing public playlist remains an access error rather than an empty result");
        rejected=false;try{SpotifyPublicPlaylistReader.Parse(id,new string('x',4*1024*1024+1));}catch(FormatException){rejected=true;}check(rejected,"public HTML input is bounded before parsing");
        var directory=Path.Combine(Path.GetTempPath(),"cncx-lyrics08-"+Guid.NewGuid().ToString("N"));
        try
        {
            const string yaml="lines:\n  - {text: 'Fast words together', start_ms: 1000, end_ms: 9000}";
            var record=new{trackName="Fixture",artistName="Artist",duration=120,instrumental=false,syncedLyrics="[00:01.000]Fast\n[00:01.250]words\n[00:01.500]together",plainLyrics="Fast words together",lyricsfile=yaml};
            using var http=new HttpClient(new Handler(JsonSerializer.Serialize(record)));using var service=new LyricsService(http,directory,TimeSpan.Zero);
            var document=await service.GetAsync(new("fixture","Fixture","Artist",null,null,"Spotify",null,120000),default);
            check(document?.Lines.Count==3&&document.Lines[1].TimeMs==1250,"alternate Lyricsfile grouping cannot hold fast LRC phrases inside one long line");
        }
        finally{if(Directory.Exists(directory))Directory.Delete(directory,true);}
        if(Environment.GetEnvironmentVariable("CNCX_LIVE_PUBLIC")=="1")
        {
            using var http=new HttpClient{Timeout=TimeSpan.FromSeconds(20)};var reader=new SpotifyPublicPlaylistReader(http);
            var content=await reader.ReadAsync("3cEYpjA9oz9GiPac4AsH4n",null,default);
            check(content.ReadOnly&&content.Tracks.Count>0&&content.Playlist.Id=="3cEYpjA9oz9GiPac4AsH4n","live public Spotify example loads through the production fallback without an API token");
        }
    }
    sealed class Handler(string body):HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token)=>Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK){Content=new StringContent(body,System.Text.Encoding.UTF8,"application/json")});
    }
}
