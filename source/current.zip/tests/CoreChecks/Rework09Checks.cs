using System.Net;
using System.Text.Json;
using GlassPlayer;
using GlassPlayer.Core;
static class Rework09Checks
{
    public static async Task Run(Action<bool,string> check)
    {
        var gate=new SilenceGate();double now=0;string track="one";bool enabled=true,local=true,measured=true,muted=false,playing=true,ended=false,fresh=true;double volume=.8;
        bool Sample(double peak,double after=0){now+=after;return gate.Observe(track,enabled,local,measured,peak,muted,volume,playing,ended,fresh,now);}
        check(!Sample(0,2000)&&!Sample(0,1000),"a silent or missing stream before any audible audio cannot activate the highlight");
        check(!Sample(.2)&&!Sample(0)&&!Sample(0,649)&&Sample(0,1),"real silence must persist 650ms after audible playback");
        check(gate.QuietStartedAt==3000,"measured silence retains its original onset instead of the confirmation time");
        check(!Sample(.002)&&!Sample(.002,2000),"instrumental audio immediately cancels the silence hold");
        check(gate.QuietStartedAt==null,"audible instrumental clears the held silence onset");
        Sample(0);muted=true;check(!Sample(0,1000),"system or session mute never counts as musical silence");muted=false;Sample(0);volume=0;check(!Sample(0,1000),"app volume zero never counts as silence");volume=.8;
        Sample(.2);Sample(0);local=false;check(!Sample(0,1000),"remote Spotify Connect cannot claim silence from a local meter");local=true;
        measured=false;check(!Sample(0,1000),"unavailable audio sessions never invent a silence measurement");measured=true;
        fresh=false;check(!Sample(0,1000),"stale or stalled playback cannot activate silence");fresh=true;
        playing=false;check(!Sample(0,1000),"manual pause never activates the hold");playing=true;Sample(.2);Sample(0);playing=false;ended=true;check(Sample(0,650),"a naturally completed track may retain its last audible word");
        track="two";check(!Sample(0,1000),"track replacement clears prior audio evidence");ended=false;playing=true;Sample(.3);Sample(0);enabled=false;check(!Sample(0,1000),"the setting disables the measured-silence behavior");enabled=true;
        check(!Sample(double.NaN),"invalid meter values cannot activate silence");volume=double.NaN;check(!Sample(0,1000),"invalid volume values fail closed");
        const string id="0000000000000000000001";
        var sp=CatalogReader.Spotify(JsonSerializer.Serialize(new{
            tracks=new{next="https://api.spotify.com/v1/search?offset=10",items=new[]{new{id,uri="spotify:track:"+id,name="Dark Red",artists=new[]{new{name="Steve Lacy"}},duration_ms=180000}}},
            artists=new{items=new object?[]{null,new{id,name="Steve Lacy",images=Array.Empty<object>()}}},
            albums=new{items=new[]{new{id,name="Demo",total_tracks="unexpected",artists=new[]{new{name="Steve Lacy"}}}}},
            playlists=new{items=new[]{new{id,name="Favoritas",owner=new{display_name="xy"},tracks=new{total=42}}}}
        }),0);
        check(sp.Tracks.Count==1&&sp.Entities.Count==3&&sp.NextOffset==10,"Spotify search parses tracks, artists, albums and playlists with independent pagination");
        check(sp.Entities.Single(e=>e.Kind=="playlist").Count==42&&sp.Entities.Single(e=>e.Kind=="album").Count==0,"sparse and malformed optional catalog counts do not break all search results");
        check(CatalogReader.Spotlight("Dark Red",sp.Tracks,sp.Entities)?.Track?.Title=="Dark Red","relevance selects an exact song as the search highlight");
        check(CatalogReader.Spotlight("Steve Lacy",sp.Tracks,sp.Entities)?.Entity?.Kind=="artist","an exact artist can be the prominent search result");
        check(CatalogReader.Spotlight("totally unrelated",sp.Tracks,sp.Entities)==null,"unrelated entries do not become a misleading highlight");
        check(CatalogReader.Score("acucar","Açúcar","")>CatalogReader.Score("acucar","Other",""),"catalog ranking normalizes accents without changing displayed text");
        object Song(long n,string policy="ALLOW")=>new{kind="track",id=n,title="Sound "+n,permalink_url="https://soundcloud.com/fixture/sound-"+n,duration=190000,artwork_url="https://i1.sndcdn.com/test-large.jpg",streamable=true,policy,user=new{username="Creator"},publisher_metadata=new{artist="Singer"}};
        object Playlist(object[] songs,int count)=>new{kind="playlist",id=99,title="SC list",permalink_url="https://soundcloud.com/fixture/sets/list",track_count=count,tracks=songs,user=new{username="Creator"}};
        var scJson=JsonSerializer.Serialize(new{collection=new[]{Song(1),Song(2,"SNIP"),(object)new{kind="user",id=7,username="Creator",permalink_url="https://soundcloud.com/fixture"},Playlist(Array.Empty<object>(),0)},next_href="https://api-v2.soundcloud.com/search?q=test&offset=opaque%3A20&client_id=ignored"});
        var sc=SoundCloudCatalog.ParseSearch(scJson);
        check(sc.Tracks.Count==2&&sc.Entities.Count==2&&sc.NextCursor=="opaque:20","SoundCloud mixed search preserves category metadata and an opaque next cursor");
        check(sc.Tracks[0].Artist=="Singer"&&sc.Tracks[0].Art!.EndsWith("-t500x500.jpg")&&!sc.Tracks[1].Available,"SoundCloud publisher metadata, artwork and preview restrictions are respected");
        check(MediaIdentity.Supported(sc.Tracks[0])&&MediaIdentity.Supported(sp.Tracks[0]),"mixed-provider queues use valid canonical identities");
        foreach(var url in new[]{"http://soundcloud.com/a/b","https://soundcloud.com.evil.test/a/b","https://user:pass@soundcloud.com/a/b","https://soundcloud.com:444/a/b","file:///etc/passwd"}){bool bad=false;try{SoundCloudCatalog.PublicUrl(url);}catch(ArgumentException){bad=true;}check(bad,"invalid SoundCloud link rejected: "+url);}
        check(SoundCloudCatalog.PublicUrl("https://www.soundcloud.com/a/b?si=abc")=="https://soundcloud.com/a/b","SoundCloud identities strip tracking without losing the public track path");
        bool rejected=false;try{SoundCloudCatalog.ParseSearch(scJson.Replace("https://api-v2.soundcloud.com/search","https://evil.test/search"));}catch(FormatException){rejected=true;}check(rejected,"foreign SoundCloud pagination cannot be followed");
        int apiCalls=0;bool partial=false;
        using(var http=new HttpClient(new Handler(request=>{
            var url=request.RequestUri!;
            if(url.Host=="soundcloud.com")return "<script src=\"https://a-v2.sndcdn.com/assets/test.js\"></script>";
            if(url.Host=="a-v2.sndcdn.com")return "client_id:\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"";
            apiCalls++;
            return url.AbsolutePath=="/tracks"?JsonSerializer.Serialize(new[]{Song(2)}):JsonSerializer.Serialize(Playlist(new[]{Song(1),(object)new{id=2},Song(1)},partial?4:3));
        })))
        using(var catalog=new SoundCloudCatalog(http))
        {
            var list=await catalog.ResolveAsync("https://soundcloud.com/fixture/sets/list",default);
            check(list.Tracks.Count==3&&list.Tracks[0].Id==list.Tracks[2].Id&&list.Tracks[1].Id=="sc:2"&&apiCalls==2,"SoundCloud playlist hydration preserves duplicate occurrences and fetches missing tracks");
            partial=true;rejected=false;try{await catalog.ResolveAsync("https://soundcloud.com/fixture/sets/list",default);}catch(FormatException){rejected=true;}check(rejected,"partial SoundCloud playlists remain explicit failures");
        }
        int discoveries=0,tries=0;
        using(var http=new HttpClient(new StatusHandler(request=>{
            string host=request.RequestUri!.Host;
            if(host=="soundcloud.com"){discoveries++;return Reply("<script src=\"https://a-v2.sndcdn.com/assets/test.js\"></script>");}
            if(host=="a-v2.sndcdn.com")return Reply("client_id:\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
            if(++tries==1)return new(HttpStatusCode.Unauthorized){Content=new StringContent("expired")};
            return Reply(scJson);
        })))
        using(var catalog=new SoundCloudCatalog(http))
        {var page=await catalog.SearchAsync("test","0",default);check(page.Tracks.Count==2&&tries==2&&discoveries==2,"an expired public SoundCloud client id is refreshed once before retrying");}
        int limited=0;
        using(var http=new HttpClient(new StatusHandler(request=>{
            if(request.RequestUri!.Host=="soundcloud.com")return Reply("<script src=\"https://a-v2.sndcdn.com/assets/test.js\"></script>");
            if(request.RequestUri.Host=="a-v2.sndcdn.com")return Reply("client_id:\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"");
            limited++;return new(HttpStatusCode.TooManyRequests){Content=new StringContent("busy")};
        })))
        using(var catalog=new SoundCloudCatalog(http))
        {
            int failures=0;for(int i=0;i<2;i++)try{await catalog.SearchAsync("test","0",default);}catch(HttpRequestException ex)when(ex.StatusCode==HttpStatusCode.TooManyRequests){failures++;}
            check(failures==2&&limited==1,"SoundCloud rate limits prevent an immediate repeated network request");
            using var cancel=new CancellationTokenSource();cancel.Cancel();bool aborted=false;try{await catalog.SearchAsync("test","0",cancel.Token);}catch(OperationCanceledException){aborted=true;}check(aborted&&limited==1,"cancelled catalog work never starts an HTTP request");
        }
        var dir=Path.Combine(Path.GetTempPath(),"cncx09-"+Guid.NewGuid().ToString("N"));
        try{var store=new LocalPlaylistStore(Path.Combine(dir,"mixed.json"));store.Load();var list=store.Create("Mixed","");store.Add(list.Id,sp.Tracks[0]);store.Add(list.Id,sc.Tracks[0]);var restored=new LocalPlaylistStore(Path.Combine(dir,"mixed.json"));restored.Load();check(restored.Open(list.Id).Tracks.Select(t=>t.Source).SequenceEqual(new[]{"Spotify","SoundCloud"}),"local playlist persistence restores Spotify and SoundCloud together");}
        finally{if(Directory.Exists(dir))Directory.Delete(dir,true);}
        if(Environment.GetEnvironmentVariable("CNCX_LIVE_SOUNDCLOUD")=="1")
        {
            using var live=new SoundCloudCatalog();var page=await live.SearchAsync("Steve Lacy Dark Red","0",default);var song=page.Tracks.First(t=>t.Available);
            var resolved=await live.ResolveAsync(song.OpenUri!,default);
            check(page.Tracks.Count>0&&resolved.Tracks.Single().Id==song.Id,"live SoundCloud production catalog searches and resolves the same playable public track");
        }
    }
    static HttpResponseMessage Reply(string body)=>new(HttpStatusCode.OK){Content=new StringContent(body)};
    sealed class StatusHandler(Func<HttpRequestMessage,HttpResponseMessage> response):HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token){token.ThrowIfCancellationRequested();return Task.FromResult(response(request));}
    }
    sealed class Handler(Func<HttpRequestMessage,string> response):HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token){token.ThrowIfCancellationRequested();return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK){Content=new StringContent(response(request))});}
    }
}
