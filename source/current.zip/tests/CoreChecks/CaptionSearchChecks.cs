using System.Diagnostics;
using GlassPlayer;
using GlassPlayer.Core;

static class CaptionSearchChecks
{
    public static Task Run(Action<bool,string> check)
    {
        var glyphs=CaptionTimeline.Build("A é 👩‍💻",1000,5000);
        check(glyphs.Count==5&&glyphs[4].Text=="👩‍💻","caption reveal preserves emoji grapheme clusters");
        check(string.Concat(glyphs.Select(g=>g.Text))=="A é 👩‍💻","caption reveal reproduces the original text");
        var combining=CaptionTimeline.Build("e\u0301",0,2000);check(combining.Count==1,"combining accent is one reveal unit");
        check(glyphs.Where(g=>g.FadeMs>0).Zip(glyphs.Where(g=>g.FadeMs>0).Skip(1)).All(pair=>pair.First.StartMs<=pair.Second.StartMs),"caption characters appear in monotonic order");
        check(glyphs[0].OpacityAt(0)==0&&glyphs[0].OpacityAt(100000)==1,"caption opacity clamps at timeline boundaries");
        check(glyphs[0].OpacityAt(glyphs[0].StartMs+glyphs[0].FadeMs/2) is >.45 and <.55,"caption can resume halfway through a character fade");
        check(glyphs[1].FadeMs==0&&glyphs[1].OpacityAt(0)==1,"spaces do not delay reveal scheduling");
        check(CaptionTimeline.Build("",0,1000).Count==0,"empty caption is supported");
        check(CaptionTimeline.Build(new string('x',5000),0,1000).Count==1,"very long phrases use one bounded fade instead of thousands of animations");
        check(CaptionTimeline.Build("fixture",1000,1000).All(g=>g.FadeMs>=0&&g.StartMs>=1000),"zero-duration phrase is bounded");
        var lines=new[]{new LyricLine(1000,"One"),new LyricLine(5000,"Two")};
        check(CaptionTimeline.EndOfLine(lines,0,9000)==5000&&CaptionTimeline.EndOfLine(lines,1,9000)==9000,"caption duration follows the next phrase or track end");
        check(CaptionTimeline.EndOfLine(lines,1,0)>5000,"last phrase without track duration has a finite fallback");
        var index=new SearchSuggestions(3);
        Track Song(string id,string title,string artist="Performer",string source="Spotify")=>new(id,title,artist,null,null,source,"spotify:track:"+id);
        index.Add(new[]{Song("1","Yellow"),Song("2","Yellow Brick Road"),Song("3","Sparks","Coldplay")});
        check(index.Find("y").Count>=2&&index.Find("y").Any(t=>t.Id=="1")&&index.Find("y").Any(t=>t.Id=="2"),"one letter produces local suggestions immediately");
        check(index.Find("Yellow")[0].Id=="1","exact title ranks above longer prefix matches");
        check(index.Find("Coldplay sparks").Single().Id=="3","query tokens can match both artist and title");
        check(index.Find("missing").Count==0&&index.Find("  ").Count==0,"unmatched and empty queries are deterministic");
        index.Add(new[]{Song("4","Été")});check(index.Find("yellow").All(t=>t.Id!="1"),"suggestion memory is bounded");
        check(index.Find("ete").Single().Id=="4","suggestions normalize accents");
        index.Add(new[]{Song("4","Updated")});check(index.Find("Updated").Count==1&&index.Find("ete").Count==0,"updated tracks replace old metadata without duplicates");
        index.Add(new[]{Song("5","Removed","Other","SoundCloud")});check(index.Find("Removed").Count==0,"suggestion index admits Spotify tracks only");
        var stopwatch=Stopwatch.StartNew();for(int i=0;i<500;i++)index.Find("y");stopwatch.Stop();
        check(stopwatch.Elapsed<TimeSpan.FromSeconds(3),"local suggestion loop stays responsive without network I/O");
        Console.WriteLine($"Local suggestion benchmark: {stopwatch.Elapsed.TotalMilliseconds:F2} ms for 500 small-index lookups (not a Spotify network measurement).");
        return Task.CompletedTask;
    }
}
