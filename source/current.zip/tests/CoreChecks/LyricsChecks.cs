using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using GlassPlayer;
using GlassPlayer.Core;

static class LyricsChecks
{
    public static async Task Run(Action<bool,string> check)
    {
        var lines=LyricsParser.Parse("[ar:Fixture]\n[00:02.50]Second\n[00:01.1][00:03.01]Repeated\n[00:02.50]Duet\n[00:04.001]\n[00:70]Invalid");
        check(lines.Count==4,"LRC multiple timestamps and malformed seconds");
        check(lines[0].TimeMs==1100&&lines[1].TimeMs==2500&&lines[2].TimeMs==3010&&lines[3].TimeMs==4001,"LRC fractions and stable ordering");
        check(lines[1].Text=="Second\nDuet","LRC simultaneous duet lines retained");
        check(LyricsParser.FindLine(lines,1099)==-1&&LyricsParser.FindLine(lines,1100)==0,"no lyric highlighted before its timestamp");
        check(LyricsParser.FindLine(lines,2500)==1&&LyricsParser.FindLine(lines,99999)==3,"seek uses timestamp floor");
        check(LyricsParser.FindLine(lines,2000,500)==1&&LyricsParser.FindLine(lines,2000,-1000)==-1,"live synchronization adjustment in both directions");
        check(LyricsParser.Parse("[offset:500]\n[00:01.00]Fixture")[0].TimeMs==500,"LRC global offset advances the display");
        check(LyricsParser.Parse("[offset:5000]\n[00:01]Fixture")[0].TimeMs==0,"negative adjusted timestamps clamp to zero");
        check(LyricsParser.Parse("ordinary plain text").Count==0&&LyricsParser.FindLine(Array.Empty<LyricLine>(),100)==-1,"plain lyrics do not manufacture timing");
        check(LyricsParser.Parse("[00:01]Olá 世界")[0].Text=="Olá 世界","Unicode lyrics preserved");
        check(LyricsParser.Normalize("Été — D'ÁGUA")=="ete d agua","metadata accent and punctuation matching");
        check(LyricsParser.Compatible("Fixture (Official Audio)","Performer, Guest",120000,"Fixture","Performer",120),"safe metadata normalization");
        check(!LyricsParser.Compatible("Fixture","Performer",120000,"Fixture","Performer",180),"wrong-duration versions rejected");
        check(!LyricsParser.Compatible("Fixture","Performer",120000,"Fixture","Someone Else",120),"wrong artist rejected");
        check(!LyricsParser.Compatible("Fixture (Live)","Performer",120000,"Fixture","Performer",120),"live and studio titles remain distinct");
        bool bounded=false;try{LyricsParser.Parse(new string('x',1024*1024+1));}catch(FormatException){bounded=true;}check(bounded,"oversized lyrics bounded");

        var values=new List<int>();int current=0,max=0;
        using(var writer=new CoalescingWriter<int>(async(value,ct)=>{max=Math.Max(max,Interlocked.Increment(ref current));values.Add(value);await Task.Delay(8,ct);Interlocked.Decrement(ref current);},_=>TimeSpan.FromMilliseconds(12)))
        {
            writer.Submit(1);check(values.Count==1,"volume first value is sent before mouse release");
            for(int i=2;i<=100;i++)writer.Submit(i);
            await writer.WhenIdle;
            check(values.SequenceEqual(new[]{1,100}),"drag values coalesce to latest instead of building a backlog");
            check(max==1,"volume requests never overlap");
            writer.Submit(42);await writer.WhenIdle;check(values[^1]==42,"volume writer restarts after becoming idle");
        }
        bool failed=false;var recovered=new List<int>();
        using(var writer=new CoalescingWriter<int>((value,_)=>{if(value==1)throw new HttpRequestException("fixture failure");recovered.Add(value);return Task.CompletedTask;},_=>TimeSpan.FromMilliseconds(1)))
        {writer.Failed+=_=>failed=true;writer.Submit(1);writer.Submit(2);await writer.WhenIdle;check(failed&&recovered.SequenceEqual(new[]{2}),"volume failure does not permanently jam later updates");}
        var cancelObserved=new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
        var disposable=new CoalescingWriter<int>(async(_,ct)=>{try{await Task.Delay(30000,ct);}catch(OperationCanceledException){cancelObserved.TrySetResult(true);throw;}},_=>TimeSpan.Zero);
        disposable.Submit(1);disposable.Submit(2);disposable.Dispose();await cancelObserved.Task.WaitAsync(TimeSpan.FromSeconds(1));check(cancelObserved.Task.IsCompletedSuccessfully,"closing cancels pending live-volume work");
        var cache=new RecentCache<string>(2,TimeSpan.FromMinutes(1));cache.Set("Spotify:a","one");cache.Set("Spotify:b","two");cache.Set("Spotify:c","three");check(!cache.TryGet("Spotify:a",out _)&&cache.TryGet("Spotify:c",out var cached)&&cached=="three","search cache is bounded");
        check(!cache.TryGet("SoundCloud:c",out _),"search cache separates providers");cache.Clear();check(!cache.TryGet("Spotify:c",out _),"search cache can be invalidated");
        var expired=new RecentCache<int>(2,TimeSpan.Zero);expired.Set("key",1);check(!expired.TryGet("key",out _),"expired results are not reused");

        string temp=Path.Combine(Path.GetTempPath(),"cncx-tests-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(temp);
        try
        {
            var track=new Track("fixture","Fixture","Performer",null,null,"Spotify","spotify:track:0000000000000000000001",120000);
            string Record(string artist="Performer",double duration=120,bool synced=true)=>JsonSerializer.Serialize(new{trackName="Fixture",artistName=artist,duration,instrumental=false,syncedLyrics=synced?"[00:01]Test line":null,plainLyrics="Test line"});
            var handler=new FakeHandler((_,request)=>new(HttpStatusCode.OK){Content=new StringContent(request.RequestUri!.AbsolutePath.EndsWith("/search")?"["+Record()+"]":Record(),Encoding.UTF8,"application/json")});
            using(var client=new LyricsService(new HttpClient(handler),temp,TimeSpan.Zero))
            {
                var found=await client.GetAsync(track,CancellationToken.None);check(found is{Synced:true}&&found.Lines[0].TimeMs==1000,"lyrics response becomes a synchronized document");
                int requests=handler.Count;await client.GetAsync(track,CancellationToken.None);check(handler.Count==requests,"memory cache prevents repeated lyric requests");
            }
            var noNetwork=new FakeHandler((_,_)=>throw new Exception("network should not be called"));
            using(var client=new LyricsService(new HttpClient(noNetwork),temp,TimeSpan.Zero))
            {
                check((await client.GetAsync(track,CancellationToken.None))?.Synced==true&&noNetwork.Count==0,"cached lyrics work offline");
                var custom=new LyricsDocument("Fixture","Performer",new(){new(500,"User line")},null,false,"Arquivo local");await client.SaveOverrideAsync(track,custom,CancellationToken.None);
                check((await client.GetAsync(track,CancellationToken.None))?.Lines[0].TimeMs==500,"user-imported lyrics take precedence and persist");
            }
            var badHandler=new FakeHandler((_,_)=>new(HttpStatusCode.TooManyRequests){Content=new StringContent("busy")});bool busy=false;
            using(var client=new LyricsService(new HttpClient(badHandler),Path.Combine(temp,"limit"),TimeSpan.Zero))try{await client.GetAsync(track,CancellationToken.None);}catch(HttpRequestException ex){busy=ex.Message.Contains("ocupado");}check(busy&&badHandler.Count==1,"rate limits stop requests and produce a clear status");
            var mismatch=new FakeHandler((count,_)=>new(HttpStatusCode.OK){Content=new StringContent(count==1?Record("Other"):"["+Record("Other")+"]",Encoding.UTF8,"application/json")});
            using(var client=new LyricsService(new HttpClient(mismatch),Path.Combine(temp,"wrong"),TimeSpan.Zero))check(await client.GetAsync(track,CancellationToken.None)==null,"wrong-song response is not displayed as a match");
            var plainHandler=new FakeHandler((_,_)=>new(HttpStatusCode.OK){Content=new StringContent(Record(synced:false),Encoding.UTF8,"application/json")});
            using(var client=new LyricsService(new HttpClient(plainHandler),Path.Combine(temp,"plain"),TimeSpan.Zero))check((await client.GetAsync(track,CancellationToken.None)) is{Synced:false,PlainText:"Test line"},"plain lyric fallback is labeled without fake sync");
            using var canceled=new CancellationTokenSource();canceled.Cancel();var counter=new FakeHandler((_,_)=>throw new Exception("must not send"));bool cancellation=false;
            using(var client=new LyricsService(new HttpClient(counter),Path.Combine(temp,"cancel"),TimeSpan.Zero))try{await client.GetAsync(track,canceled.Token);}catch(OperationCanceledException){cancellation=true;}check(cancellation&&counter.Count==0,"canceled old lyric request never reaches the network");
        }
        finally{Directory.Delete(temp,true);}
    }
    sealed class FakeHandler(Func<int,HttpRequestMessage,HttpResponseMessage> response):HttpMessageHandler
    {
        public int Count;
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken cancellationToken){cancellationToken.ThrowIfCancellationRequested();return Task.FromResult(response(++Count,request));}
    }
}
