using GlassPlayer.Core;
using GlassPlayer;

static class PrefetchChecks
{
    public static async Task Run(Action<bool,string> check)
    {
        var queue=new PlaybackQueue<string>(new Random(13));queue.Start(new[]{"a","b","c"},0);
        check(queue.PeekNext()=="b"&&queue.Current=="a"&&queue.Index==0,"look-ahead does not advance playback or queue position");
        check(queue.Next()=="b"&&queue.PeekNext()=="c","next playback agrees with the warmed linear track");queue.Next();
        check(queue.PeekNext()==null,"look-ahead stops at a queue without repeat");queue.Repeat=RepeatMode.All;
        check(queue.PeekNext()=="a"&&queue.Next()=="a","look-ahead wraps with repeat all");queue.Repeat=RepeatMode.One;
        check(queue.PeekNext()=="a"&&queue.PeekNext(true)=="b","natural repeat one keeps the current track while manual skip still looks ahead");
        var shuffle=new PlaybackQueue<string>(new Random(9)){Shuffle=true,Repeat=RepeatMode.All};shuffle.Start(new[]{"a","b","c"},0);
        for(int i=0;i<8;i++){var before=shuffle.Current;var planned=shuffle.PeekNext();check(planned==shuffle.PeekNext()&&shuffle.Current==before&&shuffle.Next()==planned,"shuffled look-ahead is stable and agrees with playback #"+i);}
        shuffle.Clear();check(shuffle.PeekNext()==null,"clearing the queue invalidates the reserved next track");
        var first=new Track("first","First","Artist",null,null,"Spotify","spotify:track:first",30000);
        var second=first with{Id="second"};var warmed=new List<string>();
        using(var prefetch=new LyricsPrefetcher((track,_)=>{warmed.Add(track.Id);return Task.CompletedTask;},TimeSpan.FromMilliseconds(25)))
        {
            prefetch.Schedule(first);prefetch.Schedule(second);await prefetch.WhenIdle;
            check(warmed.SequenceEqual(new[]{"second"}),"rapid changes warm only the latest look-ahead target");
            prefetch.Schedule(second);await prefetch.WhenIdle;check(warmed.Count==1,"repeated scheduling does not refetch a recently warmed target");
            prefetch.Schedule(first);await prefetch.CancelAsync();check(warmed.Count==1,"foreground cancellation waits for the background job to stop");
            prefetch.Schedule(first with{Available=false});await prefetch.WhenIdle;check(warmed.Count==1,"unavailable tracks are never prefetched");
        }
        int calls=0;
        using(var prefetch=new LyricsPrefetcher((_,_)=>{calls++;throw new InvalidOperationException("Fixture outage");},TimeSpan.Zero))
        {prefetch.Schedule(first);await prefetch.WhenIdle;check(calls==1,"optional prefetch errors finish silently without retries or playback failure");}
        bool canceled=false;var started=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        using(var prefetch=new LyricsPrefetcher(async(_,ct)=>{started.SetResult();try{await Task.Delay(10000,ct);}catch(OperationCanceledException){canceled=true;throw;}},TimeSpan.Zero))
        {prefetch.Schedule(first);await started.Task;await prefetch.CancelAsync();check(canceled,"a foreground track change cancels an in-flight source request");}
    }
}
