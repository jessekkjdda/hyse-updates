using System.Net;
using System.Text.Json;
using GlassPlayer.Core;

static class PlaylistWorkflowChecks
{
    const string Existing="0000000000000000000001";
    static string Song(int i)=>"spotify:track:"+i.ToString("D22");
    static object Item(string uri)=>new{uri,name="Song "+uri[^2..],artists=new[]{new{name="Artist"}},album=new{name="Album",images=Array.Empty<object>()},duration_ms=180000};
    public static async Task Run(Action<bool,string> check)
    {
        var server=new Server();var client=new SpotifyLibraryClient(server.Request);
        var found=await client.MineAsync(default);
        check(found.Single().Id==Existing,"existing Spotify playlists are listed before any creation");
        var original=await client.OpenAsync(Existing,default);
        check(original.Tracks.Count==2&&original.Stable,"an existing owned playlist opens with its complete track list");
        var created=await client.CreateAsync("New list","Description",false,default);
        var empty=await client.OpenAsync(created.Id,default);
        check(empty.Tracks.Count==0&&empty.Playlist.Name=="New list","create then open accepts a genuinely empty playlist");
        await client.AddAsync(created.Id,Song(1),default);await client.AddAsync(created.Id,Song(2),default);await client.AddAsync(created.Id,Song(1),default);
        var added=await client.OpenAsync(created.Id,default);
        check(added.Tracks.Select(t=>t.OpenUri).SequenceEqual(new[]{Song(1),Song(2),Song(1)}),"adding tracks preserves duplicate positions on readback");
        await client.MoveAsync(created.Id,2,0,3,added.Playlist.Snapshot,default);
        var moved=await client.OpenAsync(created.Id,default);
        check(moved.Tracks.Select(t=>t.OpenUri).SequenceEqual(new[]{Song(1),Song(1),Song(2)}),"reordering persists after reopening the playlist");
        await client.RemoveAsync(created.Id,Song(1),moved.Playlist.Snapshot,default);
        var removed=await client.OpenAsync(created.Id,default);
        check(removed.Tracks.Count==1&&removed.Tracks[0].OpenUri==Song(2),"removal readback reflects the Spotify URI occurrence semantics");
        await client.UpdateAsync(created.Id,"Renamed","Edited",true,default);
        var edited=await client.OpenAsync(created.Id,default);
        check(edited.Playlist.Name=="Renamed"&&edited.Playlist.Public&&edited.Playlist.Description=="Edited","name, description and privacy persist across playlist reads");
        check((await client.MineAsync(default)).Any(p=>p.Id==created.Id&&p.Name=="Renamed"&&p.Count==1),"created playlists reappear in the account library with their saved metadata");

        string metadata=JsonSerializer.Serialize(new{id=Existing,name="Fixture",owner=new{id="user"},snapshot_id="s1",items=new{total=2}});
        string page=JsonSerializer.Serialize(new{total=2,next=(string?)null,items=new[]{new{item=Item(Song(1))},new{item=Item(Song(2))}}});
        int reads=0;
        var partialFailure=new SpotifyLibraryClient((_,path,_,_)=>
        {
            if(!path.Contains("/items?")&&++reads>1)throw new HttpRequestException("fixture",null,HttpStatusCode.ServiceUnavailable);
            return Task.FromResult(path.Contains("/items?")?page:metadata);
        });
        var readable=await partialFailure.OpenAsync(Existing,default);
        check(readable.Tracks.Count==2&&!readable.Stable&&readable.Notice!=null,"secondary metadata failure keeps loaded songs visible without permitting stale edits");
        int revision=0;
        var changing=new SpotifyLibraryClient((_,path,_,_)=>Task.FromResult(path.Contains("/items?")?page:metadata.Replace("s1","s"+(++revision))));
        var unstable=await changing.OpenAsync(Existing,default);
        check(unstable.Tracks.Count==2&&!unstable.Stable&&revision==4,"continuous concurrent changes have a bounded retry and preserve readable songs");

        var optional=JsonSerializer.SerializeToElement(new{uri=Song(3),name="Minimal",album=(object?)null,artists=(object?)null});
        var minimal=SpotifyPlaylistReader.ToTrack(optional);
        check(minimal.Art==null&&minimal.Artist==""&&minimal.Title=="Minimal","missing optional album and artist fields cannot prevent a playlist opening");
        var legacy=JsonSerializer.SerializeToElement(new{uri=Song(4),name="No images",album=new{name="Album"},artists=new[]{new{name="A"}}});
        check(SpotifyPlaylistReader.ToTrack(legacy).Art==null,"missing album image collections remain valid track metadata");
        string mixed=JsonSerializer.Serialize(new{total=4,next=(string?)null,items=new object[]{new{item=Item(Song(1))},new{item=(object?)null},new{is_local=true,item=new{uri="spotify:local:artist:title",name="Local"}},new{item=new{uri="spotify:episode:"+Existing,name="Episode",type="episode"}}}});
        var mixedTracks=await SpotifyPlaylistReader.ReadAsync(Existing,(_,_)=>Task.FromResult(mixed),allowUnavailable:true);
        check(mixedTracks.Count==4&&mixedTracks.Count(t=>t.Available)==1&&mixedTracks[2].Artist=="Arquivo local"&&mixedTracks[3].Artist=="Episódio","deleted, local and episode entries cannot erase or abort the rest of a playlist");

        string first=JsonSerializer.Serialize(new{total=2,next="https://api.spotify.com/v1/playlists/"+Existing+"/tracks?offset=1&limit=1",items=new[]{new{track=Item(Song(1))}}});
        string second=JsonSerializer.Serialize(new{total=2,next=(string?)null,items=new[]{new{item=Item(Song(2))}}});
        var paths=new List<string>();var progress=new List<int>();
        var pages=await SpotifyPlaylistReader.ReadAsync(Existing,(path,_)=>{paths.Add(path);return Task.FromResult(paths.Count==1?first:second);},progress:(items,_)=>progress.Add(items.Count));
        check(pages.Count==2&&paths[1].EndsWith("/items?offset=1&limit=1"),"legacy Spotify pagination paths normalize to the current items endpoint");
        check(progress.SequenceEqual(new[]{1,2}),"playlist pages are reported progressively instead of waiting for the entire list");
        int embeddedRequests=0;var updates=new List<int>();
        string embedded=JsonSerializer.Serialize(new{id=Existing,name="Embedded",owner=new{id="user"},snapshot_id="s1",items=JsonSerializer.Deserialize<JsonElement>(page)});
        var embeddedClient=new SpotifyLibraryClient((_,_,_,_)=>{embeddedRequests++;return Task.FromResult(embedded);});
        var embeddedContent=await embeddedClient.OpenAsync(Existing,default,content=>updates.Add(content.Tracks.Count));
        check(embeddedContent.Tracks.Count==2&&embeddedRequests==2&&updates.SequenceEqual(new[]{0,2}),"embedded first pages open immediately without an unnecessary items request");

        using var cancel=new CancellationTokenSource();cancel.Cancel();bool canceled=false;
        try{await SpotifyPlaylistReader.ReadAsync(Existing,(_,_)=>throw new Exception("must not fetch"),cancel.Token);}catch(OperationCanceledException){canceled=true;}
        check(canceled,"a canceled playlist selection cannot start another network read");
        bool forbidden=false;var denied=new SpotifyLibraryClient((_,_,_,_)=>throw new HttpRequestException("403 fixture",null,HttpStatusCode.Forbidden));
        try{await denied.OpenAsync(Existing,default);}catch(HttpRequestException ex){forbidden=ex.StatusCode==HttpStatusCode.Forbidden;}
        check(forbidden,"initial access errors propagate to the playlist error panel with their status");

        var openedAgain=await client.OpenAsync(Existing,default);
        check(openedAgain.Tracks.Count==2,"the same playlist can be opened again without relying on a changed selection");
    }
    sealed class Entry(string id,string name)
    {
        public string Id=id,Name=name,Description="";public bool Public;public int Revision=1;
        public List<string> Songs=new();
        public object Metadata()=>new{id=Id,name=Name,description=Description,@public=Public,owner=new{id="user",display_name="User"},images=Array.Empty<object>(),snapshot_id="s"+Revision,items=new{total=Songs.Count}};
    }
    sealed class Server
    {
        readonly Dictionary<string,Entry> lists=new(){{Existing,new(Existing,"Existing"){Songs=new(){Song(10),Song(11)}}}};
        public Task<string> Request(HttpMethod method,string path,object? body,CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();var json=JsonSerializer.SerializeToElement(body);object result;
            if(path=="/me/playlists?limit=50")result=new{items=lists.Values.Select(v=>v.Metadata()).ToArray(),next=(string?)null};
            else if(path=="/me/playlists"&&method==HttpMethod.Post)
            {
                string id=(lists.Count+1).ToString("D22");var entry=new Entry(id,json.GetProperty("name").GetString()!){Description=json.GetProperty("description").GetString()!,Public=json.GetProperty("public").GetBoolean()};lists.Add(id,entry);result=entry.Metadata();
            }
            else
            {
                string id=path.Split('/')[2];var entry=lists[id];
                if(!path.Contains("/items"))
                {
                    if(method==HttpMethod.Put){entry.Name=json.GetProperty("name").GetString()!;entry.Description=json.GetProperty("description").GetString()!;entry.Public=json.GetProperty("public").GetBoolean();entry.Revision++;}
                    result=entry.Metadata();
                }
                else if(method==HttpMethod.Get)result=new{total=entry.Songs.Count,next=(string?)null,items=entry.Songs.Select(uri=>new{item=Item(uri)}).ToArray()};
                else
                {
                    if(method==HttpMethod.Post)entry.Songs.AddRange(json.GetProperty("uris").EnumerateArray().Select(value=>value.GetString()!));
                    else if(method==HttpMethod.Delete){var uris=json.GetProperty("items").EnumerateArray().Select(item=>item.GetProperty("uri").GetString()).ToHashSet();entry.Songs.RemoveAll(uri=>uris.Contains(uri));}
                    else{int from=json.GetProperty("range_start").GetInt32(),before=json.GetProperty("insert_before").GetInt32();string value=entry.Songs[from];entry.Songs.RemoveAt(from);entry.Songs.Insert(before>from?before-1:before,value);}
                    result=new{snapshot_id="s"+(++entry.Revision)};
                }
            }
            return Task.FromResult(JsonSerializer.Serialize(result));
        }
    }
}
