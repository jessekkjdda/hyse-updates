using System.Net;
using System.Text.Json;
using GlassPlayer;
using GlassPlayer.Core;
static class Rework10Checks
{
    public static async Task Run(Action<bool,string> check)
    {
        const string xml="<tt xmlns='http://www.w3.org/ns/ttml' xmlns:ttm='http://www.w3.org/ns/ttml#metadata'><body><div><p begin='00:01.000' end='00:05.000'><span begin='1s' end='2s'>Hello</span> <span begin='4s' end='5s'>world</span><span ttm:role='x-translation'>Tradução</span></p><p begin='9000ms' end='10s'>Return</p></div></body></tt>";
        var parsed=TtmlReader.Parse(xml);check(parsed.Count==2&&parsed[0].Text=="Hello world"&&parsed[0].Words?.Count==2,"TTML preserves main words and whitespace while excluding translation");
        check(parsed[0].Words![1].StartMs==4000&&parsed[0].Words![1].EndMs==5000&&parsed[0].EndMs==5000,"TTML keeps native word starts, ends and vocal gaps in milliseconds");
        check(CaptionTimeline.ActiveLine(parsed,6000)==-1,"TTML explicit end does not light a lyric during an instrumental gap");
        check(TtmlReader.Parse("<tt><p begin='27.173' end='0:29.988'><span begin='27.173' end='28.516'>First </span><span begin='28.516' end='29.988'>word</span></p></tt>")[0].Words![1].StartMs==28516,"TTML supports real AMLL bare-second timestamps alongside clock expressions");
        bool bad=false;try{TtmlReader.Parse("<!DOCTYPE tt [<!ENTITY xxe SYSTEM 'file:///etc/passwd'>]><tt><p begin='1s'>&xxe;</p></tt>");}catch(FormatException){bad=true;}check(bad,"TTML prohibits DTD and external entity resolution");
        bad=false;try{TtmlReader.Parse("<tt><p begin='3s' end='1s'>Bad</p></tt>");}catch(FormatException){bad=true;}check(bad,"TTML rejects a reversed line interval");
        bad=false;try{TtmlReader.Parse(new string('x',1024*1024+1));}catch(FormatException){bad=true;}check(bad,"TTML document allocation is bounded");
        check(TtmlReader.Parse("<tt xmlns:ttm='http://www.w3.org/ns/ttml#metadata'><p begin='1s' end='4s'><span begin='1s' end='2s'>Main</span> <span begin='2s' end='4s'>voice</span><span ttm:role='x-bg'>Background</span></p></tt>")[0].Text=="Main voice","overlapping background vocals do not replace the principal lyric");
        var folder=Path.Combine(Path.GetTempPath(),"cncx-profile10-"+Guid.NewGuid().ToString("N"));
        try
        {
            var store=new PersonalProfileStore(folder);check(store.Load().Name=="","profile starts independently of the Spotify account");store.Save("  Sam  "," My profile ");check(new PersonalProfileStore(folder).Load()==new PersonalProfile("Sam","My profile"),"local app profile persists a trimmed name and biography");
            bad=false;try{store.Save(new string('x',61),"");}catch(ArgumentException){bad=true;}check(bad&&store.Load().Name=="Sam","an invalid profile update preserves the prior saved data");
            var png=new byte[]{137,80,78,71,13,10,26,10,0};store.SetImage("avatar",png);store.SetImage("banner",png);check(store.Image("avatar")!.StartsWith("data:image/png;base64,")&&store.Image("banner")!=null,"profile photo and banner are stored independently");
            bad=false;try{store.SetImage("../settings",png);}catch(ArgumentException){bad=true;}check(bad,"profile asset names cannot escape their dedicated folder");
            bad=false;try{store.SetImage("avatar",new byte[]{1,2});}catch(ArgumentException){bad=true;}check(bad&&store.Image("avatar")!=null,"invalid image bytes do not overwrite the stored profile photo");
            store.SetImage("avatar",null);check(store.Image("avatar")==null&&store.Image("banner")!=null,"removing the photo preserves the banner");
        }
        finally{if(Directory.Exists(folder))Directory.Delete(folder,true);}
        const string id="0000000000000000000010";int calls=0;bool wrong=false;
        using(var http=new HttpClient(new Handler(()=>{calls++;return new(HttpStatusCode.OK){Content=new StringContent(JsonSerializer.Serialize(new{status=200,data=new{spotifyIds=new[]{wrong?"0000000000000000000011":id},format="ttml",lyrics=xml}}))};})))
        using(var provider=new WordLyricsProvider(http))
        {
            var track=new Track(id,"Fixture","Artist",null,null,"Spotify","spotify:track:"+id,120000);var found=await provider.GetAsync(track,default);check(found?.WordSynced==true&&found.Source=="AMLL TTML","production word provider accepts only exact Spotify metadata and timed TTML");await provider.GetAsync(track,default);check(calls==1,"word lyrics cache prevents repeated requests for the same song");wrong=true;check(await provider.GetAsync(track with{Id="0000000000000000000012"},default)==null,"foreign Spotify lyric identities are rejected instead of attached to the current song");
            check(await provider.GetAsync(track with{Id="sc:3",Source="SoundCloud"},default)==null,"SoundCloud is never queried using a fabricated Spotify identity");
        }
        if(Environment.GetEnvironmentVariable("CNCX_LIVE_AMLL")=="1")
        {
            using var provider=new WordLyricsProvider();var song=new Track("0VjIjW4GlUZAMYd2vXMi3b","Blinding Lights","The Weeknd",null,null,"Spotify","spotify:track:0VjIjW4GlUZAMYd2vXMi3b",200040);var actual=await provider.GetAsync(song,default);check(actual?.WordSynced==true&&actual.Lines.Count>5,"live AMLL exact Spotify lookup becomes native word-timed lyrics in the production parser");
        }
    }
    sealed class Handler(Func<HttpResponseMessage> response):HttpMessageHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken ct){ct.ThrowIfCancellationRequested();return Task.FromResult(response());}
    }
}
