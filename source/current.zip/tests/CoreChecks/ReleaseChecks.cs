using System.Net;
using System.Text;
using System.Text.Json;
using GlassPlayer;
using GlassPlayer.Core;

static class ReleaseChecks
{
    public static async Task Run(Action<bool,string> check)
    {
        async Task Reject(Func<Task> action,string name)
        {
            try { await action(); }
            catch(Exception ex) when(ex is ArgumentException or FormatException or YamlDotNet.Core.YamlException) { check(true,name); return; }
            throw new Exception("FAIL: "+name);
        }

        double time=0;
        var clock=new PlaybackClock(()=>time,1800);
        clock.Update(1000,10000,true,"fixture");time=375;
        check(clock.Position==1375,"monotonic playback clock interpolates real sample positions");
        clock.SetPlaying(false);time=900;
        check(clock.Position==1375&&!clock.Playing,"pause freezes the clock at the current interpolated position");
        clock.SetPlaying(true);time=1100;
        check(clock.Position==1575,"resume continues from the frozen position without a jump");
        clock.Seek(5000);time=1200;
        check(clock.Position==5100,"seek restarts interpolation at the requested position");
        time=10000;check(clock.Position==6800,"stale playback samples stop extrapolating");
        clock.Seek(9999);time=10050;check(clock.Position==10000,"playback clock never passes track duration");
        clock.Clear();check(clock.Position==0&&clock.Uri==null&&!clock.Playing,"clearing a track removes its old clock state");
        clock.Update(-1,-20,true,null);check(clock.Position==0&&clock.Duration==0,"invalid clock samples remain bounded");

        const string timed="""
version: '1.0'
lines:
  - text: 'Hold breathe'
    start_ms: 1000
    end_ms: 5000
    words:
      - {text: 'Hold ', start_ms: 1000, end_ms: 1600}
      - {text: 'breathe', start_ms: 4000, end_ms: 5000}
  - text: 'Return'
    start_ms: 9000
    end_ms: 10000
""";
        var lines=LyricsfileReader.Parse(timed);
        check(lines.Count==2&&lines[0].Words?.Count==2,"Lyricsfile retains word starts, word ends and line ends");
        var glyphs=CaptionTimeline.Accurate(lines[0]);
        check(string.Concat(glyphs.Select(g=>g.Text))==lines[0].Text,"timed word rendering preserves original spacing");
        check(glyphs[1].OpacityAt(3999)==0&&glyphs[1].OpacityAt(4090)==1,"a word stays unrevealed throughout the vocal pause before it");
        check(CaptionTimeline.ActiveLine(lines,999)==-1&&CaptionTimeline.ActiveLine(lines,1000)==0,"lyrics never activate before their actual start marker");
        check(CaptionTimeline.ActiveLine(lines,4999)==0&&CaptionTimeline.ActiveLine(lines,5000)==-1&&CaptionTimeline.ActiveLine(lines,8999)==-1,"explicit vocal gaps remain unhighlighted until the next line");
        check(CaptionTimeline.ActiveLine(lines,9000)==1&&CaptionTimeline.ActiveLine(lines,10000)==-1,"last-line end also clears its active highlight");
        check(CaptionTimeline.ActiveLine(lines,8000,1000)==1&&CaptionTimeline.ActiveLine(lines,9000,-1000)==-1,"per-track offset shifts both line starts and gaps");
        var simple=CaptionTimeline.Accurate(new(1000,"Full phrase"));
        check(simple.Count==1&&simple[0].StartMs==1000,"line-only lyrics never invent character or word timing");
        check(CaptionTimeline.ActiveLine(new[]{new LyricLine(0,"One"),new LyricLine(2000," "),new LyricLine(5000,"Two")},3000)==-1,"empty LRC lines explicitly mark a vocal break");
        var mismatch=LyricsfileReader.Parse(timed.Replace("text: 'Hold '","text: 'Wrong '"));
        check(mismatch[0].Words==null&&mismatch[0].Text=="Hold breathe","mismatched word text falls back to its reliable phrase marker");
        await Reject(()=>Task.FromResult(LyricsfileReader.Parse(timed.Replace("start_ms: 4000","start_ms: 400"))),"word timing before its line start is rejected");
        await Reject(()=>Task.FromResult(LyricsfileReader.Parse(timed.Replace("end_ms: 1600","end_ms: 999"))),"word end before word start is rejected");
        await Reject(()=>Task.FromResult(LyricsfileReader.Parse(timed.Replace("end_ms: 5000}","end_ms: 6000}"))),"word end beyond its line end is rejected");
        await Reject(()=>Task.FromResult(LyricsfileReader.Parse(new string('x',1024*1024+1))),"Lyricsfile input size is bounded before YAML parsing");
        var duet=LyricsfileReader.Parse("lines:\n  - {text: 'A', start_ms: 1000}\n  - {text: 'B', start_ms: 1000}");
        check(duet.Count==1&&duet[0].Text=="A\nB","simultaneous lyric voices survive equal timestamps");

        const string id="0000000000000000000001",song="spotify:track:0000000000000000000002";
        string Meta(string snapshot="s1")=>JsonSerializer.Serialize(new{id,name="Minha playlist",description="A &amp; B <b>test</b>",images=Array.Empty<object>(),owner=new{id="user",display_name="Owner"},@public=false,collaborative=false,items=new{total=2},snapshot_id=snapshot});
        var requests=new List<(HttpMethod Method,string Path,JsonElement Body)>();
        string response=Meta();
        var client=new SpotifyLibraryClient((method,path,body,_)=>
        {
            requests.Add((method,path,JsonSerializer.SerializeToElement(body)));
            return Task.FromResult(response);
        });
        var created=await client.CreateAsync("  Minha playlist  ","Descrição",false,default);
        check(requests[^1].Method==HttpMethod.Post&&requests[^1].Path=="/me/playlists","playlist creation uses the current Spotify endpoint");
        check(requests[^1].Body.GetProperty("name").GetString()=="Minha playlist"&&!requests[^1].Body.GetProperty("public").GetBoolean(),"playlist name and privacy choices reach the request body");
        check(created.Description=="A & B test"&&created.Count==2&&created.Art==null,"playlist metadata handles HTML descriptions and absent cover images");
        await client.UpdateAsync(id,"Edited","",true,default);
        check(requests[^1].Method==HttpMethod.Put&&requests[^1].Path=="/playlists/"+id,"editing playlist details preserves its Spotify identity");
        await client.AddAsync(id,song,default);
        check(requests[^1].Method==HttpMethod.Post&&requests[^1].Path.EndsWith("/items")&&requests[^1].Body.GetProperty("uris")[0].GetString()==song,"adding a track sends its URI to playlist items");
        await client.RemoveAsync(id,song,"s1",default);
        check(requests[^1].Method==HttpMethod.Delete&&requests[^1].Body.GetProperty("items")[0].GetProperty("uri").GetString()==song&&requests[^1].Body.GetProperty("snapshot_id").GetString()=="s1","removal carries the playlist snapshot and selected track URI");
        await client.MoveAsync(id,0,2,3,"s1",default);
        check(requests[^1].Body.GetProperty("range_start").GetInt32()==0&&requests[^1].Body.GetProperty("insert_before").GetInt32()==3,"moving a track down adjusts the insertion point correctly");
        await client.MoveAsync(id,2,0,3,"s1",default);
        check(requests[^1].Body.GetProperty("range_start").GetInt32()==2&&requests[^1].Body.GetProperty("insert_before").GetInt32()==0&&!requests[^1].Body.TryGetProperty("uris",out _),"moving a track up reorders without replacing playlist contents");
        int sent=requests.Count;await client.MoveAsync(id,1,1,3,"s1",default);
        check(requests.Count==sent,"moving a track to its current position sends no mutation");
        await Reject(()=>client.MoveAsync(id,-1,0,3,"s1",default),"out-of-range playlist moves are rejected before a request");
        await Reject(()=>client.AddAsync(id,"spotify:episode:"+id,default),"track-only playlist actions reject episode URIs");
        await Reject(()=>client.CreateAsync(" ","",false,default),"empty playlist names are rejected");
        await Reject(()=>client.CreateAsync("Valid",new string('x',301),false,default),"playlist description length is bounded");
        await Reject(()=>client.OpenAsync("../me",default),"playlist IDs cannot alter a request path");
        response=JsonSerializer.Serialize(new{items=new[]{JsonSerializer.Deserialize<JsonElement>(Meta())},next=(string?)null});
        check((await client.MineAsync(default)).Single().Id==id,"library listing returns the user's playlists");
        response=JsonSerializer.Serialize(new{items=Array.Empty<object>(),next="https://evil.test/v1/me/playlists?offset=50"});
        await Reject(()=>client.MineAsync(default),"library pagination rejects foreign hosts");

        int metadataReads=0;
        var stable=new SpotifyLibraryClient((_,path,_,_)=>Task.FromResult(path.EndsWith("/items?limit=50")?"{\"total\":1,\"items\":[{\"item\":null}],\"next\":null}":Meta()));
        var content=await stable.OpenAsync(id,default);
        check(content.Tracks.Count==1&&!content.Tracks[0].Available,"unavailable songs retain their positions in a playlist");
        var changing=new SpotifyLibraryClient((_,path,_,_)=>Task.FromResult(path.EndsWith("/items?limit=50")?"{\"total\":0,\"items\":[],\"next\":null}":Meta(++metadataReads==1?"before":"after")));
        var recovered=await changing.OpenAsync(id,default);
        check(recovered.Stable&&metadataReads==4&&recovered.Playlist.Snapshot=="after","one snapshot change retries the playlist read and opens its current version");

        var root=Path.Combine(Path.GetTempPath(),"cncx-release-checks-"+Guid.NewGuid().ToString("N"));
        var track=new Track("fixture","Fixture","Performer",null,null,"Spotify",song,120000,"Album");
        string Record(string? yaml=null,bool synced=true)=>JsonSerializer.Serialize(new{trackName="Fixture",artistName="Performer",albumName="Album",duration=120,instrumental=false,syncedLyrics=synced?"[00:01]Hold breathe":null,plainLyrics="Hold breathe",lyricsfile=yaml});
        try
        {
            var better=new Handler((request)=>new(HttpStatusCode.OK){Content=new StringContent(request.RequestUri!.AbsolutePath.EndsWith("/search")?"["+Record(timed)+"]":Record(),Encoding.UTF8,"application/json")});
            using(var service=new LyricsService(new HttpClient(better),Path.Combine(root,"rich"),TimeSpan.Zero))
            {
                var document=await service.GetAsync(track,default);
                check(document is{Synced:true,WordSynced:false}&&better.Queries.Count==1,"an exact synchronized lyric is preserved instead of switching recordings for word timing");
                check(better.Queries[0].Contains("album_name=Album"),"automatic lyric matching includes the album identity");
            }
            var exactWords=new Handler(_=>new(HttpStatusCode.OK){Content=new StringContent(Record(timed),Encoding.UTF8,"application/json")});
            using(var service=new LyricsService(new HttpClient(exactWords),Path.Combine(root,"exact-words"),TimeSpan.Zero))
                check((await service.GetAsync(track,default)) is{WordSynced:true} words&&words.Lines[0].Words![1].StartMs==4000,"word timestamps from the exact recording remain available without choosing another lyric version");
            var fallback=new Handler(request=>request.RequestUri!.AbsolutePath.EndsWith("/search")?new(HttpStatusCode.ServiceUnavailable):new(HttpStatusCode.OK){Content=new StringContent(Record(),Encoding.UTF8,"application/json")});
            using(var service=new LyricsService(new HttpClient(fallback),Path.Combine(root,"fallback"),TimeSpan.Zero))
                check((await service.GetAsync(track,default))?.Synced==true,"optional word lookup failure preserves a valid exact phrase result");
            var upgrade=new Handler(request=>new(HttpStatusCode.OK){Content=new StringContent(request.RequestUri!.AbsolutePath.EndsWith("/search")?"["+Record()+"]":Record(synced:false),Encoding.UTF8,"application/json")});
            using(var service=new LyricsService(new HttpClient(upgrade),Path.Combine(root,"upgrade"),TimeSpan.Zero))
                check((await service.GetAsync(track,default))?.Synced==true,"a timed search result improves an unsynchronized exact response");
        }
        finally { if(Directory.Exists(root))Directory.Delete(root,true); }
    }
    sealed class Handler(Func<HttpRequestMessage,HttpResponseMessage> reply):HttpMessageHandler
    {
        public List<string> Queries {get;}=new();
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken ct)
        {ct.ThrowIfCancellationRequested();Queries.Add(request.RequestUri!.Query);return Task.FromResult(reply(request));}
    }
}
