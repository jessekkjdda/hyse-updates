using GlassPlayer.Core;

static class DesktopChecks
{
    public static void Run(Action<bool,string> check)
    {
        foreach(bool exiting in new[]{false,true})
        foreach(bool sessionEnding in new[]{false,true})
        foreach(bool trayAvailable in new[]{false,true})
        {
            bool hide=CloseBehavior.HideToTray(exiting,sessionEnding,trayAvailable);
            check(hide==(trayAvailable&&!exiting&&!sessionEnding),$"close policy exit={exiting}, session={sessionEnding}, tray={trayAvailable}");
        }
    }
}
