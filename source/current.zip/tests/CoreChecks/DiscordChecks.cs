using System.Buffers.Binary;
using System.Collections.Concurrent;
using System.Text;
using System.Text.Json;
using System.Threading.Channels;
using GlassPlayer;
using GlassPlayer.Core;

static class DiscordChecks
{
    public static async Task Run(Action<bool,string> check)
    {
        var track=new Track("0123456789012345678901","First song","An artist","https://i.scdn.co/image/cover",null,"Spotify","spotify:track:0123456789012345678901",180000,"The album");
        var options=new DiscordPresenceOptions();var model=new DiscordActivity();var now=DateTimeOffset.FromUnixTimeSeconds(1806000000);
        using var first=JsonDocument.Parse(model.Build(track,true,45000,180000,options,now)!);var root=first.RootElement;
        check(root.GetProperty("type").GetInt32()==2&&root.GetProperty("name").GetString()=="Hyse","Discord uses Listening with the requested hyse application identity");
        check(root.GetProperty("details").GetString()==track.Title&&root.GetProperty("state").GetString()==track.Artist,"presence uses the actual song and artist");
        check(root.GetProperty("assets").GetProperty("large_image").GetString()==track.Art&&root.GetProperty("assets").GetProperty("small_image").GetString()==DiscordActivity.IconAsset,"album artwork and the named original app-icon asset occupy separate slots");
        check(root.GetProperty("assets").GetProperty("large_text").GetString()=="The album","album title is retained in the artwork tooltip");
        check(root.GetProperty("timestamps").GetProperty("start").GetInt64()==1805999955&&root.GetProperty("timestamps").GetProperty("end").GetInt64()==1806000135,"progress timestamps come from the confirmed playback position and duration");
        var a=model.Build(track,true,45500,180000,options,now.AddMilliseconds(500));
        check(a==first.RootElement.GetRawText(),"advancing playback does not republish an unchanged activity every tick");
        using var seek=JsonDocument.Parse(model.Build(track,true,90000,180000,options,now.AddSeconds(1))!);
        check(seek.RootElement.GetProperty("timestamps").GetProperty("start").GetInt64()==1805999911,"seeking adjusts the presence clock without changing the media clock");
        using var pause=JsonDocument.Parse(model.Build(track,false,90000,180000,options,now.AddSeconds(2))!);
        check(!pause.RootElement.TryGetProperty("timestamps",out _)&&pause.RootElement.GetProperty("state").GetString()!.StartsWith("Pausado"),"pause removes the running timer and marks the paused song");
        check(model.Build(track,false,90000,180000,options with{HidePaused=true},now)==null,"hide-on-pause clears the activity");
        check(model.Build(track,true,0,180000,options with{Enabled=false},now)==null&&model.Build(null,false,0,0,options,now)==null,"disabled or absent playback never advertises a song");
        using var noArt=JsonDocument.Parse(model.Build(track,true,0,180000,options with{ShowArtwork=false,ShowTime=false,ShowButton=false,Text="app"},now)!);
        check(noArt.RootElement.GetProperty("assets").GetProperty("large_image").GetString()==DiscordActivity.IconAsset&&!noArt.RootElement.TryGetProperty("timestamps",out _)&&!noArt.RootElement.TryGetProperty("buttons",out _),"artwork, time and link controls affect only their own presence fields");
        check(noArt.RootElement.GetProperty("status_display_type").GetInt32()==0,"app-name status preference uses the documented name display mode");
        check(root.GetProperty("buttons").GetArrayLength()==1&&root.GetProperty("buttons")[0].GetProperty("url").GetString()=="https://open.spotify.com/track/"+track.Id,"Spotify RPC button links to the same song without a custom protocol");
        var cloud=track with{Id="sc:1",Source="SoundCloud",OpenUri="https://soundcloud.com/artist/song?tracking=private#part"};
        check(DiscordActivity.TrackUrl(cloud)=="https://soundcloud.com/artist/song","SoundCloud link uses its canonical path without query or fragment");
        foreach(string bad in new[]{"file:///private/art.png","data:image/png;base64,AA","http://example.com/art.png","https://user:password@example.com/art.png"})check(DiscordActivity.ImageUrl(bad)==null,"invalid or credential-bearing presence artwork is omitted: "+bad.Split(':')[0]);
        foreach(string bad in new[]{"https://open.spotify.com.evil.test/track/x","https://user:password@open.spotify.com/track/x","javascript:alert(1)","http://open.spotify.com/track/x"})check(DiscordActivity.TrackUrl(track with{OpenUri=bad})==null,"presence button rejects unrelated or non-public links");
        using var unicode=JsonDocument.Parse(model.Build(track with{Title=string.Concat(Enumerable.Repeat("🎵áЖ",100))},true,0,180000,options,now)!);
        check(Encoding.UTF8.GetByteCount(unicode.RootElement.GetProperty("details").GetString()!)<=128&&!unicode.RootElement.GetProperty("details").GetString()!.Contains('\ufffd'),"long Unicode metadata stays within the field limit without splitting a rune");
        using(var single=JsonDocument.Parse(model.Build(track with{Title="梦",Artist="É"},true,0,180000,options,now)!))check(single.RootElement.GetProperty("details").GetString()!.EnumerateRunes().Count()>=2&&single.RootElement.GetProperty("state").GetString()!.EnumerateRunes().Count()>=2,"single non-ASCII titles and artists meet Discord minimum text length");
        var memory=new CountedWrites();await DiscordFrames.WriteAsync(memory,3,Encoding.UTF8.GetBytes("ping"),default);check(memory.Writes==1,"handshake/frame header and JSON are written as one complete IPC packet");memory.Position=0;
        var frame=await DiscordFrames.ReadAsync(new FragmentedStream(memory.ToArray()),default);
        check(frame.Opcode==3&&Encoding.UTF8.GetString(frame.Data)=="ping","partial IPC reads reconstruct the complete little-endian frame");
        foreach(int length in new[]{-1,65537})
        {
            var header=new byte[8];BinaryPrimitives.WriteInt32LittleEndian(header,1);BinaryPrimitives.WriteInt32LittleEndian(header.AsSpan(4),length);
            try{await DiscordFrames.ReadAsync(new MemoryStream(header),default);throw new Exception("Invalid frame accepted");}catch(InvalidDataException){check(true,"invalid frame length rejected before allocating: "+length);}
        }
        using(var cancel=new CancellationTokenSource())
        {
            cancel.Cancel();try{await DiscordFrames.ReadAsync(new MemoryStream(new byte[8]),cancel.Token);throw new Exception("Read not canceled");}catch(OperationCanceledException){check(true,"IPC reads honor cancellation");}
        }
        await using(var server=new MockDiscord())
        await using(var ipc=await DiscordIpc.OpenAsync(server.ConnectAsync,default))
        {
            check(server.ClientId==DiscordActivity.ApplicationId,"IPC handshake sends the supplied public Application ID over the simulated duplex stream");
            await server.SendAsync(3,"{}"u8.ToArray());await Until(()=>server.Pongs>0);
            check(server.Pongs==1,"idle IPC read pump responds to Discord heartbeat without a new song");
            await ipc.PingAsync(default);check(server.Pings==1,"client liveness ping is acknowledged independently from activity updates");
            server.AutoAck=false;var publish=ipc.SetActivityAsync(a,default);await Until(()=>server.Messages.Count==1);
            await server.SendAsync(1,JsonSerializer.SerializeToUtf8Bytes(new{cmd="SET_ACTIVITY",nonce="unrelated"}));await Task.Delay(30);
            check(!publish.IsCompleted,"an unrelated nonce never acknowledges a presence command");
            await server.AckAsync(server.Messages.Last());await publish;
            check(server.Messages.Last().GetProperty("args").GetProperty("pid").GetInt32()==Environment.ProcessId,"presence command includes the real process ID");
            server.AutoAck=true;await ipc.SetActivityAsync(null,default);
            check(server.Messages.Last().GetProperty("args").GetProperty("activity").ValueKind==JsonValueKind.Null,"clearing sends activity:null instead of stale metadata");
            server.Reject=true;try{await ipc.SetActivityAsync(a,default);throw new Exception("Error not propagated");}catch(IOException){check(true,"Discord errors fail their command without requiring login credentials");}
        }
        await using(var server=new MockDiscord())
        await using(var ipc=await DiscordIpc.OpenAsync(server.ConnectAsync,default))
        {
            server.Abort();await Until(()=>ipc.Disconnected);
            try{await ipc.SetActivityAsync(a,default);throw new Exception("Closed pipe accepted");}catch(IOException){check(true,"closed pipe fails immediately instead of waiting for an acknowledgement");}
        }
        var servers=new ConcurrentQueue<MockDiscord>();
        Task<Stream> Connect(CancellationToken ct){var server=new MockDiscord();servers.Enqueue(server);return server.ConnectAsync(ct);}
        var presence=new DiscordPresence(Connect,TimeSpan.FromMilliseconds(650),TimeSpan.FromMilliseconds(30));
        try
        {
            presence.Update(false,a);await Task.Delay(300);check(servers.IsEmpty&&presence.Status=="Desativado","disabled presence opens no Discord pipe");
            presence.Update(true,a);await Until(()=>servers.Count==1&&servers.First().Messages.Count==1);
            check(presence.Status=="Conectado","service reports connected only after RPC READY and command acknowledgement");
            for(int i=0;i<10;i++)presence.Update(true,a);await Task.Delay(300);check(servers.First().Messages.Count==1,"unchanged track samples do not flood Discord");
            string next=model.Build(track with{Title="Latest song"},true,0,180000,options,now.AddSeconds(5))!;
            presence.Update(true,"{\"details\":\"obsolete\"}");presence.Update(true,next);await Until(()=>servers.First().Messages.Count==2);
            check(servers.First().Messages.Last().GetProperty("args").GetProperty("activity").GetProperty("details").GetString()=="Latest song","latest pending song replaces obsolete samples under the send limit");
            check((servers.First().Times.Last()-servers.First().Times.First()).TotalMilliseconds>=640,"presence updates respect the configured minimum interval");
            servers.First().Abort();presence.Update(true,next);await Until(()=>servers.Count>=2&&servers.Last().Messages.Count==1);
            check(servers.Last().Messages.Last().GetProperty("args").GetProperty("activity").GetProperty("details").GetString()=="Latest song","Discord restart reconnects and restores only the latest activity");
            presence.Reconnect();await Until(()=>servers.Count>=3&&servers.Last().Messages.Count==1);check(presence.Status=="Conectado","manual reconnect keeps the worker alive and republishes the latest song");
            presence.Update(false,null);await Until(()=>servers.Last().Closed);int total=servers.Count;await Task.Delay(300);
            check(presence.Status=="Desativado"&&servers.Count==total,"disabling immediately closes IPC and stops reconnection");
        }
        finally{presence.Dispose();await presence.Completion;foreach(var server in servers)await server.DisposeAsync();}
        int attempts=0;await using var recovery=new MockDiscord();
        using(var resilient=new DiscordPresence(ct=>++attempts==1?throw new ObjectDisposedException("closed transport"):recovery.ConnectAsync(ct),TimeSpan.FromMilliseconds(20),TimeSpan.FromMilliseconds(20)))
        {
            resilient.Update(true,a);await Until(()=>recovery.Messages.Count>0);check(attempts>=2&&!resilient.Completion.IsCompleted,"a disposed pipe during connection does not permanently kill the presence worker");resilient.Dispose();await resilient.Completion;
        }
        var quietServers=new ConcurrentQueue<MockDiscord>();
        Task<Stream> QuietConnect(CancellationToken ct){var server=new MockDiscord{AutoAck=!quietServers.IsEmpty,DropPongs=true};quietServers.Enqueue(server);return server.ConnectAsync(ct);}
        var watchdog=new DiscordPresence(QuietConnect,TimeSpan.FromMilliseconds(20),TimeSpan.FromMilliseconds(20),TimeSpan.FromMilliseconds(650),TimeSpan.FromMilliseconds(180));
        try
        {
            watchdog.Update(true,a);await Until(()=>quietServers.Count>=2&&quietServers.Last().Messages.Count>=1);
            check(quietServers.First().Pings==0&&quietServers.First().Closed,"an unacknowledged activity triggers recovery without depending on client PING support");
            await Until(()=>quietServers.Last().Messages.Count>=2);check(true,"an unchanged activity is periodically refreshed after a successful acknowledgement");
        }
        finally{watchdog.Dispose();await watchdog.Completion;foreach(var server in quietServers)await server.DisposeAsync();}
        await using(var noPong=new MockDiscord{DropPongs=true})
        using(var passive=new DiscordPresence(noPong.ConnectAsync,TimeSpan.FromMilliseconds(20),TimeSpan.FromMilliseconds(20),TimeSpan.FromMilliseconds(60)))
        {
            passive.Update(true,a);await Until(()=>noPong.Messages.Count>=3);check(noPong.Pings==0&&!noPong.Closed&&passive.State.Connected,"a client that ignores unsolicited PING stays connected through supported activity acknowledgements");passive.Dispose();await passive.Completion;
        }
        await using(var firstEndpoint=new MockDiscord{NoReady=true})
        await using(var secondEndpoint=new MockDiscord())
        await using(var selected=await DiscordIpc.OpenFirstAsync(new Func<CancellationToken,Task<Stream>>[]{firstEndpoint.ConnectAsync,secondEndpoint.ConnectAsync},default,TimeSpan.FromMilliseconds(100)))
            check(selected.Endpoint=="discord-ipc-1"&&firstEndpoint.Closed,"a pipe that opens but never sends READY does not hide a valid second Discord endpoint");
        await using(var rejected=new MockDiscord{RejectHandshake=true})
        {
            try{await DiscordIpc.OpenFirstAsync(new Func<CancellationToken,Task<Stream>>[]{rejected.ConnectAsync,_=>throw new TimeoutException()},default);check(false,"expected handshake rejection");}
            catch(DiscordRpcError ex){check(ex.Code==4000&&ex.Phase=="handshake"&&ex.Closed,"the original Discord handshake code survives later missing endpoints");}
        }
        var compatibleServers=new ConcurrentQueue<MockDiscord>();
        Task<Stream> CompatConnect(CancellationToken ct){var server=new MockDiscord{RejectActivity=node=>node.TryGetProperty("name",out _)||node.TryGetProperty("assets",out _)};compatibleServers.Enqueue(server);return server.ConnectAsync(ct);}
        var compatible=new DiscordPresence(CompatConnect,TimeSpan.FromMilliseconds(20),TimeSpan.FromMilliseconds(20));
        try
        {
            compatible.Update(true,a);await Until(()=>compatible.State.Compatibility==2&&compatible.State.Phase=="ready");
            check(compatibleServers.Count==1&&compatibleServers.First().Messages.Count==3,"invalid optional fields negotiate compatibility on the same connection instead of reconnecting forever");
            var activity=compatibleServers.First().Messages.Last().GetProperty("args").GetProperty("activity");
            check(activity.GetProperty("type").GetInt32()==2&&activity.GetProperty("details").GetString()==track.Title&&!activity.TryGetProperty("assets",out _),"minimal compatible activity preserves Listening and song identity");
        }
        finally{compatible.Dispose();await compatible.Completion;foreach(var server in compatibleServers)await server.DisposeAsync();}
        await using(var denied=new MockDiscord{Reject=true,RejectCode=4006})
        using(var connected=new DiscordPresence(denied.ConnectAsync,TimeSpan.FromMilliseconds(20),TimeSpan.FromMilliseconds(20)))
        {
            connected.Update(true,a);await Until(()=>connected.State.Code==4006);await Task.Delay(300);
            check(connected.State.Connected&&connected.State.Phase=="activity"&&denied.Messages.Count==1&&!denied.Closed,"permission rejection is displayed as an activity error without destroying a valid connection");connected.Dispose();await connected.Completion;
        }
        await using(var idleServer=new MockDiscord())
        using(var idle=new DiscordPresence(idleServer.ConnectAsync,TimeSpan.FromMilliseconds(20),TimeSpan.FromMilliseconds(20)))
        {
            idle.Update(true,null);await Until(()=>idleServer.Messages.Count==1&&idle.State.Phase=="ready");check(idle.State.Connected,"connection checks work even before a song is playing");idle.Dispose();await idle.Completion;
        }
        check(presence.Completion.IsCompletedSuccessfully,"shutdown cancels the worker without blocking the player");
    }
    static async Task Until(Func<bool> condition){using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(5));while(!condition())await Task.Delay(10,timeout.Token);}
    sealed class CountedWrites:MemoryStream
    {
        public int Writes;
        public override ValueTask WriteAsync(ReadOnlyMemory<byte> data,CancellationToken ct=default){Writes++;return base.WriteAsync(data,ct);}
    }
    sealed class FragmentedStream(byte[] data):MemoryStream(data)
    {
        public override ValueTask<int> ReadAsync(Memory<byte> buffer,CancellationToken ct=default)=>base.ReadAsync(buffer[..Math.Min(2,buffer.Length)],ct);
    }
    sealed class MockDiscord:IAsyncDisposable
    {
        readonly CancellationTokenSource lifetime=new();readonly SemaphoreSlim writer=new(1,1);Stream? server;Task? loop;
        public ConcurrentQueue<JsonElement> Messages{get;}=new();public ConcurrentQueue<DateTimeOffset> Times{get;}=new();
        public bool AutoAck=true,Reject,DropPongs,NoReady,RejectHandshake;public int RejectCode=4000;public Func<JsonElement,bool>? RejectActivity;public int Pings;public int Pongs;public string? ClientId;public bool Closed;
        public Task<Stream> ConnectAsync(CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();var inbound=Channel.CreateUnbounded<byte[]>();var outbound=Channel.CreateUnbounded<byte[]>();
            server=new MemoryPipe(inbound,outbound);Stream client=new MemoryPipe(outbound,inbound);loop=ReadAsync();return Task.FromResult(client);
        }
        async Task ReadAsync()
        {
            try
            {
                var handshake=await DiscordFrames.ReadAsync(server!,lifetime.Token);if(handshake.Opcode!=0)throw new Exception("Missing handshake");
                using(var data=JsonDocument.Parse(handshake.Data))ClientId=data.RootElement.GetProperty("client_id").GetString();
                if(RejectHandshake){await SendAsync(2,"{\"code\":4000,\"message\":\"Invalid client ID\"}"u8.ToArray());return;}
                if(!NoReady)await SendAsync(1,"{\"cmd\":\"DISPATCH\",\"evt\":\"READY\",\"data\":{}}"u8.ToArray());
                while(!lifetime.IsCancellationRequested)
                {
                    var frame=await DiscordFrames.ReadAsync(server!,lifetime.Token);
                    if(frame.Opcode==3){Interlocked.Increment(ref Pings);if(!DropPongs)await SendAsync(4,frame.Data);continue;}
                    if(frame.Opcode==4){Interlocked.Increment(ref Pongs);continue;}
                    using var data=JsonDocument.Parse(frame.Data);var command=data.RootElement.Clone();Messages.Enqueue(command);Times.Enqueue(DateTimeOffset.UtcNow);
                    if(AutoAck)await AckAsync(command);
                }
            }
            catch(Exception ex)when(ex is IOException or OperationCanceledException or ObjectDisposedException){}
            finally{Closed=true;}
        }
        public Task AckAsync(JsonElement command)
        {
            var activity=command.GetProperty("args").GetProperty("activity");bool reject=Reject||activity.ValueKind==JsonValueKind.Object&&RejectActivity?.Invoke(activity)==true;
            return SendAsync(1,JsonSerializer.SerializeToUtf8Bytes(new{cmd="SET_ACTIVITY",nonce=command.GetProperty("nonce").GetString(),evt=reject?"ERROR":null,data=reject?new{code=RejectCode,message="Unsupported activity field"}:null}));
        }
        public async Task SendAsync(int opcode,byte[] data){await writer.WaitAsync();try{await DiscordFrames.WriteAsync(server!,opcode,data,lifetime.Token);}finally{writer.Release();}}
        public void Abort(){lifetime.Cancel();server?.Dispose();}
        public async ValueTask DisposeAsync(){Abort();if(loop!=null)await loop;lifetime.Dispose();writer.Dispose();}
    }
    // An in-memory test transport; it neither creates sockets nor claims to
    // exercise Windows named pipes. It deliberately fragments every read.
    sealed class MemoryPipe(Channel<byte[]> input,Channel<byte[]> output):Stream
    {
        byte[]? chunk;int offset;bool disposed;
        public override bool CanRead=>!disposed;public override bool CanWrite=>!disposed;public override bool CanSeek=>false;
        public override long Length=>throw new NotSupportedException();public override long Position{get=>throw new NotSupportedException();set=>throw new NotSupportedException();}
        public override async ValueTask<int> ReadAsync(Memory<byte> buffer,CancellationToken ct=default)
        {
            ObjectDisposedException.ThrowIf(disposed,this);if(buffer.Length==0)return 0;
            while(chunk==null||offset==chunk.Length){try{chunk=await input.Reader.ReadAsync(ct);offset=0;}catch(ChannelClosedException){return 0;}}
            int n=Math.Min(3,Math.Min(buffer.Length,chunk.Length-offset));chunk.AsMemory(offset,n).CopyTo(buffer);offset+=n;return n;
        }
        public override async ValueTask WriteAsync(ReadOnlyMemory<byte> buffer,CancellationToken ct=default)
        {
            ObjectDisposedException.ThrowIf(disposed,this);if(buffer.Length==0)return;
            try{await output.Writer.WriteAsync(buffer.ToArray(),ct);}catch(ChannelClosedException ex){throw new IOException("Test pipe closed.",ex);}
        }
        public override int Read(byte[] buffer,int offset,int count)=>ReadAsync(buffer.AsMemory(offset,count)).AsTask().GetAwaiter().GetResult();
        public override void Write(byte[] buffer,int offset,int count)=>WriteAsync(buffer.AsMemory(offset,count)).AsTask().GetAwaiter().GetResult();
        public override void Flush(){}public override long Seek(long offset,SeekOrigin origin)=>throw new NotSupportedException();public override void SetLength(long value)=>throw new NotSupportedException();
        protected override void Dispose(bool disposing){disposed=true;output.Writer.TryComplete();input.Writer.TryComplete();base.Dispose(disposing);}
    }
}
