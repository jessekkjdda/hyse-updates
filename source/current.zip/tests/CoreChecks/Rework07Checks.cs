using GlassPlayer;
using GlassPlayer.Core;
static class Rework07Checks
{
    public static Task Run(Action<bool,string> check)
    {
        var dir=Path.Combine(Path.GetTempPath(),"cncx-local-tests-"+Guid.NewGuid().ToString("N"));var path=Path.Combine(dir,"local-playlists.json");
        try
        {
            var store=new LocalPlaylistStore(path);store.Load();var playlist=store.Create("  Noite  ","Local");
            check(playlist.Id.StartsWith("local-")&&playlist.Name=="Noite"&&playlist.OwnerId=="local","local playlists have an explicit separate identity and trimmed name");
            var first=new Track("a","First","Artist",null,null,"Spotify","spotify:track:0000000000000000000001");var second=first with{Id="b",Title="Second",OpenUri="spotify:track:0000000000000000000002"};
            store.Add(playlist.Id,first);store.Add(playlist.Id,first);store.Add(playlist.Id,second);
            check(store.Open(playlist.Id).Tracks.Count==3,"local playlists preserve intentional duplicate occurrences");
            store.Remove(playlist.Id,0);check(store.Open(playlist.Id).Tracks.Select(t=>t.Id).SequenceEqual(new[]{"a","b"}),"removal only removes the selected local occurrence");
            store.Move(playlist.Id,0,1);check(store.Open(playlist.Id).Tracks.Select(t=>t.Id).SequenceEqual(new[]{"b","a"}),"local reordering uses the requested final index");
            store.Update(playlist.Id,"New name","Description");var restored=new LocalPlaylistStore(path);restored.Load();check(restored.List()[0].Name=="New name"&&restored.Open(playlist.Id).Tracks.Count==2,"new process restores playlist metadata, tracks and order from disk");
            bool rejected=false;try{store.Move(playlist.Id,-1,1);}catch(ArgumentOutOfRangeException){rejected=true;}check(rejected&&store.Open(playlist.Id).Tracks.Count==2,"invalid move leaves the persisted playlist intact");
            rejected=false;try{store.Add(playlist.Id,first with{Available=false});}catch(ArgumentException){rejected=true;}check(rejected&&store.Open(playlist.Id).Tracks.Count==2,"unavailable tracks cannot corrupt a local playlist");
            rejected=false;try{store.Create(" ","");}catch(ArgumentException){rejected=true;}check(rejected&&store.List().Count==1,"invalid creation does not leave a phantom playlist");
            store.Delete(playlist.Id);restored.Load();check(restored.List().Count==0,"confirmed deletion persists across reload");
        }
        finally{if(Directory.Exists(dir))Directory.Delete(dir,true);}
        var words=LyricsParser.Parse("[00:01.00]<00:01.00>Hold <00:04.00>breathe<00:05.00>\n[00:09.00]Return");
        check(words[0].Text=="Hold breathe"&&words[0].Words?.Count==2,"enhanced LRC imports real inline word timestamps without displaying tags");
        check(words[0].Words![1].StartMs==4000&&words[0].Words![1].EndMs==5000&&words[0].EndMs==5000,"enhanced LRC preserves a breath gap and an explicit line end");
        check(CaptionTimeline.ActiveLine(words,6000)==-1,"enhanced LRC leaves a marked instrumental interval empty");
        var shifted=LyricsParser.Parse("[offset:100]\n[00:01.00]<00:01.00>Hold <00:04.00>breathe<00:05.00>");
        check(shifted[0].TimeMs==900&&shifted[0].Words![1].StartMs==3900&&shifted[0].EndMs==4900,"file offset shifts line, word and end timestamps together");
        var malformed=LyricsParser.Parse("[00:02.00]<00:01.00>Invalid");check(malformed[0].Words==null&&malformed[0].Text=="Invalid","invalid inline word timing falls back to the source line timing");
        return Task.CompletedTask;
    }
}
