using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using GlassPlayer;
using GlassPlayer.Core;

static class Regression06Checks
{
    public static async Task Run(Action<bool,string> check)
    {
        double time=0;var clock=new PlaybackClock(()=>time);
        clock.Update(0,10000,true,"song");
        for(int i=1;i<=4;i++){time=i*200;clock.Update(0,10000,true,"song");}
        check(clock.Position==800,"repeated SDK samples cannot reset lyric progress back to 200 ms");
        time=1000;clock.Update(1000,10000,true,"song");time=1300;
        check(clock.Position==1300,"new position samples continue on the same song clock");
        clock.Update(1300,10000,false,"song");time=1900;
        check(clock.Position==1300,"word timing remains frozen through an actual pause");
        clock.Seek(7000);time=2000;clock.Update(1300,10000,false,"song");
        check(clock.Position==7000,"a stale sample immediately after seek cannot return lyrics to the old verse");
        clock.Update(7000,10000,false,"song");
        check(clock.Position==7000,"confirmed seek positions settle without a second jump");
        clock.Update(0,50000,true,"other");time=2300;
        check(clock.Position==300&&clock.Uri=="other","changing songs does not reuse the previous song's clock");

        const string uri="spotify:track:0000000000000000000001";
        object TrackJson(int i,bool available)=>new{uri="spotify:track:"+i.ToString("D22"),name="Song "+i,album=new{images=Array.Empty<object>()},artists=Array.Empty<object>(),is_playable=available};
        string payload=JsonSerializer.Serialize(new{tracks=new{total=12,next="https://api.spotify.com/v1/search?offset=10",items=new[]{TrackJson(1,true),TrackJson(2,false),TrackJson(3,true)}}});
        var parsed=TrackSearchReader.Parse(payload,0);
        check(parsed.Tracks.Count==2&&parsed.Tracks[1].Title=="Song 3","one unavailable Spotify result cannot break the remaining search results");
        check(parsed.NextOffset==3,"pagination uses the number of raw search entries, including unavailable ones");

        int inFlight=0,maximum=0;var requests=new List<string>();var firstStarted=new TaskCompletionSource();var finishFirst=new TaskCompletionSource();
        var search=new SearchRequestQueue<string>(async(query,_,ct)=>
        {
            maximum=Math.Max(maximum,++inFlight);requests.Add(query);
            if(query=="first"){firstStarted.SetResult();await finishFirst.Task.WaitAsync(ct);}
            inFlight--;return query;
        },TimeSpan.Zero);
        using var obsolete=new CancellationTokenSource();using var middle=new CancellationTokenSource();
        var a=search.RunAsync("first",0,obsolete.Token,default);await firstStarted.Task;obsolete.Cancel();
        var b=search.RunAsync("middle",0,middle.Token,default);var c=search.RunAsync("latest",0,default,default);middle.Cancel();finishFirst.SetResult();
        check(await a=="first"&&await c=="latest","sent search requests finish while only the newest pending query proceeds");
        bool canceled=false;try{await b;}catch(OperationCanceledException){canceled=true;}
        check(canceled&&requests.SequenceEqual(new[]{"first","latest"})&&maximum==1,"rapid typing cannot create overlapping or obsolete queued search requests");

        var pageState=new PageState();
        foreach(var page in Enum.GetValues<AppPage>().Where(page=>page!=AppPage.Player))
        {pageState.Navigate(page);if(pageState.ShowsPlayer)throw new Exception("Player leaked behind "+page);}
        check(true,"every non-player page hides the full player");pageState.Navigate(AppPage.Player);
        check(pageState.ShowsPlayer&&!pageState.ShowsTrackList,"returning to Player does not leave search or queue layered over it");

        var song=new Track("one","History song","Artist",null,null,"Spotify",uri,120000);
        var history=new ListeningHistory();history.Begin(song,DateTimeOffset.UtcNow);history.Observe(0,true,0);
        for(int i=1;i<=4;i++)history.Observe(i*1000,true,i*1000);
        check(history.Entries.Count==0,"clicking a song or playing it briefly does not manufacture listening history");
        history.Observe(5000,true,5000);check(history.Entries.Count==1,"confirmed playback records a song after five seconds heard");
        history.Observe(5000,false,6000);history.Observe(5000,false,12000);
        check(history.Entries[0].HeardMs==5000,"paused time is never counted as listening");
        history.Observe(90000,true,13000);history.Observe(91000,true,14000);
        check(history.Entries[0].HeardMs==6000,"seeking past most of a song does not count the skipped portion as listening");
        history.Begin(song,DateTimeOffset.UtcNow.AddMinutes(1));history.Observe(0,true,15000);
        for(int i=1;i<=5;i++)history.Observe(i*1000,true,15000+i*1000);
        check(history.Entries.Count==2&&history.Entries[0].SessionId!=history.Entries[1].SessionId,"listening to the same song again creates a distinct history occurrence");
        string directory=Path.Combine(Path.GetTempPath(),"cncx-history-check-"+Guid.NewGuid().ToString("N"));
        try
        {
            var store=new ListeningHistoryStore(Path.Combine(directory,"history.json"));await store.SaveAsync(history.Entries);
            var restored=new ListeningHistory();restored.Restore(store.Load());
            check(restored.Entries.Count==2&&restored.Entries[0].Track.OpenUri==uri,"listening history survives a save and reload");
            history.Clear();await store.SaveAsync(history.Entries);check(store.Load().Count==0,"clearing history persists the empty state");
            await File.WriteAllTextAsync(Path.Combine(directory,"history.json"),"corrupted");check(store.Load().Count==0,"corrupt history cannot stop the player opening");
        }
        finally{if(Directory.Exists(directory))Directory.Delete(directory,true);}

        int calls=0,invalidations=0;
        using(var http=new HttpClient(new Handler((request,_)=>
        {
            calls++;check(request.RequestUri!.AbsoluteUri=="https://api.spotify.com/v1/me/playlists","production transport builds the expected Spotify URL");
            check(request.Headers.Authorization?.Parameter=="fixture-token","production transport applies the bearer token");
            return Task.FromResult(new HttpResponseMessage(calls==1?HttpStatusCode.ServiceUnavailable:HttpStatusCode.OK));
        })))
        {
            var transport=new SpotifyApiTransport(http,_=>Task.FromResult("fixture-token"),()=>invalidations++,TimeSpan.Zero);
            using var response=await transport.SendAsync(HttpMethod.Get,"/me/playlists",null,default);
            check(response.IsSuccessStatusCode&&calls==2,"a temporary Spotify read failure is retried exactly once");
        }
        calls=0;
        using(var http=new HttpClient(new Handler((_,_)=>{calls++;throw new TaskCanceledException("fixture timeout");})))
        {
            var transport=new SpotifyApiTransport(http,_=>Task.FromResult("fixture-token"),()=>{},TimeSpan.Zero);bool timeout=false;
            try{await transport.SendAsync(HttpMethod.Get,"/me/playlists",null,default);}catch(TimeoutException){timeout=true;}
            check(timeout&&calls==2,"a network timeout becomes a visible timeout error instead of a silent cancellation");
        }
        calls=0;
        using(var http=new HttpClient(new Handler((_,_)=>{calls++;return Task.FromResult(new HttpResponseMessage(HttpStatusCode.ServiceUnavailable));})))
        {
            var transport=new SpotifyApiTransport(http,_=>Task.FromResult("fixture-token"),()=>{},TimeSpan.Zero);
            using var response=await transport.SendAsync(HttpMethod.Post,"/me/playlists",new{name="Do not duplicate"},default);
            check(calls==1&&!response.IsSuccessStatusCode,"playlist creation is never blindly retried after a server failure");
        }
        calls=0;
        using(var http=new HttpClient(new Handler((_,_)=>{calls++;var response=new HttpResponseMessage(HttpStatusCode.TooManyRequests);response.Headers.RetryAfter=new RetryConditionHeaderValue(TimeSpan.FromSeconds(2));return Task.FromResult(response);})))
        {
            var transport=new SpotifyApiTransport(http,_=>Task.FromResult("fixture-token"),()=>{},TimeSpan.Zero);int denied=0;
            for(int i=0;i<2;i++)try{await transport.SendAsync(HttpMethod.Get,"/me/playlists",null,default);}catch(HttpRequestException e)when(e.StatusCode==HttpStatusCode.TooManyRequests){denied++;}
            check(denied==2&&calls==1,"Retry-After prevents repeated network requests during Spotify rate limiting");
        }
    }
    sealed class Handler(Func<HttpRequestMessage,CancellationToken,Task<HttpResponseMessage>> reply):HttpMessageHandler
    {protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken ct)=>reply(request,ct);}
}
