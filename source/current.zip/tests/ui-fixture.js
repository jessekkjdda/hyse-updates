// Test-only native host; never included in the app's Web directory.
module.exports=function install(fixture){
  const listeners=new Set(),calls=[],bridgeMessages=[],canceled=new Set();let sequence=0,played=null,personal={name:'Test User',bio:'',avatar:null,banner:null};
  const emit=(type,data)=>{for(const listener of listeners)listener({data:{type,data}});};
  const tracks=fixture.tracks,playlists=fixture.playlists,local={};let settings={artworkShape:'rounded',artworkMotion:true,animatedBackground:true,fadeSpeed:1.035,fadeLeadMs:120,preferWordLyrics:true,silenceWordHighlight:true,volume:.8,animationSpeed:1,lyricsFontSize:32,lyricsBlur:35,lyricsTransparency:.6,lyricsAlbumBackground:true,trackOffsets:{},...(fixture.settings||{})};
  const eventTrack=(track,index=0,queue=tracks)=>{played=track;emit('track',{track,index,queue,device:'fixture'});emit('playback',{sequence:++sequence,position:0,duration:track.durationMs,playing:true,uri:track.openUri,track,index,repeat:0,shuffle:false});setTimeout(()=>emit('lyrics',{trackId:track.id,document:fixture.lyrics,offset:0}),50);};
  const open=id=>local[id]||{playlist:playlists.find(p=>p.id===id),tracks:tracks.filter(t=>t.source==='Spotify'),stable:true};
  async function respond(message){
    const{method,args:a,id}=message;calls.push({method,args:a,id});let result;
    try{
      switch(method){
        case 'boot':result={version:'0.16.0',personalProfile:personal,settings,profile:{name:'Conta de teste',id:'owner'},signedIn:true,configured:true,queue:tracks,index:0,history:[],recentSearches:['saved query']};break;
        case 'profile.get':result=personal;break;
        case 'profile.save':personal={...personal,name:a.name,bio:a.bio};result=personal;break;
        case 'profile.image.pick':personal={...personal,[a.kind]:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLbtAAAAABJRU5ErkJggg=='};result=personal;break;
        case 'profile.image.remove':personal={...personal,[a.kind]:null};result=personal;break;
        case 'discord.reconnect':result={status:'Conectando…'};setTimeout(()=>emit('discord',{status:'Conectado'}),60);break;
        case 'discord.status':result={status:'Conectado'};break;
        case 'updates.status':result={state:'idle',message:'Ainda não verificado.',enabled:settings.automaticUpdates!==false,installed:true,busy:false,ready:false};break;
        case 'updates.check':result={state:'checking',message:'Verificando atualizações…',installed:true,busy:true,ready:false};setTimeout(()=>emit('update',{state:'ready',message:'Atualização pronta. Será instalada ao sair.',version:'0.16.1',installed:true,busy:false,ready:true}),50);break;
        case 'updates.restart':result=true;break;
        case 'app.info':result={version:'0.16.0',system:'Windows x64',localAudio:true};break;
        case 'app.licenses':result='cncx · GPL-3.0\nRiff · MIT\nNAudio · MIT';break;
        case 'background.read':result=null;break;
        case 'window.tint':case 'window.minimize':result=true;break;
        case 'window.maximize':result={maximized:true};break;
        case 'playlist.read-session':{const p=playlists.find(p=>p.id===a.id);result={playlist:{...p,count:42},tracks:Array.from({length:42},(_,i)=>tracks[i%tracks.length]),stable:true,readOnly:true,access:'session',notice:'Leitura pela sessão Spotify'};break;}
        case 'clipboard.copy':result=true;break;
        case 'lyrics.refresh':emit('lyrics',{trackId:(played||tracks[0]).id,document:fixture.lyrics,offset:0});result=true;break;
        case 'playlists.list':result=[...Object.values(local).map(p=>p.playlist),...playlists];break;
        case 'playlists.local':result=Object.values(local).map(p=>p.playlist);break;
        case 'playlist.open':{
          let target=a.id;if(target.startsWith('https:'))target=target.split('/').pop();
          if(target==='blocked'){throw Error('O Spotify recusou a leitura desta playlist (403). Teste de permissão.');}
          if(target==='retry'){fixture.retried=(fixture.retried||0)+1;if(fixture.retried===1)throw Error('Falha temporária na rede.');target=playlists[0].id;}
          result=JSON.parse(JSON.stringify(open(target)));if(!result.playlist)throw Error('Playlist não encontrada.');
          emit('playlist.progress',{requestId:id,content:{...result,stable:false,tracks:result.tracks.slice(0,1)}});await new Promise(r=>setTimeout(r,150));break;}
        case 'playlist.create':{const pid=a.location==='local'?`local-${Date.now()}`:`0000000000000000000099`;result={id:pid,name:a.name,description:a.description,ownerId:'owner',ownerName:a.location==='local'?'Neste cncx':'Conta de teste',public:a.public,count:0};local[pid]={playlist:result,tracks:[],stable:true};break;}
        case 'playlist.update':{const p=local[a.id]||open(a.id);p.playlist.name=a.name;p.playlist.description=a.description;local[a.id]=p;result=true;break;}
        case 'playlist.add':{const p=local[a.id]||open(a.id);p.tracks.push(tracks.find(t=>t.id===a.trackId));p.playlist.count=p.tracks.length;local[a.id]=p;result=true;break;}
        case 'playlist.move':{const p=local[a.id]||open(a.id);const[t]=p.tracks.splice(a.from,1);p.tracks.splice(a.to,0,t);local[a.id]=p;result=true;break;}
        case 'playlist.remove':{const p=local[a.id]||open(a.id);p.tracks.splice(a.index,1);p.playlist.count=p.tracks.length;local[a.id]=p;result=true;break;}
        case 'playlist.delete':delete local[a.id];result=true;break;
        case 'search.history':result=['saved query'];break;
        case 'search.remember':case 'search.history.clear':result=true;break;
        case 'soundcloud.resolve':result={tracks:tracks.filter(t=>t.source==='SoundCloud')};break;
        case 'catalog.open':result={entity:fixture.entities.find(e=>`${e.source}|${e.kind}|${e.id}`===a.key),tracks:tracks.slice(0,2),entities:[],notice:'Catálogo de teste'};break;
        case 'search.catalog':{
          await new Promise(r=>setTimeout(r,a.query==='slow'?650:40));
          const filtered=tracks.filter(t=>a.source==='all'||t.source===a.source);
          const found=a.query==='slow'?[tracks[0]]:a.query==='fast'?[tracks[1]]:a.more?filtered.slice(2):filtered.slice(0,2);
          result={tracks:found,entities:(fixture.entities||[]).filter(e=>a.source==='all'||e.source===a.source),spotlight:{track:found[0]},nextSpotify:a.more||['fast','slow'].includes(a.query)||a.source==='SoundCloud'?null:2,nextSoundCloud:null,notices:[]};break;}
        case 'search':await new Promise(r=>setTimeout(r,a.query==='slow'?650:60));result={tracks:a.query==='slow'?[tracks[0]]:a.query==='fast'?[tracks[1]]:a.offset?tracks.slice(2):tracks.slice(0,2),nextOffset:a.offset||['slow','fast'].includes(a.query)?null:2,total:3};break;
        case 'queue.play':{const q=a.ids.map(id=>tracks.find(t=>t.id===id));eventTrack(q[a.index],a.index,q);result=true;break;}
        case 'playback.volume':settings.volume=a.volume;result=true;break;
        case 'playback.toggle':fixture.paused=!fixture.paused;emit('playback',{sequence:++sequence,position:2000,duration:played?.durationMs||tracks[0].durationMs,playing:!fixture.paused,uri:(played||tracks[0]).openUri,track:played||tracks[0],index:0,repeat:0,shuffle:false});result=true;break;
        case 'playback.seek':emit('playback',{sequence:++sequence,position:a.position,duration:tracks[0].durationMs,playing:false,uri:(played||tracks[0]).openUri,track:played||tracks[0],index:0,repeat:0,shuffle:false});result=true;break;
        case 'queue.mode':emit('playback',{sequence:++sequence,position:2000,duration:tracks[0].durationMs,playing:false,track:played||tracks[0],...a});result=true;break;
        case 'history':result=fixture.history||[];break;
        case 'history.clear':fixture.history=[];result=true;break;
        case 'lyrics.offset':result=a.offset;break;
        case 'settings.save':if(fixture.settingsSaveDelay)await new Promise(r=>setTimeout(r,fixture.settingsSaveDelay));settings={...settings,...a,spotifyClientId:a.clientId??settings.spotifyClientId,lyricsAlbumBackground:a.albumBackground??settings.lyricsAlbumBackground};result=settings;break;
        case 'account.connect':emit('account',{profile:{name:'Conectado',id:'owner'},signedIn:true});result=true;break;
        case 'external.open':result=true;break;
        default:throw Error('Test fixture: unexpected action '+method);
      }
      if(!canceled.has(id))emit('response',{id,ok:true,result});
    }catch(error){emit('response',{id,ok:false,error:error.message,code:a.id==='blocked'?'playlist_access':null,diagnostics:'Fixture: API 403'});}
  }
  window.chrome={...(window.chrome||{}),webview:{addEventListener(type,listener){if(type==='message')listeners.add(listener);},postMessage(message){bridgeMessages.push(message);if(message.type==='cancel'){canceled.add(message.id);return;}if(message.type==='request')respond(message);}}};
  window.__host={calls,bridgeMessages,emit,eventTrack,get local(){return local;},get sequence(){return sequence;},setPlayback(p){emit('playback',{sequence:++sequence,position:0,duration:tracks[0].durationMs,playing:false,track:played||tracks[0],index:0,...p});}};
};
