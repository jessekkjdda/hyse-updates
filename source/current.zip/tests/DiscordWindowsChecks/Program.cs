using System.Buffers.Binary;
using System.IO.Pipes;
using System.Text;
using System.Text.Json;
using GlassPlayer.Core;

if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException("This check requires real Windows named pipes.");
using var deadline=new CancellationTokenSource(TimeSpan.FromSeconds(25));var ct=deadline.Token;int passed=0;
void Check(bool value,string label){if(!value)throw new Exception(label);Interlocked.Increment(ref passed);Console.WriteLine("PASS: "+label);}
async Task<(int Op,byte[] Data)> ReadMessage(NamedPipeServerStream pipe)
{
    var bytes=new byte[65544];int n=await pipe.ReadAsync(bytes,ct);
    if(n<8||!pipe.IsMessageComplete||BinaryPrimitives.ReadInt32LittleEndian(bytes.AsSpan(4))!=n-8)throw new Exception("IPC header and payload must be one complete native pipe message.");
    return(BinaryPrimitives.ReadInt32LittleEndian(bytes),bytes.AsSpan(8,n-8).ToArray());
}
async Task Send(NamedPipeServerStream pipe,int opcode,byte[] data)
{
    var bytes=new byte[data.Length+8];BinaryPrimitives.WriteInt32LittleEndian(bytes,opcode);BinaryPrimitives.WriteInt32LittleEndian(bytes.AsSpan(4),data.Length);data.CopyTo(bytes,8);await pipe.WriteAsync(bytes,ct);await pipe.FlushAsync(ct);
}
async Task Ready(NamedPipeServerStream pipe)
{
    await pipe.WaitForConnectionAsync(ct);pipe.ReadMode=PipeTransmissionMode.Message;var packet=await ReadMessage(pipe);
    using var doc=JsonDocument.Parse(packet.Data);if(packet.Op!=0||doc.RootElement.GetProperty("client_id").GetString()!=DiscordActivity.ApplicationId)throw new Exception("Invalid handshake.");
    await Send(pipe,1,"{\"cmd\":\"DISPATCH\",\"evt\":\"READY\",\"data\":{}}"u8.ToArray());
}
NamedPipeServerStream Server(string name)=>new(name,PipeDirection.InOut,1,PipeTransmissionMode.Message,PipeOptions.Asynchronous);
string Name()=>"hyse-rpc-test-"+Guid.NewGuid().ToString("N");
async Task Ack(NamedPipeServerStream pipe,JsonElement message)=>await Send(pipe,1,JsonSerializer.SerializeToUtf8Bytes(new{cmd="SET_ACTIVITY",nonce=message.GetProperty("nonce").GetString()}));

string name=Name();await using(var server=Server(name))
{
    var serve=Task.Run(async()=>
    {
        await Ready(server);Check(true,"native Windows handshake receives a single complete frame");
        var message=await ReadMessage(server);using var doc=JsonDocument.Parse(message.Data);var args=doc.RootElement.GetProperty("args");
        Check(message.Op==1&&args.GetProperty("pid").GetInt32()==Environment.ProcessId&&args.GetProperty("activity").GetProperty("details").GetString()=="Native pipe test","native SET_ACTIVITY carries exact process and activity data");
        await Ack(server,doc.RootElement);await Send(server,3,"native-heartbeat"u8.ToArray());var pong=await ReadMessage(server);
        Check(pong.Op==4&&Encoding.UTF8.GetString(pong.Data)=="native-heartbeat","server-initiated heartbeat is answered over the real Windows pipe");
        await Send(server,2,"{\"code\":4002,\"message\":\"Rate limited\"}"u8.ToArray());
    },ct);
    await using var ipc=await DiscordIpc.OpenAsync(token=>DiscordIpc.ConnectWindowsPipeAsync(name,token),ct);
    await ipc.SetActivityAsync("{\"type\":2,\"details\":\"Native pipe test\",\"state\":\"Protocol check\"}",ct);
    await serve;while(!ipc.Disconnected)await Task.Delay(5,ct);
    Check(ipc.Failure is DiscordRpcError{Code:4002,Closed:true},"native CLOSE preserves the Discord code and reason");
}
string badName=Name(),goodName=Name();await using(var bad=Server(badName))await using(var good=Server(goodName))
{
    var release=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var badTask=Task.Run(async()=>{await bad.WaitForConnectionAsync(ct);bad.ReadMode=PipeTransmissionMode.Message;await ReadMessage(bad);await Send(bad,2,"{\"code\":4000,\"message\":\"Rejected test endpoint\"}"u8.ToArray());},ct);
    var goodTask=Task.Run(async()=>{await Ready(good);await release.Task.WaitAsync(ct);},ct);
    await using(var ipc=await DiscordIpc.OpenFirstAsync(new Func<CancellationToken,Task<Stream>>[]{token=>DiscordIpc.ConnectWindowsPipeAsync(badName,token),token=>DiscordIpc.ConnectWindowsPipeAsync(goodName,token)},ct))
        Check(ipc.Endpoint=="discord-ipc-1","a rejected Windows endpoint falls through to the next completed handshake");
    release.SetResult();await Task.WhenAll(badTask,goodTask);
}
string idleName=Name();await using(var server=Server(idleName))
{
    var acknowledged=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var release=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var serve=Task.Run(async()=>{await Ready(server);var message=await ReadMessage(server);using var doc=JsonDocument.Parse(message.Data);if(doc.RootElement.GetProperty("args").GetProperty("activity").ValueKind!=JsonValueKind.Null)throw new Exception("Expected idle activity clear.");await Ack(server,doc.RootElement);acknowledged.SetResult();await release.Task.WaitAsync(ct);},ct);
    var presence=new DiscordPresence(token=>DiscordIpc.ConnectWindowsPipeAsync(idleName,token));
    try{presence.Update(true,null);await acknowledged.Task.WaitAsync(ct);while(!presence.State.Connected)await Task.Delay(5,ct);Check(true,"enabled presence connects on Windows before music playback");}
    finally{presence.Dispose();await presence.Completion;release.SetResult();await serve;}
}
Console.WriteLine($"{passed} Windows IPC checks passed.");
