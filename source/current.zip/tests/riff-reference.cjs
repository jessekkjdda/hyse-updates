// Unmodified Riff math/layout functions, MIT © 2026 rootscripts.
// Reference commit 5031a840fb50dbb53a5830329ed69363fe09d824.
const PUNCT_OR_SPACE_REGEX=/^[\s\p{P}]$/u,CJK_REGEX=/^[\p{sc=Han}\p{sc=Hiragana}\p{sc=Katakana}\p{sc=Hangul}]$/u,MARK_REGEX=/^\p{M}$/u;
const CYRILLIC_VOWELS=new Set('аеёиоуыэюяєіїўѣѵѫѧѩѭ'),LATIN_VOWEL_EXTRA=new Set(['æ','ø','œ','ı']);
let gradientLineCache={},bounds={start:0,end:1},manualLyricsOffset=0;
const el={nativeAudio:{currentTime:0}},state={isCustomLyrics:false,isPlaying:true,isTvKaraokeOpen:false};
const CASCADE_CONFIG={anchorY:35,delayStep:35,maxDelay:180,duration:1.15,bezier:'cubic-bezier(0.22, 1, 0.36, 1)',blurStep:1.3,maxBlur:6,pastOpacity:.12};
const document={body:{classList:{contains:()=>false}},getElementById:()=>null},window={matchMedia:()=>({matches:false})};
function getLineStartTime(){return bounds.start;}function getLineEndTime(){return bounds.end;}
  function getEffectiveLineDuration(idx) {
    const start = getLineStartTime(idx);
    const rawDur = Math.max(0.45, getLineEndTime(idx) - start);
    const breathTail = rawDur > 2.2 ? Math.min(0.12, rawDur * 0.03) : 0;
    return Math.max(0.40, rawDur - breathTail);
  }
  function getCharBaseWeight(c, nextChar = '') {
    if (c === ',' || c === ';' || c === ':' || c === '、' || c === '，' || c === '；') return 4.6;
    if (c === '.' || c === '!' || c === '?' || c === '—' || c === '–' || c === '-' || c === '―' || c === '‒' || c === '。' || c === '！' || c === '？' || c === '…') return 5.8;
    if (c === '.' && nextChar === '.') return 6.0;
    if (PUNCT_OR_SPACE_REGEX.test(c)) return 0.55;
    if (CJK_REGEX.test(c)) return 2.8;
    if (MARK_REGEX.test(c)) return 2.6;
    const lower = c.toLowerCase();
    if (CYRILLIC_VOWELS.has(lower)) return 2.5;
    const base = c.normalize('NFD')[0].toLowerCase();
    if ('aeiouy'.includes(base) || LATIN_VOWEL_EXTRA.has(lower)) return 2.5;
    return 1.0;
  }
  function getLineGradientWeights(lineEl, idx, text) {
    if (gradientLineCache.lineEl === lineEl && gradientLineCache.lineIdx === idx && gradientLineCache.text === text) {
      return gradientLineCache;
    }
    const chars = Array.from(text);
    const N = chars.length;
    if (N === 0) {
      gradientLineCache = { lineEl, lineIdx: idx, text, N: 0, cumWeights: null, totalWeight: 0 };
      return gradientLineCache;
    }
    const cumWeights = new Float64Array(N + 1);
    cumWeights[0] = 0;
    let total = 0;
    for (let i = 0; i < N; i++) {
      let w = getCharBaseWeight(chars[i], chars[i + 1] || '');
      if (i >= N - 2) w *= 1.18;
      total += w;
      cumWeights[i + 1] = total;
    }
    gradientLineCache = { lineEl, lineIdx: idx, text, N, cumWeights, totalWeight: total };
    return gradientLineCache;
  }
  function updateActiveGradient(targetLineEl) {
    const lineEl = targetLineEl || document.querySelector('.lyric-line.active.gradient-line');
    if (!lineEl || !el.nativeAudio) return;
    if (!lineEl._fillMain) {
      lineEl._fillMain = lineEl.querySelector('.lyric-fill-main') || lineEl.firstElementChild;
    }
    const fillMain = lineEl._fillMain;
    if (!fillMain) return;
    if (lineEl._fillParen === undefined) {
      lineEl._fillParen = lineEl.querySelector('.lyric-fill.lyric-paren');
    }
    const fillParen = lineEl._fillParen;

    const idx = parseInt(lineEl.id.replace('lyric-line-', ''), 10);
    const start = getLineStartTime(idx);
    const dur = getEffectiveLineDuration(idx);
    const t = el.nativeAudio.currentTime + (state.isCustomLyrics ? 0.25 : 0);
    const tau = Math.min(1, Math.max(0, (t - start) / dur));

    const mainStr = fillMain.textContent || '';
    const parenStr = fillParen ? (fillParen.textContent || '') : '';
    const fullText = mainStr + parenStr;
    const cache = getLineGradientWeights(lineEl, idx, fullText);

    let k = tau;
    if (cache.N > 0 && cache.totalWeight > 0) {
      if (tau <= 0) k = 0;
      else if (tau >= 1) k = 1;
      else {
        const tw = tau * cache.totalWeight;
        const cw = cache.cumWeights;
        const N = cache.N;
        let low = 0, high = N - 1, i = 0;
        while (low <= high) {
          const mid = (low + high) >> 1;
          if (cw[mid + 1] <= tw) low = mid + 1;
          else if (cw[mid] > tw) high = mid - 1;
          else { i = mid; break; }
        }
        const charWeight = cw[i + 1] - cw[i];
        const pi = charWeight > 0 ? (tw - cw[i]) / charWeight : 0;
        k = Math.min(1, Math.max(0, (i + pi) / N));
      }
    }

    if (lineEl._kwEl === undefined) {
      lineEl._kwEl = lineEl.querySelector('.lyric-keyword') || null;
    }
    if (lineEl._kwEl) {
      const rStart = parseFloat(lineEl._kwEl.dataset.kwStartRatio ?? '-1');
      const rEnd = parseFloat(lineEl._kwEl.dataset.kwEndRatio ?? '-1');
      let isKwActive = false;
      if (rStart >= 0 && rEnd >= 0) {
        isKwActive = (k >= rStart - 0.02 && k <= rEnd + 0.05);
      } else {
        const kwStart = parseFloat(lineEl._kwEl.dataset.kwStart || '0');
        const kwEnd = parseFloat(lineEl._kwEl.dataset.kwEnd || '0');
        isKwActive = (t >= kwStart - 0.02 && t <= kwEnd + 0.08);
      }
      lineEl._kwEl.classList.toggle('keyword-active', isKwActive);
    }

    if (Math.abs(k - (lineEl._lastK ?? -1)) < 0.0015) return;
    lineEl._lastK = k;

    if (fillParen && parenStr.length > 0) {
      const pStart = parseFloat(fillParen.dataset.startRatio || '0.7');
      const pEnd = Math.max(pStart + 0.1, parseFloat(fillParen.dataset.endRatio || '1.0'));
      const kMain = Math.min(1, Math.max(0, k));
      const kParen = Math.min(1, Math.max(0, (k - pStart) / (pEnd - pStart)));
      fillMain.style.setProperty('--k', kMain.toFixed(4));
      fillParen.style.setProperty('--k', kParen.toFixed(4));
    } else {
      fillMain.style.setProperty('--k', k.toFixed(4));
    }
  }
  function layoutLyricsCascade(activeIndex, snap = false) {
    const container = el.lyricsContainer;
    if (!container) return;
    const lines = container.querySelectorAll('.lyric-line');
    const n = lines.length;
    if (n === 0) return;

    container.style.position = 'relative';

    const containerW = container.clientWidth;
    const heights = new Array(n);
    for (let i = 0; i < n; i++) {
      const line = lines[i];
      if (!line._cachedH || container._lastCascadeW !== containerW) {
        line._cachedH = line.offsetHeight;
      }
      heights[i] = line._cachedH;
    }
    container._lastCascadeW = containerW;

    const containerH = container.clientHeight || container.parentElement?.clientHeight || 400;
    const a = activeIndex >= 0 ? Math.min(activeIndex, n - 1) : 0;
    const anchor = containerH * (CASCADE_CONFIG.anchorY / 100);
    const tvElement = el.tvKaraoke || document.getElementById('tv-karaoke');
    const isTvk = !!(state.isTvKaraokeOpen || (tvElement && tvElement.contains(container)));
    let baseGap = 16;
    if (isTvk) {
      const tvkS = typeof getTvk === 'function' ? getTvk() : null;
      const rawG = tvkS && tvkS.gap !== undefined ? Number(tvkS.gap) : 16;
      baseGap = (!isNaN(rawG) ? rawG : 16) * 2;
    }
    const extraMargin = baseGap * 1.0;

                         
    const targets = new Array(n);

    let y = anchor;
    for (let i = a; i < n; i++) {
      const dist = activeIndex >= 0 ? (i - a) : i;
      targets[i] = { y, dist, past: false };
      y += heights[i] + baseGap + (i === a ? extraMargin : 0);
    }

    y = anchor;
    for (let i = a - 1; i >= 0; i--) {
      y -= heights[i] + baseGap;
      const dist = activeIndex >= 0 ? (a - i) : (i + 1);
      targets[i] = { y, dist, past: true };
    }

                      
    const isPerf = document.body.classList.contains('perf') || (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

    if (snap) {
      container.classList.add('no-transition');
    }

    for (let i = 0; i < n; i++) {
      const line = lines[i];
      const t = targets[i];
      line._baseY = t.y;
      const finalY = Math.round(t.y + manualLyricsOffset);
      const delay = isPerf ? 0 : Math.min(t.dist * CASCADE_CONFIG.delayStep, CASCADE_CONFIG.maxDelay);
      const blur = (isPerf || t.dist === 0) ? 0 : Math.min(t.dist * CASCADE_CONFIG.blurStep, CASCADE_CONFIG.maxBlur);
      const opacity = t.dist === 0 ? 1 : (t.past ? CASCADE_CONFIG.pastOpacity : Math.max(0.45 - t.dist * 0.1, 0.08));

      if (line._lastFinalY !== finalY) {
        line._lastFinalY = finalY;
        line.style.setProperty('--y', `${finalY}px`);
      }
      if (line._lastBlur !== blur) {
        line._lastBlur = blur;
        line.style.setProperty('--blur', `${blur.toFixed(2)}px`);
      }
      const opStr = opacity.toFixed(3);
      if (line._lastOpacity !== opStr) {
        line._lastOpacity = opStr;
        line.style.setProperty('--opacity', opStr);
      }
      if (line._lastDelay !== delay) {
        line._lastDelay = delay;
        line.style.setProperty('--delay', `${delay}ms`);
      }
      if (!line._hasDur) {
        line.style.setProperty('--duration', `${CASCADE_CONFIG.duration}s`);
        line.style.setProperty('--bezier', CASCADE_CONFIG.bezier);
        line._hasDur = true;
      }
    }

    if (snap) {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          container.classList.remove('no-transition');
        });
      });
    }
  }
module.exports={gradient(text,position,start,end){bounds={start:start/1000,end:end/1000};el.nativeAudio.currentTime=position/1000;let value=0;const line={id:'lyric-line-0',_fillMain:{textContent:text,style:{setProperty:(k,v)=>value=Number(v)}},_fillParen:null,_kwEl:null};updateActiveGradient(line);return value;},layout(heights,active,height){const rows=heights.map(offsetHeight=>({offsetHeight,style:{values:{},setProperty(k,v){this.values[k]=v;}}}));el.lyricsContainer={style:{},clientWidth:640,clientHeight:height,querySelectorAll:()=>rows,classList:{add(){},remove(){}}};layoutLyricsCascade(active,false);return rows.map(r=>r.style.values);}};
