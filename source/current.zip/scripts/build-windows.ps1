$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Push-Location $projectRoot
try {
    npm ci
    if ($LASTEXITCODE -ne 0) { throw 'A instalação das dependências falhou.' }
    node scripts/build-liner.cjs
    if ($LASTEXITCODE -ne 0) { throw 'O bundle original do Liner falhou.' }
    node scripts/check-compat.cjs
    if ($LASTEXITCODE -ne 0) { throw 'A verificação das bases falhou.' }
    node --experimental-vm-modules scripts/check-web.cjs
    if ($LASTEXITCODE -ne 0) { throw 'Os testes de módulos falharam.' }
    node scripts/check-preservation.cjs
    if ($LASTEXITCODE -ne 0) { throw 'A preservação da versão aprovada falhou.' }
    node scripts/check-fallback.cjs
    if ($LASTEXITCODE -ne 0) { throw 'Os testes do fade por linha falharam.' }
    node scripts/check-wave.cjs
    if ($LASTEXITCODE -ne 0) { throw 'Os testes da ondulação falharam.' }
    node scripts/check-media-clock.cjs
    if ($LASTEXITCODE -ne 0) { throw 'Os testes do relógio original falharam.' }
    node scripts/check-liner.cjs
    if ($LASTEXITCODE -ne 0) { throw 'Os testes do motor original falharam.' }
    node scripts/check-frame-metrics.cjs
    if ($LASTEXITCODE -ne 0) { throw 'Os diagnósticos de quadros falharam.' }
    node scripts/check-volume.cjs
    if ($LASTEXITCODE -ne 0) { throw 'O volume durante arraste falhou.' }
    node scripts/check-collections.cjs
    if ($LASTEXITCODE -ne 0) { throw 'A busca dentro das listas falhou.' }
    node scripts/check-dom.cjs
    if ($LASTEXITCODE -ne 0) { throw 'Os testes DOM falharam.' }
    $spicyFixturePath = Join-Path $projectRoot 'artifacts/checks/spicy-transport.json'
    $previousSpicyFixture = $env:CNCX_SPICY_FIXTURE_OUTPUT
    try {
        $env:CNCX_SPICY_FIXTURE_OUTPUT = $spicyFixturePath
        dotnet run --project tests/CoreChecks -c Release
    } finally { $env:CNCX_SPICY_FIXTURE_OUTPUT = $previousSpicyFixture }
    if ($LASTEXITCODE -ne 0) { throw 'Os testes falharam.' }
    node scripts/check-spicy.cjs $spicyFixturePath
    if ($LASTEXITCODE -ne 0) { throw 'A integração local do Spicy falhou.' }
    dotnet restore GlassPlayer/GlassPlayer.csproj -r win-x64 --locked-mode
    if ($LASTEXITCODE -ne 0) { throw 'A restauração falhou.' }
    dotnet publish GlassPlayer/GlassPlayer.csproj -c Release -r win-x64 --self-contained true --no-restore -p:PublishSingleFile=false -p:PublishTrimmed=false -o artifacts/hyse-windows-x64
    if ($LASTEXITCODE -ne 0) { throw 'A compilação falhou.' }
    dotnet publish UpdateHelper/UpdateHelper.csproj -c Release -r win-x64 --self-contained true -o artifacts/update-helper
    if ($LASTEXITCODE -ne 0) { throw 'A compilação do atualizador falhou.' }
    Copy-Item artifacts/update-helper/hyse-update.exe artifacts/hyse-windows-x64/hyse-update.exe -Force
    foreach ($notice in @('LICENSE', 'NOTICE.md', 'THIRD_PARTY.md', 'README.md')) {
        Copy-Item $notice (Join-Path 'artifacts/hyse-windows-x64' $notice) -Force
    }
    if (Test-Path 'licenses') { Copy-Item 'licenses' 'artifacts/hyse-windows-x64' -Recurse -Force }
    Write-Host 'Pronto: artifacts\hyse-windows-x64\hyse.exe'
} finally { Pop-Location }
