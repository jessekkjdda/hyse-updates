const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const source=fs.readFileSync(path.join(__dirname,'../GlassPlayer/Web/frame-metrics.js'),'utf8').replace('export class','class')+'\nglobalThis.Subject=FrameMetrics;';
const scope={};vm.runInNewContext(source,scope);const FrameMetrics=scope.Subject;let passed=0;
function check(v,label){assert.ok(v,label);passed++;console.log('PASS: '+label);}
const metrics=new FrameMetrics(20);metrics.sample(0,1);for(let i=1;i<=20;i++)metrics.sample(i*20,2);
let s=metrics.snapshot();check(s.samples===20&&s.fps===50&&s.p95Ms===20&&s.slowFrames===0,'steady frame intervals report their measured rate and percentile');
metrics.sample(500,7);s=metrics.snapshot();check(s.samples===20&&s.worstMs===100&&s.slowFrames===1,'a long frame is retained as a stall in the bounded rolling window');
metrics.sample(600,8);check(metrics.snapshot().p95Ms===100,'P95 exposes repeated stalls even when average FPS masks them');
metrics.sample(10000,0,false);metrics.sample(20000,0,true);check(metrics.snapshot().worstMs===100,'hidden-window time is not counted as a foreground rendering stall');
metrics.reset();check(metrics.snapshot()===null,'visibility reset discards the obsolete measurement window');
metrics.sample(0,0);metrics.sample(1500,4);check(metrics.snapshot().worstMs===1500,'a real visible 1.5 second stall is retained without clipping');
metrics.reset();metrics.sample(0);metrics.sample(16,NaN);check(metrics.snapshot().workP95Ms===0,'invalid work samples cannot pollute the numeric output');
for(let i=2;i<=1000;i++)metrics.sample(i*16,1);check(metrics.snapshot().samples===20&&metrics.intervals.length===20,'long sessions retain only the configured sample capacity');
check(metrics.snapshot().workP95Ms===1,'JS work is measured separately from callback spacing');
console.log(`\n${passed} frame-metric checks passed.`);
