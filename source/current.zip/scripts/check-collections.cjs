const assert=require('node:assert/strict'),esbuild=require('esbuild'),vm=require('node:vm'),path=require('node:path');
const result=esbuild.buildSync({entryPoints:[path.join(__dirname,'../GlassPlayer/Web/collection-filter.js')],bundle:true,platform:'node',format:'cjs',write:false});
const moduleValue={exports:{}};vm.runInNewContext(result.outputFiles[0].text,{module:moduleValue,exports:moduleValue.exports});
const{matchesCollection,filterTracks}=moduleValue.exports;let count=0;
function check(value,label){assert.ok(value,label);count++;console.log('PASS: '+label);}
check(matchesCollection('cancao','Canção'),'playlist matching ignores accents');
check(matchesCollection('ARTISTA azul','Álbum Azul','Artista'),'terms can span title and artist');
check(!matchesCollection('azul ausente','Álbum Azul'),'every search term must match');
check(matchesCollection('  \t ','Any playlist'),'blank query preserves all rows');
check(matchesCollection('[demo]','[Demo]'),'punctuation stays literal, without a regular expression');
const same={id:'same',title:'Água',artist:'Singer',albumName:'Noite',source:'Spotify'},other={id:'other',title:'Fogo',artist:'Cloud',source:'SoundCloud'};
const tracks=[same,other,same],filtered=filterTracks(tracks,'AGUA');
check(filtered.length===2&&filtered[0].index===0&&filtered[1].index===2,'duplicate song occurrences retain their distinct source indices');
check(filtered[1].track===same&&tracks.length===3&&tracks[1]===other,'filtering preserves track identity and the original queue order');
check(filterTracks(tracks,'Noite Singer').length===2,'album and artist participate in playlist search');
check(filterTracks(tracks,'soundcloud')[0].index===1,'mixed local lists can be filtered by provider');
check(filterTracks(tracks,'nothing').length===0,'unmatched query produces an empty result');
console.log(`\n${count} collection-search checks passed.`);
