// Production frontend modules tested with a native bridge and SDK double.
// These are module/protocol checks, not browser rendering or live Spotify tests.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
let passed=0;const check=(value,name)=>{assert.ok(value,name);passed++;console.log('PASS: '+name);};
const messages=[],listeners=new Set(),intervals=new Map(),players=[];let intervalId=0;
class Player{
  constructor(options){this.options=options;this.listeners={};this.state=null;players.push(this);}
  addListener(name,callback){this.listeners[name]=callback;}
  async connect(){this.options.getOAuthToken(token=>this.token=token);return true;}
  disconnect(){this.disconnected=true;}
  getCurrentState(){return Promise.resolve(this.state);}
  async pause(){this.paused=true;}
  async resume(){this.paused=false;}
  async seek(ms){this.position=ms;}
  async setVolume(volume){this.volume=volume;}
}
const win={chrome:{webview:{postMessage:m=>messages.push(m),addEventListener:(_,fn)=>listeners.add(fn)}},Spotify:{Player},addEventListener(){}};
const context=vm.createContext({window:win,console,performance,DOMException,AbortController,setTimeout,clearTimeout,setInterval:fn=>{let id=++intervalId;intervals.set(id,fn);return id;},clearInterval:id=>intervals.delete(id),Image:class{},document:{documentElement:{},querySelector(){}}});
const modules=new Map();async function load(name){if(modules.has(name))return modules.get(name);const source=fs.readFileSync(path.join(__dirname,'../GlassPlayer/Web',name),'utf8');const m=new vm.SourceTextModule(source,{context,identifier:name});modules.set(name,m);await m.link(spec=>load(path.posix.join(path.posix.dirname(name),spec)));await m.evaluate();return m;}
function reply(id,result,ok=true){for(const fn of listeners)fn({data:{type:'response',data:{id,ok,result,error:ok?undefined:result}}});}
const tick=()=>new Promise(setImmediate);
(async()=>{
 const bridge=(await load('bridge.js')).namespace;
 const first=bridge.request('first'),second=bridge.request('second');reply(second.requestId,2);reply(first.requestId,1);check(await first===1&&await second===2,'out-of-order RPC replies resolve only their own request');
 const controller=new AbortController(),cancel=bridge.request('slow',{},controller.signal);const rejected=cancel.catch(e=>e.name);controller.abort();reply(cancel.requestId,'obsolete');check(await rejected==='AbortError'&&messages.some(m=>m.type==='cancel'&&m.id===cancel.requestId),'cancelled requests notify native and ignore late replies');
 const error=bridge.request('failed');const fail=error.catch(e=>e.message);reply(error.requestId,'Exact API failure',false);check(await fail==='Exact API failure','native failure text reaches the frontend without disappearing');
 let received=0;const off=bridge.on('progress',n=>received+=n);for(const listener of listeners)listener({data:{type:'progress',data:2}});off();for(const listener of listeners)listener({data:{type:'progress',data:3}});check(received===2,'event listeners unsubscribe cleanly on teardown');
 const lyric=(await load('lyrics.js')).namespace;const lines=[{timeMs:1000,endMs:5000,text:'Hold breathe'},{timeMs:9000,endMs:10000,text:'Return'}];
 check(lyric.activeLine(lines,999)===-1&&lyric.activeLine(lines,1000)===0,'lyric renderer never activates a phrase before its source time');
 check(lyric.activeLine(lines,5000)===-1&&lyric.activeLine(lines,8999)===-1,'explicit breath and instrumental intervals clear the active line');
 check(lyric.activeLine(lines,9000)===1&&lyric.activeLine(lines,10000)===-1,'seek boundaries honor line starts and explicit ends');
 check(lyric.activeLine([{timeMs:0,text:'a'},{timeMs:1000,text:''},{timeMs:5000,text:'b'}],2000)===-1,'blank LRC markers preserve vocal gaps');
 const word={startMs:4000,endMs:5000};check(lyric.wordProgress(word,3999)===0&&lyric.wordProgress(word,4500)===.5&&lyric.wordProgress(word,6000)===1,'word gradient follows true start/end times and never guesses a breath');
 check(lyric.wordProgress({startMs:4000,endMs:4000},3999)===0&&lyric.wordProgress({startMs:4000,endMs:4000},4001)===1,'zero-duration timestamp markers stay bounded');
 let previous=-1;for(let i=0;i<=100;i++){const x=lyric.bezier(i/100);assert.ok(x>=previous-1e-4&&x>=0&&x<=1);previous=x;}check(true,'Riff-derived lyric easing remains monotonic and bounded');
 const riff=require('../tests/riff-reference.cjs');
 for(const text of ['Hold breathe','Fast, quick!','Açúcar e café…','日本語の歌','Привет — мир']){const weights=lyric.gradientWeights(text);for(let ms=0;ms<=8000;ms+=25){assert.ok(Math.abs(lyric.gradientProgress(weights,ms,1000,6000)-riff.gradient(text,ms,1000,6000))<=.000051,`${text} at ${ms}`);}}check(true,'restored fade matches the 0.8/Riff reference across languages and fast progression');
 const timed=[{timeMs:1000,endMs:5000,text:'Hold breathe',words:[{text:'Hold ',startMs:1000,endMs:1600},{text:'breathe',startMs:4000,endMs:5000}]},{timeMs:9000,endMs:10000,text:'Return'}];
 check(lyric.holdTarget(timed,999)==null&&lyric.holdTarget(timed,3000)?.token===0&&lyric.holdTarget(timed,6000)?.token===1,'silence selection uses already completed real word timestamps when supplied');
 const plain=[{timeMs:1000,text:'One two three four'},{timeMs:9000,text:'Return'}];
 const fallback=lyric.holdTarget(plain,5000);check(fallback?.line===0&&fallback.token<3,'line-only silence keeps a token already painted by the fade rather than revealing the final future word');
 check(lyric.holdTarget([{timeMs:1000,endMs:5000,text:'Hello world'}],1300)?.token===0,'a partly painted first word can be held without exposing a later word');
 check(lyric.holdTarget(plain,9000)===null,'the next phrase is never highlighted before its first token is painted');
 check(lyric.holdTarget([{timeMs:1000,endMs:2000,text:'   One   two!  '}],3000)?.token===1,'trailing whitespace and punctuation retain exactly the last word');
 check(lyric.holdTarget([{timeMs:1000,endMs:2000,text:'<b> & último'}],3000)?.token===2,'untrusted text remains text rather than lyric markup');
 const Timeline=(await load('timeline.js')).namespace.PlaybackTimeline;let timestamp=0;const tc=new Timeline(()=>timestamp);
 tc.sample({uri:'one',position:1000,duration:10000,playing:true},true);timestamp=160;check(tc.current===1160,'local device samples advance on animation frames without a native round trip');
 tc.sample({uri:'one',position:1000,duration:10000,playing:true},true);timestamp=220;check(tc.current===1220,'duplicate device positions do not hold or restart the visual timeline');
 check(!tc.sample({uri:'one',position:1050,duration:10000,playing:true})&&tc.current===1220,'slower native samples do not override a fresh local device clock');
 tc.seek(6000);check(!tc.sample({uri:'one',position:1300,duration:10000,playing:true},true)&&tc.current===6000,'late pre-seek device data cannot pull the lyric backwards');
 tc.sample({uri:'one',position:6100,duration:10000,playing:false},true);timestamp=1000;check(tc.current===6100,'pause freezes the confirmed timeline');
 check(lyric.holdTarget(timed,4500)?.token===1,'silence holds the sustained word that already started rather than jumping to an earlier completed word');
 const presentation=(await load('presentation.js')).namespace;check(presentation.formatSetting(33.006289308176086,' px')==='33 px','settings hide floating point artifacts from imported preferences');
 for(const shape of ['rounded','square','circle','squircle','petal'])check(presentation.coverShape(shape).radius!=null&&!presentation.coverShape(shape).clip.includes('NaN'),'cover customization produces valid '+shape+' geometry');
 const theme=(await load('theme.js')).namespace;for(const rgb of [[0,0,0],[255,255,255],[12,100,180]]){const p=theme.palette(...rgb);assert.equal(Object.keys(p).length,8);assert.ok(Object.values(p).every(v=>!v.includes('NaN')));}check(true,'dark, light and saturated covers all produce complete readable surface palettes');
 await load('sdk.js');await win.cncxSdk.start();await tick();const tokenRequest=messages.filter(m=>m.method==='sdk.token').at(-1);reply(tokenRequest.id,'fixture-token');await tick();check(players[0].token==='fixture-token','Spotify token callback uses the native RPC without persistent frontend storage');
 players[0].listeners.ready({device_id:'fixture-device'});check(messages.some(m=>m.type==='sdk-ready'&&m.device==='fixture-device'),'SDK ready publishes the real device ID to native playback');
 players[0].listeners.player_state_changed({paused:false,position:179500,duration:180000,track_window:{current_track:{uri:'spotify:track:fixture'}}});players[0].listeners.player_state_changed({paused:true,position:0,duration:180000,track_window:{current_track:{uri:'spotify:track:fixture'}}});players[0].listeners.player_state_changed({paused:true,position:0,duration:180000,track_window:{current_track:{uri:'spotify:track:fixture'}}});check(messages.filter(m=>m.type==='sdk-ended').length===1,'natural completion advances once even when reset samples repeat');
 await win.cncxSdk.command({id:'pause',method:'pause'});await win.cncxSdk.command({id:'seek',method:'seek',value:3450});check(players[0].paused&&players[0].position===3450&&messages.some(m=>m.type==='sdk-command'&&m.id==='seek'&&m.ok),'pause and seek acknowledge completion after the SDK accepts them');
 await win.cncxSdk.command({id:'invalid',method:'removeAllData'});check(messages.some(m=>m.type==='sdk-command'&&m.id==='invalid'&&!m.ok),'SDK command bridge rejects methods outside the playback allowlist');
 const interval=[...intervals.values()][0];let finish;players[0].getCurrentState=()=>new Promise(resolve=>finish=resolve);const oldSample=interval();win.cncxSdk.reset();const count=messages.length;finish({paused:false,position:0,duration:1000,track_window:{current_track:{uri:'stale'}}});await oldSample;check(players[0].disconnected&&intervals.size===0&&messages.length===count,'reset disconnects the SDK and discards an in-flight sample');
 // Syntax-check the full app module without pretending Node can validate layout.
 new vm.SourceTextModule(fs.readFileSync(path.join(__dirname,'../GlassPlayer/Web/app.js'),'utf8'),{context});check(true,'application ES module parses with its production syntax');
 console.log(`\n${passed} frontend module checks passed.`);
})().catch(e=>{console.error(e);process.exitCode=1;});
