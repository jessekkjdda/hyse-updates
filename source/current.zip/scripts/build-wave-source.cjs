// Spicy Lyrics, AGPL-3.0: extract original animation math, isolate DOM metrics.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),vendor=path.join(root,'vendor/spicy-wave');
function verifyWave(){const m=JSON.parse(fs.readFileSync(path.join(vendor,'manifest.json'),'utf8'));for(const f of m.files){const b=fs.readFileSync(path.join(vendor,f.local));if(crypto.createHash('sha1').update('blob '+b.length+'\0').update(b).digest('hex')!==f.sha)throw Error('Wave upstream source changed: '+f.path);}return m;}
function extractWave(){
 verifyWave();const original=fs.readFileSync(path.join(vendor,'original/LyricsAnimator.ts'),'utf8');
 const start=original.indexOf('const RefreshedEmphasis = {'),end=original.indexOf('// A word sung in several split syllables',start);if(start<0||end<start)throw Error('Wave extraction anchors changed');
 let body=original.slice(start,end);
 const type='type SplitLetter = NonNullable<SyllableLead["Letters"]>[number];';if(!body.includes(type))throw Error('Wave letter contract changed');body=body.replace(type,'type SplitLetter = WaveLetter;');
 const a=body.indexOf("// Split letters' widths in em, measured once."),b=body.indexOf('// Every letter of the word this frame',a);if(a<0||b<a)throw Error('Wave width adapter anchor changed');
 body=body.slice(0,a)+'// Canvas supplies measured widths in em; no DOM reads per frame.\nconst getLetterWidthsEm = (letters: SplitLetter[]) => letters.map(letter => letter.WidthEm);\n\n'+body.slice(b);
 return '// Derived from Spicy Lyrics, AGPL-3.0. Extracted at build time.\n// See vendor/spicy-wave/manifest.json and licenses/Spicy-Lyrics-LICENSE.txt.\nimport {cubicBezier} from "../vendor/spicy-wave/original/CubicBezier";\nexport interface WaveLetter {StartTime:number;WidthEm:number;}\nconst Clamp = (value:number,min:number,max:number)=>Math.max(min,Math.min(value,max));\n'+body+'\nexport {getRefreshedFlame,getRefreshedWaveStrength,getRefreshedLift,RefreshedEmphasis,RefreshedLift};\n';
}
const wavePlugin={name:'hyse-spicy-wave-source',setup(build){build.onResolve({filter:/spicy-wave-source$/},()=>({path:'spicy-wave-source',namespace:'spicy-wave'}));build.onLoad({filter:/.*/,namespace:'spicy-wave'},()=>({contents:extractWave(),loader:'ts',resolveDir:path.join(root,'integration')}));build.onResolve({filter:/utils\/stores\.ts$/},args=>args.importer.endsWith('/spicy-wave/original/IsLetterCapable.ts')?{path:path.join(root,'integration/spicy-wave-style.ts')}:null);}};
module.exports={verifyWave,extractWave,wavePlugin};
if(require.main===module){verifyWave();console.log('7 original Spicy wave files verified.');}
