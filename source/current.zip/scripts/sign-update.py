#!/usr/bin/env python3
"""Create the signed hyse feed from the exact installer that will be published."""
import argparse
import hashlib
import json
import re
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--installer', required=True)
    parser.add_argument('--private-key', required=True)
    parser.add_argument('--output-dir', required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    version = ET.parse(root / 'GlassPlayer/GlassPlayer.csproj').findtext('.//Version')
    if not re.fullmatch(r'(0|[1-9][0-9]{0,4})\.(0|[1-9][0-9]{0,4})\.(0|[1-9][0-9]{0,4})', version):
        raise ValueError('Invalid release version')
    installer = Path(args.installer).resolve()
    key = Path(args.private_key).resolve()
    output = Path(args.output_dir).resolve()
    if key.is_relative_to(root):
        raise ValueError('The private signing key must stay outside corresponding source')
    if installer.name != f'hyse-{version}-Setup.exe':
        raise ValueError('Installer filename does not match project version')
    data = installer.read_bytes()
    if not 1024 <= len(data) <= 256 * 1024 * 1024 or data[:2] != b'MZ':
        raise ValueError('Not a supported Windows installer')
    trust = (root / 'GlassPlayer/Core/UpdateTrust.cs').read_text()
    expected = re.search(r'-----BEGIN PUBLIC KEY-----.*?-----END PUBLIC KEY-----', trust, re.S).group()
    actual = subprocess.check_output(['openssl', 'pkey', '-in', str(key), '-pubout'], text=True).strip()
    if actual != expected:
        raise ValueError('Signing key does not match the key pinned in the desktop and helper')
    manifest = {
        'schema': 1, 'product': 'hyse', 'platform': 'windows-x64', 'version': version,
        'downloadUrl': f'https://github.com/jessekkjdda/hyse-updates/releases/download/v{version}/{installer.name}',
        'sizeBytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()
    }
    output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='hyse-feed-') as temp:
        raw, sig, pub = (Path(temp) / name for name in ('hyse-update.json', 'hyse-update.sig', 'public.pem'))
        raw.write_text(json.dumps(manifest, ensure_ascii=True, separators=(',', ':')) + '\n')
        pub.write_text(expected + '\n')
        subprocess.run(['openssl', 'dgst', '-sha256', '-sign', str(key), '-out', str(sig), str(raw)], check=True)
        subprocess.run(['openssl', 'dgst', '-sha256', '-verify', str(pub), '-signature', str(sig), str(raw)], check=True)
        (output / raw.name).write_bytes(raw.read_bytes())
        (output / sig.name).write_bytes(sig.read_bytes())
    print(json.dumps({'version': version, 'installer': installer.name, 'sha256': manifest['sha256'], 'signed': True}))


if __name__ == '__main__':
    main()
