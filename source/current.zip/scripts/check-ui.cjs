// Compatibility entry point: DOM interactions and official widget protocol.
// This suite does not perform browser painting or Windows playback validation.
require('./check-dom.cjs');
