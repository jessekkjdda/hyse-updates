#!/usr/bin/env python3
"""Package a published hyse release with corresponding source and notices."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import struct
import tempfile
import xml.etree.ElementTree as ET
import zipfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish-dir', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    published = (root / args.publish_dir).resolve()
    output = Path(args.output).resolve()
    version = ET.parse(root / 'GlassPlayer/GlassPlayer.csproj').findtext('.//Version')
    name = f'hyse-{version}-Windows-x64'
    if output.name != name + '.zip':
        raise ValueError(f'Expected output filename: {name}.zip')
    for required in ('hyse.exe', 'hyse-update.exe', 'hyse.dll', 'hyse.deps.json', 'coreclr.dll',
                     'PresentationFramework.dll', 'YamlDotNet.dll', 'WebView2Loader.dll', 'NAudio.Core.dll', 'NAudio.Wasapi.dll'):
        if not (published / required).is_file():
            raise FileNotFoundError(required)
    for file in (root / 'GlassPlayer/Web').rglob('*'):
        if file.is_file():
            installed = published / 'Web' / file.relative_to(root / 'GlassPlayer/Web')
            if not installed.is_file() or hashlib.sha256(installed.read_bytes()).digest() != hashlib.sha256(file.read_bytes()).digest():
                raise ValueError('Published web asset does not match source: ' + str(file.relative_to(root)))
    exe = (published / 'hyse.exe').read_bytes()
    pe = struct.unpack_from('<I', exe, 0x3c)[0]
    if exe[:2] != b'MZ' or exe[pe:pe+4] != b'PE\0\0' or struct.unpack_from('<H', exe, pe+4)[0] != 0x8664:
        raise ValueError('Expected Windows x64 executable')
    config = json.loads((root / 'GlassPlayer/config.json').read_text())
    if any(value not in ('', None) for value in config.values()):
        raise ValueError('Release config must not contain personal credentials')
    output.parent.mkdir(parents=True, exist_ok=True)
    ignore = shutil.ignore_patterns('bin', 'obj', 'artifacts', '__pycache__', '*.user', '*.suo', 'config.local.json', 'node_modules')
    with tempfile.TemporaryDirectory(prefix='hyse-package-') as temp:
        package = Path(temp) / name
        app, source = package / 'app', package / 'source'
        shutil.copytree(published, app)
        source.mkdir()
        for folder in ('GlassPlayer', 'tests', 'scripts', 'docs', 'licenses', '.github', 'vendor', 'integration', 'UpdateHelper', 'installer'):
            shutil.copytree(root / folder, source / folder, ignore=ignore)
        for filename in ('LICENSE', 'NOTICE.md', 'THIRD_PARTY.md', 'README.md', 'global.json', '.gitignore', 'package.json', 'package-lock.json'):
            shutil.copy2(root / filename, source / filename)
        for filename in ('LICENSE', 'NOTICE.md', 'THIRD_PARTY.md', 'README.md'):
            shutil.copy2(root / filename, package / filename)
            shutil.copy2(root / filename, app / filename)
        shutil.copytree(root / 'licenses', app / 'licenses', dirs_exist_ok=True)
        temporary = output.with_suffix('.zip.tmp')
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for file in sorted(package.rglob('*')):
                if file.is_file():
                    archive.write(file, file.relative_to(Path(temp)).as_posix())
        with zipfile.ZipFile(temporary) as archive:
            failed = archive.testzip()
            if failed:
                raise ValueError('Corrupt archive entry: ' + failed)
            names = archive.namelist()
            for required in ('app/hyse.exe', 'app/YamlDotNet.dll', 'app/Web/index.html', 'app/Web/styles.css', 'app/Web/sdk.js', 'app/Web/search.js', 'app/Web/soundcloud-player.js', 'app/Web/spotify-reader.js', 'source/GlassPlayer/SpotifySessionReader.cs', 'source/GlassPlayer/Core/PlaylistScan.cs', 'source/GlassPlayer/MainWindow.xaml.cs', 'source/licenses/Riff-LICENSE.txt', 'source/GlassPlayer/Web/app.js',
                             'source/tests/CoreChecks/ReleaseChecks.cs', 'source/GlassPlayer/packages.lock.json',
                             'source/scripts/package-release.py', 'source/licenses/YamlDotNet-LICENSE.txt', 'source/licenses/NAudio-LICENSE.txt', 'source/GlassPlayer/WindowsAudioLevelMonitor.cs', 'source/GlassPlayer/Core/SoundCloudCatalog.cs', 'source/scripts/check-dom.cjs', 'source/package-lock.json', 'source/GlassPlayer/Core/TtmlReader.cs', 'source/GlassPlayer/Core/WordLyricsProvider.cs', 'source/GlassPlayer/Core/PersonalProfile.cs', 'app/Web/settings-view.js', 'app/Web/dock.js', 'app/Web/ambient.js', 'app/Web/timeline.js', 'source/GlassPlayer/MainWindow.Personal.cs', 'source/tests/CoreChecks/Rework10Checks.cs', 'app/Web/slider.js', 'app/Web/window.js', 'app/Web/fonts/InterVariable.woff2', 'app/licenses/Inter-OFL.txt', 'app/Web/fonts/Montserrat-Variable.ttf', 'app/licenses/Montserrat-OFL.txt', 'source/scripts/check-liner.cjs', 'source/scripts/build-liner.cjs', 'source/vendor/liner/manifest.json', 'source/integration/lyrics.ts', 'source/integration/sliders.tsx', 'app/Web/liner-lyrics.js', 'app/Web/liner-sliders.js', 'app/licenses/Liner-LICENSE.txt', 'app/Web/liner-clock.js', 'source/integration/media-clock.ts', 'source/integration/media-state.ts', 'source/vendor/liner/features/player/hooks/mediaClock.ts', 'source/scripts/check-media-clock.cjs', 'source/integration/estimated-line.ts', 'source/scripts/check-fallback.cjs', 'source/scripts/check-preservation.cjs', 'source/tests/preservation-112.json', 'source/tests/preservation-113.json', 'source/vendor/spicy/manifest.json', 'source/vendor/spicy/src/utils/Lyrics/ttml/parser.ts', 'source/integration/spicy-ttml.ts', 'source/integration/spicy-logger.ts', 'source/scripts/check-spicy.cjs', 'app/licenses/Spicy-Lyrics-LICENSE.txt', 'app/licenses/fast-xml-parser-LICENSE.txt', 'source/tests/preservation-114.json', 'source/GlassPlayer/Core/LyricsPrefetcher.cs', 'source/GlassPlayer/MainWindow.Lyrics.cs', 'app/Web/glass-select.js', 'app/Web/frame-metrics.js', 'source/scripts/check-frame-metrics.cjs', 'source/docs/VALIDACAO-0.11.4.md', 'app/Web/collection-filter.js', 'source/GlassPlayer/MainWindow.Radio.cs', 'source/GlassPlayer/MainWindow.Taskbar.cs', 'source/GlassPlayer/Core/RadioPlanner.cs', 'source/GlassPlayer/Core/TaskbarPlayback.cs', 'source/GlassPlayer/Core/QueueSession.cs', 'source/tests/CoreChecks/RadioTaskbarChecks.cs', 'source/scripts/check-collections.cjs', 'source/docs/VALIDACAO-0.14.0.md', 'source/docs/VALIDACAO-0.15.0.md', 'source/docs/VALIDACAO-0.16.0.md', 'source/docs/VALIDACAO-0.16.1.md', 'source/GlassPlayer/Core/DiscordRpcError.cs', 'source/tests/DiscordWindowsChecks/Program.cs', 'source/tests/DiscordWindowsChecks/DiscordWindowsChecks.csproj', 'source/GlassPlayer/Core/RadioDiscovery.cs', 'source/vendor/spicy-wave/manifest.json', 'source/vendor/spicy-wave/original/LyricsAnimator.ts', 'source/scripts/build-wave-source.cjs', 'source/scripts/check-wave.cjs', 'source/integration/spicy-wave-canvas.ts', 'source/integration/spicy-wave-source.ts', 'source/integration/spicy-wave-style.ts'):
                if name + '/' + required not in names:
                    raise ValueError('Missing archive entry: ' + required)
            if any('/obj/' in path or '/bin/' in path for path in names):
                raise ValueError('Build intermediates must not be packaged')
        temporary.replace(output)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    checksum = output.with_suffix('.zip.sha256')
    checksum.write_text(f'{digest}  {output.name}\n')
    print(json.dumps({'archive': str(output), 'size_bytes': output.stat().st_size,
                      'entries': len(names), 'sha256': digest, 'checksum': str(checksum)}))


if __name__ == '__main__':
    main()
