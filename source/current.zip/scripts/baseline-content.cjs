// Undo only exact authorized name/volume edits and the added Discord settings.
// Any other change still fails against the approved release's original hashes.
const fs=require('node:fs'),path=require('node:path');
const edits={
 'GlassPlayer/Settings.cs':[['    public bool LyricsWave {get;set;}=true;\n',''],['    public bool AutomaticUpdates {get;set;}=true;\n',''],[`    public bool DiscordEnabled {get;set;}=true;
    public bool DiscordArtwork {get;set;}=true;
    public bool DiscordTime {get;set;}=true;
    public bool DiscordButton {get;set;}=true;
    public bool DiscordHidePaused {get;set;}
    public string DiscordText {get;set;}="track";
`, '']],
 'GlassPlayer/Web/sdk.js':[["name:'hyse'","name:'cncx'"]],
 'GlassPlayer/Core/SpotifyPublicPlaylistReader.cs':[['hyse/0.12.0','cncx/0.8.0']],
 'GlassPlayer/SpotifySessionReader.cs':[['Spotify · hyse','Spotify · cncx']],
 'GlassPlayer/Web/dock.js':[["this.element.querySelector('#dock-volume').oninput=e=>c.volume(+e.target.value,false);this.element.querySelector('#dock-volume').onchange=e=>c.volume(+e.target.value,true);","this.element.querySelector('#dock-volume').onchange=e=>c.volume(+e.target.value);"]],
 'GlassPlayer/MainWindow.xaml':[['Title="hyse"','Title="cncx"'],['Abrindo hyse…','Abrindo cncx…']],
 'GlassPlayer/LyricsService.cs':[['hyse/0.12.0','cncx/0.10.0']]
};
module.exports=(root,file)=>{
 const data=fs.readFileSync(path.join(root,file));if(!edits[file])return data;
 let text=data.toString('utf8');for(const[now,before]of edits[file]){
  if(text.split(now).length!==2)throw Error('Expected exactly one authorized edit: '+file+' / '+now);
  text=text.replace(now,before);
 }return Buffer.from(text);
};
