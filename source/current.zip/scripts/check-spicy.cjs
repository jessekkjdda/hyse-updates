const assert = require('node:assert/strict');
const path = require('node:path');
const vm = require('node:vm');
const esbuild = require('esbuild');
const {aliases, plugins, verifySpicy} = require('./build-liner.cjs');
(async()=>{
const root = path.resolve(__dirname, '..');
verifySpicy();
const build = await esbuild.build({stdin: {contents: `export {prepareSpicyDocument} from './integration/spicy-ttml'; export {toLinerLyrics} from './integration/lyrics'; export {buildLines} from './vendor/liner/features/lyrics/canvas/buildLines';`, resolveDir: root}, bundle: true, format: 'iife', globalName: 'Subject', platform: 'browser', alias: aliases, plugins, write: false});
let networkCalls = 0;
const sandbox = {console: {warn() {}, error() {}, info() {}, debug() {}}, fetch() {networkCalls++; throw Error('Local processing must not use the network');}};
vm.runInNewContext(build.outputFiles[0].text, sandbox);
const {prepareSpicyDocument: prepare, toLinerLyrics: convert, buildLines} = sandbox.Subject;
let passed = 0;
function check(value, label) { assert.ok(value, label); passed++; console.log('PASS: ' + label); }
const ttml = content => `<tt xmlns="http://www.w3.org/ns/ttml" xmlns:ttm="http://www.w3.org/ns/ttml#metadata" xmlns:itunes="http://music.apple.com/lyric-ttml-internal" itunes:timing="Word"><body><div>${content}</div></body></tt>`;
const line = (text, timeMs, endMs, words) => ({text, timeMs, endMs, ...(words ? {words} : {})});
const word = (text, startMs, endMs) => ({text, startMs, endMs});
const xml = ttml(`<p begin="1s" end="7s"><span begin="1s" end="2s">Hel</span><span begin="2s" end="3s">lo</span> <span begin="5s" end="6s">world</span></p><p begin="9s" end="10s"><span begin="9s" end="9.4s">Come</span> <span begin="9.4s" end="10s">back</span></p>`);
const baseline = {synced: true, wordSynced: true, source: 'AMLL TTML', spicyTtml: xml, lines: [line('Hello world', 1000, 7000, [word('Hel',1000,2000), word('lo ',2000,3000), word('world',5000,6000)]), line('Come back',9000,10000,[word('Come ',9000,9400),word('back',9400,10000)])]};
const before = JSON.stringify(baseline), prepared = prepare(baseline);
check(prepared !== baseline && prepared.lines[0].words.length === 3, 'production adapter executes the original Spicy parser on native TTML');
check(JSON.stringify(prepared.lines[0].words.map(w => [w.startMs,w.endMs])) === '[[1000,2000],[2000,3000],[5000,6000]]', 'native syllable starts, ends and breathing gap remain exact');
check(prepared.lines[0].text === 'Hello world' && prepared.lines[0].words[0].text === 'Hel' && prepared.lines[0].words[1].text === 'lo ', 'Spicy word boundaries join syllables without adding a space inside the word');
check(JSON.stringify(baseline) === before && prepared.source === 'AMLL TTML', 'original document and true provider attribution remain unchanged');
check(prepare(baseline) === prepared && prepare(prepared) === prepared, 'each immutable document is parsed once and reused across animation frames');
const visual = convert(baseline,12000), vocal = visual.lyrics[visual.sourceMap[0]];
const production = await esbuild.build({entryPoints:[path.join(root,'GlassPlayer/Web/liner-lyrics.js')],bundle:true,platform:'browser',format:'iife',globalName:'Production',write:false});
vm.runInNewContext(production.outputFiles[0].text,sandbox);
const shipped = sandbox.Production.toLinerLyrics(baseline,12000);
check(JSON.stringify(shipped.lyrics) === JSON.stringify(visual.lyrics), 'the shipped production bundle matches the tested source conversion');
check(vocal.parts[2].startTimeMs === 5000 && vocal.parts[2].durationMs === 1000 && !vocal.estimatedTiming, 'Spicy data reaches the existing Liner renderer as real timing, not an estimate');
check(visual.nativeShiftMs === 150 && buildLines(visual.lyrics).shiftMs === 150, 'the existing native word clock shift remains unchanged');

const brokenEnvelope = ttml('<p begin="1s" end="1s"><span begin="1s" end="2s">Slow</span> <span begin="4s" end="5s">finish</span></p>');
const recovered = prepare({synced: true, spicyTtml: brokenEnvelope, lines:[line('Slow finish',1000,1000)]});
check(recovered.lines[0].endMs === 5000 && recovered.lines[0].words?.[1].startMs === 4000, 'Spicy recovers real word timing from a collapsed paragraph window instead of rushing its entire verse');
const recoveredModel = convert(recovered,7000), recoveredLine = recoveredModel.lyrics[recoveredModel.sourceMap[0]];
check(recoveredLine.parts[1].startTimeMs === 4000 && recoveredLine.parts[1].durationMs === 1000, 'the recovered final word stays at its sung time in the production renderer input');

const mixed = {synced: true, spicyTtml: ttml('<p begin="1s" end="3s"><span begin="1s" end="2s">Sing</span> <span begin="2s" end="3s">now</span></p><p begin="4s" end="12s">One measured phrase remains line timed</p>'), lines:[line('Sing now',1000,3000),line('One measured phrase remains line timed',4000,12000)]};
const mixedView = convert(mixed,14000);
check(mixedView.lyrics[mixedView.sourceMap[1]].estimatedTiming === true && mixedView.lyrics[mixedView.sourceMap[1]].parts.at(-1).startTimeMs > 10000, 'a line-only verse inside word TTML keeps the tested gradual fallback');

const backgroundDoc = {synced:true,spicyTtml:ttml('<p begin="1s" end="5s"><span begin="1s" end="2s">Main</span> <span begin="2s" end="3s">voice</span><span ttm:role="x-bg"><span begin="4s" end="6s">(Echo)</span></span></p><p begin="8s" end="9s"><span begin="8s" end="8.5s">Next</span> <span begin="8.5s" end="9s">verse</span></p>'),lines:[line('Main voice',1000,5000),line('Next verse',8000,9000)]};
const background = convert(backgroundDoc,10000), bgLine = background.lyrics[background.sourceMap[0]];
check(bgLine.parts.some(p=>p.isBackground && p.words.includes('Echo') && p.startTimeMs===4000), 'background vocals keep their own original times and native Liner background styling');
check(background.lyrics.some(l=>l.isInstrumental && l.startTimeMs===6000 && l.durationMs===2000), 'instrumental gaps begin after the last actual background vocal');

const foreign = {...baseline, spicyTtml:xml.replace('world','different')};
check(prepare(foreign).lines[0] === foreign.lines[0] && prepare(foreign).lines[1] !== foreign.lines[1], 'an incompatible verse keeps its baseline while another valid verse still uses Spicy');
const shifted = {...baseline, spicyTtml:xml.replace('begin="5s"','begin="5.2s"')};
check(prepare(shifted).lines[0] === shifted.lines[0] && prepare(shifted).lines[1] !== shifted.lines[1], 'a timing disagreement falls back only that verse without shifting approved word timestamps');
const reduced = {...baseline, spicyTtml:ttml('<p begin="1s" end="7s">Hello world</p><p begin="9s" end="10s">Come back</p>')};
check(prepare(reduced) === reduced, 'line-level data cannot downgrade existing word-level timing');
const repeated={synced:true,spicyTtml:ttml('<p begin="10s" end="12s"><span begin="10s" end="11s">Same</span> <span begin="11s" end="12s">chorus</span></p>'),lines:[line('Same chorus',1000,3000),line('Same chorus',10000,12000)]};
const repeatedResult=prepare(repeated);
check(repeatedResult.lines[0]===repeated.lines[0]&&repeatedResult.lines[1]!==repeated.lines[1],'a repeated chorus can only match its own source position after an omitted verse');
const noMatch={...baseline,spicyTtml:xml.replaceAll('Hello','Other').replaceAll('Come','Different').replaceAll('world','song')};
check(prepare(noMatch)===noMatch,'a completely unrelated document never upgrades the source lyrics');
for (const badXml of ['', '<tt><body>', '<not-ttml/>', '<!DOCTYPE tt [<!ENTITY x "expansion">]><tt><body/></tt>', 'x'.repeat(1024*1024+1)]) {
  const document = {...baseline, spicyTtml:badXml};
  assert.equal(prepare(document),document);
}
check(true,'empty, malformed, foreign, entity-bearing and oversized XML preserve the baseline');
for(const original of [{synced:false,plainText:'Plain text'}, {synced:true,lines:[line('One slow line',1000,9000)]}, {instrumental:true,lines:[]}, baseline.lines[0]]) assert.equal(prepare(original),original);
check(true,'LRCLIB, plain text, instrumental tracks and old cached documents remain on their original path');
const unicodeDoc = {synced:true,spicyTtml:ttml('<p begin="1s" end="4s"><span begin="1s" end="2s">Ação</span> <span begin="3s" end="4s">🧡 &amp; café</span></p>'),lines:[line('Ação 🧡 & café',1000,4000)]};
check(prepare(unicodeDoc).lines[0].words?.[1].text==='🧡 & café','Unicode and XML entities arrive as visible text without HTML injection');
check(networkCalls===0,'original Spicy code works locally without a key, account, request or new lyrics service');
if(process.argv[2]) {
  const native = JSON.parse(require('node:fs').readFileSync(process.argv[2],'utf8'));
  const transported = prepare(native), scene = convert(native,12000);
  check(native.lines[0].words == null && transported.lines[0].words?.[1].startMs===4000 && transported.lines[0].endMs===5000, 'actual C# provider → camelCase WebView payload → Spicy parser recovers the collapsed paragraph');
  const timing = words => JSON.stringify(words.map(w => [w.text,w.startMs,w.endMs]));
  check(timing(transported.lines[1].words) === timing(native.lines[1].words) && scene.lyrics[scene.sourceMap[0]].parts[1].durationMs===1000, 'the native-to-renderer path preserves the already correct verse and recovered word duration');
}
console.log(`\n${passed} local Spicy integration checks passed.`);

})().catch(error=>{console.error(error);process.exitCode=1;});
