#!/usr/bin/env python3
"""Build an actual per-user NSIS installer and corresponding source archive."""
import argparse,hashlib,json,os,shutil,struct,subprocess,zipfile
from pathlib import Path

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--makensis',default='makensis')
    parser.add_argument('--publish-dir',default='artifacts/hyse-windows-x64')
    parser.add_argument('--output',required=True)
    args=parser.parse_args();root=Path(__file__).resolve().parents[1]
    import xml.etree.ElementTree as ET
    version=ET.parse(root/'GlassPlayer/GlassPlayer.csproj').findtext('.//Version')
    payload=(root/args.publish_dir).resolve();output=Path(args.output).resolve()
    if output.name!=f'hyse-{version}-Setup.exe':raise ValueError('Unexpected installer filename')
    output.parent.mkdir(parents=True,exist_ok=True)
    if any(value not in ('',None) for value in json.loads((root/'GlassPlayer/config.json').read_text()).values()):raise ValueError('Release config contains personal credentials')
    for name in ['hyse.exe','hyse.dll','hyse.ico','hyse-update.exe','Web/index.html']:
        if not (payload/name).is_file():raise FileNotFoundError(name)
    for name in ['LICENSE','NOTICE.md','THIRD_PARTY.md','README.md']:shutil.copy2(root/name,payload/name)
    shutil.copytree(root/'licenses',payload/'licenses',dirs_exist_ok=True)
    # Every distributed installer carries its complete corresponding source.
    source=payload/'source.zip'
    include=['GlassPlayer','tests','scripts','docs','licenses','vendor','integration','UpdateHelper','installer','.github']
    ignored={'bin','obj','node_modules','artifacts','__pycache__'}
    with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for folder in include:
            for file in sorted((root/folder).rglob('*')):
                if file.is_file() and not any(p in ignored for p in file.relative_to(root).parts) and not file.name.endswith(('.user','.suo')) and file.name!='config.local.json':archive.write(file,file.relative_to(root).as_posix())
        for name in ['LICENSE','NOTICE.md','THIRD_PARTY.md','README.md','package.json','package-lock.json','global.json','.gitignore']:archive.write(root/name,name)
    manifest=root/'artifacts/installer-delete.nsh';manifest.parent.mkdir(parents=True,exist_ok=True)
    def safe(path):
        value=path.as_posix().replace('/','\\')
        if any(c in value for c in ['$','"','\n','\r']):raise ValueError('Unsafe payload path')
        return value
    files=[p for p in payload.rglob('*') if p.is_file()]
    dirs=sorted({parent.relative_to(payload) for p in files for parent in p.parents if parent!=payload and payload in parent.parents},key=lambda p:(len(p.parts),str(p)),reverse=True)
    lines=[f'Delete "$INSTDIR\\{safe(p.relative_to(payload))}"' for p in sorted(files)]
    lines.extend(f'RMDir "$INSTDIR\\{safe(p)}"' for p in dirs if p.parts)
    manifest.write_text('\n'.join(lines)+'\n')
    flag='/' if os.name=='nt' else '-'
    command=[args.makensis,flag+'V3',f'{flag}DAPP_VERSION={version}',f'{flag}DPAYLOAD={payload}',f'{flag}DOUTPUT={output}',f'{flag}DDELETE_MANIFEST={manifest}',str(root/'installer/hyse.nsi')]
    subprocess.run(command,check=True,cwd=root)
    data=output.read_bytes();pe=struct.unpack_from('<I',data,0x3c)[0]
    if data[:2]!=b'MZ' or data[pe:pe+4]!=b'PE\0\0':raise ValueError('Setup is not a Windows executable')
    digest=hashlib.sha256(data).hexdigest();output.with_suffix('.exe.sha256').write_text(digest+'  '+output.name+'\n')
    print(json.dumps({'installer':str(output),'size_bytes':len(data),'sha256':digest,'payload_files':len(files),'source_included':True}))

if __name__=='__main__':main()
