const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),manifest=require('../tests/compatibility-09.json'),baseline=require('./baseline-content.cjs');
for(const[file,hash]of Object.entries(manifest)){const actual=crypto.createHash('sha256').update(baseline(root,file)).digest('hex');assert.equal(actual,hash,file+' changed from its requested baseline');console.log('PASS: baseline '+file);}
console.log(Object.keys(manifest).length+' historical baselines preserved apart from exact product-name substitutions.');
