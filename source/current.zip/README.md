# hyse 0.14.0

Atualização de 25 de novembro de 2026, sobre a 0.13.0 publicada.

- Tocar uma faixa pela busca, histórico ou recentes inicia uma continuação de
  músicas, sem transformar os outros resultados de pesquisa em fila.
- A continuação elimina versões repetidas da mesma composição, respeita a
  origem da faixa, evita músicas já enfileiradas/recentes e intercala artistas
  quando há variedade. Usa faixas relacionadas disponíveis no serviço; quando
  esse acesso não está disponível, usa catálogo por artista e contexto de escuta
  do hyse. O algoritmo privado do Spotify/SoundCloud não é copiado nem inferido.
- Playlists e álbuns continuam usando sua ordem, shuffle e repetição existentes.
  A busca na biblioteca filtra playlists; dentro das listas, filtra música,
  artista, álbum e origem sem alterar o índice original de cada ocorrência.
- A prévia da barra de tarefas ganha Anterior, Reproduzir/Pausar e Próxima,
  usando os mesmos comandos nativos do player, sem abrir a janela.
- Removidos os nomes de outros aplicativos dos dados de implementação em
  App info. Os avisos e licenças dos componentes permanecem recolhidos em
  Licenças e acompanham a distribuição.

Letras, sincronização, fontes, sliders, fundos, bordas, playlists, contas e
atualizador foram preservados. As filas antigas são lidas como listas normais;
a nova continuação começa na próxima escolha de uma faixa isolada. Detalhes dos
testes e limites em `docs/VALIDACAO-0.14.0.md`.


## Base 0.13.0

Atualização de 25 de novembro de 2026. Base aprovada 0.12.1 preservada;
esta versão acrescenta o atualizador automático. Letras, sincronização, fontes,
interface, playlists e volume mantêm o comportamento da versão anterior.

## Atualizações automáticas

Instale `hyse-0.13.0-Setup.exe` uma vez por cima da versão existente. A versão
0.12.1 ainda não possui esse atualizador e não consegue recebê-lo sozinha.

O canal oficial é https://github.com/jessekkjdda/hyse-updates/releases/latest.
O app instalado verifica 15 segundos após abrir e depois a cada 6 horas enquanto
estiver em execução. Em Configurações → App info há verificação manual,
controle de atualizações automáticas e **Reiniciar e atualizar** quando o
instalador estiver pronto. Downloads acontecem em segundo plano. Uma falha de
rede não interfere na reprodução e a próxima verificação tenta novamente.

Com a opção automática ligada, **Sair** salva o aplicativo e aplica a atualização
já baixada sem reabrir a janela. O X continua escondendo o player na bandeja;
não instala nem interrompe a música. Desligar a opção impede a instalação ao
sair e as verificações periódicas; a verificação e reinicialização manuais
continuam disponíveis. Desligar a opção durante um download não cancela o arquivo
em andamento, mas impede que ele seja aplicado automaticamente. Encerramento
do Windows não inicia instalação. A edição portátil permite apenas usar o app;
instale pelo Setup para habilitar a atualização da cópia instalada.

O manifesto tem assinatura RSA-3072/SHA-256, com chave pública fixada no app e
no helper. Tamanho, versão, origem HTTPS, assinatura e SHA-256 do instalador são
conferidos. Downgrades, outro repositório e executáveis incompletos são rejeitados.
O helper roda fora da pasta instalada, espera o processo sair sem terminá-lo à
força, verifica novamente os arquivos e usa o mesmo instalador per-user. Faz uma
cópia dos arquivos instalados e tenta restaurá-los se a instalação falhar; uma
queda de energia durante a troca ainda pode exigir executar o Setup novamente.
Conta, playlists, histórico, perfil e configurações não são parte dessa cópia
nem são apagados. Os resultados ficam no cache local de atualizações.

O repositório publica apenas arquivos de distribuição, manifestos e notas.
Não inclui credenciais da conta nem a chave privada de assinatura. Cada nova
versão precisa ser compilada, testada, assinada e publicada nesse canal para
ser recebida automaticamente; não há geração autônoma de novas versões.
O fluxo de publicação está em `docs/ATUALIZACOES.md` e a validação desta entrega
em `docs/VALIDACAO-0.13.0.md`.

## Discord — 0.12.1

A presença usa o Application ID público `1574964498241036328`, fornecido pelo
usuário. O Discord de PC precisa estar aberto, conectado e com compartilhamento
de atividades permitido. O hyse usa IPC local sem senha, token de usuário ou bot,
sem servidor/porta pública e sem instalar dependências adicionais.

Configurações → Serviços → Discord contém o controle de atividade e opções de
capa, tempo, link, ocultação ao pausar e texto do status. O padrão é mostrar a
música, artista, capa, tempo e um link para a faixa no serviço original.
Pausa remove o cronômetro; retomar e buscar ajustam os timestamps confirmados.
Desligar a integração fecha a conexão. Fechar para a bandeja mantém a presença;
Sair encerra a conexão junto com o aplicativo.

O worker fica separado da reprodução, responde a heartbeat durante períodos
sem mudanças, mantém só a presença mais recente e reconecta após fechar/abrir
o Discord. O intervalo mínimo entre atualizações é 4,5 segundos. A evolução do
tempo é desenhada pelo Discord a partir dos timestamps; não há envio por frame.
A aparência do cartão e a exibição dos botões dependem do cliente Discord.
Botões são visíveis para outros usuários e abrem a faixa; não criam uma sessão
de ouvir junto. A presença nativa do Spotify pode ser exibida separadamente.

### Ícone original

`GlassPlayer/Assets/hyse-icon.png` foi extraído sem reencodificação da entrada
256×256 do mesmo ICO usado pelo aplicativo. O arquivo acompanha o código e é
fornecido separadamente para o portal. Para usar a imagem em todos os lugares:

1. Em General Information do aplicativo Discord, envie `hyse-icon.png` como ícone.
2. Em Rich Presence → Art Assets, envie a mesma imagem com a chave **hyse**.
3. Salve as alterações. O código já referencia essa chave; não exige outro build.

O ícone e o asset remoto **hyse** foram salvos no portal do Discord após a
verificação do usuário. Não foi confirmada uma conexão IPC com o Discord real. A integração foi verificada com stream duplex
em memória e publicação Windows x64; detalhes em `docs/VALIDACAO-0.12.1.md`.

## Instalar no Windows

1. Feche o cncx portátil anterior. O instalador não encerra essa versão à força.
2. Execute `hyse-0.14.0-Setup.exe` e conclua a instalação.
3. Abra hyse pelo Menu Iniciar ou pelo atalho da área de trabalho.
4. Para fixar na barra de tarefas, abra o app, clique com o botão direito no
   ícone da barra e escolha **Fixar na barra de tarefas**.

O instalador usa `%LOCALAPPDATA%/Programs/hyse`, sem solicitar administrador.
As versões futuras usam a mesma identidade e pasta, substituindo os arquivos
do programa. A versão instalada é solicitada a salvar e sair antes da troca.
O canal de atualizações automáticas desta versão está descrito acima.

Conta, playlists, histórico, perfil, fotos e configurações continuam nas pastas
anteriores `%APPDATA%/cncx` e `%LOCALAPPDATA%/cncx`. Esses nomes internos são
mantidos para preservar tokens, caminhos de imagens, caches e a sessão WebView2.
Instalação e desinstalação não apagam esses dados. Não renomeie essas pastas.

O X e Alt+F4 ocultam a janela, mantendo a reprodução. Clique no ícone da bandeja
ou escolha **Abrir hyse** para restaurar. **Sair** encerra e salva o aplicativo.
Se a bandeja estiver indisponível, fechar encerra o processo para não deixá-lo
inacessível. Abrir outro atalho restaura a instância existente. Não foi adicionado
início automático com o Windows.

Windows 10 19041 ou posterior, x64, e Microsoft Edge WebView2 Runtime são
necessários. O runtime .NET está incluído; Node e Python são ferramentas de
compilação e não são necessários para usar o app. A alternativa portátil é
extrair o ZIP inteiro e abrir `app/hyse.exe`, mantendo Web e DLLs junto ao EXE.

## Ajustes desta versão

- Controles de minimizar, maximizar/restaurar e fechar agrupados em vidro escuro,
  com padding maior e hover, mantendo a janela sem faixa de título separada.
- Volume nos dois players envia áudio em `input`, antes de soltar o ponteiro.
  Há no máximo um comando em andamento, intervalo mínimo de 40 ms e substituição
  das amostras pendentes pela escolha mais recente. `change` confirma o valor
  final e grava a preferência; teclado mantém a confirmação.
- Nome visível, EXE, metadados, atalhos e dispositivo Spotify usam hyse. IDs do
  bridge, domínio local e diretórios antigos continuam como contratos internos.
- Renderer, sincronização, fontes, sliders originais, personalização de capas,
  paleta, playlists, pesquisa e histórico conservam o comportamento aprovado.

Código correspondente completo em `source` no ZIP e em `source.zip` na pasta
instalada. Avisos ficam em App info e nos arquivos de licenças da distribuição.
Verificações e limites em `docs/VALIDACAO-0.12.0.md`.

## Atualização 0.11.4

Menus de seleção e diálogos usam vidro escuro, desfoque e as cores globais do
álbum atual. Os selects nativos continuam presentes apenas para dados/validação;
o popup visível é desenhado pelo app, com mouse, teclado, foco, opções desativadas
e fechamento ao sair. Isso remove o menu branco do Windows.

Escolher um formato de capa salva a preferência automaticamente. Há prévia da
capa na categoria Aparência; o formato é aplicado ao contêiner e à imagem.
As gravações são serializadas e a resposta antiga não substitui a escolha mais
recente, inclusive ao sair/reabrir configurações durante o salvamento.

O Spicy faz fallback por verso. Uma incompatibilidade conserva somente aquela
linha anterior, enquanto outras linhas válidas são aproveitadas. O pareamento
exige texto e posição originais; refrões repetidos não emprestam tempos de outra
ocorrência. Todos os tempos reais já disponíveis continuam protegidos.

Após carregar as letras atuais, o aplicativo aguarda 3 s e pré-carrega no máximo
a próxima faixa. Isso usa os caches, os limites e o backoff dos provedores
existentes, sem conta/chave Spicy. Mudanças de faixa cancelam a preparação e
aguardam sua conclusão antes de ler a música atual. O modo aleatório reserva uma
próxima escolha estável sem avançar índice, fila ou histórico. Repetição de uma
faixa não dispara busca redundante.

App info mostra FPS da interface, intervalo P95, maior intervalo, custo JS P95 e
quadros acima de 34 ms nas últimas 240 amostras. A medição não altera relógios ou
animações e descarta intervalos de janela oculta. É diagnóstico, não uma promessa
de FPS ou uma medição do áudio/compositor do Windows.

A validação está em `docs/VALIDACAO-0.11.4.md`. Configurações, sliders, fontes,
leitores de playlists e relógios aprovados são preservados.

## Integração local do Spicy — 0.11.3

O parser TTML original do Spicy Lyrics foi incorporado, sem alterações, do
commit 1c02f47cd64ed8c34bb76dd8ff00755db9d1d66f. Ele funciona localmente e usa
os TTML recebidos pelo provedor AMLL existente ou importados pelo usuário.
Não precisa de chave nem de conta Spicy. O catálogo/API do Spicy não está conectado.

O processamento mantém fronteiras de palavras/sílabas, tempos e vocais de apoio.
Um parágrafo com duração zerada ou insuficiente pode recuperar seu intervalo
pelos tempos reais dos spans. O adaptador conserva o motor visual, os relógios,
a fonte e os controles originais do Liner. Nada redefine preferências.

O parser novo só é aceito quando corresponde às mesmas linhas da letra original
e preserva todos os tempos válidos por palavra já disponíveis. Dados incompatíveis,
XML inválido e letras por linha mantêm o caminho da 0.11.2. Uma linha sem tempos
por palavra dentro de TTML misto continua com a estimativa gradual existente.
As fontes verdadeiras continuam identificadas como AMLL TTML, LRCLIB ou Arquivo local.

Arquivos TTML importados antes desta versão continuam funcionando pelo caminho
anterior; para processá-los pelo Spicy, importe novamente o arquivo original.
As consultas AMLL feitas nesta versão já conservam o XML automaticamente.

Isso melhora o processamento de dados disponíveis; não cria marcações de palavras
que a fonte não fornece. Não foi medida uma porcentagem de precisão ou FPS.
Fontes originais, hashes, licença AGPL-3.0 e adaptadores acompanham o pacote.
Validação e limites em `docs/VALIDACAO-0.11.3.md`.

## Correções 0.11.2

A progressão rápida foi localizada no fallback de fontes por linha: sem partes
por palavra, o renderer original cria inícios separados por 50 ms. Nesta versão,
só essas linhas recebem uma estimativa distribuída pela duração do verso. Tempos
reais por palavra, inclusive trechos rápidos, são preservados.

A estimativa usa os pesos de texto já presentes no hyse e respeita o final
explícito ou a próxima linha. Intervalos instrumentais conhecidos continuam
separados. Os dados continuam classificados como sincronização por linha.
O destaque congelado no silêncio usa a palavra atingida pela estimativa exibida.
O shift original é mantido: 115 ms para fontes por linha e 150 ms para partes
reais, sem adiantar a rolagem só por adicionar a estimativa visual.

A margem nativa de 6 px ao redor do WebView foi retirada; o viewport ocupa o
contorno arredondado da janela. O resize é preservado por oito regiões de borda
transparentes, desativadas quando maximizado. A área normal de scroll reserva
espaço interno para não sobrepor o scrollbar aos controles de resize.

A escala da capa passa a uma transição de 1,4 s. O movimento lento fica na camada
externa e é congelado, em vez de reiniciado, ao pausar. Fonte, clocks, leitores,
sliders, paleta e personalizações aprovadas são preservados. Esta atualização
não redefine preferências nem offsets por faixa.

## Alterações 0.11.1

O mediaClock.ts original do Liner foi integrado sem alterar seu arquivo de origem.
O adaptador fornece a ele amostras confirmadas dos SDKs, pois o Spotify e o
SoundCloud reproduzem em componentes próprios, e não no elemento de áudio do
Liner. A fonte de posição continua sendo cada serviço; isso não transforma os
SDKs no transporte de áudio usado pelo Liner.

A consulta de posição local passa para 50 ms, com pedidos sem sobreposição.
As mensagens nativas repetidas permanecem limitadas a 200 ms, exceto mudanças
de faixa, pausa ou duração. O clock original mantém seu carry de até 100 ms.
Se as posições do SDK forem repetidas/espaçadas, o adaptador utiliza o fallback
nativo contínuo para não introduzir uma parada periódica nas letras.

Na primeira abertura desta versão, os parâmetros globais das letras voltam aos
originais: Montserrat local, peso 600, tamanho 32, entrelinha 44,8, transição 1×
e ajustes de fade neutros para o renderer. As outras preferências, perfis,
playlists e ajustes por faixa permanecem. Depois, os controles continuam editáveis.

Wordly permanece pendente. O usuário informou autorização para usar o código,
sem acesso ao serviço. O cliente publicado pelo Liner chama seu backend com
autenticação e assinatura; esse acesso não foi fornecido. Esta versão não emula
credenciais ou assinaturas nem apresenta AMLL/LRCLIB com o nome Wordly.
Para concluir esse provedor é necessário o acesso de integração liberado pelos
autores, com o método de autenticação e a credencial correspondente.

## Letras

A tela grande importa o `LyricsCanvasRenderer` original do Liner, com seus
módulos de disposição, quebra de palavras, rolagem, curvas de movimento,
pintura por palavra, camadas Canvas e nota de instrumental. O renderer DOM
anterior e seu spring próprio foram retirados da tela de produção.

Os arquivos originais estão em `source/vendor/liner`, com o commit e os hashes
Git em `manifest.json`. `source/integration/lyrics.ts` contém a adaptação ao
relógio, aos documentos de letras e aos eventos do hyse. Os algoritmos de rolagem,
quebra e pintura dos módulos originais são mantidos. A adaptação trata tamanho,
redução de movimentos, ajustes opcionais e a palavra sustentada no silêncio.

A família das letras é Montserrat, incluída localmente. O relógio original do Liner recebe as amostras dos SDKs pelo adaptador; o relógio
nativo existente fica como fallback. O renderer aplica os deslocamentos e
os efeitos de sua implementação original. Ajustar sincronia por música permanece
no menu de letras. Os controles opcionais de fade do hyse são aplicados nos
inputs do adaptador; os valores padrão preservam a apresentação do renderer.
A velocidade do fade por palavra só altera partes com tempos por palavra.

Quando o medidor confirma silêncio, a posição visual é congelada no início do
silêncio e somente a palavra já iniciada fica destacada. Ao voltar o áudio,
a apresentação acompanha a posição atual. Em letra por linha, a seleção da
palavra continua estimada, pois a fonte não fornece o instante de cada palavra.
Pausa, mute e falta de medição não são classificados como silêncio da gravação.
Intervalos instrumentais indicados pelos dados usam o desenho original do Liner.

O catálogo Wordly não foi integrado. Os provedores continuam AMLL TTML quando
houver correspondência Spotify exata, LRCLIB e arquivos importados. O motor
visual original não torna os tempos das fontes idênticos aos dados do Wordly.
Não foram copiados credenciais, assinatura de requisições nem serviços do Liner.

## Sliders e navegação

`TimelineSlider.tsx` e `Slider.tsx` originais são montados em componentes React.
A skin CSS e os callbacks fazem a ligação com o hyse. A timeline conserva seu
preenchimento suavizado, interação por ponteiro e atalhos de cinco segundos,
Home e End. Volume e preferências usam o Slider original com passos e limites.

Início, busca, playlists, histórico e configurações continuam independentes do
player. Clique na capa, no título ou no botão de letras do rodapé para abrir a
tela grande; Escape ou Voltar retorna. Dados internos ficam em App info.
Perfis locais, foto, banner, formas da capa e fundo animado continuam disponíveis.

Os cinco arquivos de leitura Spotify e o relógio nativo preservam os hashes do
baseline. Nenhuma autorização ou playlist do usuário é substituída pelo pacote.
O SoundCloud mantém catálogo e widget oficiais, incluindo playlists locais mistas.

## Código, testes e build

Todo o código correspondente está em `source`, incluindo vendor, adaptadores,
fontes, avisos, locks e scripts. A integração do Liner foi feita sob a autorização
informada pelo usuário; a licença original e a atribuição foram preservadas.
Veja `NOTICE.md`, `THIRD_PARTY.md` e `docs/VALIDACAO-0.11.3.md`.

Para compilar, use .NET SDK 10.0.404, Node 24 e PowerShell:

```powershell
./scripts/build-windows.ps1
```

Verificações separadas:

```powershell
npm ci
npm run build:liner
node scripts/check-compat.cjs
npm run test:web
npm run test:liner
npm run test:clock
npm run test:fade
npm run test:spicy
npm run test:preservation
npm run test:volume
npm run test:dom
dotnet run --project tests/CoreChecks -c Release
```

O build compara os arquivos originais com os blobs Git, gera os dois bundles,
executa os testes e publica o Windows x64 self-contained. O teste Canvas usa
renderização de software; não mede FPS nem valida a janela Windows real.

Para empacotar o resultado, com Python 3:

```powershell
python scripts/package-release.py --publish-dir artifacts/hyse-windows-x64 --output ../hyse-0.14.0-Windows-x64.zip
```


Para gerar o instalador com NSIS 3.11 instalado:

```powershell
python scripts/build-installer.py --makensis "C:/Program Files (x86)/NSIS/makensis.exe" --output ../hyse-0.14.0-Setup.exe
```

O instalador tem identidade estável `hyse` em HKCU e não depende do número da
versão no caminho de instalação. Executar um instalador futuro atualiza esse
mesmo app; não crie outra identidade/pasta para cada versão.
