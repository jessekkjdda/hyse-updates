# Validação hyse 0.12.1

24 de novembro de 2026. Base: hyse 0.12.0.

## Implementação

- Application ID público 1574964498241036328, da imagem fornecida pelo usuário.
- IPC nativo local sobre named pipes no Windows, handshake v1, framing little
  endian, READY, nonce por comando, SET_ACTIVITY, ERROR e PING/PONG contínuo.
- Leituras completas de frames parciais, tamanho máximo de 64 KiB e cancelamento.
- Worker separado do dispatcher/reprodução, reconexão com intervalo, descarte de
  estados pendentes antigos, deduplicação e intervalo mínimo de 4,5 s por envio.
- Música, artista, álbum, imagens externas HTTPS, ícone nomeado hyse, timestamps
  estáveis até seek/retomada e link canônico Spotify/SoundCloud. Pausa não mantém
  um timer em andamento. Desativar ou sair fecha a conexão.
- Opções persistidas apenas em Serviços: ativação, capa, tempo, botão, ocultar ao
  pausar e mostrar música/nome no status. Nenhuma aba nova ou marca extra.
- Ícone PNG extraído sem reencodificação da entrada 256×256 de Assets/hyse.ico.

## Verificações

| Grupo | Quantidade |
|---|---:|
| Core, incluindo 42 novos testes Discord | 535 |
| Módulos frontend/SDK | 38 |
| Renderer e rasterização original | 19 |
| Relógio original | 19 |
| Regressões do fade | 16 |
| DOM/bridge, incluindo cinco novos fluxos de preferências Discord | 86 |
| Spicy local com transporte C# → JSON | 24 |
| Métricas de quadros | 9 |
| Volume durante arraste e coalescência | 10 |
| **Total funcional** | **756** |

O teste de IPC usa um stream duplex em memória com leituras fragmentadas,
servidor simulado, heartbeat enquanto ocioso, correlação de nonce, erro,
atividade nula, desconexão, reconexão, substituição de estados, limite de envios,
desativação e encerramento. Ele executa os mesmos codec, conexão e worker de
produção, mas não exercita o transporte de named pipes do Windows.

Uma tentativa de criar named pipe local para o teste Linux foi recusada por
Permission denied na criação de socket. Não houve escalada nem mudança na rede.
O teste foi adaptado para transporte puramente em memória. Essa tentativa não
conta como validação aprovada de IPC nativo ou conexão Discord real.

Os 31 arquivos protegidos anteriores continuam comparados aos hashes originais;
o filtro só permite as mudanças exatas de nomes/volume já aprovadas e a adição
dos seis campos de configuração Discord. Fontes, renderer, relógios, bundles,
sliders, formas, tema e leitores de playlists mantêm os bytes aprovados.
Os 34 originais Liner, quatro Spicy e seis hashes históricos continuam verificados.

## Distribuição e limites

Compilação e publicação Windows x64 self-contained com lock de dependências.
Instalador NSIS 3.11, identidade/pasta e dados da 0.12.0 preservados. Código
correspondente, ícone, documentação e licenças acompanham ZIP e source.zip.
Integridade do instalador e ZIP conferida por CRC e SHA-256.

Não houve execução Windows, áudio real, pintura CSS ou perfil Discord real.
No portal, o CAPTCHA expirou após uma tentativa autorizada pelo usuário. O ícone
na aplicação Discord e o asset remoto com chave hyse ainda não foram alterados.
O PNG e os passos exatos acompanham o README; publicar esse asset permitirá usar
o mesmo ícone sem recompilar o aplicativo. Não há credencial ou imagem da tela
de login nos arquivos distribuídos.
