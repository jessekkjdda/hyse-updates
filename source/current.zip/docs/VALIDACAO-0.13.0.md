# Validação 0.13.0 — 25/11/2026

Base: fonte e executáveis da distribuição 0.12.1 recuperada, ZIP SHA-256
`5bc5205b7615c23672e893d43258490a5f5da0f21792a850ee9b71db5f5ec474`.

Mudança: atualização automática Windows per-user pelo canal público
`jessekkjdda/hyse-updates`. Download e verificação em segundo plano, instalação
apenas em Sair ou reinicialização explícita em App info. X continua na bandeja.

## Verificações automatizadas

- 606 verificações Core: 535 anteriores e 71 novas para assinatura RSA real,
  chave estrangeira, manifesto alterado, produto/plataforma/tamanho/origem,
  versões inválidas, cache corrompido, cancelamento, download truncado/adulterado,
  limite de bytes, redirecionamento hostil/cíclico, modo offline e recuperação.
  As 16 combinações de política de saída verificam que X e encerramento do
  Windows não aplicam a atualização.
- 38 módulos frontend, 91 fluxos DOM/adapters, 19 renderer Canvas original,
  19 relógio original, 16 fade de fallback, 24 integração local Spicy,
  9 métricas de quadros e 10 volume durante arraste: 832 verificações funcionais.
- 31 arquivos aprovados preservados por hash, permitindo apenas as alterações
  exatas já autorizadas e o novo booleano de atualização em Settings.
- 6 bases históricas de playlists, sessão e relógio preservadas por hash.
- Publicação .NET 10 Windows x64 do WPF e do helper single-file separado;
  compilação sem avisos ou erros. Helper não carrega WebView nem usa tokens.
- Instalador NSIS compilado com detecção de erro de extração e saída não zero;
  ZIP com fonte correspondente e hashes de distribuição.

O helper confere assinatura e hash novamente, bloqueia o instalador contra
escrita, espera o processo salvar e sair e não o mata. Faz cópia dos arquivos
instalados antes de executar o mesmo NSIS silencioso; tenta restaurá-los se a
instalação falhar. Diretórios de dados legados não são incluídos nem alterados.
A identidade de registro, atalhos e pasta de instalação permanecem `hyse`.

## Limites práticos

Os testes rodam em Linux com cross-build Windows. Não houve execução nativa do
Setup, IPC Discord real, reinicialização Windows nem teste de falha de disco ou
energia. Os testes DOM não são validação visual e o Canvas de software não
prova taxa de quadros em GPU. A restauração do helper é uma tentativa em erro
controlado; não garante recuperação de desligamento abrupto. A 0.13.0 exige uma
instalação inicial manual para introduzir o atualizador.

O teste `tests/FeedCheck` usa o código e a chave pública de produção para baixar
e validar a release real, sem executá-la. O resultado do canal publicado e os
hashes finais ficam em `artifacts/checks/release-verification.json` no ambiente
da entrega e nos arquivos `.sha256` distribuídos.
