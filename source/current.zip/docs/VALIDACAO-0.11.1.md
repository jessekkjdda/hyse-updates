# Validação — cncx 0.11.1

24/11/2026. A autorização informada pelo usuário cobre o código do Liner; ele
confirmou que não recebeu acesso ao serviço Wordly. O provedor remoto continua
pendente e não é anunciado como integrado.

## Código e ligação

O arquivo original mediaClock.ts foi adicionado aos 33 arquivos já copiados.
Os 34 arquivos são conferidos contra os blobs do commit
54eaab9ade697b95756c68b6901a24b0a27949e4. O relógio está em
vendor/liner/features/player/hooks/mediaClock.ts, sem alterações. A importação do
store é resolvida por um adaptador local durante o bundle. O renderer e os
sliders originais da 0.11.0 continuam preservados.

O contrato de áudio original é alimentado por um elemento local sem src e com
getters para as amostras do SDK. Ele não reproduz música nem lê elementos de
áudio cross-origin. O limite de carry de 100 ms é o do código original. Quando
as amostras são espaçadas/repetidas ou o dispositivo é externo, entra o store
fallback alimentado pelo relógio nativo anterior. Não é uma afirmação de que o
Spotify SDK fornece a mesma granularidade do HTMLAudioElement usado pelo Liner.

O polling passa para 50 ms sem sobreposição. As publicações nativas repetidas
são limitadas a 200 ms; transições de estado/faixa continuam imediatas.
A migração de preferências reaplica Montserrat 600, 32 px, line-height 44,8 e
os parâmetros globais neutros do renderer. Offsets por faixa são conservados.

## Verificações executadas

- 458 verificações Core offline.
- 38 verificações dos módulos frontend/SDK/protocolos e helpers.
- 18 verificações do renderer original e rasterização, mantendo a comparação
  de 12 quadros não vazios byte a byte durante transições de 260 ms.
- 63 verificações DOM/adaptadores do aplicativo com os fluxos de navegação,
  playlists, sliders, seek, silêncio, perfil e configurações.
- 19 verificações do relógio original: amostras confirmadas, carry, pausa,
  seek, troca de faixa, externo, desconexão, SoundCloud e dados de baixa cadência.

Total: 596 verificações funcionais, além de 34 hashes de arquivos Liner e
6 hashes preservados dos leitores de playlists/relógio nativo.

A tipografia padrão é obtida da configuração original já incluída na 0.11.0.
O arquivo de fonte Montserrat local e o renderer Canvas não foram trocados.
O novo clock é importado pela interface de produção; não é só uma fixture.

## Limites

Não houve autenticação ou consulta real Wordly. Não foram extraídas chaves
compartilhadas, contornadas assinaturas ou emuladas permissões do serviço.
A API que o cliente consulta usa login/token e assinatura do próprio Liner.
Para concluir Wordly falta a conexão de integração autorizada pelos autores.

Não houve sessão gráfica Windows nem teste de sincronização com áudio real de
Spotify/SoundCloud, medição de FPS ou validação visual da janela no Windows.
A comparação Canvas usa rasterização de software e não cobre CSS ou hardware.
Os dados das letras continuam AMLL TTML, LRCLIB e importações, com qualidade
variável; a tipografia e o código do relógio não acrescentam tempos por palavra
a uma fonte que só fornece tempos por linha.

## Reprodução

```powershell
npm ci
npm run build:liner
node scripts/check-compat.cjs
npm run test:web
npm run test:liner
npm run test:clock
npm run test:dom
dotnet run --project tests/CoreChecks -c Release
./scripts/build-windows.ps1
```
