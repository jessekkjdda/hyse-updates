# Validação 0.14.0 — 25/11/2026

Base: ZIP da release pública 0.13.0, SHA-256
`78acccd7b502bebf08ebd9de7f8ce1b39ec1643ea2e1372b0f93fd9cb4edcf64`.

Escopo: continuação ao selecionar faixa isolada, busca nas listas, limpeza de
nomes de implementações em App info e botões da prévia da barra de tarefas.

## Verificação automatizada

- 628 verificações Core: 606 anteriores e 22 novas para composição/versões,
  alternância de artistas, origem, indisponíveis, histórico, fallback, orçamento
  de consultas, cancelamento, queue.json legado/novo e estados da barra.
- 98 fluxos DOM/adapters: 91 anteriores e 7 novos para fila isolada da busca,
  filtro de playlists, índice original e fila completa de uma faixa filtrada,
  resultado vazio e limpeza de App info.
- 10 testes de busca em listas: acentos, termos, origem, álbum, ocorrências
  duplicadas e preservação da identidade e ordem originais.
- 38 módulos frontend, 19 renderer Canvas, 19 relógio, 16 fade por linha,
  24 integração local Spicy, 9 métricas e 10 volume durante arraste.
- Total: 871 verificações funcionais. 31 arquivos aprovados e 6 bases históricas
  preservados pelos hashes originais, sem afrouxar a proteção das letras,
  aparência, sliders, sessão Spotify ou leitura de playlists.
- WPF Windows x64 compilado sem avisos ou erros. O helper de atualização usa a
  mesma chave pública; não foram alterados o protocolo de atualização e os
  diretórios legados de dados.

## Comportamento

A faixa isolada é a única entrada inicial da fila. A seleção relacionada ocorre
em segundo plano, é cancelada quando outra fila começa e não muda o relógio ou
as letras em execução. Versões da mesma composição, faixas indisponíveis,
origens diferentes e músicas recentes/enfileiradas são excluídas. As páginas
por artista avançam para evitar limitar a continuação aos dez primeiros itens.

APIs de recomendações do Spotify são restritas a determinados aplicativos;
403/404/410 desativam só essa tentativa até reabrir o processo. O fallback usa
busca por artista e o contexto carregado no hyse. SoundCloud usa sua coleção de
relacionadas, respeitando limites e erros existentes. Se nenhum candidato
válido estiver disponível, a fila termina; não são inventadas recomendações.

Filtrar uma lista não escreve na conta nem modifica sua ordem. Cada ocorrência
mantém o índice original usado pelos comandos de reprodução e edição. Os
botões da barra chamam o mesmo dispatcher com o mesmo lock dos controles do
player. Não ativam/restauram a janela. Fechar para a bandeja não muda: uma
janela escondida pelo X deixa de ter o botão de janela na barra de tarefas.

Consulta real do SoundCloud, sem sessão de usuário: a busca retornou uma faixa
pública e o mesmo cliente leu 30 relacionadas de 30 artistas. Isso verifica a
rota de dados, sem simular o conteúdo e sem afirmar reprodução de áudio.

## Limites

Os testes rodam em Linux. A execução nativa do Setup, os botões de miniatura no
Explorer e o áudio real no Spotify/SoundCloud devem ser conferidos no Windows.
Os testes DOM não comprovam o visual nem a taxa de quadros da GPU. O algoritmo
privado de nenhum serviço é acessível ou reproduzido pelo hyse.
