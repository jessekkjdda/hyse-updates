# Validação 0.16.1 — 26/11/2026

Base publicada: commit 90ec2e36373a139688189d6a347823a12382564e, hyse 0.16.0.
Escopo: conexão/protocolo Discord, apresentação de erro e diagnóstico.

## Evidência e limite

Usuário confirmou Discord instalado no Windows e que nunca chega a Conectado.
Não há acesso ao pipe do computador do usuário, portanto a causa específica
não foi observada diretamente. A 0.16.0 escondia o código/resposta e tratava
recusa de SET_ACTIVITY como falha de transporte. A implementação também escrevia
cabeçalho e JSON em chamadas separadas e escolhia o primeiro pipe que abrisse,
sem procurar outro após handshake recusado ou sem READY.

A referência oficial envia um frame contíguo em uma escrita:
https://github.com/discord/discord-rpc/blob/master/src/rpc_connection.cpp
https://github.com/discord/discord-rpc/blob/master/src/connection_win.cpp
A alteração alinha o encoder a esse comportamento. Isso é correção de
compatibilidade; não se afirma prova da causa exclusiva no PC do usuário.

## Comportamento

- Frame completo em uma única escrita, com limites e leitura fragmentada mantidos.
- Varredura com READY obrigatório e prazo por endpoint; erro explícito de protocolo
  preservado mesmo quando os demais endpoints estão ausentes.
- Conexão habilitada sem exigir música; status por evento do worker com envio ao
  dispatcher WPF, sem depender de polling de reprodução.
- Código/motivo do ERROR e CLOSE retidos. DiscordRpcError separa handshake,
  conexão e atividade. Uma recusa de atividade mantém o pipe aberto.
- Em 4000 de atividade, remove campos opcionais e, se necessário, assets;
  mantém Listening, título, artista e tempos. Nunca transforma em Playing.
- Sucesso informa modo compatível quando aplicável. Erro de permissão não fica
  tentando o mesmo payload em reconexões contínuas.
- Não exige PONG a um PING iniciado pelo hyse. A renovação normal usa ACK de
  SET_ACTIVITY, e o leitor responde ao PING enviado pelo Discord.
- Código 4002 de fechamento impõe espera mínima de 20 segundos. Os limites
  entre atualizações são mantidos mesmo após reconectar.
- Comprimento mínimo de metadados usa grafemas/runes e contempla título Unicode
  de um caractere. Diagnóstico não inclui tokens, usuário, fila ou histórico.

## Verificações

652 Core, 108 DOM, 38 módulos web, 19 renderer, 24 onda, 19 relógio,
16 fade por linha, 24 parser Spicy, 9 métricas, 10 volume e 10 coleções:
929 verificações funcionais. Preservados 31 arquivos e seis bases históricas.

Mais seis verificações executadas em windows-latest com NamedPipeServerStream
em modo Message e o cliente de produção, usando nomes exclusivos de teste:
frame atômico do handshake, SET_ACTIVITY real, PING/PONG iniciado pelo servidor,
CLOSE com código preservado, fallback de endpoint recusado e conexão sem música.
O servidor Windows interpreta bytes/largura de mensagem independentemente do
encoder. O build de distribuição depende do sucesso desse job.

935 verificações no total, sem inflar contagens pelas 1.500 transições de rádio
já exercitadas na base. O transporte foi testado no Windows; não houve sessão
em um cliente Discord real nem instalação nativa do Setup.
