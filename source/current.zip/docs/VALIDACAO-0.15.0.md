# Validação 0.15.0 — 25/11/2026

Base: source/current.zip do commit publicado
3010651b806ea797d0835827da91000656d93635 (hyse 0.14.0).
Escopo: ondulação local por letra e sua opção em Letras.

## Código incorporado

Spikerko/spicy-lyrics, commit 1c02f47cd64ed8c34bb76dd8ff00755db9d1d66f.
Sete arquivos originais completos, hashes Git conferidos no build. Curvas
RefreshedEmphasis/RefreshedLift/getRefreshedFlame e cubicBezier copiadas da origem.
O extrator troca apenas tipo de letra e leitura de largura DOM por largura Canvas.
Elegibilidade e SplitLetters executados diretamente dos arquivos originais.
A pintura Canvas preserva o gradiente e a textura da fonte já aprovada. Usa
textura completa com recortes por grafema; scripts de escrita conectada mantêm
a forma de palavra inteira. Não há spans DOM por letra.

## Verificações

- 628 verificações Core, 102 DOM/adapters, 10 filtro de coleções, 38 módulos web.
- 19 renderer Liner, 19 relógio original, 16 fallback por linha, 24 parser Spicy.
- 9 métricas, 10 volume durante arraste e 21 novas de ondulação. Total: 896.
- A referência independente mantém a leitura DOM original, executada com
  larguras fixas. Os resultados coincidem exatamente em 3.090 pontos, cobrindo
  palavras de 2–7 letras, durações de 1–9 segundos, entrada e relaxamento.
- Rasterização: efeito visível, pausa dos grafemas, avanço e retorno, opção
  desligada pixel a pixel, modos reduzidos, silêncio, sílabas, árabe e descarte.
- 60 amostras sucessivas geram 60 quadros distintos; isso verifica a solicitação
  de desenho, não promete 60 FPS na GPU. DPR 1,25 e 2, mil versos, menos de 25
  bitmaps visíveis, dois Canvas DOM e descarte da textura de alta resolução.
- Os 12 quadros anteriores de trechos rápidos com linhas a cada 260 ms continuam
  idênticos ao renderer original. 31 arquivos aprovados e 6 bases históricas
  preservados; 34 arquivos Liner e 4 do parser Spicy continuam intactos.
- WPF e helper compilados para Windows x64. Nenhum endpoint, chave ou serviço
  Spicy/Wordly adicionado. Fila, playlists, histórico, contas, fonte, sliders,
  background e bordas não recebem alterações nesta atualização.

## Comportamento e limites

A ondulação usa o mesmo tempo visual do fade; não muda tempos, shift, velocidade
do relógio ou passagem de linhas. A regra Bloom original exige 2–7 grafemas,
no mínimo 1 segundo e voz principal. Linhas com tempos estimados mantêm o fade
anterior sem ondas. Desligada, com movimentos reduzidos, efeitos reduzidos ou
palavra mantida no silêncio, usa a pintura anterior. Pausa mantém a posição
musical; a rolagem/fog já existentes podem terminar sua transição.

Validação executada em Linux com DOM de teste e Canvas 2D de software.
A prévia rasterizada foi inspecionada sobre fundo opaco. O visual CSS, áudio
real, GPU/WebView2 e instalador ainda exigem teste nativo no Windows.
