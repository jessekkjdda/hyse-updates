# Validação — cncx 0.11.0

24/11/2026. .NET SDK 10.0.404, Node 24, publicação Windows x64 self-contained.

## Código original

Origem: https://github.com/tryliner/desktop , commit
54eaab9ade697b95756c68b6901a24b0a27949e4. Manifesto:
source/vendor/liner/manifest.json.

Foram copiados sem alterações 27 módulos de produção Canvas, 2 arquivos de
seus testes, Slider.tsx, TimelineSlider.tsx, windowVisibility.ts e LICENSE:
33 arquivos conferidos contra os respectivos hashes de blob Git.
A importação de @braccato/parsers no renderer de produção é apenas de tipos;
nenhum parser ou backend de serviço é substituído por essa importação.

O bundle de produção importa o renderer original e os dois componentes React.
O antigo renderer DOM e o spring LineMotion da 0.10.1 foram retirados da rota
usada pelo aplicativo. Nenhum fallback apresenta esse código antigo como Liner.

A adaptação em integration/lyrics.ts converte tempos e partes do cncx, inclui
notas em intervalos instrumentais explícitos, liga o relógio existente, eventos,
visibilidade, resize e descarte. Preferências de fonte e movimento e a pintura
da palavra em silêncio são extensões separadas. Os valores padrão de fade não
alteram os tempos nem o desenho do renderer. Opções não padrão são aplicadas
nos inputs do adaptador. Não se chama Wordly a outro provedor.

## Testes executados

- 458 verificações Core: leitores, relógio, persistência, TTML, filas, histórico,
  SoundCloud e perfil, sem nova consulta externa de catálogo.
- 38 verificações de módulos frontend e protocolos RPC/SDK/relógio/helpers.
- 18 verificações do motor original e da adaptação, incluindo 3 casos executados
  diretamente do arquivo original exitClock.test.ts e 15 casos de integração.
- 63 verificações DOM/adaptadores com o aplicativo de produção: slider React por
  teclado e ponteiro, bloqueio de gesto do botão direito, seek/volume nativos,
  silêncio, duas camadas Canvas, playlists, busca, histórico, perfil e ajustes.
- 6 arquivos de leitura Spotify/relógio conferidos por SHA-256 e preservados.
- 33 arquivos Liner conferidos por hash de blob Git antes do bundle.

Total funcional: 577 verificações, além dos hashes de integridade.

Na comparação gráfica foram renderizados 180 quadros sintéticos com mudanças
de linha a cada 260 ms. Em 12 quadros amostrados, a composição de base + camada
live do renderer adaptado coincidiu byte a byte com a do renderer original,
com as configurações padrão e os mesmos dados. As imagens foram confirmadas
como não vazias. É uma comparação Canvas em rasterizador de software, sem CSS.

O caso de silêncio também verifica pixels: a palavra sustentada possui pintura
branca opaca e a palavra anterior fica sem pixels de destaque opaco. Pausa,
retorno de áudio, mil linhas, plain text sem seek, controles opcionais, redução
de movimento e descarte de callbacks após carregamento de fontes são cobertos.

## Build e limites

Restore locked e publicação Windows são executados antes de gerar o pacote.
O empacotador verifica PE x64, arquivos obrigatórios, hashes dos assets publicados
contra o código atual, configuração vazia de credenciais e CRC do ZIP.

Não houve sessão gráfica Windows, escuta real, medição de FPS do aplicativo ou
comparação pixel a pixel da interface completa. O teste de Canvas compara o
renderer e não valida a geometria CSS, WebView2 ou o texto de uma música real.
Os controles da janela nativa conservam a implementação 0.10.1 e a compilação
confere sua sintaxe; seus gestos precisam ser observados no Windows de destino.

Os dados continuam AMLL TTML/LRCLIB/importações. A qualidade dos timestamps e a
cobertura variam por faixa. A integração do renderer não replica o catálogo
Wordly nem sua autenticação. A consulta real AMLL documentada na versão 0.10
é evidência daquela versão; não foi apresentada como teste real novo.

Os testes de playlist desta atualização usam os leitores preservados e fixtures.
A conta e a playlist privada do usuário não foram acessadas no Windows.

## Reproduzir

```powershell
npm ci
npm run build:liner
node scripts/check-compat.cjs
npm run test:web
npm run test:liner
npm run test:dom
dotnet run --project tests/CoreChecks -c Release
./scripts/build-windows.ps1
```
