# Validação cncx 0.7.0

Data: 22 de novembro de 2026. Ambiente de compilação: Linux, .NET 10.0.404,
compilação cruzada para Windows x64, Node 24.

| Verificação | Resultado |
| --- | --- |
| CoreChecks | 385 verificações aprovadas: fila, relógio, OAuth, letras, transporte HTTP, biblioteca, histórico e persistência local |
| Módulos web | 19 verificações aprovadas: correlação/cancelamento RPC, SDK, tempos, pausas, easing, paleta e sintaxe |
| Publicação WPF Windows x64 | Compila sem avisos ou erros; runtime .NET incluído |
| Teste de navegador | Preparado em scripts/check-ui.cjs; execução bloqueada antes de carregar a página |
| Execução nativa no Windows | Não executada neste ambiente Linux |
| Login/reprodução/playlists em conta real | Não executados nesta sessão |

O Chromium local falhou ao criar o socket de perfil: operação não permitida.
A tentativa pela prévia do navegador remoto não alcançou o servidor local.
Não há evidência visual aprovada nem confirmação de áudio real desta sessão.
Os testes de SDK/HTTP usam substitutos controlados e não provam a integração real.

A suíte de navegador preparada cobre navegação sem player residual, letras em
pausas e seeks, carregamento progressivo, erro/retry de playlist, criação local,
edição, remoção, reordenação, busca concorrente/paginada, adicionar faixa,
histórico, pausa e janela mínima. Ela deverá rodar em Windows/Chromium antes de
classificar a distribuição como estável.

## Diagnóstico de playlists

| Sintoma/retorno | Comportamento |
| --- | --- |
| Carregamento em andamento | Quantidade parcial visível e edição bloqueada |
| Resposta incompleta ou contagem divergente | Erro explícito, sem declarar leitura completa |
| 403 | Texto do Spotify preservado; Tentar novamente na própria tela |
| Playlist seguida, sem posse/colaboração | Pode ser listada, mas a API atual pode negar os itens |
| 401 | Transporte invalida e renova o token uma vez |
| Falha temporária de leitura | Uma repetição controlada; falha persistente é exibida |
| 429 | Retry-After respeitado; não há repetição agressiva |
| Falha ao criar/editar | Não há repetição cega de gravações |
| Faixa indisponível | Posição preservada na lista e ignorada ao avançar a fila |

Referências oficiais consultadas:
- https://developer.spotify.com/documentation/web-api/tutorials/february-2026-migration-guide
- https://developer.spotify.com/documentation/web-api/reference/get-playlists-items

## Estrutura

WebView2 único → bridge de ações tipadas → serviços Spotify/arquivos locais.
As telas são exclusivas no DOM. O SDK fornece o estado de reprodução ao relógio;
o renderer deriva a posição visual desse estado, com extrapolação limitada.
As letras seguem marcas reais e o offset da faixa. O tema publica tokens globais
usados por navegação, listas, cards, controles e letras.
