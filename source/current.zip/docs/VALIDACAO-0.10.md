# Validação cncx 0.10.0

23/11/2026. Compilação Windows x64 produzida com .NET SDK 10.0.404 em Linux.

| Verificação | Resultado |
| --- | --- |
| CoreChecks offline | 458 verificações aprovadas. Inclui filas, playlists, OAuth, letras, silêncio, perfil local e TTML. |
| Consulta real AMLL | Mais uma verificação aprovada: identidade Spotify exata da faixa de referência, TTML interpretado pelo parser de produção, múltiplas linhas e tempos por palavra válidos. |
| Módulos frontend | 38 verificações aprovadas. Inclui relógio por quadro, prioridade de amostras locais, posições repetidas, guarda de seek, pausa, última palavra iniciada, formatos de capa e formatação de preferências. |
| DOM e protocolo | 54 verificações aprovadas. Aplicativo real com host e SoundCloud Widget explicitamente substituídos. Início, player opcional, rodapé persistente, pesquisa, paginação, transições de estado, palavras sustentadas, notas de instrumental, no máximo 17 linhas montadas, perfil, foto, banner, categorias, App info, licenças, capas, preservação de preferências e fluxos de playlists. |
| Compatibilidade | Cinco arquivos dos leitores Spotify 0.8 e PlaybackClock.cs da base anterior preservados byte a byte. SDK recebe apenas o evento local adicional necessário para o novo relógio visual; seus comandos/autenticação permanecem no caminho existente. |
| Compilação/publicação | Release win-x64 self-contained, dependências travadas, sem credenciais no config distribuído. |
| Pacote | PE x64, fontes correspondentes, módulos novos, testes e licenças conferidos pelo empacotador; CRC de todas as entradas e SHA-256 do ZIP. |

O parser TTML cobre clock time, segundos com e sem sufixo e milissegundos.
Preserva espaços e tempos de palavras; exclui traduções, romanização e vozes de
fundo sobrepostas da linha principal. Proíbe DTD/entidades externas e limita
alocação. A fonte nova é consultada por identidade Spotify exata, usa cache em
memória e respeita 429. Timeout ou indisponibilidade mantém o fallback LRCLIB.

Perfil é salvo de forma atômica em pasta própria. Foto e banner são independentes.
O seletor nativo valida a imagem, limita dimensões e a converte para PNG local,
sem alterar o arquivo escolhido. Atualizar um grupo de configurações não limpa
as preferências dos demais. Créditos e versão não aparecem na navegação normal.

O relógio visual usa amostras locais do SDK/widget, interpolação por quadro e
fallback nativo. Posições repetidas não reiniciam a interpolação; amostras antigas
não arrastam um seek para trás. O fade tem um pequeno avanço visual ajustável,
sem antecipar a seleção da próxima linha.

No silêncio, a palavra atual já iniciada substitui a regra anterior que exigia
palavra concluída e podia recuar. O alvo é fixado no início medido do silêncio.
Gaps por palavra ou linha indicados pela fonte podem mostrar ♪ durante instrumental.
Nenhuma dessas regras é detecção/transcrição de voz. Sem tempos por palavra,
a seleção continua estimada pelo fade.

## Limites de evidência

A execução WPF/WebView2 e o áudio real não foram testados em Windows nesta sessão.
Não há medição de 60 fps, teste de pintura WebGL ou comparação auditiva com Liner.
Os testes DOM verificam interação e estado, sem validar geometria ou suavidade
visual. Os estilos e o shader foram implementados e a publicação Windows foi
compilada; a aparência final precisa ser observada no ambiente de destino.

O catálogo AMLL não é o Wordly do Liner. A consulta real aprovada cobre uma faixa;
outros títulos podem não existir ou ter dados de qualidade diferente. LRCLIB
continua por linha quando não há contribuição TTML correspondente. O código do
sincronizador e do shader do Liner não foi extraído para o cncx.

Playlists públicas e privadas mantêm a cadeia 0.8. Os testes reais de rede das
versões anteriores não são apresentados como novos testes nesta atualização.
A playlist privada do usuário depende da conta e da sessão disponíveis no Windows.

Para reproduzir:

```powershell
npm ci
node scripts/check-compat.cjs
npm run test:web
npm run test:dom
dotnet run --project tests/CoreChecks -c Release
$env:CNCX_LIVE_AMLL='1'
dotnet run --project tests/CoreChecks -c Release
./scripts/build-windows.ps1
```
