# Validação — cncx 0.11.3

24/11/2026. Integração local do parser TTML original do Spicy Lyrics sobre a
base aprovada 0.11.2, preservando o renderer Canvas, fontes, relógios e sliders
originais do Liner. Nenhuma chave ou serviço Spicy é necessário.

## Código original incorporado

Origem: https://github.com/Spikerko/spicy-lyrics
Commit: 1c02f47cd64ed8c34bb76dd8ff00755db9d1d66f
Quatro arquivos originais em vendor/spicy: parser.ts (TTML), EmptyLines.ts,
StripZeroWidth.ts e LICENSE. O build verifica cada conteúdo contra seu blob Git.
A licença AGPL-3.0 e a origem acompanham source/vendor e app/licenses.
O logger recebe um adaptador de host separado; o parser não é editado.

## Caminho de produção

O provedor AMLL existente conserva o XML recebido no documento de letras.
Arquivos TTML importados também conservam o original no override local.
O adaptador frontend usa o parser Spicy para interpretar os spans, fronteiras
entre sílabas/palavras, agentes e vocais de apoio; converte segundos em ms
sem reescalar o tempo. Os dados seguem para o renderer original do Liner.
O deslocamento nativo de 150 ms para partes reais permanece.

São exigidos: XML limitado a 1 MB, estrutura válida, ausência de DTD/entidades
declaradas, até 2.000 linhas e 30.000 partes, tempos finitos e ordenados,
mesma sequência de texto principal da baseline e preservação de todos os
limites de palavras já temporizados. Divergências devolvem o objeto original.
A integração nunca cria uma requisição ao catálogo Spicy.

Documentos LRCLIB, dados antigos sem XML, texto simples, instrumentais e fontes
por linha ficam no caminho existente. Uma linha sem tempos por palavra dentro
de TTML misto mantém a estimativa gradual. O XML é processado uma vez por
documento; frames de animação não repetem o parsing.

Um parágrafo de duração zerada, contendo spans válidos, recupera início/fim
reais das palavras em vez de comprimir o verso inteiro. Uma fixture com primeira
linha defeituosa e segunda linha válida percorre o provedor C#, JSON camelCase,
parser original e modelo do renderer. A segunda linha mantém seus tempos.
Vocais de apoio preservam seus próprios spans e usam isBackground do Liner.
O intervalo instrumental é contado após a última voz conhecida.

## Resultados automatizados

- 465 verificações Core offline, incluindo sete do transporte/cache TTML.
- 38 verificações de módulos frontend e SDK.
- 19 verificações do renderer e raster de software; 12 quadros de troca rápida
  de linhas continuam idênticos ao renderer original na fixture de tempos reais.
- 19 verificações do relógio original/fallback.
- 16 regressões do fade de linhas, sem mudança dos tempos reais.
- 68 verificações DOM, playlists, busca, perfis, controles, capa e navegação.
- 22 verificações locais Spicy, incluindo o bundle de produção e duas do
  transporte real C# → JSON → frontend usando dados de teste artificiais.

Total funcional executado: 647 verificações.

Os 34 arquivos originais do Liner e quatro do Spicy passam pela verificação
Git. Além disso, 34 arquivos protegidos da base 0.11.2 conservam SHA-256:
styles, estrutura da janela, contorno, SDKs/clocks, leitores de playlists,
fontes, sliders, busca, navegação, perfil/configurações e serviços anteriores.
O único ajuste no WordLyricsProvider é conservar o XML no documento; seus
filtros de identidade, HTTP, cache, limites e backoff permanecem.

## Build e distribuição

Restore NuGet com lock; publicação Windows x64 self-contained. O empacotador
confere assets publicados contra fontes, PE x64, configuração sem credenciais,
conteúdo obrigatório e CRC do ZIP. O código correspondente completo é incluído.

O build PowerShell reproduz os testes, exporta uma fixture de transporte
artificial e a verifica no adaptador antes de publicar:

```powershell
./scripts/build-windows.ps1
```

Testes frontend específicos:

```powershell
npm ci
npm run build:liner
npm run test:spicy
npm run test:fade
npm run test:clock
npm run test:liner
npm run test:preservation
```

## Limites

Não foi executado áudio real, medição de FPS ou uma sessão gráfica Windows.
Os resultados não demonstram percentual de melhora perceptiva. O parser local
melhora o uso de dados disponíveis; não inventa marcações ausentes nas fontes.
O catálogo hospedado do Spicy e Wordly não estão conectados. TTL/cache/dados
continuam sendo os das fontes existentes, sem espelhamento de catálogos.
