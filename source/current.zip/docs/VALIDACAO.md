# Validação — cncx 0.6.0

Data: 22/11/2026. SDK 10.0.404, runtime .NET 10.0.15, alvo Windows x64.

## Regressões tratadas

- Player visível atrás das páginas: navegação passou a aplicar estados exclusivos;
  apenas Player mostra seu painel, e o rodapé duplicado da biblioteca foi retirado.
- Busca descartada por uma faixa inválida: o parser isola itens indisponíveis.
- Busca disputada por consultas anteriores: uma fila serial preserva só a consulta
  pendente mais recente e impede a atualização da página por resultados obsoletos.
- Carregamento sem retorno: timeout de leitura não é mais engolido como cancelamento;
  o transporte HTTP usado em produção tem retry limitado para GET, preserva a
  limitação por Retry-After e não repete cegamente a criação de playlists.
- Letras: destaques agora dependem do relógio atual, sem animações independentes
  de palavras futuras; amostras repetidas não reiniciam a interpolação; um salto
  recente tem proteção contra a resposta antiga; uma correspondência exata
  sincronizada não é trocada por outra gravação em busca de tempos por palavra.

## Verificações executadas

- Compilação WPF/XAML e publicação Windows x64 com dependências fixadas.
- 371 verificações da lógica, incluindo os cenários anteriores e as novas regressões.
- Produção HTTP com HttpMessageHandler controlado: URL e cabeçalho de autenticação,
  leitura 503 seguida de sucesso, timeout repetido convertido em erro visível,
  criação POST sem repetição indevida e backoff 429.
- Busca: resultados mistos, paginação e exclusão de consultas pendentes obsoletas.
- Reprodução: amostras duplicadas, pausa, troca de faixa e amostras antigas após salto.
- Histórico: reprodução mínima, pausa, salto, ocorrências repetidas, persistência,
  limpeza e tolerância a arquivo corrompido.
- Invariante de navegação: nenhuma página fora do Player mostra o player.
- JavaScript: ponte de tokens, início/fim, pausa, concorrência e amostras atrasadas.
- Integridade do ZIP, executável x64, manifesto e inclusão do código correspondente.

## Limites da validação

Os testes não usaram a conta do usuário. A causa específica do não carregamento
da playlist não foi reproduzida com uma resposta autenticada; foram corrigidos
defeitos comprováveis no código e adicionado o retorno explícito da falha.
Um 403 por restrição da conta ou da playlist continua sendo uma recusa do Spotify.

Não foram feitos testes de áudio, renderização WPF ou medições de fluidez em
Windows. A compilação e os testes de lógica não comprovam funcionamento integral
na máquina do usuário. O botão Copiar erro permite obter o retorno concreto da
playlist caso o problema persista.

## Fontes técnicas

- https://developer.spotify.com/documentation/web-playback-sdk/reference
- https://developer.spotify.com/documentation/web-api/reference/search
- https://developer.spotify.com/documentation/web-api/reference/get-playlists-items
- https://developer.spotify.com/documentation/web-api/tutorials/february-2026-migration-guide
- https://github.com/tranxuanthang/lrclib/blob/main/ARCHITECTURE.md
