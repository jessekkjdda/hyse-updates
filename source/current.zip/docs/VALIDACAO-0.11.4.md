# Validação — cncx 0.11.4

24/11/2026. Base 0.11.3 preservada em checkout separado.

## Alterações

- O adaptador Spicy faz validação por verso, usando texto e posição temporal
  como chave. Um verso incompatível conserva o mesmo objeto da baseline.
  Refrões repetidos não recebem os tempos de outra ocorrência. Tempos válidos
  por palavra continuam obrigatoriamente iguais aos originais.
- Um único pré-carregamento aguarda 3 s após terminar a letra atual, usa os
  provedores/caches/backoff existentes e é cancelado/aguardado antes de carregar
  a próxima música em primeiro plano. Não emite letras, não altera reprodução
  nem cria uma conexão com o catálogo Spicy. Erros opcionais não disparam retries.
- A fila fornece PeekNext sem avançar índice ou histórico; em aleatório reserva
  a escolha que Next realmente usará. Mudanças de fila/modo invalidam a reserva.
- O carregamento de letras tem geração própria; respostas canceladas ou antigas
  não substituem uma busca nova ou uma letra importada.
- Os selects mantêm dados nativos para FormData e usam um popup próprio com
  paleta do álbum, blur, mouse, teclado, foco e fechamento. Há caminho sem Popover
  para hosts que não ofereçam essa API. Diálogos usam o mesmo vidro escuro.
- O formato da capa é salvo ao selecionar. Uma prévia usa a mesma máscara do
  player, aplicada também à imagem. A seleção é restaurada explicitamente ao
  reconstruir o formulário. As gravações são serializadas entre instâncias da
  tela, evitando que respostas antigas restaurem um formato anterior.
- App info exibe uma janela de 240 intervalos da interface: FPS, P95, maior
  intervalo, quadros acima de 34 ms e custo JS P95 do callback medido. Tempo
  oculto é descartado. Isso não mede diretamente o compositor ou o renderer
  Canvas independente, nem muda qualquer relógio de reprodução.

## Verificações

- Core: 485 verificações offline; 20 novas de fila, reserva e pré-carregamento.
- Módulos frontend/SDK: 38.
- Renderer original e rasterização de software: 19; comparação de 12 quadros
  da fixture rápida continua idêntica ao Liner original.
- Relógio original: 19.
- Regressões do fade: 16.
- Fluxos DOM/bridge: 76, incluindo escolha sem Save, reabertura, teclado,
  descarte do popup, respostas atrasadas entre telas e atualização de métricas.
- Integração Spicy local: 24, incluindo fallback parcial, refrão repetido,
  bundle de produção e transporte C# → JSON → renderer.
- Métricas de quadros: 9, incluindo stalls visíveis, ocultação, percentil,
  limite de memória e separação entre intervalo e custo JS.

Total funcional executado: 686 verificações.

Os 34 arquivos originais Liner e quatro Spicy mantêm os blobs Git fixados.
31 arquivos protegidos da 0.11.3 conservam SHA-256: fontes, SDKs, clocks,
leitores de playlists, sliders, paleta, fundo, contorno nativo e parsers/serviços
anteriores. App, settings-view e CSS foram retirados da lista porque esta
atualização modifica esses três arquivos por solicitação do usuário.
Os seis hashes históricos de leitores Spotify/clock também são preservados.

## Distribuição

Restore NuGet com lock e publicação Windows x64 self-contained. O empacotador
confere configuração sem credenciais, PE x64, assets publicados, código-fonte
correspondente, arquivos obrigatórios e CRC do ZIP. Não há dependência nova.

O build reprodutível está em scripts/build-windows.ps1, incluindo os novos
check-frame-metrics e testes Core. Os locks, notices e fontes acompanham source.

## Limites

Não houve execução gráfica Windows, reprodução de áudio real ou medição de FPS
em hardware do usuário. Os testes DOM não validam pintura CSS pelo WebView2.
A tentativa de iniciar Chromium local foi recusada pela restrição de sockets do
ambiente; nenhuma captura visual foi produzida e esse ensaio não conta como teste
aprovado. O diagnóstico de quadros será útil no teste real do aplicativo.

A sincronização continua limitada aos tempos disponíveis nas fontes. Não foi
medida uma porcentagem de melhoria. O catálogo hospedado Spicy e Wordly não são
consultados. Arquivos originais importados antes da 0.11.3 precisam ser importados
novamente para que o XML seja conservado para o parser local.
