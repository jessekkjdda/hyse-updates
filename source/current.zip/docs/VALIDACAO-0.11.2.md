# Validação — cncx 0.11.2

24/11/2026. Correção restrita ao fade de dados por linha, ao preenchimento do
contorno da janela e à transição de escala da capa.

## Causa e alteração

O tokens.ts original usa LINE_SYNCED_DELAY_MS = 50 para palavras de uma linha
sem tempos próprios, com duração zero. Assim, uma frase longa pode receber todos
os destaques em poucas centenas de milissegundos. Isso explica uma música com
word-sync ficar correta e outras por linha correrem ao final logo no início.

O adaptador agora fornece partes estimadas apenas quando faltam tempos úteis
por palavra. Os pesos de texto e o intervalo do verso distribuem os inícios e
durações. Os timestamps de palavras reais não passam pela estimativa. Marcadores
com inícios reais distintos, mesmo de duração zero, continuam válidos. Os dados
originais e o campo wordSynced não são alterados.

O shift é calculado com o modelo original antes da inclusão de estimativas,
conservando 115 ms por linha e 150 ms para partes realmente temporizadas.
Silêncio em uma linha estimada segura a palavra visualmente alcançada. Não se
apresenta essa estimativa como medição do instante de cada palavra cantada.

A margem WebView de 6 px e sua atualização em ApplyWindowShape foram removidas.
O recorte nativo arredondado continua definindo a janela. Oito grips transparentes
enviam nomes de borda validados, usando resize do Windows; são desativados no
estado maximizado. A borda direita/inferior de páginas com scroll preserva
espaço para o scrollbar. A fonte e o layout do player não foram redesenhados.

A animação de drift está no cover-stage e mantém a fase ao pausar. O cover-shell
executa só a escala com transição de 1,4 s, sem competição com a animação anterior.
A preferência de reduzir movimentos desativa esses movimentos.

## Verificações executadas

- 458 verificações Core offline.
- 38 verificações de módulos frontend e SDK.
- 19 verificações do renderer e raster: os 12 quadros da fixture com tempos
  reais continuam iguais ao renderer original; silêncio e descarte são cobertos.
- 19 verificações do relógio original e seus fallbacks.
- 16 regressões novas de fade: reprodução do burst antigo, progressão parcial,
  final tardio, partes reais intactas, pontos temporais, gaps, Unicode e duração.
- 68 verificações DOM/protocolos: fluxos anteriores, oito grips, bloqueio em
  maximizado e preservação dos elementos da capa entre pausa e reprodução.

Total funcional: 618 verificações.

Os 34 arquivos importados do Liner continuam iguais aos blobs Git fixados.
Além disso, 22 arquivos da 0.11.1 foram conferidos por SHA-256: clocks e SDKs,
leitores, fontes, sliders, paleta, fundo e apresentação. O manifesto está em
tests/preservation-112.json. Os seis hashes de compatibilidade históricos também
continuam válidos. Nenhuma dependência de runtime foi adicionada.

Restore e publicação Windows x64 são executados antes do pacote. O empacotador
verifica os assets publicados contra o source, PE x64, configuração vazia de
credenciais, arquivos obrigatórios e CRC. As fontes originais são incluídas.

## Limites

Os testes Canvas usam rasterização de software, e os testes DOM não validam CSS
pintado pelo WebView2. A janela arredondada e o resize foram compilados, mas não
executados numa sessão gráfica Windows. Não houve teste com áudio real, captura
de FPS ou comparação visual da transição de escala no Windows.

Tempos por linha não contêm o ritmo real de cada palavra: a correção evita o
burst e distribui o fade, sem criar dados vocais que a fonte não oferece.
Wordly permanece fora desta atualização e os provedores não foram alterados.

## Reprodução

```powershell
npm ci
npm run build:liner
npm run test:preservation
npm run test:fade
npm run test:web
npm run test:clock
npm run test:liner
npm run test:dom
dotnet run --project tests/CoreChecks -c Release
./scripts/build-windows.ps1
```
