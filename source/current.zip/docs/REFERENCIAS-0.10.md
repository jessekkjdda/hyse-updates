# Referências e decisões — 0.10.0

23/11/2026. Foram examinadas as imagens enviadas e o vídeo de 4,75 segundos,
1920 × 1080, 60 quadros por segundo. O material demonstra a referência visual;
a taxa de quadros do arquivo não mede a taxa do aplicativo cncx.

| Material | Observação | Implementação nesta versão |
| --- | --- | --- |
| Configurações cncx | Informações técnicas, versão e créditos misturados às preferências; números com muitas casas decimais. | Categorias separadas, perfil próprio, App info e formatação curta dos valores. |
| Busca cncx | Frase promocional e atalhos repetidos para abas existentes. | Removidos; mantém busca, filtros e histórico de consultas. |
| 505 no cncx | Muitos rótulos de fonte/estado junto da capa e letra. | Título, artista, controles e menu; fonte e ajustes ficam no menu ou App info. |
| Riff, faixa russa | Máscara da capa com contorno orgânico, além da capa quadrada. | Formas próprias circular, pétalas, superelipse, quadrada e arredondada; seleção automática estável opcional. |
| Riff, outra faixa | Transição entre linhas e fade contínuos. | Linhas virtualizadas, transforms e pintura por quadro, sem quantização de progresso. |
| Liner, Início | Navegação por ícones, listas reais e player persistente no rodapé. | Início independente, ícones, dados de escutas existentes e player compacto que não força a tela grande. |
| Liner, Black | Capa grande, controles abaixo, coluna de letras e fonte Wordly. | Composição própria enxuta; dados por palavra via AMLL quando houver correspondência exata, LRCLIB como fallback. |
| Vídeo Liner | Fundo continua se movendo com a faixa pausada. | Campo de cores WebGL próprio; movimento pausado mais lento e controles para reduzir/desligar os efeitos. |

Liner foi consultado no commit 54eaab9ade697b95756c68b6901a24b0a27949e4.
Sua licença Source-Available & Non-Commercial Contribution License 1.1 permite
estudo, mas restringe a extração de sincronização, shaders, recursos e interfaces
distintivas para aplicativos separados. Não foram copiados esses componentes.
As consultas de letras no Liner passam pelo backend oficial com autenticação e
assinatura. A indicação Wordly na imagem não corresponde ao catálogo LRCLIB.
O cncx não usa nem emula essa autenticação ou serviço.

Riff foi consultado no commit 5031a840fb50dbb53a5830329ed69363fe09d824, MIT.
O código de shapes confirma formatos orgânicos adicionais. Os cálculos de fade
já adaptados do Riff permanecem com o aviso MIT; as formas novas, o campo WebGL,
o relógio visual e a organização do cncx são implementações próprias.

A API pública oficial AMLL TTML foi conferida na documentação e consultada em
execução. O endpoint /v1/lyrics/get aceita spotifyId e retorna metadados, identidade
de plataforma e TTML. O cncx exige identidade exata, interpreta tempos reais e
recusa resposta de outra faixa. Uma consulta real para Blinding Lights foi
convertida pelo parser de produção para letras com tempos por palavra. Um exemplo
505 consultado não teve correspondência: a cobertura não é universal e não é
apresentada como equivalente ao Wordly.

Fontes:

- https://github.com/tryliner/desktop
- https://github.com/tryliner/desktop/blob/54eaab9ade697b95756c68b6901a24b0a27949e4/LICENSE
- https://github.com/tryliner/desktop/blob/54eaab9ade697b95756c68b6901a24b0a27949e4/src/shared/api/api.ts
- https://github.com/rootscripts/riff
- https://github.com/rootscripts/riff/blob/5031a840fb50dbb53a5830329ed69363fe09d824/src/renderer/shapes.js
- https://amll.dev/reference/http-api/overview.html
- https://amll.dev/api/ttml/openapi.yaml
- https://github.com/amll-dev/amll-ttml-db/blob/main/LICENSE
