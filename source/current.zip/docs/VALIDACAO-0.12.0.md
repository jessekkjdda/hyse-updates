# Validação hyse 0.12.0

24 de novembro de 2026. Base: cncx 0.11.4 aprovada pelo usuário.

## Escopo

- Renomeação do produto visível para hyse e identificação de dispositivo Spotify.
- Grupo de três controles de janela, com vidro da paleta existente e alvos maiores.
- Volume durante `input` nos dois players; serialização, substituição de amostras
  antigas e intervalo mínimo de 40 ms. `change` confirma a preferência no disco.
- X/Alt+F4 oculta; bandeja oferece Abrir hyse e Sair. Uma segunda abertura pede
  restauração da instância. Saída explícita e encerramento do Windows encerram;
  ausência da bandeja mantém uma saída acessível. Reinício do Explorer recria o ícone.
- Instalador NSIS por usuário, atalhos, desinstalador e identidade estável para
  atualização no mesmo local. O app salva e sai mediante --exit-for-update antes
  de substituir arquivos. Não há force kill, inicialização automática ou feed online.

## Preservação

Os caminhos `%APPDATA%/cncx`, `%LOCALAPPDATA%/cncx`, o perfil WebView2, domínio local
e contratos do bridge são mantidos. Conta, DPAPI, biblioteca, histórico, offsets,
imagens, configurações e caches não são migrados nem apagados pelo instalador.
O desinstalador enumera apenas arquivos distribuídos e pastas vazias da instalação.

Os 31 hashes protegidos da versão anterior continuam verificados. Em seis
arquivos, o verificador reverte somente os trechos exatos de renomeação ou o
callback de volume antes de comparar com o SHA-256 original. Qualquer outra
diferença continua falhando. Os seis hashes históricos também usam esse filtro.
Renderer, bundles, fontes, relógios, parsers e algoritmos de letras não foram editados.
Os 34 arquivos originais Liner e quatro Spicy conservam seus blobs Git fixados.

## Verificações executadas

| Grupo | Quantidade |
|---|---:|
| Core, incluindo as oito combinações da política de fechamento | 493 |
| Módulos frontend e SDK | 38 |
| Renderer original e rasterização de software | 19 |
| Relógio original | 19 |
| Regressões do fade | 16 |
| Fluxos DOM/bridge, incluindo ponteiro ainda pressionado nos dois volumes | 81 |
| Integração Spicy local com transporte C# → JSON | 24 |
| Métricas de quadros | 9 |
| Fila de volume, coalescência, espaçamento, falha e commit final | 10 |
| **Total funcional** | **709** |

Restore com lock e compilação/publicação Windows x64 self-contained aprovados.
NuGet não conseguiu consultar a lista online de vulnerabilidades (NU1900); isso
não impediu o restore/build. Dependências do aplicativo e seus locks são os mesmos.

O instalador é compilado pelo NSIS 3.11. O script verifica PE, SHA-256 e inclui
código correspondente, avisos e licenças. O ZIP confere CRC, PE x64 do aplicativo,
assets publicados iguais ao source, arquivos obrigatórios e configuração sem
credenciais. O instalador usa HKCU e LocalAppData, sem solicitar administrador.

## Limites

Não houve execução do instalador ou da bandeja em uma sessão Windows real,
reprodução de áudio real ou inspeção visual da pintura CSS. O teste DOM confirma
comandos de áudio durante o arraste e protocolo de commit, não o som físico.
Não foi repetida a tentativa de Chromium bloqueada por sockets no ambiente.
A instalação, restauração pela bandeja, atualização e aparência requerem teste
no Windows do usuário. A fonte e sincronização aprovadas foram preservadas.
