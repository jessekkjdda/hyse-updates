# Validação — cncx 0.10.1

23/11/2026. Publicação Windows x64 self-contained, .NET SDK 10.0.404.

## Resultados executados

- 458 verificações Core offline: leitores, persistência, relógio, TTML, histórico,
  filas, SoundCloud e perfis. O conjunto existente foi preservado.
- 38 verificações dos módulos frontend/RPC/SDK e fade/timeline.
- 7 verificações da nova integração analítica do movimento: equivalência da
  trajetória em 30/60/144 Hz, posição/velocidade contínuas ao retarget, oito
  mudanças de 120 ms, snap, retorno após suspensão, timestamps e velocidade.
- 62 verificações DOM e adaptadores: fluxo real de módulos com host de teste,
  novos comandos minimizar/maximizar/restaurar, seek e volume, progressão do
  transform entre quadros na tela de letras, playlists e configurações.
- 6 arquivos de leitura de playlists/relógio permanecem idênticos ao baseline,
  conferidos por SHA-256 no script check-compat.cjs.
- Montserrat variável original decodificada como TrueType pelo FontTools, eixo
  wght 100–900. Licenças SIL OFL incluídas com os dois arquivos de fontes.
- Restore locked e publicação Windows concluídos. O empacotador verifica PE x64,
  arquivos obrigatórios, configuração sem credenciais e CRC do ZIP.

Total: 565 verificações funcionais offline, mais 6 hashes de compatibilidade.
As trajetórias sintéticas a 30/60/144 Hz testam a independência matemática do
passo de integração; não medem a taxa de renderização da aplicação.

## Correção da capa

Na 0.10.0, left:50% não tinha efeito no elemento estático e translateX(-50%)
continuava aplicado. Isso deslocava a capa para fora da coluna, como na imagem
enviada. A nova regra usa margem automática e largura limitada por coluna e
altura útil. A imagem usa object-fit:contain. O contorno selecionado continua
recortando apenas conforme a máscara configurada.

## Limites observados

Não houve sessão gráfica Windows, medição de FPS, escuta de áudio, comparação
pixel a pixel nem validação dos gestos nativos de arrastar, bordas ou botões em
um Windows real. Testes DOM não validam pintura CSS ou geometria de tela.
O build verifica compilação e empacotamento; o resultado visual requer o destino.

Wordly não foi integrado e o motor de letras do Liner não foi extraído. A licença
da primeira publicação e da versão atual restringe essa extração. O cliente
Liner consultado usa serviço autenticado e assinado para letras. Esta versão
mantém AMLL TTML/LRCLIB e importações, com cobertura e qualidade próprias.
Não foi executada uma nova consulta real AMLL nesta correção; o teste real
registrado na documentação 0.10 é evidência da versão anterior.

## Reproduzir

```powershell
npm ci
node scripts/check-compat.cjs
npm run test:web
npm run test:motion
npm run test:dom
dotnet run --project tests/CoreChecks -c Release
./scripts/build-windows.ps1
```
