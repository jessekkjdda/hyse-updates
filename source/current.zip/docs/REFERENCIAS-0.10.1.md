# Referências — correção 0.10.1

A imagem enviada mostra o título nativo em uma faixa separada e a capa
transladada para fora da coluna esquerda. A correção remove a faixa, mantém o
título do processo e integra comandos de janela ao cliente WebView2.

Liner foi consultado pelo repositório oficial https://github.com/tryliner/desktop .
A licença atual 1.1 e a inicial 1.0 restringem extração dos algoritmos de letras
para um aplicativo separado; não há versão permissiva anterior no histórico de
LICENSE publicado. Não foi incorporado código protegido dessas implementações.

src/features/lyrics/canvas/fonts.ts usa a família Montserrat; index.html carrega
essa família pelo Google Fonts e define --font-montserrat-family. O cncx incorpora
Montserrat do repositório independente Google Fonts, sob OFL, e usa essa família
nas letras sem copiar arquivos de fonte do Liner. Wordly é provedor de letras,
não a família tipográfica. As chamadas Liner passam por seu serviço autenticado;
o cncx continua usando seus provedores declarados, sem renomeá-los.

O novo spring utiliza a solução analítica comum do oscilador criticamente
amortecido; implementação própria em motion.js. slider.js conserva o input range
nativo e acrescenta trilha/indicador próprios. Não são componentes extraídos do
Liner. Fontes e avisos de terceiros acompanham a distribuição.
