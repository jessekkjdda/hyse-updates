# Validação cncx 0.9.0

Data: 23/11/2026. Compilação Windows x64 produzida em Linux com .NET 10.0.404.

## Verificações executadas

| Verificação | Resultado |
| --- | --- |
| CoreChecks, sem rede | 437 verificações aprovadas. Inclui o conjunto anterior, catálogo de quatro entidades, URLs/cursor SoundCloud, hidratação de playlists com duplicatas, contagem parcial, cache de ID público, renovação após 401, recuo 429, cancelamento e playlists locais mistas. |
| Módulos frontend | 19 verificações aprovadas: RPC fora de ordem, cancelamento, erros, tempos/pausas, palavras, easing, tema e protocolo Spotify. |
| Aplicativo completo em DOM | 41 verificações aprovadas com Happy DOM, bundle real do aplicativo e host/Widget de teste. Navegação, letras dedicadas, Escape, destaque da última palavra/linha, pesquisa obsoleta, destaque/categorias, paginação, artista, SoundCloud, adição local, histórico, configurações, recuperação de playlist, comandos e cancelamento do Widget. |
| Compatibilidade por SHA-256 | Sete arquivos preservados byte a byte: cinco leitores/integrações de playlist da 0.8, sdk.js e PlaybackClock.cs da 0.7. |
| Rede real Spotify | Playlist pública de exemplo `3cEYpjA9oz9GiPac4AsH4n` abriu pelo leitor de produção. Não envolve conta privada nem edição. |
| Rede real SoundCloud | Busca `Steve Lacy Dark Red` pelo catálogo de produção e resolução de uma faixa pública retornaram a mesma identidade. Não constitui teste de reprodução de áudio. |
| Build Release | Compilação aprovada, sem avisos ou erros. Publicação self-contained win-x64 com NuGet em locked mode. |
| Pacote | EXE PE x64, dependências, fontes correspondentes, testes e licenças conferidos pelo empacotador; CRC de todas as entradas e SHA-256 do ZIP. |

Os testes de silêncio usam a classe de produção SilenceGate com relógio e
amostras controlados. Cobre áudio anterior obrigatório, limiar e estabilidade de
650 ms, instrumental audível, mute, volume zero/inválido, amostra inválida,
Connect remoto, medidor ausente, amostras antigas, pausa manual, término natural,
troca de faixa e configuração desligada. A renderização recebe o estado
confirmado e só destaca palavra/linha já concluída.

Os testes DOM executam app.js e seus módulos reais, sem cópia da interface de
produção. O host nativo e o SoundCloud Widget são substitutos explícitos de teste.
O ambiente não ofereceu navegador local utilizável: não houve captura visual ou
medição de FPS. DOM não comprova geometria, transparência, cantos, suavidade visual,
DRM, qualidade de áudio ou alinhamento ouvido pelo usuário.

## Limites que exigem Windows

Não foi executado o aplicativo WPF/WebView2 em Windows nesta sessão. Ainda é
necessário observar o player oficial com áudio real, a sessão Core Audio do
WebView2, a detecção de silêncio da gravação e a comparação auditiva de músicas
rápidas. A janela foi configurada em 1200 × 780, com mínimos responsivos 820 × 560;
proporções e estilos estão implementados, mas a aparência final não foi comprovada
por teste visual neste ambiente.

Uma leitura pública real não valida a playlist privada do usuário. Essa cadeia
permanece exatamente na base 0.8. O SoundCloud pode exigir login ou bloquear uma
faixa no widget, ainda que o metadado público exista. O app não converte prévias
em faixas completas e mostra falhas recebidas.

O destaque especial exige silêncio medido no áudio local, não classificação de
voz. Instrumental acima do limiar continua desativando o destaque. Sem marcação
por palavra, a última palavra dentro de uma frase ainda em andamento não pode ser
confirmada; o recurso aguarda o fim conhecido da linha. Connect externo e medidor
indisponível mantêm a detecção desligada.

## Reproduzir

```powershell
npm ci
node scripts/check-compat.cjs
npm run test:web
npm run test:dom
dotnet run --project tests/CoreChecks -c Release
$env:CNCX_LIVE_PUBLIC='1'
$env:CNCX_LIVE_SOUNDCLOUD='1'
dotnet run --project tests/CoreChecks -c Release
./scripts/build-windows.ps1
```

Referências e análise comparativa estão em REFERENCIAS-0.9.md.
