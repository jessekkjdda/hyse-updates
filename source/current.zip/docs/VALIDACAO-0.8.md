# Validação cncx 0.8.0

Data: 22 de novembro de 2026. Linux, .NET SDK 10.0.404, compilação cruzada para
Windows x64. Node 24. Versão de referência Riff: 5031a840fb50dbb53a5830329ed69363fe09d824.

| Verificação | Resultado |
| --- | --- |
| CoreChecks com CNCX_LIVE_PUBLIC=1 | 402 verificações aprovadas, incluindo 1 chamada pública real ao Spotify |
| Módulos frontend | 33 verificações aprovadas |
| Gradiente Riff | Comparação contra funções originais em centenas de posições, vários alfabetos e pontuação, tolerância do arredondamento original |
| Geometria da cascata | Comparação com layoutLyricsCascade original para alturas variáveis |
| Frases rápidas | Próxima linha ativa antes do fim da animação anterior; LRC não é substituído por um agrupamento YAML longo |
| Relógio direto | Duplicatas, limite de 250 ms, pausa, seek e mudança de faixa verificados |
| Leitura virtualizada | 378 posições artificiais, páginas sobrepostas/fora de ordem, repetições, lacunas e mudanças concorrentes |
| Leitura pública real | Playlist de exemplo da documentação Spotify, lida sem token pelo código de produção |
| Janela Windows | Compila com WindowStyle=None, WindowChrome e recorte GDI arredondado; aparência ainda não verificada no Windows |
| Sessão privada Spotify | Implementação integrada; não validada com a conta privada do usuário |
| Navegador/UI completa | Suite preparada/atualizada; execução anterior bloqueada pelo ambiente, sem aprovação visual nova |

Os testes de SDK e da lista virtualizada usam substitutos controlados. A leitura
pública real não valida o login nem o DOM privado da conta. O extrator da janela
Spotify depende da estrutura visível do site; alterações dessa estrutura podem
exigir ajuste. A extração recusa concluir quando não consegue confirmar todas as
posições e a quantidade esperada. Não salva uma lista parcial como se fosse inteira.

## Recuperação da playlist

API da conta → renovação de permissões, se explicitamente ausentes → leitura
pública completa → botão de leitura pela sessão Spotify da própria conta.

A sessão tem janela própria, perfil WebView2 persistente e navegação limitada aos
hosts oficiais open.spotify.com e accounts.spotify.com. A automação percorre a
lista somente após o usuário clicar em Ler músicas. Não lê armazenamento de
sessão, senha ou tokens e não usa a API privada Pathfinder do Riff.

O resultado de uma sessão é somente para reprodução, salvo por conta. A edição
permanece no caminho da API com snapshot e permissões. Cancelar/fechar a janela
libera o pedido pendente; trocar de aba cancela a leitura da aba anterior.

## Diferenças temporais preservadas

O Riff usa um elemento de áudio próprio. O cncx usa o SDK Spotify ou Connect.
Os algoritmos visuais foram comparados; igualdade do áudio, do catálogo de letras
ou de toda a experiência de execução não foi comprovada. O gradiente é estimado
por linha, conforme o algoritmo do Riff; o offset continua disponível por faixa.

Fontes:
- https://github.com/rootscripts/riff
- https://developer.spotify.com/documentation/web-api/reference/get-playlists-items
- https://developer.spotify.com/documentation/web-api/tutorials/february-2026-migration-guide
