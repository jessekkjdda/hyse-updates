# hyse 0.14.0

- Corrigida a fila ao tocar uma faixa pesquisada: as outras versões do resultado não são mais adicionadas automaticamente.
- Continuação de músicas relacionadas e seleção do hyse, com menos repetições e alternância de artistas. A ordem das playlists e álbuns permanece igual.
- Pesquisa na biblioteca de playlists e dentro de playlists, álbuns e listas do SoundCloud. Reprodução e edição mantêm a posição original das músicas filtradas.
- Anterior, Reproduzir/Pausar e Próxima na prévia do ícone da barra de tarefas, sem abrir o aplicativo.
- App info sem nomes de outros aplicativos na parte de implementação. Avisos de licença ficam recolhidos em Licenças e nos arquivos da distribuição.

871 verificações funcionais, 31 arquivos aprovados e 6 bases históricas preservados. Compilação Windows x64 sem erros. O instalador e os controles da barra de tarefas ainda requerem teste nativo no Windows; testes e cross-build foram executados em Linux.

Quem já instalou a 0.13.0 recebe esta versão pelo atualizador. Configurações → App info → Buscar atualizações. O download acontece em segundo plano; a instalação ocorre ao escolher Sair ou Reiniciar e atualizar. O X continua escondendo a janela na bandeja. Conta, playlists, histórico, perfil e configurações são preservados.

O ZIP e o Setup incluem o código correspondente completo e as licenças. A chave privada de assinatura fica fora do GitHub e dos pacotes.
