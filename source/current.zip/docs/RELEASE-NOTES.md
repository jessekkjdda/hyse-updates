# hyse 0.15.0

- Ondulação por letra nas palavras sustentadas, usando as curvas originais do Spicy Lyrics adaptadas ao Canvas do hyse.
- Opção Ondulação por letra em Configurações → Letras, ligada por padrão. Reduzir movimentos e Efeitos reduzidos continuam sendo respeitados.
- Relógio, tempos das palavras, fade, passagem das linhas, fonte e comportamento da última palavra no silêncio preservados.
- Pausa congela a onda e avanço/repetição reconstrói a animação na posição correta. Sem DOM por letra e com buffers limitados às linhas visíveis.

896 verificações funcionais; comparação com o código original em 3.090 amostras; 31 arquivos aprovados e 6 bases históricas preservados. Testes e cross-build em Linux. A taxa de quadros e o áudio real precisam ser conferidos no Windows; não foi executado teste nativo do Setup.

Quem já instalou a 0.13.0 ou posterior recebe a versão pelo atualizador: Configurações → App info → Buscar atualizações. O download ocorre em segundo plano; escolha Reiniciar e atualizar ou Sair para instalar. O X continua escondendo a janela na bandeja. Conta, playlists, histórico, perfil e configurações são preservados.

O Setup e o ZIP incluem o código correspondente completo e as licenças. Nenhuma chave de catálogo é necessária para a animação local.
