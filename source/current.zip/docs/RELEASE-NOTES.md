# hyse 0.16.1

- Correção focada no ciclo de reconexão Discord. Quadros IPC completos em uma escrita, busca de uma conexão que conclua o handshake e verificação mesmo sem música tocando.
- Resposta do Discord preservada: código e motivo aparecem em Serviços → Discord. Copiar diagnóstico fica disponível em falhas ou modo compatível.
- Campos opcionais recusados são negociados na conexão existente. Recusa de atividade não provoca desconexão e reconexão sem fim.
- Renovação via ACK, sem exigir resposta a PING iniciado pelo hyse. Responde aos PINGs enviados pelo Discord, respeita prazos e espera maior em rate limit.
- Fila, ondulação, sincronização, fontes, sliders e reprodução permanecem iguais à 0.16.0.

929 verificações funcionais e 6 testes com pipes nativos Windows passaram no pipeline. Os testes Windows validam o transporte com um servidor de teste próprio, sem acesso a conta Discord real. Perfil real e execução do Setup ainda precisam de teste no PC do usuário.

Atualização em Configurações → App info → Buscar atualizações. Após atualizar, Serviços → Discord → Reconectar faz nova tentativa. Conta, playlists, histórico e configurações são preservados.
