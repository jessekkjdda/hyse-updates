# hyse 0.16.0

- Corrigida a ausência de ondulação em letras por linha e palavras curtas. O efeito segue os tempos que o fade já usa, sem alterar a sincronização.
- Rádio renova a fila antecipadamente e consulta páginas adicionais em vez de se limitar aos primeiros resultados. A fila real do Spotify para a música atual é usada quando disponível; o fallback usa relacionadas e catálogo por gênero/artista.
- Autoplay ao terminar uma playlist sem repetição, com controle em Configurações → Reprodução → Continuar com músicas relacionadas.
- Sessões longas de rádio mantêm histórico recente e próximas faixas sem atingir o limite da fila.
- RPC com nome do aplicativo por padrão, ícone original do hyse, teste periódico de conexão, renovação da atividade e recuperação após desconexões. Botão Reconectar em Serviços.

917 verificações funcionais passaram, incluindo 1.500 avanços aleatórios em uma sessão de teste e desconexões IPC simuladas. Testes e cross-build executados em Linux; áudio, GPU, Setup e perfil Discord reais ainda requerem teste no Windows. Nenhum bot, servidor ou nova conta são necessários.

Atualização disponível em Configurações → App info → Buscar atualizações. Reiniciar e atualizar ou Sair aplica o instalador baixado. O X continua escondendo a janela na bandeja. Conta, playlists, histórico, perfil e configurações são preservados; a apresentação do RPC migra uma vez para o nome do aplicativo e pode ser personalizada novamente.
