# Validação 0.16.0 — 26/11/2026

Base: source/current.zip do commit f5ecd7cc322a384d3c470ae06ab1fd5cddefec2d,
release pública hyse 0.15.0. Escopo: ondulação, continuação e RPC.

## Ondulação

A 0.15.0 excluía fontes por linha e palavras que não cumpriam 1 segundo e 2–7
grafemas. A ponte agora aplica elevação pelas mesmas curvas aos tempos já
usados pelo fade. Não altera o documento, shift, relógio ou posições das linhas.
Swell permanece restrito à regra Bloom original. Em estimativas e palavras
curtas há elevação/glow leve, sem swell. Scripts conectados/RTL e palavras com
mais de 32 grafemas movem como palavra inteira para preservar forma e custo.
Não há ondas em letras sem sincronização, voz de fundo, silêncio retido ou
modos reduzidos. A opção desligada restaura a pintura original.

## Continuação

Paginação com até oito consultas por preenchimento, quatro artistas e rotação
entre contextos disponíveis. A fila Spotify só é aceita se currently_playing.id
for a música selecionada; fila de outro contexto é rejeitada. As recomendações
podem ser restritas pela API, gêneros podem estar ausentes e a rede pode falhar.
Nesses casos usa páginas por artista e contexto já conhecido. Não se afirma
reprodução do algoritmo privado do Spotify ou do SoundCloud.

Preenchimento começa com seis faixas restantes, é serializado e cancelado por
uma nova fila. Cada chamada tem prazo, há cooldown e nova tentativa ao final.
Listas finitas passam para rádio somente ao término natural sem repetição e
com Autoplay ligado. Repetição e opção desligada são respeitadas. Rádio remove
histórico antigo mantendo Current, próximas posições, Back recente e PeekNext.
Se nenhum candidato válido existir, informa falha em vez de simular músicas.

## RPC

Application ID permanece 1574964498241036328. A consulta pública do Discord
confirmou nome registrado hyse e ícone bdc8a85f6ca8225cfc6b552f9c41d608,
inspecionado como o mesmo ícone do app. Usa a URL CDN oficial em vez da chave
hyse de um asset Rich Presence que não estava publicado. O modo nome migra uma
vez via DiscordIdentityVersion. O cliente Discord decide a apresentação final.

READY e ACK continuam obrigatórios. Escritas têm cancelamento e prazo; erros de
transporte descartado deixam de encerrar o worker. PING/PONG testa liveness a
cada 15 segundos; atividade é renovada a cada 60 segundos. Reconexão mantém o
limite global entre atualizações e envia só o estado mais recente. Há comando
manual independente em Serviços. Sem OAuth novo, bot ou serviço adicional.

## Verificações

643 Core, 105 DOM/adapters, 38 módulos web, 19 Liner Canvas, 24 onda,
19 relógio, 16 fade por linha, 24 parser Spicy, 9 métricas, 10 volume e 10
coleções: 917. As 1.500 transições do rádio contam como uma verificação de sessão,
sem inflar o total por música. Cobertura de páginas repetidas, fila nativa,
contexto incorreto, gêneros, reserva de shuffle, poda, reconexão manual,
ObjectDisposedException, falta de PONG e renovação de atividade.

31 arquivos aprovados e seis bases históricas conservados; apenas os campos
autorizados da preferência Discord são canonicalizados na proteção de Settings.
34 originais Liner, quatro do parser Spicy e sete de onda continuam íntegros.
A rasterização confirma diferença visível em fonte por linha e em palavra
curta, com timing intacto. 3.090 amostras matemáticas coincidem com a origem.
Pixels de comparação histórica são medidos com a nova onda desligada.

Testes executados em Linux, DOM e Canvas 2D de software, IPC em memória.
Build Windows x64 concluído pelo pipeline. Não foi executado Setup, áudio real,
perfil Discord real nem medição de GPU no Windows.
