# Validação cncx 0.9.1

23/11/2026. Ajuste de fade, destaque no silêncio e formas dos ícones de transporte.
Os resultados anteriores estão em VALIDACAO-0.9.md; esta versão os complementa.

| Verificação | Resultado |
| --- | --- |
| CoreChecks offline | 439 aprovadas. Inclui início original do silêncio preservado e limpeza desse início quando o áudio reaparece. |
| Módulos frontend | 26 aprovadas. Fade comparado com a referência 0.8/Riff em cinco famílias de escrita e amostras de 25 ms. Inclui seleção temporal, seleção visual em linha sem palavras, espaços, pontuação, marcação não confiável e palavras ainda não alcançadas. |
| DOM e protocolo | 47 aprovadas com o aplicativo real, host e Widget explicitamente substituídos. Fade renderizado via variável de progresso, texto preservado, palavra única, âncora no começo do silêncio, não avanço para frases futuras, retomada ao áudio, modo único salvo, barras de pausa preenchidas e triângulo preenchido. Inclui os fluxos anteriores de playlist, busca, histórico e SoundCloud. |
| Compatibilidade | Sete hashes preservados: cinco arquivos dos leitores Spotify da 0.8, SDK e PlaybackClock da 0.7. |
| Release Windows x64 | Build sem avisos ou erros; publicação self-contained e pacote completo com código, testes e licenças. |

O fade da 0.8 é usado como apresentação única. Seus cálculos são preservados;
o relógio de reprodução não foi substituído pelo relógio direto da 0.8.
O destaque no silêncio guarda a posição no primeiro pico silencioso observado,
e só ativa após 650 ms de silêncio estável. O alvo é calculado uma vez para essa
posição e permanece fixo até o áudio retornar, a faixa mudar ou a posição mudar
por seek. Isso impede que a passagem do relógio revele palavras futuras no silêncio.

Com tempos por palavra válidos, seleciona a última palavra já concluída. Com
fonte apenas por linha, usa a última palavra alcançada pelo fade antes do silêncio;
é uma estimativa visual, assim como o próprio fade da 0.8, e não reconhecimento
ou transcrição de voz. Volume zero, mute, pausa manual, áudio remoto, medidor ausente
e posição travada continuam desativando a detecção. Instrumental audível limpa o
alvo e volta à posição corrente.

As barras de pausa são dois retângulos preenchidos de largura 4,2 e altura 15
no viewBox 24 × 24, com raio 2,1. O play é uma forma triangular preenchida e
arredondada. O círculo, alvo de clique e rótulos de acessibilidade são preservados.
Os testes DOM conferem geometria e atributos SVG, sem medir a pintura na tela.

Não houve execução nativa em Windows, teste auditivo de sincronia ou medição real
Core Audio nesta sessão. DOM não valida pintura do gradiente, aparência final,
fluidez visual ou disponibilidade de áudio no widget. As integrações de catálogo
não foram alteradas nesta correção; os testes reais anteriores são relatados na
validação 0.9, sem alegação de novos testes de rede para esta versão.

Reprodução das verificações:

```powershell
npm ci
node scripts/check-compat.cjs
npm run test:web
npm run test:dom
dotnet run --project tests/CoreChecks -c Release
./scripts/build-windows.ps1
```
