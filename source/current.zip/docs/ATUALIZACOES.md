# Publicar uma atualização do hyse

Canal: https://github.com/jessekkjdda/hyse-updates

O desktop consulta os assets `hyse-update.json` e `hyse-update.sig` da última
release estável. Não publique uma release estável incompleta: crie um rascunho,
envie todos os arquivos e publique só depois de conferir nomes e hashes.
Pré-releases não alimentam o canal estável.

1. Recupere a fonte correspondente à última versão. Preserve os testes de
   compatibilidade, os dados internos `cncx` e a chave pública de `UpdateTrust.cs`.
2. Faça a alteração e aumente a versão estável `X.Y.Z` no csproj do desktop,
   `CurrentVersion`, App info, Boot, package.json/lock, fixtures, helper e NSIS.
   Não reutilize uma versão publicada para outros bytes de instalador.
3. Execute `scripts/build-windows.ps1` com .NET 10, Node 20+ e as dependências
   fixadas pelo lock. Ele testa a base, publica o app e publica o helper isolado.
4. Gere o instalador com NSIS 3.11 e o pacote com a fonte correspondente:

   ```powershell
   python scripts/build-installer.py --output ../hyse-X.Y.Z-Setup.exe
   python scripts/package-release.py --publish-dir artifacts/hyse-windows-x64 --output ../hyse-X.Y.Z-Windows-x64.zip
   ```

5. Recupere a chave privada de assinatura guardada separadamente. Mantenha-a
   fora da árvore de fonte e nunca a envie ao repositório nem junto ao Setup.
   O script verifica que a chave corresponde à pública fixada no aplicativo:

   ```powershell
   python scripts/sign-update.py --installer ../hyse-X.Y.Z-Setup.exe --private-key C:/private/hyse-update-signing-key.pem --output-dir ../release-feed
   ```

6. Em Releases do repositório, crie o rascunho com a tag `vX.Y.Z`. Anexe:
   `hyse-X.Y.Z-Setup.exe`, seu `.sha256`, o ZIP com fonte e seu `.sha256`,
   `hyse-update.json` e `hyse-update.sig`. Escreva as mudanças e os testes.
7. Confira que o manifesto aponta para essa tag e para os bytes exatos do Setup.
   Publique como release estável mais recente. Não remova os assets de releases
   anteriores enquanto houver usuários baixando essas versões.
8. Rode `dotnet run --project tests/FeedCheck -- <cache-temporario>` para testar
   o canal real com o verificador de produção e conferir o download completo.
   Esse comando apenas baixa e verifica; não executa o instalador.
9. Em um Windows de teste, confirme baixar a versão, continuar a reprodução,
   fechar no X sem atualizar e escolher “Reiniciar e atualizar”. Teste ainda a
   opção de sair sem reabrir, a sessão, as playlists, o histórico e o volume.

A chave privada permite assinar futuras atualizações; conserve uma cópia
privada. Perdê-la impede distribuir atualizações aceitas pelas instalações
atuais. Trocar de repositório ou de chave exige uma versão de transição assinada
com a chave atual. Não desative a verificação para contornar uma falha.

O manifesto assina versão, plataforma, produto, tamanho e SHA-256. O helper
confere a versão real instalada, a pasta registrada em HKCU e a identidade do
processo que pediu a saída. A instalação ocorre no usuário atual, sem serviço
de sistema, acesso à conta Spotify ou alteração dos diretórios de dados.

Se uma instalação falhar, consulte
`%LOCALAPPDATA%/hyse/updates/last-result.json`. O helper tenta restaurar os
arquivos anteriores. Se uma queda de energia interromper essa etapa, execute o
último Setup completo. Desinstalar não apaga os dados históricos do cncx.
