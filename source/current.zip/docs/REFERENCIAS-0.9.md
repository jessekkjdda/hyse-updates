# Integrações e composição — 0.9

Análise em 23/11/2026. Referências fixadas para permitir reavaliação.

| Projeto | Referência | O que atende melhor a este pedido |
| --- | --- | --- |
| Liner (`tryliner/desktop`) | `54eaab9ade697b95756c68b6901a24b0a27949e4` | Separação da tela de letras, proporção inicial 1200 × 780, capa grande e pesquisa por várias entidades com destaque. |
| Riff (`rootscripts/riff`) | `5031a840fb50dbb53a5830329ed69363fe09d824` | Integração pública SoundCloud mais direta e independente, além da referência MIT para easing e tema já usada pelo cncx. |
| cncx 0.8 | Código entregue em 22/11/2026 | Playlists Spotify públicas, contagem completa, duplicatas, leitura por sessão e edição oficial existentes. |
| cncx 0.7 | Código entregue em 22/11/2026 | Relógio e fluxo de sincronização por timestamps solicitados pelo usuário. |

O Liner combina catálogo/busca e adaptadores com backend próprio e autenticação;
a pesquisa envolve YouTube Music e o serviço oficial `api.tryliner.fun`. Seu
SoundCloud também resolve/importa links públicos. É uma base visual útil para
estudo, mas adotar o backend acrescentaria dependência de outra conta e serviço.
Sua licença Source-Available & Non-Commercial Contribution License 1.1 restringe
extração para outros aplicativos. Nenhum código, algoritmo, fonte, ícone, imagem
ou outro recurso do Liner foi copiado para esta distribuição. A implementação
própria usa a organização comum de duas colunas e categorias de catálogo.

O Riff usa integração de catálogo SoundCloud baseada na configuração pública da
página web e no endpoint API-v2; a implementação de áudio de seu servidor inclui
outros mecanismos. No cncx, a consulta pública é implementada separadamente e o
áudio fica no widget oficial SoundCloud. O ID público é temporário, não é uma
credencial pessoal e não é incluído fixo no pacote. Há limite de requisições,
cache temporário, atualização única após 401 e recuo após 429. Mudanças na página
pública podem exigir manutenção. O pacote não inclui yt-dlp, ffmpeg ou backend Riff.

A reprodução Spotify continua no Web Playback SDK oficial ou dispositivo Connect.
A busca usa a API oficial da conta para tracks, artists, albums e playlists.
Artistas/álbuns abrem telas de catálogo; playlists Spotify seguem os leitores da
0.8. Usar a integração Spotify atual preserva login, fila e biblioteca do usuário.

A tela de letras do cncx tem capa à esquerda, informações/controles abaixo e
letras à direita, com saída explícita e Escape. Preserva paleta, ícones e cantos
do cncx. O relógio e `sdk.js` correspondem à 0.7; animação não estima a duração das
palavras pelo comprimento do texto. A 0.8 continua fornecendo os leitores de
playlist e a proteção contra agrupamento alternativo que esconderia frases rápidas.

Fontes analisadas:

- https://github.com/tryliner/desktop
- https://github.com/tryliner/desktop/blob/54eaab9ade697b95756c68b6901a24b0a27949e4/LICENSE
- https://github.com/tryliner/desktop/blob/54eaab9ade697b95756c68b6901a24b0a27949e4/electron/main.ts
- https://github.com/tryliner/desktop/blob/54eaab9ade697b95756c68b6901a24b0a27949e4/src/features/player/ui/FullscreenPlayer.tsx
- https://github.com/tryliner/desktop/blob/54eaab9ade697b95756c68b6901a24b0a27949e4/src/features/search/ui/SearchResultsList.tsx
- https://github.com/rootscripts/riff
- https://developers.soundcloud.com/docs/api/html5-widget
- https://learn.microsoft.com/windows/win32/coreaudio/peak-meters


## Ajuste 0.9.1

O pedido posterior restaura especificamente o fade da 0.8. Os cálculos de
charWeight, gradientWeights, effectiveDuration e gradientProgress são os mesmos
da 0.8/Riff; a organização da tela permanece a 0.9 e o relógio continua o da 0.7.
O fade estimado por linha não deve ser confundido com timestamps por palavra.
No silêncio confirmado, a apresentação congela um token já alcançado no início
do trecho silencioso. Instrumental audível retoma a apresentação no tempo atual.
