Unicode true
!include "MUI2.nsh"
!include "LogicLib.nsh"
!include "x64.nsh"
!ifndef APP_VERSION
!define APP_VERSION "0.13.0"
!endif
!ifndef PAYLOAD
!error "PAYLOAD must point to the published, validated app folder"
!endif
!ifndef OUTPUT
!error "OUTPUT must name the setup executable"
!endif
Name "hyse"
OutFile "${OUTPUT}"
RequestExecutionLevel user
InstallDir "$LOCALAPPDATA\Programs\hyse"
InstallDirRegKey HKCU "Software\hyse" "InstallDir"
SetCompressor /SOLID lzma
SetCompressorDictSize 32
VIProductVersion "${APP_VERSION}.0"
VIAddVersionKey "ProductName" "hyse"
VIAddVersionKey "FileDescription" "Instalador do hyse"
VIAddVersionKey "FileVersion" "${APP_VERSION}"
VIAddVersionKey "ProductVersion" "${APP_VERSION}"
VIAddVersionKey "LegalCopyright" "hyse contributors; bundled components retain their notices"
Icon "${PAYLOAD}/hyse.ico"
UninstallIcon "${PAYLOAD}/hyse.ico"
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN "$INSTDIR\hyse.exe"
!define MUI_FINISHPAGE_RUN_TEXT "Abrir hyse"
!define MUI_WELCOMEPAGE_TITLE "Instalar hyse"
!define MUI_WELCOMEPAGE_TEXT "O hyse será instalado para este usuário.$\r$\n$\r$\nConta, playlists, histórico e preferências existentes serão preservados."
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "PortugueseBR"

Function .onInit
  SetShellVarContext current
  ${IfNot} ${RunningX64}
    MessageBox MB_OK|MB_ICONSTOP "Esta versão do hyse requer Windows x64."
    Abort
  ${EndIf}
FunctionEnd

!macro WaitForHyse PREFIX
  ; Ask the running instance to save and exit; never terminate it forcibly.
  IfFileExists "$INSTDIR\hyse.exe" 0 +2
    ExecWait '"$INSTDIR\hyse.exe" --exit-for-update'
  StrCpy $1 0
  ${PREFIX}wait:
    System::Call 'kernel32::OpenMutexW(i 0x100000, i 0, w "Local\hyse.desktop") p .r0'
    ${If} $0 == 0
      Goto ${PREFIX}ready
    ${EndIf}
    System::Call 'kernel32::CloseHandle(p r0)'
    IntOp $1 $1 + 1
    ${If} $1 >= 150
      IfSilent ${PREFIX}abort
      MessageBox MB_RETRYCANCEL|MB_ICONEXCLAMATION "Feche o hyse para continuar." IDRETRY ${PREFIX}retry
      ${PREFIX}abort:
        Abort
      ${PREFIX}retry:
        StrCpy $1 0
    ${EndIf}
    Sleep 100
    Goto ${PREFIX}wait
  ${PREFIX}ready:
!macroend

Section "hyse"
  SetErrorLevel 1
  SetShellVarContext current
  !insertmacro WaitForHyse "install_"
  ; Portable versions predate the hyse shutdown protocol. They must be closed
  ; before two WebView2 hosts open the same existing profile.
  legacy:
    FindWindow $0 "" "cncx"
    ${If} $0 != 0
      IfSilent legacy_abort
      MessageBox MB_RETRYCANCEL|MB_ICONEXCLAMATION "Feche a versão portátil anterior para preservar a sessão e continuar." IDRETRY legacy
      legacy_abort:
        Abort
    ${EndIf}
  SetOutPath "$INSTDIR"
  SetOverwrite on
  ClearErrors
  File /r "${PAYLOAD}/*"
  ${If} ${Errors}
    SetErrorLevel 1
    Abort
  ${EndIf}
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  CreateShortcut "$SMPROGRAMS\hyse.lnk" "$INSTDIR\hyse.exe" "" "$INSTDIR\hyse.ico"
  CreateShortcut "$DESKTOP\hyse.lnk" "$INSTDIR\hyse.exe" "" "$INSTDIR\hyse.ico"
  WriteRegStr HKCU "Software\hyse" "InstallDir" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\App Paths\hyse.exe" "" "$INSTDIR\hyse.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\hyse" "DisplayName" "hyse"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\hyse" "DisplayVersion" "${APP_VERSION}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\hyse" "DisplayIcon" "$INSTDIR\hyse.exe"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\hyse" "InstallLocation" "$INSTDIR"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\hyse" "UninstallString" '$\"$INSTDIR\Uninstall.exe$\"'
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\hyse" "QuietUninstallString" '$\"$INSTDIR\Uninstall.exe$\" /S'
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\hyse" "NoModify" 1
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\hyse" "NoRepair" 1
  SetErrorLevel 0
SectionEnd

Section "Uninstall"
  SetShellVarContext current
  !insertmacro WaitForHyse "uninstall_"
  ; The generated manifest lists only shipped files. User data is never removed.
  !include "${DELETE_MANIFEST}"
  Delete "$SMPROGRAMS\hyse.lnk"
  Delete "$DESKTOP\hyse.lnk"
  DeleteRegKey HKCU "Software\hyse"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\App Paths\hyse.exe"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\hyse"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
SectionEnd
