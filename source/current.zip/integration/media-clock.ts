import {createMediaClock} from '../vendor/liner/features/player/hooks/mediaClock';
import {mediaState} from './media-state';
interface Sample{uri:string;position:number;duration:number;playing:boolean;source?:string;}
let changedAt=0,coarseSample=false,coarseCadence=false;
let sample:(Sample&{at:number})|null=null,activeUri='',clock=createMediaClock(),audio:HTMLAudioElement|null=null,allowLocal=true,playing=false;
// The original clock expects an HTML audio element. This local element is a
// transport facade over confirmed SDK samples: it has no src, plays no second
// stream, and never reads a cross-origin or DRM-controlled media element.
function sampled(){return allowLocal&&!coarseSample&&!coarseCadence&&sample?.uri===activeUri&&performance.now()-sample.at<1500?sample:null;}
function ensureAudio(){
  if(audio?.isConnected)return;audio=document.createElement('audio');audio.id='liner-audio';audio.hidden=true;audio.muted=true;audio.setAttribute('aria-hidden','true');audio.preload='none';
  Object.defineProperties(audio,{
    currentTime:{get:()=>{const s=sampled();return s?s.position/1000:Number.NaN;}},
    paused:{get:()=>!(sampled()?.playing??playing)},
    ended:{get:()=>{const s=sampled();return !!s&&s.duration>0&&s.position>=s.duration&&!s.playing;}},
    readyState:{get:()=>sampled()?4:0},playbackRate:{get:()=>1}
  });(document.getElementById('media-host')||document.body).append(audio);
}
export function sampleLinerClock(data:Sample){if(!data?.uri||!Number.isFinite(data.position))return;const now=performance.now();if(!sample||sample.uri!==data.uri||sample.position!==data.position||!data.playing){coarseCadence=!!sample&&sample.uri===data.uri&&sample.playing&&data.playing&&now-changedAt>100;changedAt=now;coarseSample=false;}else if(data.playing&&now-changedAt>100)coarseSample=true;sample={...data,position:Math.max(0,data.position),duration:Math.max(0,data.duration||0),at:now};}
export function seekLinerClock(position:number,uri:string,duration:number,isPlaying:boolean){activeUri=uri;coarseSample=false;coarseCadence=false;changedAt=performance.now();if(sample?.uri===uri)sample={uri,position:Math.max(0,position),duration,playing:isPlaying,at:performance.now()};else sample=null;clock=createMediaClock();}
export function resetLinerClock(){sample=null;coarseSample=false;coarseCadence=false;changedAt=0;activeUri='';clock=createMediaClock();}
export function linerPosition(uri:string,fallback:number,duration:number,isPlaying:boolean,direct=true){
  ensureAudio();if(uri!==activeUri){activeUri=uri;clock=createMediaClock();}allowLocal=direct;playing=isPlaying;mediaState.fallbackPosition=fallback;
  const value=clock.timeMs();return Math.max(0,Math.min(duration||0,Number.isFinite(value)?value:fallback));
}
