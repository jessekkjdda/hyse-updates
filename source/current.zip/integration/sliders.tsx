// Actual upstream React components, hosted by cncx's existing forms/transport.
import React from 'react';
import { createRoot, Root } from 'react-dom/client';
import { TimelineSlider } from '../vendor/liner/features/player/ui/TimelineSlider';
import { Slider } from '../vendor/liner/shared/ui/Slider';
const controls=new Map<HTMLInputElement,{root:Root;wrap:HTMLElement;host:HTMLElement;key:string;timeline:boolean}>();
const pending=new Set<HTMLInputElement>();
const valueText=(i:HTMLInputElement)=>i.id==='seek'||i.id==='dock-position'?`${Math.floor(+i.value/60000)}:${String(Math.floor(+i.value/1000)%60).padStart(2,'0')}`:i.id==='volume'||i.id==='dock-volume'?`${Math.round(+i.value*100)}%`:`${Math.round(+i.value*1000)/1000}`;
function emit(input:HTMLInputElement,value:number,commit:boolean){if(!input.isConnected)return;input.value=String(value);input.dispatchEvent(new Event('input',{bubbles:true}));if(commit)input.dispatchEvent(new Event('change',{bubbles:true}));refreshSlider(input,true);}
export function refreshSlider(input:HTMLInputElement,force=false){
  const record=controls.get(input);if(!record)return;const value=+input.value,text=valueText(input);input.setAttribute('aria-valuetext',text);
  const min=Number(input.min)||0,max=input.max===''?100:Number(input.max);record.wrap.style.setProperty('--progress',`${max>min?Math.max(0,Math.min(1,(value-min)/(max-min)))*100:0}%`);
  const tooltip=record.wrap.querySelector('.slider-tip');if(tooltip&&tooltip.textContent!==text)tooltip.textContent=text;
  const key=`${record.timeline?Math.floor(value/1000):value}|${input.min}|${input.max}|${input.step}|${input.disabled}`;if(!force&&key===record.key)return;record.key=key;
  const onSeek=(position:number)=>emit(input,position,true);
  record.root.render(record.timeline?<TimelineSlider positionMs={value} durationMs={+input.max||0} onSeek={onSeek} onScrub={position=>{input.value=String(position);input.dispatchEvent(new Event('input',{bubbles:true}));}} className="liner-control liner-timeline" fillColor="var(--text)" size="md"/>:<Slider value={value} min={Number(input.min)||0} max={input.max===''?100:Number(input.max)} step={input.step==='any'?.01:Number(input.step)||1} onChange={next=>{pending.add(input);emit(input,next,!record.wrap.dataset.pointerActive);if(!record.wrap.dataset.pointerActive)pending.delete(input);}} ariaLabel={input.getAttribute('aria-label')||input.name} showValue={false} disabled={input.disabled} className="liner-control liner-generic"/>);
}
export function enhanceSliders(root:ParentNode=document){
  for(const input of root.querySelectorAll<HTMLInputElement>('input[type="range"]')){if(controls.has(input))continue;
    const wrap=document.createElement('span');wrap.className='cncx-slider liner-control-host';const host=document.createElement('span');host.className='liner-react-root';const tip=document.createElement('span');tip.className='slider-tip';tip.setAttribute('aria-hidden','true');input.before(wrap);wrap.append(host,input,tip);input.setAttribute('aria-hidden','true');input.tabIndex=-1;
    const timeline=input.id==='seek'||input.id==='dock-position';const record={root:createRoot(host),host,wrap,key:'',timeline};controls.set(input,record);
    wrap.addEventListener('pointerdown',e=>{if(e.button!==0){e.stopPropagation();return;}if(!timeline)wrap.dataset.pointerActive='1';},true);
    input.addEventListener('input',()=>refreshSlider(input));input.addEventListener('change',()=>refreshSlider(input));refreshSlider(input,true);
  }
}
function release(){for(const input of pending){delete controls.get(input)?.wrap.dataset.pointerActive;if(input.isConnected)input.dispatchEvent(new Event('change',{bubbles:true}));}pending.clear();for(const r of controls.values())delete r.wrap.dataset.pointerActive;}
window.addEventListener('pointerup',()=>queueMicrotask(release));window.addEventListener('pointercancel',()=>queueMicrotask(release));window.addEventListener('blur',release);
enhanceSliders();
new MutationObserver(()=>{for(const[input,r]of controls)if(!input.isConnected){r.root.unmount();controls.delete(input);pending.delete(input);}enhanceSliders();}).observe(document.body,{childList:true,subtree:true});
