// Host-side state used by the unchanged Liner mediaClock module's store fallback.
export const mediaState={fallbackPosition:0};
export const usePlayerStore={getState:()=>({positionMs:mediaState.fallbackPosition})};
