// Derived from Spicy Lyrics, AGPL-3.0. Extracted at build time.
// See vendor/spicy-wave/manifest.json and licenses/Spicy-Lyrics-LICENSE.txt.
import {cubicBezier} from "../vendor/spicy-wave/original/CubicBezier";
export interface WaveLetter {StartTime:number;WidthEm:number;}
const Clamp = (value:number,min:number,max:number)=>Math.max(min,Math.min(value,max));
const RefreshedEmphasis = {
  // How much bigger a letter gets, at full strength.
  Scale: 0.14,
  // Strength grows from nothing at FromMs to full at ToMs.
  FromMs: 1000,
  ToMs: 2000,
  // Letters set off across this share of the word, at most MaxStaggerMs apart.
  Stagger: 0.4,
  MaxStaggerMs: 400,
  // Neither the swell nor the ease back takes longer than this.
  MaxPhaseMs: 3000,
  // The glow: white, at most this alpha, blurred by BlurEm + BlurPx.
  GlowAlpha: 0.5,
  BlurEm: 0.17,
  BlurPx: 1,
};

// Bloom: a word (or a split letter) lifts the moment it is
// sung, on a stiff, barely underdamped spring, and stays up. Lift is in em.
const RefreshedLift = {
  Em: 0.0588,
  // Angular frequency (rad/s) and damping ratio.
  Omega: 5,
  Damping: 0.93,
};

type RefreshedWaveStrength = { Duration: number };

function getRefreshedWaveStrength(duration: number): RefreshedWaveStrength {
  return { Duration: Math.max(1, duration) };
}

const emphasisEase = cubicBezier(0.25, 0.1, 0.25, 1);

type SplitLetter = WaveLetter;

// 0 to 1: how far a lift `elapsed` ms old has come.
function getRefreshedLift(elapsed: number): number {
  if (elapsed <= 0) return 0;
  const { Omega: w, Damping: z } = RefreshedLift;
  const t = elapsed / 1000;
  const decay = Math.exp(-z * w * t);
  if (decay < 1e-4) return 1;
  const wd = w * Math.sqrt(1 - z * z);
  return 1 - decay * (Math.cos(wd * t) + ((z * w) / wd) * Math.sin(wd * t));
}

// Canvas supplies measured widths in em; no DOM reads per frame.
const getLetterWidthsEm = (letters: SplitLetter[]) => letters.map(letter => letter.WidthEm);

// Every letter of the word this frame, worked out together since each letter's
// push depends on the ones between it and the middle.
type RefreshedFlameState = {
  // Set when every letter is at rest, not started (0) or settled and lifted
  // (1); the arrays are then empty.
  Rest?: 0 | 1;
  Scale: number[];
  // Sideways push and lift, in em.
  X: number[];
  Y: number[];
  Glow: number[];
  Moving: boolean[];
};

const restingFlame = (rest: 0 | 1): RefreshedFlameState => ({
  Rest: rest,
  Scale: [],
  X: [],
  Y: [],
  Glow: [],
  Moving: [],
});
const FlameBefore = restingFlame(0);
const FlameAfter = restingFlame(1);

function getRefreshedFlame(
  letters: SplitLetter[],
  position: number,
  strength: RefreshedWaveStrength
): RefreshedFlameState {
  const E = RefreshedEmphasis;
  const n = Math.max(1, letters.length);
  const duration = strength.Duration;
  const phase = Math.min(duration, E.MaxPhaseMs);
  const stagger = Math.min((E.Stagger * duration) / n, E.MaxStaggerMs);
  const holdMs = (2 * duration) / n;
  const peak = E.Scale * (Clamp(duration / E.FromMs, 1, E.ToMs / E.FromMs) - 1);
  const held = emphasisEase(Math.min(1, holdMs / phase));
  const elapsed = position - (letters[0]?.StartTime ?? 0);
  if (elapsed <= 0) return FlameBefore;
  const lastAt = elapsed - (n - 1) * stagger;
  if (lastAt >= holdMs + phase && getRefreshedLift(lastAt) === 1) return FlameAfter;

  const scale: number[] = [];
  const glow: number[] = [];
  const y: number[] = [];
  const moving: boolean[] = [];
  for (let i = 0; i < n; i++) {
    const at = elapsed - i * stagger;
    let amount = 0;
    if (at > 0 && at < holdMs) amount = emphasisEase(Math.min(1, at / phase));
    else if (at >= holdMs) amount = held * (1 - emphasisEase(Math.min(1, (at - holdMs) / phase)));
    const lift = getRefreshedLift(at);
    scale.push(1 + peak * amount);
    glow.push(E.GlowAlpha * amount);
    y.push(-RefreshedLift.Em * lift);
    moving.push(at < holdMs + phase || lift < 1);
  }

  // Each letter grows about its middle, so it is moved out by half its own
  // growth on the side away from the middle of the word, plus half of the push
  // the letter inside it got.
  const widths = getLetterWidthsEm(letters);
  const half = scale.map((s, i) => ((s - 1) * (widths[i] ?? 0)) / 2);
  const x: number[] = Array.from({ length: n }, () => 0);
  const middle = n % 2 === 0 ? n / 2 - 0.5 : Math.floor(n / 2);
  const leftStart = Number.isInteger(middle) ? middle - 1 : Math.floor(middle);
  const rightStart = Number.isInteger(middle) ? middle + 1 : Math.ceil(middle);
  for (let i = leftStart; i >= 0; i--) {
    let push = half[i];
    if (i + 1 <= middle) push += half[i + 1];
    if (i + 1 < middle) push += Math.abs(x[i + 1]);
    x[i] = -push / 2;
  }
  for (let i = rightStart; i < n; i++) {
    let push = half[i];
    if (i - 1 >= middle) push += half[i - 1];
    if (i - 1 > middle) push += Math.abs(x[i - 1]);
    x[i] = push / 2;
  }

  return { Scale: scale, X: x, Y: y, Glow: glow, Moving: moving };
}


export {getRefreshedFlame,getRefreshedWaveStrength,getRefreshedLift,RefreshedEmphasis,RefreshedLift};
