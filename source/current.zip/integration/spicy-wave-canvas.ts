// Spicy Lyrics animation adapted to the existing Canvas painter; AGPL-3.0.
import {SplitLetters} from '../vendor/spicy-wave/original/SplitLetters';
import {IsLetterCapable,MinLetterCapableDuration} from '../vendor/spicy-wave/original/IsLetterCapable';
import {getRefreshedFlame,getRefreshedWaveStrength,getRefreshedLift,RefreshedEmphasis,RefreshedLift,type WaveLetter} from './spicy-wave-source';
import {drawToken,white} from '../vendor/liner/features/lyrics/canvas/drawWord';
import {mainFont,backgroundFont,subtitleFont} from '../vendor/liner/features/lyrics/canvas/fonts';
import {tokenHighlight,lineExitMs} from '../vendor/liner/features/lyrics/canvas/timing';
import {exitFade} from '../vendor/liner/features/lyrics/canvas/exitClock';
import type {LineLayout,LyricsTypography,PlacedToken} from '../vendor/liner/features/lyrics/canvas/types';
type Glyph={from:number;to:number};
type Group={tokens:PlacedToken[];letters:WaveLetter[];glyphs:Glyph[];start:number;duration:number;strengthDuration:number;left:number;width:number;fontPx:number;font:string;ascent:number;descent:number;whole:boolean};
type Plan={stamp:string;groups:Group[];groupFor:Map<PlacedToken,Group>};
type Flame=ReturnType<typeof getRefreshedFlame>;
export type WaveFrame={plan:Plan;flames:Map<Group,Flame>;moving:boolean;mix:number;time:number;now:number;type:LyricsTypography;dpr:number};
const clamp=(x:number)=>Math.max(0,Math.min(1,x));
const joined=/[\p{scx=Arabic}\p{scx=Syriac}\p{scx=Devanagari}\p{scx=Bengali}\p{scx=Tamil}\p{scx=Telugu}\p{scx=Kannada}\p{scx=Malayalam}]/u;
const unspaced=/[\p{scx=Han}\p{scx=Hiragana}\p{scx=Katakana}\p{scx=Thai}\p{scx=Lao}\p{scx=Khmer}\p{scx=Myanmar}]/u;
export class SpicyWaveCanvas{
 private plans=new WeakMap<LineLayout,Plan>();
 private scratch:HTMLCanvasElement;
 private scratchCtx:CanvasRenderingContext2D;
 constructor(){this.scratch=document.createElement('canvas');const ctx=this.scratch.getContext('2d');if(!ctx)throw Error('Canvas 2D unavailable');this.scratchCtx=ctx;}
 reset(){this.plans=new WeakMap();}
 dispose(){this.reset();this.scratch.width=this.scratch.height=1;}
 private plan(ctx:CanvasRenderingContext2D,layout:LineLayout,type:LyricsTypography,ratio:number,estimated:boolean):Plan{
  const stamp=`${type.family}:${type.size}:${type.weight}:${ratio}:${estimated}`,cached=this.plans.get(layout);if(cached?.stamp===stamp)return cached;
  // Measuring must not mutate the original scene's painting context.
  ctx=this.scratchCtx;
  const plan:Plan={stamp,groups:[],groupFor:new Map()};let run:PlacedToken[]=[];
  const finish=()=>{
   if(!run.length)return;const tokens=run;run=[];
   const text=tokens.map(p=>p.token.text).join(''),start=tokens[0].token.startMs;
   const duration=Math.max(...tokens.map(p=>p.token.startMs+p.token.durationMs*ratio))-start;
   if(duration<=0||tokens[0].token.background)return;
   const glyphText=SplitLetters(text),split=!estimated&&duration>=MinLetterCapableDuration()&&IsLetterCapable(glyphText.length,duration,false);
   const font=mainFont(type),fontPx=type.size;ctx.font=font;
   const left=Math.min(...tokens.map(p=>p.x)),width=Math.max(...tokens.map(p=>p.x+p.width))-left;if(width<=0)return;
   const whole=glyphText.length>32||layout.line.rtl||joined.test(text);
   const glyphs:Glyph[]=[],letters:WaveLetter[]=[];
   if(whole){glyphs.push({from:0,to:width});letters.push({StartTime:start,WidthEm:width/fontPx});}
   else
   for(const p of tokens){let prefix='',at=0;for(const glyph of SplitLetters(p.token.text)){prefix+=glyph;const next=Math.min(p.width,Math.max(at,ctx.measureText(prefix).width));glyphs.push({from:p.x-left+at,to:p.x-left+next});letters.push({StartTime:start,WidthEm:(next-at)/fontPx});at=next;}}
   if(!glyphs.length)return;glyphs[glyphs.length-1].to=width;
   const metrics=ctx.measureText(text),group:Group={tokens,letters,glyphs,start,duration,strengthDuration:split?duration:Math.min(duration,999),left,width,fontPx,font,ascent:metrics.fontBoundingBoxAscent||fontPx,descent:metrics.fontBoundingBoxDescent||fontPx*.3,whole};
   plan.groups.push(group);for(const token of tokens)plan.groupFor.set(token,group);
  };
  for(const placed of layout.tokens){
   if(placed.token.space){finish();continue;}const previous=run.at(-1);
   if(previous&&(previous.token.background!==placed.token.background||previous.baseline!==placed.baseline||placed.token.startMs-previous.token.startMs-previous.token.durationMs*ratio>100||unspaced.test(previous.token.text+placed.token.text)))finish();
   run.push(placed);
  }
  finish();this.plans.set(layout,plan);return plan;
 }
 frame(ctx:CanvasRenderingContext2D,layout:LineLayout,time:number,now:number,type:LyricsTypography,dpr:number,ratio:number,estimated=false):WaveFrame|null{
  const plan=this.plan(ctx,layout,type,ratio,estimated);if(!plan.groups.length)return null;
  const mix=time>=lineExitMs(layout.line)?exitFade(layout.line,time,now):1;if(mix<=0)return null;
  const flames=new Map<Group,Flame>();let moving=false;
  for(const group of plan.groups){if(time<=group.start)continue;const lift=getRefreshedLift(time-group.start);const flame:Flame=group.whole?{Scale:[1],X:[0],Y:[-RefreshedLift.Em*lift],Glow:[0],Moving:[lift!==1]}:getRefreshedFlame(group.letters,time,getRefreshedWaveStrength(group.strengthDuration));flames.set(group,flame);moving ||= flame.Moving.some(Boolean);}
  return flames.size?{plan,flames,moving,mix,time,now,type,dpr}:null;
 }
 paint(ctx:CanvasRenderingContext2D,layout:LineLayout,top:number,frame:WaveFrame){
  const {type,time,now,dpr}=frame,drawn=new Set<Group>();ctx.direction=layout.line.rtl?'rtl':'ltr';let font='';
  for(const placed of layout.tokens){
   const nextFont=placed.token.background?backgroundFont(type):mainFont(type);if(nextFont!==font){ctx.font=nextFont;font=nextFont;}
   const group=frame.plan.groupFor.get(placed),flame=group&&frame.flames.get(group);
   if(group&&flame){if(!drawn.has(group)){this.paintGroup(ctx,layout,top,group,flame,frame);drawn.add(group);}continue;}
   drawToken({ctx,top,rtl:layout.line.rtl,base:placed.token.background ? .234 : .3,remPx:16,dpr},placed,tokenHighlight(placed.token,layout.line,time,now));
  }
  if(layout.subtitle.length){ctx.font=subtitleFont(type);ctx.fillStyle=white(.6);for(const text of layout.subtitle)ctx.fillText(text.text,text.x,Math.round((top+text.baseline)*dpr)/dpr);}
 }
 private paintGroup(ctx:CanvasRenderingContext2D,layout:LineLayout,top:number,group:Group,flame:Flame,frame:WaveFrame){
  const {dpr,time,now,mix}=frame;
  if(group.whole){
   const scale=1+(Math.max(1,...flame.Scale)-1)*mix,y=(flame.Y[0]??-RefreshedLift.Em*(flame.Rest??0))*group.fontPx*mix;
   const center=group.left+group.width/2,baseline=top+group.tokens[0].baseline;ctx.save();ctx.translate(center,baseline+y);ctx.scale(scale,scale);ctx.translate(-center,-baseline);
   for(const placed of group.tokens)drawToken({ctx,top,rtl:layout.line.rtl,base:.3,remPx:16,dpr},placed,tokenHighlight(placed.token,layout.line,time,now));ctx.restore();return;
  }
  const pad=Math.ceil(Math.max(24,group.fontPx*.5)),baseline=pad+group.ascent;
  const width=Math.ceil((group.width+pad*2)*dpr),height=Math.ceil((group.ascent+group.descent+pad*2)*dpr);
  if(this.scratch.width!==width)this.scratch.width=width;if(this.scratch.height!==height)this.scratch.height=height;
  const scratch=this.scratchCtx;scratch.setTransform(dpr,0,0,dpr,0,0);scratch.clearRect(0,0,width/dpr,height/dpr);scratch.font=group.font;scratch.textAlign='left';scratch.textBaseline='alphabetic';scratch.direction='ltr';
  for(const placed of group.tokens){const highlight=tokenHighlight(placed.token,layout.line,time,now);drawToken({ctx:scratch,top:0,rtl:false,base:.3,remPx:16,dpr},{...placed,x:pad+placed.x-group.left,baseline},highlight?{...highlight,glowRem:0}:null);}
  const targetY=Math.round((top+group.tokens[0].baseline)*dpr)/dpr-baseline;
  group.glyphs.forEach((glyph,i)=>{
   const from=i===0?-pad:glyph.from,to=i===group.glyphs.length-1?group.width+pad:glyph.to;if(to<=from)return;
   const center=group.left+(glyph.from+glyph.to)/2,anchor=top+group.tokens[0].baseline;
   const scale=1+((flame.Scale[i]??1)-1)*mix,x=(flame.X[i]??0)*group.fontPx*mix,y=(flame.Y[i]??-RefreshedLift.Em*(flame.Rest??0))*group.fontPx*mix;
   const placed=group.tokens.find(p=>(glyph.from+glyph.to)/2<=p.x-group.left+p.width)||group.tokens.at(-1)!;
   const highlight=tokenHighlight(placed.token,layout.line,time,now),offset=((glyph.from+glyph.to)/2-(placed.x-group.left))/Math.max(1,placed.width);
   const lit=highlight?clamp((highlight.clear-offset)/Math.max(.000001,highlight.clear-highlight.solid))*highlight.opacity:0;
   ctx.save();ctx.translate(center+x,anchor+y);ctx.scale(scale,scale);ctx.translate(-center,-anchor);
   const glow=(flame.Glow[i]??0)*mix*lit;if(glow>0){ctx.shadowColor=white(glow);ctx.shadowBlur=(RefreshedEmphasis.BlurEm*group.fontPx+RefreshedEmphasis.BlurPx)*dpr;}
   ctx.drawImage(this.scratch,(pad+from)*dpr,0,(to-from)*dpr,height,group.left+from,targetY,to-from,height/dpr);ctx.restore();
  });
 }
}
