// cncx host adapter. The upstream renderer under vendor/liner is kept verbatim.
import {estimatedLineParts} from './estimated-line';
import {prepareSpicyDocument, type LyricsInput} from './spicy-ttml';
import {buildLines} from '../vendor/liner/features/lyrics/canvas/buildLines';
import { LyricsCanvasRenderer } from '../vendor/liner/features/lyrics/canvas/lyricsCanvasRenderer';
import { drawScene } from '../vendor/liner/features/lyrics/canvas/drawScene';
import { drawToken } from '../vendor/liner/features/lyrics/canvas/drawWord';
import { mainFont, backgroundFont } from '../vendor/liner/features/lyrics/canvas/fonts';
import { applyWindowVisibility } from '../vendor/liner/shared/utils/windowVisibility';
import { activeLine, holdTarget } from '../GlassPlayer/Web/lyric-timing.js';

const isNote=(text:string)=>!text.trim()||/^[♪♫♬♩·\s]+$/u.test(text);
type Document=LyricsInput;
export function toLinerLyrics(document:Document,duration=0,options:any={}){
  document=prepareSpicyDocument(document);
  const ratio=Number.isFinite(options.fadeSpeed)?Math.max(.5,Math.min(2,options.fadeSpeed/1.035)):1;
  const lyrics:any[]=[],sourceMap:number[]=[];
  const lines=document.lines?.length?document.lines:(document.plainText||'').split(/\r?\n/).filter(Boolean).map(text=>({text,timeMs:0}));
  const timed=document.synced===true||document.synced!==false&&lines.some(l=>l.timeMs>0||l.endMs!=null);
  if(document.instrumental)return{lyrics:[{words:'',startTimeMs:0,durationMs:Math.max(1,duration),isInstrumental:true}],sourceMap:[-1],timed:true};
  for(let i=0;i<lines.length;i++){
    const line=lines[i],start=timed?Math.max(0,line.timeMs):0;
    const next=lines[i+1]?.timeMs,end=timed?Math.max(start+1,line.endMs??next??(duration>start?duration:start+4000)):0;
    if(i===0&&timed&&start>500)lyrics.push({words:'',startTimeMs:0,durationMs:start,isInstrumental:true,sourceIndex:-1});
    sourceMap[i]=lyrics.length;
    const sourceWords=line.words?.length&&line.words.map(w=>w.text).join('')===line.text?line.words:null;
    const usable=sourceWords?.every(w=>Number.isFinite(w.startMs)&&Number.isFinite(w.endMs)&&w.endMs>=w.startMs)&&(sourceWords.some(w=>w.endMs>w.startMs)||sourceWords.some(w=>w.startMs!==sourceWords[0].startMs));
    const words=usable?sourceWords:null;
    const estimated=!!timed&&!isNote(line.text||'')&&!words;
    const estimateEnd=Number.isFinite(next)&&next!>start?Math.min(end,next!):end;
    const parts:any[]|null=words?words.map(w=>({words:w.text,startTimeMs:w.startMs,durationMs:Math.max(0,w.endMs-w.startMs)/ratio})):estimated?estimatedLineParts(line.text,start,estimateEnd,ratio):null;
    let vocalEnd=end;
    for(const bg of line.background||[]){
      if(!parts||!bg.words?.length)continue;
      parts.push({words:' ',startTimeMs:bg.timeMs,durationMs:0,isBackground:true});
      parts.push(...bg.words.map(w=>({words:w.text,startTimeMs:w.startMs,durationMs:Math.max(0,w.endMs-w.startMs)/ratio,isBackground:true})));
      vocalEnd=Math.max(vocalEnd,bg.endMs??bg.timeMs);
    }
    lyrics.push({words:line.text||'',startTimeMs:start,durationMs:timed?vocalEnd-start:0,isInstrumental:isNote(line.text||''),sourceIndex:i,
      ...(line.agent?{agent:line.agent}:{}),
      ...(parts?{parts}:{}),...(estimated?{estimatedTiming:true}:{})});
    if(timed&&Number.isFinite(next)&&vocalEnd<next!-250)lyrics.push({words:'',startTimeMs:vocalEnd,durationMs:next!-vocalEnd,isInstrumental:true,sourceIndex:-1});
    else if(timed&&i===lines.length-1&&duration>vocalEnd+750)lyrics.push({words:'',startTimeMs:vocalEnd,durationMs:duration-vocalEnd,isInstrumental:true,sourceIndex:-1});
  }
  const nativeShiftMs=buildLines(lyrics.map(line=>line.estimatedTiming?{...line,parts:undefined}:line)).shiftMs;
  return{lyrics,sourceMap,timed,nativeShiftMs};
}

// The pinned upstream renderer intentionally has a small public API. All access
// to its scene/motion for cncx preferences is confined to this adapter and tested
// against the pinned source manifest. Its scroll/layout/highlight algorithms stay
// unchanged. Upgrading the vendor commit requires re-running the adapter checks.
export class LyricsView{
  element:HTMLElement;document:Document|null;onSeek:(position:number)=>void;renderer:any;
  canvas:HTMLCanvasElement;live:HTMLCanvasElement;status:HTMLElement;resizeObserver?:ResizeObserver;
  mapping:number[]=[];estimatedLines=new Set<number>();durationMs=0;position=0;visualPosition=0;playing=false;destroyed=false;
  quietAt:number|null=null;measuredAt:number|null=null;hold:any=null;settings:any={};
  private lastDuration=-1;private timingSignature='';private appearance='';private stateKey='';private frameAt=0;private animationAt=0;
  private returning:any;private manualUntil=0;private stopVisibility:()=>void;
  constructor(element:HTMLElement,document:Document|null,onSeek:(position:number)=>void){
    document=document?prepareSpicyDocument(document):null;
    this.element=element;this.document=document;this.onSeek=onSeek;
    this.canvas=window.document.createElement('canvas');this.live=window.document.createElement('canvas');
    this.canvas.className='liner-lyrics-base';this.live.className='liner-lyrics-live';
    this.canvas.setAttribute('aria-hidden','true');this.live.setAttribute('aria-hidden','true');
    this.status=window.document.createElement('span');this.status.className='sr-only';this.status.setAttribute('aria-live','off');
    element.dataset.renderer='liner-original';element.replaceChildren(this.canvas,this.live,this.status);
    if(!document||!document.instrumental&&!document.lines?.length&&!document.plainText){this.message('Sem letra disponível');return;}
    try{this.renderer=new LyricsCanvasRenderer(this.canvas,this.live,{timeMs:()=>this.visualPosition,playing:()=>this.playing},()=>{});}
    catch(error){this.message('O renderizador de letras não pôde iniciar.');console.error(error);return;}
    const engine=this.renderer,originalTick=engine.loop.tick,glide=engine.motion.glideTo.bind(engine.motion);
    engine.motion.glideTo=(value:number,anchor:number,now:number)=>this.settings.reducedMotion?engine.motion.jumpTo(value):glide(value,anchor,now);
    engine.loop.tick=(now:number,elapsed:number)=>{
      const speed=this.settings.animationSpeed||1;
      this.animationAt=this.frameAt?this.animationAt+(now-this.frameAt)*speed:now;this.frameAt=now;
      if(this.destroyed)return'idle';
      const demand=originalTick(this.animationAt,elapsed*speed);
      if(this.hold)this.paintHeld(this.animationAt);
      return demand;
    };
    this.remap();this.resize();
    if(typeof ResizeObserver!=='undefined'){this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(element);}
    element.addEventListener('wheel',this.wheel,{passive:false});element.addEventListener('pointerdown',this.pointerDown);
    element.addEventListener('pointermove',this.pointerMove);element.addEventListener('pointerup',this.pointerUp);element.addEventListener('pointercancel',this.pointerCancel);
    element.addEventListener('keydown',this.keyDown);element.tabIndex=0;
    const visibility=()=>applyWindowVisibility(!window.document.hidden);window.document.addEventListener('visibilitychange',visibility);visibility();
    this.stopVisibility=()=>window.document.removeEventListener('visibilitychange',visibility);
  }
  message(text:string){this.element.replaceChildren();const p=window.document.createElement('p');p.className='lyrics-message';p.textContent=text;this.element.append(p);}
  remap(){if(!this.renderer||!this.document)return;const data=toLinerLyrics(this.document,this.durationMs,this.settings);this.mapping=data.sourceMap;this.estimatedLines=new Set(data.sourceMap.map((index,source)=>data.lyrics[index]?.estimatedTiming?source:-1).filter(i=>i>=0));this.renderer.setLyrics(data.lyrics);this.renderer.scene.shiftMs=(data.nativeShiftMs??this.renderer.scene.shiftMs)+(this.settings.fadeLeadMs??120)-120;this.lastDuration=this.durationMs;}
  resize(){if(this.destroyed||!this.renderer)return;const rect=this.element.getBoundingClientRect();const width=Math.max(1,Math.round(rect.width||this.element.clientWidth||600)),height=Math.max(1,Math.round(rect.height||this.element.clientHeight||500));const dpr=Math.min(3,window.devicePixelRatio||1);this.canvas.style.width=this.live.style.width=width+'px';this.canvas.style.height=height+'px';this.renderer.resize(width,height,dpr);}
  wheel=(e:WheelEvent)=>{if(!this.renderer)return;e.preventDefault();this.manualUntil=performance.now()+4500;this.renderer.wheel(e.deltaY*(e.deltaMode===1?20:e.deltaMode===2?(this.element.clientHeight||500):1));clearTimeout(this.returning);this.returning=setTimeout(()=>this.renderer?.follow(),4500);};
  private pointer:{x:number;y:number;id:number;dragged:boolean}|null=null;
  pointerDown=(e:PointerEvent)=>{if(e.button!==0)return;this.pointer={x:e.clientX,y:e.clientY,id:e.pointerId,dragged:false};this.element.setPointerCapture?.(e.pointerId);};
  pointerMove=(e:PointerEvent)=>{const p=this.pointer;if(!p||p.id!==e.pointerId||e.pointerType==='mouse')return;const delta=p.y-e.clientY;if(Math.abs(delta)>5){p.dragged=true;this.wheel({preventDefault:()=>e.preventDefault(),deltaY:delta,deltaMode:0} as WheelEvent);p.y=e.clientY;}};
  pointerUp=(e:PointerEvent)=>{const p=this.pointer;this.pointer=null;if(!p||p.id!==e.pointerId||p.dragged||!this.renderer)return;if(Math.abs(p.y-e.clientY)>12||Math.abs(p.x-e.clientX)>12)return;const start=this.renderer.lineStartAt(e.clientY-this.element.getBoundingClientRect().top);if(start!=null){this.manualUntil=0;this.renderer.follow();this.onSeek(start);}};
  pointerCancel=()=>{this.pointer=null;};
  keyDown=(e:KeyboardEvent)=>{if(!this.renderer)return;if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();this.wheel({preventDefault(){},deltaY:e.key==='ArrowDown'?90:-90,deltaMode:0} as WheelEvent);}else if(e.key==='Escape'){this.renderer.follow();}};
  update(position:number,settings:any={},force=false){
    if(this.destroyed||!this.renderer||!this.document)return;
    this.settings=settings;this.position=position;const previousPlaying=this.playing;this.playing=!!settings.playing;
    if(settings.timelineDurationMs&&settings.timelineDurationMs!==this.durationMs)this.durationMs=settings.timelineDurationMs;
    const timingSignature=`${settings.fadeSpeed??1.035}:${settings.fadeLeadMs??120}`;if(this.lastDuration!==this.durationMs||timingSignature!==this.timingSignature){this.timingSignature=timingSignature;this.remap();}
    const appearance=`${settings.lyricsFontSize||32}`;
    if(appearance!==this.appearance){this.appearance=appearance;const engine=this.renderer,size=settings.lyricsFontSize||32;engine.scene.typography={...engine.scene.typography,size,lineHeight:size*1.4};engine.scene.relayout();this.resize();}
    const silent=!!settings.silenceActive,measured=settings.silencePositionMs,quiet=silent||settings.audioAvailable&&Number.isFinite(measured);
    if(quiet){if(this.quietAt==null||Number.isFinite(measured)&&measured!==this.measuredAt||force&&position<this.quietAt-850){this.quietAt=Number.isFinite(measured)?Math.min(position,measured):position;this.measuredAt=measured;}}
    else{this.quietAt=null;this.measuredAt=null;}
    this.visualPosition=this.quietAt??position;
    this.hold=silent&&settings.silenceWordHighlight!==false?holdTarget(this.document.lines||[],this.visualPosition,this.durationMs,settings.fadeLeadMs??120,settings.fadeSpeed??1.035):null;
    if(this.hold&&this.estimatedLines.has(this.hold.line)){
      const line=this.renderer.scene.lines[this.mapping[this.hold.line]],tokens=line?.tokens.filter((t:any)=>!t.space)||[];
      const at=this.visualPosition+this.renderer.scene.shiftMs;let token=-1;for(let i=0;i<tokens.length;i++)if(tokens[i].startMs<=at)token=i;
      this.hold=token>=0?{line:this.hold.line,token}:null;
    }
    const source=activeLine(this.document.lines||[],this.visualPosition);
    this.element.dataset.activeLine=source<0?'':String(source);this.element.dataset.silenceWord=this.heldText();
    const text=this.hold?this.heldText():source>=0?this.document.lines![source].text:'';if(this.status.textContent!==text)this.status.textContent=text;
    const key=`${silent}:${this.hold?.line}:${this.hold?.token}:${quiet}:${settings.reducedMotion}:${settings.animationSpeed}`;
    if(force){this.renderer.follow();this.renderer.resize(this.renderer.scene.width,this.renderer.scene.height,this.renderer.dpr);}
    if(force||previousPlaying!==this.playing||key!==this.stateKey||!this.playing&&position!==this.lastPaintPosition)this.renderer.invalidate();
    this.stateKey=key;this.lastPaintPosition=position;
  }
  private lastPaintPosition=-1;
  heldText(){if(!this.hold||!this.renderer)return'';const layout=this.renderer.scene.layouts[this.mapping[this.hold.line]];return layout?.tokens.filter((p:any)=>!p.token.space)[this.hold.token]?.token.text||'';}
  paintHeld(now:number){
    const e=this.renderer,source=this.mapping[this.hold.line],layout=e.scene.layouts[source];if(!layout)return;
    const placed=layout.tokens.filter((p:any)=>!p.token.space)[this.hold.token];if(!placed)return;
    const scene=Object.create(e.scene);scene.timed=true;
    drawScene({ctx:e.ctx,scene,motion:e.motion,fog:e.fog,bitmaps:e.bitmaps,dpr:e.dpr,now,timeMs:-Infinity},'',e.live);
    e.ctx.setTransform(e.dpr,0,0,e.dpr,0,0);e.ctx.direction=layout.line.rtl?'rtl':'ltr';e.ctx.font=placed.token.background?backgroundFont(e.scene.typography):mainFont(e.scene.typography);
    const top=layout.top-e.motion.position+e.motion.offsetFor(source,now);
    drawToken({ctx:e.ctx,top,rtl:layout.line.rtl,base:.3,remPx:16,dpr:e.dpr},placed,{opacity:1,solid:1.4,clear:1.4,glowRem:0});
    e.signature='';
  }
  debugSnapshot(){if(!this.renderer)return null;const e=this.renderer;return{scroll:e.motion.position,offsets:e.scene.layouts.map((_:any,i:number)=>e.motion.offsetFor(i,this.animationAt)),lineCount:e.scene.lines.length,bitmapCount:e.bitmaps.bitmaps.size,visualPosition:this.visualPosition,hold:this.hold,sourceMap:[...this.mapping]};}
  destroy(){this.destroyed=true;clearTimeout(this.returning);this.resizeObserver?.disconnect();this.stopVisibility?.();if(this.renderer){this.renderer.loop.poke=()=>{};this.renderer.scene.onFontsReady=()=>{};this.renderer.dispose();}this.element.removeEventListener('wheel',this.wheel);this.element.removeEventListener('pointerdown',this.pointerDown);this.element.removeEventListener('pointermove',this.pointerMove);this.element.removeEventListener('pointerup',this.pointerUp);this.element.removeEventListener('pointercancel',this.pointerCancel);this.element.removeEventListener('keydown',this.keyDown);}
}
