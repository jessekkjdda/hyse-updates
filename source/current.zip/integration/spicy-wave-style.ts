// Select the original Bloom eligibility rule without the Spicetify settings store.
export const isBloomRenderer=()=>true;
