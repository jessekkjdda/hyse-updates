// SPDX-License-Identifier: AGPL-3.0-only
// cncx adapter for the unmodified Spicy Lyrics TTML parser; see vendor/spicy.
import { XMLValidator } from 'fast-xml-parser';
import { parseTTML, type ParsedVocalGroup } from '../vendor/spicy/src/utils/Lyrics/ttml/parser';
import { StripZeroWidth } from '../vendor/spicy/src/utils/Lyrics/Applyer/Utils/StripZeroWidth';

export type TimedWord = {text: string; startMs: number; endMs: number};
export type TimedLine = {
  text: string; timeMs: number; endMs?: number; words?: TimedWord[];
  agent?: string; background?: TimedLine[];
};
export type LyricsInput = {
  lines?: TimedLine[]; plainText?: string; instrumental?: boolean;
  synced?: boolean; wordSynced?: boolean; spicyTtml?: string;
};

const prepared = new WeakMap<LyricsInput, LyricsInput>();
const textKey = (text: string) => StripZeroWidth(text).replace(/\s+/gu, '');
const millis = (seconds: number | undefined): number | undefined =>
  typeof seconds === 'number' && Number.isFinite(seconds) && seconds >= 0 && seconds <= 86400
    ? Math.round(seconds * 1000) : undefined;

function vocalLine(vocal: ParsedVocalGroup): TimedLine | null {
  if (!Array.isArray(vocal.Syllables) || vocal.Syllables.length === 0) return null;
  const words: TimedWord[] = [];
  for (const [i, syllable] of vocal.Syllables.entries()) {
    const start = millis(syllable.StartTime), end = millis(syllable.EndTime);
    if (typeof syllable.Text !== 'string' || !textKey(syllable.Text) || start === undefined ||
        end === undefined || end < start || words.length && start < words[words.length - 1].startMs)
      return null;
    // Spicy's word-boundary contract: adjacent syllables stay in the same word.
    const gap = i < vocal.Syllables.length - 1 && !syllable.IsPartOfWord ? ' ' : '';
    words.push({text: syllable.Text + gap, startMs: start, endMs: end});
  }
  const start = millis(vocal.StartTime) ?? words[0].startMs;
  const end = millis(vocal.EndTime) ?? Math.max(...words.map(w => w.endMs));
  if (end < start || words.some(w => w.startMs < start || w.endMs > end)) return null;
  return {text: words.map(w => w.text).join(''), timeMs: start, endMs: end, words};
}

// When a baseline has real timings, every timed text boundary must remain exact.
// A more detailed syllable subdivision is accepted only inside those boundaries.
function preservesTiming(baseline: TimedLine, candidate: TimedLine): boolean {
  if (textKey(baseline.text) !== textKey(candidate.text)) return false;
  const original = baseline.words;
  if (!original?.length) return true;
  const words = candidate.words;
  if (!words?.length) return false;
  const boundaries = new Map<number, {start: number; end: number}>();
  let cursor = 0;
  for (const [index, word] of words.entries()) {
    const length = textKey(word.text).length;
    const previous = boundaries.get(cursor);
    boundaries.set(cursor, {start: word.startMs, end: previous?.end ?? word.startMs});
    cursor += length;
    boundaries.set(cursor, {start: words[index + 1]?.startMs ?? word.endMs, end: word.endMs});
  }
  cursor = 0;
  for (const word of original) {
    const length = textKey(word.text).length;
    if (length === 0) continue;
    const begin = boundaries.get(cursor), end = boundaries.get(cursor + length);
    if (!begin || !end || begin.start !== word.startMs || end.end !== word.endMs) return false;
    cursor += length;
  }
  return true;
}

/** All-local preprocessing. A failure returns the exact baseline object. */
export function prepareSpicyDocument(document: LyricsInput): LyricsInput {
  const cached = prepared.get(document);
  if (cached) return cached;
  const keep = () => { prepared.set(document, document); return document; };
  const xml = document.spicyTtml;
  if (document.instrumental || typeof xml !== 'string' || xml.length === 0 || xml.length > 1024 * 1024)
    return keep();
  // The parser never loads entities; reject declarations and malformed XML at the host boundary too.
  if (/<!DOCTYPE|<!ENTITY/i.test(xml)) return keep();
  try {
    if (XMLValidator.validate(xml) !== true) return keep();
    const parsed = parseTTML(xml);
    // Line-only and plain-text documents retain the already tested 0.11.2 path.
    if (parsed?.Type !== 'Syllable' || parsed.Content.length > 2000) return keep();
    const lines: TimedLine[] = [];
    let count = 0;
    for (const group of parsed.Content) {
      const lead = vocalLine(group.Lead);
      if (!lead) continue;
      // A plain verse inside a mixed TTML file is still line-timed, even though
      // upstream represents it as one syllable. Keep our established estimate.
      if (lead.words?.length === 1 && /\S+\s+\S+/u.test(lead.text)) lead.words = undefined;
      const background: TimedLine[] = [];
      for (const vocal of group.Background ?? []) {
        const bg = vocalLine(vocal);
        if (bg) background.push(bg);
      }
      count += (lead.words?.length ?? 0) + background.reduce((n, b) => n + (b.words?.length ?? 0), 0);
      if (count > 30000) return keep();
      lines.push({...lead, agent: group.OppositeAligned ? 'v2' : undefined,
        ...(background.length ? {background} : {})});
    }
    lines.sort((a, b) => a.timeMs - b.timeMs);
    const baseline = document.lines ?? [];
    if (!lines.length || !baseline.length || baseline.length > 2000) return keep();
    // Match by text AND source position. Repeated choruses cannot borrow another
    // occurrence's timing when the parser omits a malformed verse.
    const candidates = new Map<string, TimedLine[]>();
    for (const line of lines) {
      const key = `${line.timeMs}:${textKey(line.text)}`, group = candidates.get(key) ?? [];
      group.push(line); candidates.set(key, group);
    }
    const used = new Set<TimedLine>();
    let accepted = 0;
    const merged = baseline.map(original => {
      const matches = (candidates.get(`${original.timeMs}:${textKey(original.text)}`) ?? []).filter(line =>
        !used.has(line) && line.timeMs === original.timeMs && preservesTiming(original, line));
      // Ambiguous matches and incompatible verses retain their exact original object.
      if (matches.length !== 1) return original;
      const line = matches[0]; used.add(line); accepted++;
      return line;
    });
    if (!accepted) return keep();
    const result = {...document, lines: merged, synced: true, wordSynced: merged.some(l => l.words?.length)};
    prepared.set(document, result);
    prepared.set(result, result);
    return result;
  } catch {
    return keep();
  }
}
