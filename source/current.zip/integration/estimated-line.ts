import {gradientWeights} from '../GlassPlayer/Web/lyric-timing.js';
// Rendering estimate for a line-only source. Does not change the source document
// or label it word-synced. Real word timestamps bypass this helper entirely.
export function estimatedLineParts(text:string,start:number,end:number,ratio=1){
  const weights=gradientWeights(text),span=Math.max(1,end-start),parts:any[]=[];
  if(!weights.total)return parts;
  let cursor=0;
  for(const chunk of text.match(/\s+|\S+/gu)||[]){
    const from=cursor;cursor+=Array.from(chunk).length;
    const at=start+span*weights.cum[from]/weights.total;
    const until=start+span*weights.cum[cursor]/weights.total;
    parts.push({words:chunk,startTimeMs:at,durationMs:/^\s+$/u.test(chunk)?0:(until-at)/ratio});
  }
  return parts;
}
