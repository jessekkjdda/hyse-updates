// Host logging adapter for the original Spicy TTML parser. No session or network.
export default class SpicyLogger {
  constructor(private source: string) {}
  private write(level: 'info'|'debug'|'warn'|'error', args: unknown[]) {
    // XML, lyric text, file paths and credentials never enter the diagnostic log.
    const messages = args.filter((v): v is string => typeof v === 'string')
      .map(v => v.replace(/<[^>]*>/g, '[XML]').slice(0, 180));
    if (level === 'warn' || level === 'error')
      console[level](`[cncx · ${this.source}]`, ...messages);
  }
  info(...args: unknown[]) { this.write('info', args); }
  debug(...args: unknown[]) { this.write('debug', args); }
  warn(...args: unknown[]) { this.write('warn', args); }
  error(...args: unknown[]) { this.write('error', args); }
}
