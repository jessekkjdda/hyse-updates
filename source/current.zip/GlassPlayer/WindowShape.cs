using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
namespace GlassPlayer;

static class WindowShape
{
    [StructLayout(LayoutKind.Sequential)] struct Rect { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr window, out Rect bounds);
    [DllImport("gdi32.dll")] static extern IntPtr CreateRoundRectRgn(int left, int top, int right, int bottom, int width, int height);
    [DllImport("user32.dll")] static extern int SetWindowRgn(IntPtr window, IntPtr region, bool redraw);
    [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr handle);
    [DllImport("user32.dll")] static extern bool ReleaseCapture();
    [DllImport("user32.dll")] static extern short GetAsyncKeyState(int virtualKey);
    [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr window, uint message, IntPtr wParam, IntPtr lParam);
    public static void Drag(Window window)
    {
        if ((GetAsyncKeyState(0x01) & 0x8000) == 0) return;
        var handle = new WindowInteropHelper(window).Handle;
        if (handle == IntPtr.Zero) return;
        ReleaseCapture();
        SendMessage(handle, 0x00A1, new IntPtr(2), IntPtr.Zero); // WM_NCLBUTTONDOWN / HTCAPTION
    }
    public static void Resize(Window window, string edge)
    {
        if (window.WindowState != WindowState.Normal || (GetAsyncKeyState(0x01) & 0x8000) == 0) return;
        int hit = edge switch { "w" => 10, "e" => 11, "n" => 12, "nw" => 13, "ne" => 14, "s" => 15, "sw" => 16, "se" => 17, _ => 0 };
        if (hit == 0) return;
        var handle = new WindowInteropHelper(window).Handle;
        if (handle == IntPtr.Zero) return;
        ReleaseCapture();
        SendMessage(handle, 0x00A1, new IntPtr(hit), IntPtr.Zero);
    }
    public static void Apply(Window window, FrameworkElement surface, double radius)
    {
        double r = window.WindowState == WindowState.Maximized ? 0 : radius;
        if (surface.ActualWidth > 0 && surface.ActualHeight > 0) surface.Clip = new RectangleGeometry(new System.Windows.Rect(0, 0, surface.ActualWidth, surface.ActualHeight), r, r);
        var handle = new WindowInteropHelper(window).Handle; if (handle == IntPtr.Zero) return;
        if (r == 0) { SetWindowRgn(handle, IntPtr.Zero, true); return; }
        if (!GetWindowRect(handle, out var bounds)) return;
        var dpi = VisualTreeHelper.GetDpi(window); int diameter = (int)Math.Round(r * 2 * dpi.DpiScaleX);
        var region = CreateRoundRectRgn(0, 0, bounds.Right - bounds.Left + 1, bounds.Bottom - bounds.Top + 1, diameter, diameter);
        if (region != IntPtr.Zero && SetWindowRgn(handle, region, true) == 0) DeleteObject(region);
    }
}
