using GlassPlayer.Core;
namespace GlassPlayer;

public partial class MainWindow
{
    readonly LatestOperation lyricsLoading=new();
    readonly LyricsPrefetcher lyricsPrefetch;
    bool lyricsBusy;

    void ScheduleNextLyrics()
    {
        if(closed||lyricsBusy)return;
        var next=queue.PeekNext(false);
        lyricsPrefetch.Schedule(next?.Id==queue.Current?.Id&&next?.Source==queue.Current?.Source?null:next);
    }
    async Task WarmLyricsAsync(Track track,CancellationToken ct)
    {
        // The same clients enforce their existing cache, serialization and backoff.
        // The current song has finished loading before this optional job is scheduled.
        if(settings.PreferWordLyrics&&!lyrics.HasLocalOverride(track))
            try{await wordLyrics.GetAsync(track,ct);}catch(OperationCanceledException){throw;}catch{}
        ct.ThrowIfCancellationRequested();await lyrics.GetAsync(track,ct);
    }
    async Task LoadLyricsAsync(Track track,bool force=false)
    {
        var operation=lyricsLoading.Begin();lyricsBusy=true;
        using var lookup=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token,trackWork?.Token??lifetime.Token,operation.Token);
        bool Current()=>!lookup.IsCancellationRequested&&lyricsLoading.IsCurrent(operation.Version)&&track.Id==queue.Current?.Id&&track.Source==queue.Current?.Source;
        void Deliver(LyricsDocument? document){if(Current())EmitLyrics(track,document);}
        Task<LyricsDocument?> richTask=Task.FromResult<LyricsDocument?>(null);
        try
        {
            // Let a canceled background write release its client/file before reading the current song.
            await lyricsPrefetch.CancelAsync();lookup.Token.ThrowIfCancellationRequested();
            richTask=settings.PreferWordLyrics&&!lyrics.HasLocalOverride(track)?TryWordLyricsAsync(track,lookup.Token):Task.FromResult<LyricsDocument?>(null);
            var baseTask=lyrics.GetAsync(track,lookup.Token,force);var first=await Task.WhenAny(baseTask,richTask);
            LyricsDocument? basic=null,rich=null;
            if(first==richTask)rich=await richTask;
            if(rich!=null){Deliver(rich);try{basic=await baseTask;}catch(Exception ex)when(ex is not OperationCanceledException){}if(basic?.Source=="Arquivo local")Deliver(basic);return;}
            basic=await baseTask;if(basic!=null)Deliver(basic);if(basic?.Source=="Arquivo local"){lookup.Cancel();return;}
            rich=await richTask;if(rich!=null)Deliver(rich);else if(basic==null)Deliver(null);
        }
        catch(OperationCanceledException){}
        catch(Exception ex){var rich=await richTask;if(rich!=null)Deliver(rich);else if(Current())Emit("lyrics",new{trackId=track.Id,document=(object?)null,error=ex.Message});}
        finally{if(lyricsLoading.IsCurrent(operation.Version)){lyricsBusy=false;ScheduleNextLyrics();}}
    }
    async Task<LyricsDocument?> TryWordLyricsAsync(Track track,CancellationToken ct){try{return await wordLyrics.GetAsync(track,ct);}catch(OperationCanceledException){return null;}catch{return null;}}
    void EmitLyrics(Track track,LyricsDocument? document){if(track.Id==queue.Current?.Id&&track.Source==queue.Current?.Source)Emit("lyrics",new{trackId=track.Id,document,offset=settings.TrackOffsets.GetValueOrDefault(track.Id)});}
}
