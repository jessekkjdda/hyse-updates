using System.Windows;
namespace GlassPlayer;

public partial class MainWindow
{
    TrayHost? tray;
    bool exiting,sessionEnding;
    public void RestoreWindow(){if(closed)return;Show();if(WindowState==WindowState.Minimized)WindowState=WindowState.Normal;Activate();}
    public void ExitApplication(){if(closed)return;exiting=true;Close();}
    public void ExitForInstaller(){installerExit=true;ExitApplication();}
    public void AllowSessionExit(){sessionEnding=true;}
}
