namespace GlassPlayer.Core;

public enum RepeatMode { Off, All, One }

public sealed class PlaybackQueue<T> where T : class
{
    readonly List<T> items = new();
    readonly List<int> bag = new();
    readonly List<int> history = new();
    readonly Random random;
    bool shuffle;
    int? reserved;
    RepeatMode repeat;
    public PlaybackQueue(Random? random = null) => this.random = random ?? Random.Shared;
    public IReadOnlyList<T> Items => items;
    public int Index { get; private set; } = -1;
    public T? Current => Index >= 0 && Index < items.Count ? items[Index] : null;
    public int RemainingCount => Shuffle ? bag.Count : Math.Max(0,items.Count-Index-1);
    public bool HasPrevious => Shuffle ? history.Count>0 : Index>0;
    public RepeatMode Repeat { get=>repeat; set{if(repeat!=value){repeat=value;reserved=null;}} }
    public bool Shuffle { get => shuffle; set { if (shuffle != value) { shuffle = value; ResetBag(); history.Clear(); } } }
    void ResetBag() { reserved=null;bag.Clear(); for (var i = 0; i < items.Count; i++) if (i != Index) bag.Add(i); }
    public T? PeekNext(bool manual=false)
    {
        if(Current is null)return null;
        if(!manual&&Repeat==RepeatMode.One)return Current;
        if(!Shuffle){int next=Index+1;return next<items.Count?items[next]:Repeat==RepeatMode.All?items[0]:null;}
        var candidates=bag.Count>0?bag:Repeat==RepeatMode.All?Enumerable.Range(0,items.Count).Where(i=>i!=Index).ToList():new List<int>();
        if(candidates.Count==0)return Repeat==RepeatMode.All?Current:null;
        if(reserved==null||!candidates.Contains(reserved.Value))reserved=candidates[random.Next(candidates.Count)];
        return items[reserved.Value];
    }
    public T? Start(IEnumerable<T> source, int index)
    {
        var copy = source.Take(10001).ToList();
        if (copy.Count > 10000) throw new ArgumentException("O limite da fila é de 10.000 faixas.");
        if (index < 0 || index >= copy.Count) throw new ArgumentOutOfRangeException(nameof(index));
        items.Clear(); items.AddRange(copy); Index = index; history.Clear(); ResetBag(); return Current;
    }
    public void Append(IEnumerable<T> source)
    {
        var added = source.Take(10001).ToList();
        if (items.Count + added.Count > 10000) throw new ArgumentException("O limite da fila é de 10.000 faixas.");
        reserved=null;int start = items.Count; items.AddRange(added);
        if (Index < 0 && items.Count > 0) Index = 0;
        for (int i = start; i < items.Count; i++) if (i != Index) bag.Add(i);
    }
    // Only radio calls this. Preserve future shuffle slots and recent Back history.
    public void TrimPlayed(int keep=120)
    {
        if(items.Count<Math.Max(20,keep)*2||Index<0)return;
        var retained=history.TakeLast(Math.Max(0,keep)).Append(Index).Concat(Shuffle?bag:Enumerable.Range(Index+1,items.Count-Index-1)).ToHashSet();
        if(retained.Count==items.Count)return;
        var order=retained.Order().ToArray();var map=order.Select((old,index)=>(old,index)).ToDictionary(x=>x.old,x=>x.index);
        var copy=order.Select(i=>items[i]).ToArray();var previous=history.Where(map.ContainsKey).Select(i=>map[i]).ToArray();var future=bag.Where(map.ContainsKey).Select(i=>map[i]).ToArray();
        reserved=reserved is int planned&&map.TryGetValue(planned,out int mapped)?mapped:null;Index=map[Index];
        items.Clear();items.AddRange(copy);history.Clear();history.AddRange(previous);bag.Clear();bag.AddRange(future);
    }
    public T? Next(bool manual = true)
    {
        if (Current is null) return null;
        if (!manual && Repeat == RepeatMode.One) return Current;
        int next;
        if (Shuffle)
        {
            if (bag.Count == 0) { if (Repeat != RepeatMode.All) return null; var planned=reserved;ResetBag();reserved=planned; }
            if (bag.Count == 0) return Repeat == RepeatMode.All ? Current : null;
            int slot=reserved is int plannedIndex&&bag.Contains(plannedIndex)?bag.IndexOf(plannedIndex):random.Next(bag.Count);next=bag[slot];bag.RemoveAt(slot);reserved=null;
        }
        else
        {
            next = Index + 1;
            if (next >= items.Count) { if (Repeat != RepeatMode.All) return null; next = 0; }
        }
        history.Add(Index); if (history.Count > 1000) history.RemoveAt(0); Index = next; return Current;
    }
    public T? Previous()
    {
        if (Current is null) return null;
        reserved=null;
        if (Shuffle) { if (history.Count == 0) return Current; bag.Add(Index); Index = history[^1]; history.RemoveAt(history.Count - 1); bag.Remove(Index); return Current; }
        Index = Index > 0 ? Index - 1 : Repeat == RepeatMode.All ? items.Count - 1 : 0;
        ResetBag(); return Current;
    }
    public void Clear() { reserved=null;items.Clear(); bag.Clear(); history.Clear(); Index = -1; }
}
