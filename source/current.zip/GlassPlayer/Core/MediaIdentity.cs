using System.Text.RegularExpressions;
namespace GlassPlayer.Core;
public static class MediaIdentity
{
    public static bool Supported(Track? track)
    {
        if(track==null)return false;
        if(track.Source=="Spotify")return track.OpenUri==null&&!track.Available||Regex.IsMatch(track.OpenUri??"","^spotify:track:[A-Za-z0-9]{22}$");
        if(track.Source=="SoundCloud"){if(track.OpenUri==null)return !track.Available;try{return SoundCloudCatalog.PublicUrl(track.OpenUri)==track.OpenUri;}catch(ArgumentException){return false;}}
        return false;
    }
}
