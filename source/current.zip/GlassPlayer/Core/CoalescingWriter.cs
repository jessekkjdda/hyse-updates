namespace GlassPlayer.Core;

// Sends immediately, then samples the latest pending value while the control is moving.
// Slow targets never accumulate a request for every intermediate slider position.
public sealed class CoalescingWriter<T> : IDisposable
{
    readonly object sync = new();
    readonly Func<T, CancellationToken, Task> write;
    readonly Func<T, TimeSpan> interval;
    readonly CancellationTokenSource lifetime = new();
    T? pending;
    bool hasPending, running, disposed;
    Task runner = Task.CompletedTask;
    public event Action<Exception>? Failed;
    public CoalescingWriter(Func<T, CancellationToken, Task> write, Func<T, TimeSpan> interval) { this.write = write; this.interval = interval; }
    public void Submit(T value)
    {
        lock (sync) { if (disposed) return; pending = value; hasPending = true; if (running) return; running = true; runner = RunAsync(); }
    }
    public Task WhenIdle { get { lock (sync) return runner; } }
    async Task RunAsync()
    {
        try
        {
            while (true)
            {
                T value;
                lock (sync) { if (disposed || !hasPending) { running = false; return; } value = pending!; hasPending = false; }
                try { await write(value, lifetime.Token); } catch (OperationCanceledException) when (lifetime.IsCancellationRequested) { return; } catch (Exception ex) { Failed?.Invoke(ex); }
                await Task.Delay(interval(value), lifetime.Token);
            }
        }
        catch (OperationCanceledException) when (lifetime.IsCancellationRequested) { }
        finally { lock (sync) { if (disposed) running = false; } }
    }
    public void Dispose() { lock (sync) { if (disposed) return; disposed = true; hasPending = false; lifetime.Cancel(); } }
}
