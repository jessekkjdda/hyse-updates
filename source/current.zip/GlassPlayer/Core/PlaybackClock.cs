using System.Diagnostics;
namespace GlassPlayer.Core;

public sealed class PlaybackClock
{
    readonly Func<double> milliseconds;
    readonly double maximumExtrapolation;
    double at;
    long position,duration;
    long lastSample=-1;
    long? pendingSeek;
    double seekAt;
    public bool Playing {get;private set;}
    public string? Uri {get;private set;}
    public PlaybackClock(Func<double>? milliseconds=null,double maximumExtrapolation=1800)
    {this.milliseconds=milliseconds??(()=>Stopwatch.GetTimestamp()*1000d/Stopwatch.Frequency);this.maximumExtrapolation=maximumExtrapolation;}
    public void Update(long position,long duration,bool playing,string? uri,bool force=false)
    {
        if(pendingSeek is {} target&&Uri==uri&&!force)
        {
            double elapsed=milliseconds()-seekAt;
            if(elapsed<1200&&Math.Abs(position-target)>Math.Max(350,elapsed+250))return;
            pendingSeek=null;
        }
        if(!force&&Uri==uri&&Playing&&playing&&lastSample==position&&this.duration==duration)return;
        this.duration=Math.Max(0,duration);this.position=Math.Clamp(position,0,this.duration);lastSample=position;Playing=playing;Uri=uri;at=milliseconds();
    }
    public long Position=>Math.Clamp(position+(Playing?(long)Math.Clamp(milliseconds()-at,0,maximumExtrapolation):0),0,duration);
    public long Duration=>duration;
    public void Seek(long target){position=Math.Clamp(target,0,duration);pendingSeek=position;seekAt=at=milliseconds();lastSample=-1;}
    public void SetPlaying(bool playing){position=Position;at=milliseconds();Playing=playing;}
    public void Clear(){position=duration=0;lastSample=-1;pendingSeek=null;Playing=false;Uri=null;at=milliseconds();}
}
