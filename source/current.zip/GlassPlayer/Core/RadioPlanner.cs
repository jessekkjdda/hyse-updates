using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace GlassPlayer.Core;

// Discovery selects compositions, not alternate uploads of the search result.
public sealed class RadioPlanner(
    Func<Track,CancellationToken,Task<IReadOnlyList<Track>>> related,
    Func<string,string,CancellationToken,Task<IReadOnlyList<Track>>> artistSearch,
    Random? random=null)
{
    readonly Random random=random??Random.Shared;
    static readonly Regex variations=new(@"\b(remix|remaster(?:ed)?|sped[ -]*up|slowed|reverb|nightcore|cover|karaoke|instrumental|acoustic|live|edit|version|official|audio|lyrics|visuali[sz]er)\b",RegexOptions.IgnoreCase|RegexOptions.CultureInvariant);
    public static string Normalize(string value)
    {
        var text=new StringBuilder();
        foreach(char c in (value??"").Normalize(NormalizationForm.FormD))
            if(CharUnicodeInfo.GetUnicodeCategory(c)!=UnicodeCategory.NonSpacingMark)text.Append(char.IsLetterOrDigit(c)?char.ToLowerInvariant(c):' ');
        return Regex.Replace(text.ToString(),@"\s+"," ").Trim();
    }
    public static string Composition(string title)
    {
        title=Regex.Replace(title??"",@"\([^)]*\)|\[[^\]]*\]",m=>variations.IsMatch(m.Value)?" ":m.Value);
        var suffix=Regex.Match(title,@"\s[-–—]\s(.+)$");
        if(suffix.Success&&variations.IsMatch(suffix.Groups[1].Value))title=title[..suffix.Index];
        return Normalize(title);
    }
    public static string PrimaryArtist(string value)=>Regex.Split(value??"",@"\s+(?:feat\.?|ft\.?)\s+|[,;]",RegexOptions.IgnoreCase)[0].Trim();
    public IReadOnlyList<Track> Select(Track seed,IEnumerable<Track> candidates,IEnumerable<Track> heard,int limit=20)
    {
        var seen=heard.Append(seed).ToArray();var ids=seen.Select(t=>t.Source+"|"+t.Id).ToHashSet(StringComparer.Ordinal);
        var titles=seen.Select(t=>Composition(t.Title)).Where(t=>t.Length>0).ToHashSet(StringComparer.Ordinal);
        var eligible=candidates.Take(2000).Where(t=>t.Source==seed.Source&&t.Available&&MediaIdentity.Supported(t)&&!ids.Contains(t.Source+"|"+t.Id)&&!titles.Contains(Composition(t.Title)))
            .Where(t=>Composition(t.Title).Length>0).GroupBy(t=>Composition(t.Title)).Select(g=>g.First()).ToArray();
        var groups=eligible.GroupBy(t=>Normalize(PrimaryArtist(t.Artist))).Select(g=>g.OrderBy(_=>random.Next()).ToList()).OrderBy(_=>random.Next()).ToList();
        var result=new List<Track>();string lastArtist=Normalize(PrimaryArtist(seed.Artist));
        while(result.Count<Math.Clamp(limit,0,40)&&groups.Count>0)
        {
            var choices=groups.Where(g=>Normalize(PrimaryArtist(g[0].Artist))!=lastArtist).ToList();
            var group=(choices.Count>0?choices:groups)[random.Next(choices.Count>0?choices.Count:groups.Count)];
            var track=group[0];group.RemoveAt(0);result.Add(track);lastArtist=Normalize(PrimaryArtist(track.Artist));if(group.Count==0)groups.Remove(group);
        }
        return result;
    }
    public async Task<IReadOnlyList<Track>> BuildAsync(Track seed,IReadOnlyList<Track> heard,IReadOnlyList<Track> known,CancellationToken ct)
    {
        var candidates=new List<Track>();
        try{candidates.AddRange(await related(seed,ct));}catch(OperationCanceledException){throw;}catch{}
        ct.ThrowIfCancellationRequested();var preferred=Select(seed,candidates,heard);
        if(preferred.Count>=12)return preferred;
        // The user's listening context supplies alternate artists when a service
        // does not expose its private recommendation engine to this app.
        var artists=new[]{PrimaryArtist(seed.Artist)}.Concat(known.Where(t=>t.Source==seed.Source&&Composition(t.Title)!=Composition(seed.Title)).Select(t=>PrimaryArtist(t.Artist)))
            .Where(a=>a.Length>0).DistinctBy(Normalize).Take(3).ToArray();
        foreach(string artist in artists)
        {
            ct.ThrowIfCancellationRequested();
            try{candidates.AddRange(await artistSearch(seed.Source,artist,ct));}catch(OperationCanceledException){throw;}catch{}
            if(Select(seed,candidates,heard).Count>=20)break;
        }
        ct.ThrowIfCancellationRequested();return Select(seed,candidates.Concat(known),heard);
    }
}
