using System.Text.Json;
using System.Text.RegularExpressions;
namespace GlassPlayer.Core;

public static class SpotifyPlaylistReader
{
    static string? Text(JsonElement item,string name)=>item.ValueKind==JsonValueKind.Object&&item.TryGetProperty(name,out var value)&&value.ValueKind==JsonValueKind.String?value.GetString():null;
    public static Track ToTrack(JsonElement item)
    {
        string uri=Text(item,"uri")??"", title=Text(item,"name")??"";
        if(!Regex.IsMatch(uri,"^spotify:track:[A-Za-z0-9]{22}$")||title.Length==0)throw new FormatException("Este item não é uma música Spotify disponível.");
        if(item.TryGetProperty("is_playable",out var playable)&&playable.ValueKind==JsonValueKind.False)throw new FormatException("Faixa indisponível para esta conta.");
        JsonElement album=item.TryGetProperty("album",out var a)&&a.ValueKind==JsonValueKind.Object?a:default;
        string? art=null;
        if(album.ValueKind==JsonValueKind.Object&&album.TryGetProperty("images",out var images)&&images.ValueKind==JsonValueKind.Array)
            art=images.EnumerateArray().Select(image=>Text(image,"url")).FirstOrDefault(url=>!string.IsNullOrWhiteSpace(url));
        string artist=item.TryGetProperty("artists",out var artists)&&artists.ValueKind==JsonValueKind.Array?string.Join(", ",artists.EnumerateArray().Select(artist=>Text(artist,"name")).Where(name=>!string.IsNullOrWhiteSpace(name))):"";
        int duration=item.TryGetProperty("duration_ms",out var d)&&d.ValueKind==JsonValueKind.Number&&d.TryGetInt32(out var ms)?Math.Max(0,ms):0;
        return new(uri[14..],title,artist,art,null,"Spotify",uri,duration,Text(album,"name"));
    }
    public static async Task<List<Track>> ReadAsync(string id,Func<string,CancellationToken,Task<string>> fetch,CancellationToken ct=default,bool allowUnavailable=false,Action<IReadOnlyList<Track>,int>? progress=null,JsonElement? initialPage=null)
    {
        if(!Regex.IsMatch(id,"^[A-Za-z0-9]{22}$"))throw new ArgumentException("Playlist Spotify inválida.");
        var tracks=new List<Track>();var seen=new HashSet<string>(StringComparer.Ordinal);
        string? next=$"/playlists/{id}/items?limit=50";int? total=null;
        while(next!=null)
        {
            ct.ThrowIfCancellationRequested();
            if(!seen.Add(next)||seen.Count>220)throw new FormatException("A paginação da playlist não pôde ser confirmada.");
            using var document=initialPage.HasValue?null:JsonDocument.Parse(await fetch(next,ct));
            var page=initialPage??document!.RootElement;initialPage=null;
            if(page.ValueKind!=JsonValueKind.Object||!page.TryGetProperty("total",out var n)||!n.TryGetInt32(out int count)||count<0)throw new FormatException("A contagem da playlist está ausente ou inválida.");
            if(total.HasValue&&total!=count)throw new FormatException("A playlist mudou durante a leitura. Atualize para carregar novamente.");
            total=count;if(count>10000)throw new FormatException("O limite é de 10.000 faixas.");
            if(!page.TryGetProperty("items",out var entries)||entries.ValueKind!=JsonValueKind.Array)throw new FormatException("O Spotify não retornou os itens desta playlist.");
            foreach(var entry in entries.EnumerateArray())
            {
                JsonElement item=default;
                if(entry.ValueKind==JsonValueKind.Object&&(!entry.TryGetProperty("item",out item)||item.ValueKind==JsonValueKind.Null))entry.TryGetProperty("track",out item);
                try { tracks.Add(ToTrack(item)); }
                catch(FormatException) when(allowUnavailable)
                {
                    string title=Text(item,"name")??"Faixa indisponível";
                    string reason=Text(item,"type")=="episode"?"Episódio":entry.ValueKind==JsonValueKind.Object&&entry.TryGetProperty("is_local",out var local)&&local.ValueKind==JsonValueKind.True?"Arquivo local":"Indisponível";
                    tracks.Add(new("unavailable-"+tracks.Count,title,reason,null,null,"Spotify",null,Available:false));
                }
                if(tracks.Count>count)throw new FormatException("A playlist retornou mais itens que a contagem informada.");
            }
            progress?.Invoke(tracks.ToArray(),count);
            next=null;
            if(page.TryGetProperty("next",out var link)&&link.ValueKind==JsonValueKind.String)
            {
                if(!Uri.TryCreate(link.GetString(),UriKind.Absolute,out var url)||url.Scheme!="https"||url.Host!="api.spotify.com"||url.UserInfo.Length>0||!url.IsDefaultPort||url.Fragment.Length>0||url.AbsolutePath!="/v1/playlists/"+id+"/items"&&url.AbsolutePath!="/v1/playlists/"+id+"/tracks")throw new FormatException("A paginação retornou um endereço inesperado.");
                next=$"/playlists/{id}/items"+url.Query;
            }
        }
        if(tracks.Count!=total)throw new FormatException("A playlist não foi lida por completo. Atualize para tentar novamente.");
        return tracks;
    }
}
