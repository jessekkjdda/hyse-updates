using System.IO;
using System.Text.Json;
using System.Text.Json.Nodes;
namespace GlassPlayer.Core;
public sealed class DiscordRpcError(int code,string message,string phase,bool closed=false):IOException(message)
{
    public int Code{get;}=code;
    public string Phase{get;}=phase;
    public bool Closed{get;}=closed;
    public static DiscordRpcError Read(JsonElement root,string phase,bool closed=false)
    {
        var data=root.TryGetProperty("data",out var nested)&&nested.ValueKind==JsonValueKind.Object?nested:root;
        int code=data.TryGetProperty("code",out var number)&&number.ValueKind==JsonValueKind.Number&&number.TryGetInt32(out var value)?value:0;
        string message=data.TryGetProperty("message",out var text)&&text.ValueKind==JsonValueKind.String?text.GetString()??"":"";
        message=new string(message.Where(c=>!char.IsControl(c)).Take(240).ToArray());
        return new(code,message.Length>0?message:"O Discord recusou a solicitação.",phase,closed);
    }
}
public static class DiscordCompatibility
{
    // Negotiate optional presentation fields only after an explicit invalid-payload reply.
    public static string? Apply(string? activity,int level)
    {
        if(activity==null||level<=0)return activity;
        var node=JsonNode.Parse(activity) as JsonObject??throw new JsonException("Invalid activity.");
        foreach(string key in new[]{"name","status_display_type","details_url","state_url","buttons"})node.Remove(key);
        if(node["assets"] is JsonObject assets){assets.Remove("large_url");assets.Remove("small_url");}
        if(level>=2)node.Remove("assets");
        return node.ToJsonString();
    }
}
