namespace GlassPlayer.Core;

public sealed class LatestOperation : IDisposable
{
    CancellationTokenSource? source;
    long generation;
    public (long Version, CancellationToken Token) Begin()
    {
        source?.Cancel(); source?.Dispose();
        source = new CancellationTokenSource();
        return (++generation, source.Token);
    }
    public bool IsCurrent(long version) => version == generation && source is { IsCancellationRequested: false };
    public void Cancel() { generation++; source?.Cancel(); }
    public void Dispose() { Cancel(); source?.Dispose(); source = null; }
}
