namespace GlassPlayer.Core;

// Local, bounded index used for immediate feedback while Spotify answers the current query.
public sealed class SearchSuggestions(int capacity = 300)
{
    sealed record Entry(Track Track, string Title, string Artist);
    readonly Dictionary<string, Entry> tracks = new(StringComparer.Ordinal);
    readonly Queue<string> age = new();
    public void Add(IEnumerable<Track> source)
    {
        foreach (var track in source.Where(t => t.Source == "Spotify"&&t.Available))
        {
            if (!tracks.ContainsKey(track.Id)) age.Enqueue(track.Id);
            tracks[track.Id] = new(track, LyricsParser.Normalize(track.Title), LyricsParser.Normalize(track.Artist));
            while (tracks.Count > capacity && age.Count > 0) tracks.Remove(age.Dequeue());
        }
    }
    public List<Track> Find(string query, int limit = 10)
    {
        var normalized = LyricsParser.Normalize(query); if (normalized.Length == 0) return new();
        var tokens = normalized.Split(' ');
        return tracks.Values.Where(e => tokens.All(word => e.Title.Contains(word, StringComparison.Ordinal) || e.Artist.Contains(word, StringComparison.Ordinal)))
            .OrderBy(e => e.Title == normalized ? 0 : e.Title.StartsWith(normalized, StringComparison.Ordinal) ? 1 : e.Artist.StartsWith(normalized, StringComparison.Ordinal) ? 2 : 3)
            .ThenBy(e => e.Title.Length).Take(limit).Select(e => e.Track).ToList();
    }
}
