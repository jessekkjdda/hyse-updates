using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
namespace GlassPlayer.Core;

public sealed record CatalogEntity(string Id,string Name,string Kind,string Source,string? Art,string Subtitle,string Url,int Count=0);
public sealed record CatalogPage(List<Track> Tracks,List<CatalogEntity> Entities,int? NextOffset=null,string? NextCursor=null);
public sealed record SearchSpotlight(Track? Track,CatalogEntity? Entity);
public sealed record CatalogSearchResult(List<Track> Tracks,List<CatalogEntity> Entities,SearchSpotlight? Spotlight,int? NextSpotify,string? NextSoundCloud,List<string> Notices);
public static class CatalogReader
{
    public static string S(JsonElement e,string key)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(key,out var p)&&p.ValueKind==JsonValueKind.String?p.GetString()??"":"";
    public static int N(JsonElement e,string key)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(key,out var p)&&p.ValueKind==JsonValueKind.Number&&p.TryGetInt32(out var n)?Math.Max(0,n):0;
    public static string? Art(JsonElement e)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty("images",out var images)&&images.ValueKind==JsonValueKind.Array?images.EnumerateArray().Select(i=>S(i,"url")).FirstOrDefault(s=>s.Length>0):null;
    public static CatalogPage Spotify(string json,int offset)
    {
        using var doc=JsonDocument.Parse(json);var root=doc.RootElement;var tracks=new List<Track>();var entities=new List<CatalogEntity>();bool more=false;
        foreach(var (group,kind) in new[]{("tracks","track"),("artists","artist"),("albums","album"),("playlists","playlist")})
        {
            if(!root.TryGetProperty(group,out var page)||page.ValueKind!=JsonValueKind.Object||!page.TryGetProperty("items",out var rows)||rows.ValueKind!=JsonValueKind.Array)continue;
            more|=S(page,"next").Length>0&&rows.GetArrayLength()>0;
            foreach(var row in rows.EnumerateArray())
            {
                if(row.ValueKind!=JsonValueKind.Object)continue;
                if(kind=="track"){try{tracks.Add(SpotifyPlaylistReader.ToTrack(row));}catch(FormatException){}continue;}
                string id=S(row,"id"),name=S(row,"name");if(!Regex.IsMatch(id,"^[A-Za-z0-9]{22}$")||name.Length==0)continue;
                string subtitle=kind=="artist"?"Artista":row.TryGetProperty("artists",out var artists)&&artists.ValueKind==JsonValueKind.Array?string.Join(", ",artists.EnumerateArray().Select(a=>S(a,"name"))):row.TryGetProperty("owner",out var owner)?S(owner,"display_name"):"Playlist";
                int count=N(row,"total_tracks");if(kind=="playlist"&&(row.TryGetProperty("items",out var collection)||row.TryGetProperty("tracks",out collection)))count=N(collection,"total");
                entities.Add(new(id,name,kind,"Spotify",Art(row),subtitle,"https://open.spotify.com/"+kind+"/"+id,count));
            }
        }
        return new(tracks.DistinctBy(t=>t.Id).ToList(),entities.DistinctBy(e=>(e.Kind,e.Id)).ToList(),more&&offset<990?offset+10:null);
    }
    static string Normalize(string s){var b=new StringBuilder();foreach(var c in s.Normalize(NormalizationForm.FormD))if(CharUnicodeInfo.GetUnicodeCategory(c)!=UnicodeCategory.NonSpacingMark)b.Append(char.IsLetterOrDigit(c)?char.ToLowerInvariant(c):' ');return string.Join(' ',b.ToString().Split(' ',StringSplitOptions.RemoveEmptyEntries));}
    public static double Score(string query,string title,string subtitle)
    {
        string q=Normalize(query),t=Normalize(title),combined=Normalize(title+" "+subtitle);if(q.Length==0||t.Length==0)return 0;
        double exact=q==t?100:q==combined?98:t.StartsWith(q+" ")?80:combined.Contains(q,StringComparison.Ordinal)?65:0;
        var tokens=q.Split(' ');double coverage=tokens.Count(token=>combined.Split(' ').Contains(token))/(double)tokens.Length;
        return exact+coverage*30+Math.Min(10,q.Length/(double)Math.Max(q.Length,t.Length)*10);
    }
    public static SearchSpotlight? Spotlight(string query,IReadOnlyList<Track> tracks,IReadOnlyList<CatalogEntity> entities)
    {
        var candidates=tracks.Where(t=>t.Available).Select(t=>(score:Score(query,t.Title,t.Artist)+1,spot:new SearchSpotlight(t,null))).Concat(entities.Select(e=>(Score(query,e.Name,e.Subtitle),new SearchSpotlight(null,e))));
        return candidates.Where(x=>x.Item1>=35).OrderByDescending(x=>x.Item1).FirstOrDefault().Item2;
    }
}
