namespace GlassPlayer.Core;

public sealed record PlaylistScanItem(int Position,Track Track);
// Spotify virtualizes the list. Positions, not URIs, identify occurrences.
public sealed class PlaylistScan(int expectedCount)
{
    readonly SortedDictionary<int,Track> entries=new();
    public int ExpectedCount{get;private set;}=expectedCount is >=0 and <=10000?expectedCount:throw new ArgumentOutOfRangeException(nameof(expectedCount));
    public int Count=>entries.Count;
    public bool Complete=>ExpectedCount>0&&entries.Count==ExpectedCount&&Enumerable.Range(1,ExpectedCount).All(entries.ContainsKey);
    public void SetExpectedCount(int value){if(value is <0 or >10000)throw new FormatException("A playlist excede o limite de 10.000 faixas.");if(ExpectedCount>0&&value>0&&ExpectedCount!=value)throw new FormatException("A contagem da playlist mudou durante a leitura. Atualize e tente novamente.");if(ExpectedCount==0)ExpectedCount=value;}
    public void Add(IEnumerable<PlaylistScanItem> page)
    {
        foreach(var entry in page)
        {
            if(entry.Position<1||entry.Position>10000||ExpectedCount>0&&entry.Position>ExpectedCount)throw new FormatException("O Spotify retornou uma posição inesperada na playlist.");
            if(entries.TryGetValue(entry.Position,out var previous)&&previous.OpenUri!=entry.Track.OpenUri)throw new FormatException("A ordem da playlist mudou durante a leitura. Tente novamente.");
            entries[entry.Position]=entry.Track;
        }
    }
    public List<Track> Finish(){if(!Complete)throw new FormatException($"Foram lidas {Count} de {ExpectedCount} faixas. A leitura completa ainda não foi confirmada.");return entries.Values.ToList();}
}
