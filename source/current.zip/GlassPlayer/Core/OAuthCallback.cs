using System.Security.Cryptography;
using System.Text;
namespace GlassPlayer.Core;

public sealed record OAuthCallback(string? Code, string? Error)
{
    public static OAuthCallback Parse(string requestLine, string expectedState)
    {
        if (requestLine.Length > 8192) throw new FormatException("Retorno OAuth muito longo.");
        var parts = requestLine.Split(' ');
        if (parts.Length != 3 || parts[0] != "GET" || parts[2] is not ("HTTP/1.1" or "HTTP/1.0") || !parts[1].StartsWith("/callback?", StringComparison.Ordinal)) throw new FormatException("Retorno OAuth inválido.");
        var query = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var parameter in parts[1][10..].Split('&', StringSplitOptions.RemoveEmptyEntries))
        {
            var field = parameter.Split('=', 2); var key = Uri.UnescapeDataString(field[0].Replace('+', ' ')); var value = field.Length == 2 ? Uri.UnescapeDataString(field[1].Replace('+', ' ')) : "";
            if (!query.TryAdd(key, value)) throw new FormatException("Retorno OAuth duplicado.");
        }
        if (string.IsNullOrEmpty(expectedState) || !query.TryGetValue("state", out var state) || !CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(state), Encoding.UTF8.GetBytes(expectedState))) throw new FormatException("O estado OAuth não corresponde ao login aberto.");
        if (query.TryGetValue("error", out var error) && !string.IsNullOrEmpty(error)) return new(null, error);
        if (!query.TryGetValue("code", out var code) || string.IsNullOrEmpty(code)) throw new FormatException("O retorno OAuth não contém código.");
        return new(code, null);
    }
}
