using System.Text.RegularExpressions;
namespace GlassPlayer.Core;

public sealed record ImportLink(string Provider, string Url, string? PlaylistId)
{
    public static ImportLink Parse(string value)
    {
        value = value.Trim();
        var spotify = Regex.Match(value, @"^spotify:playlist:([A-Za-z0-9]{22})$");
        if (spotify.Success) return new("Spotify", "https://open.spotify.com/playlist/" + spotify.Groups[1].Value, spotify.Groups[1].Value);
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri) || uri.Scheme != "https" || !string.IsNullOrEmpty(uri.UserInfo) || !uri.IsDefaultPort)
            throw new ArgumentException("Cole um link HTTPS de playlist do Spotify.");
        if (uri.Host == "open.spotify.com")
        {
            var m = Regex.Match(uri.AbsolutePath, @"^/(?:intl-[a-z]+/)?playlist/([A-Za-z0-9]{22})/?$");
            if (!m.Success) throw new ArgumentException("No Spotify, use o link de uma playlist.");
            return new("Spotify", "https://open.spotify.com/playlist/" + m.Groups[1].Value, m.Groups[1].Value);
        }
        throw new ArgumentException("Cole o link de uma playlist do Spotify.");
    }
}
