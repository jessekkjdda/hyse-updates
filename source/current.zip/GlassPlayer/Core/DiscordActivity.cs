using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace GlassPlayer.Core;

public sealed record DiscordPresenceOptions(bool Enabled=true,bool ShowArtwork=true,bool ShowTime=true,bool ShowButton=true,bool HidePaused=false,string Text="app");

// Uses confirmed playback samples only; presence never changes the media clock.
public sealed class DiscordActivity
{
    public const string ApplicationId="1574964498241036328";
    public const string IconAsset="https://cdn.discordapp.com/app-icons/1574964498241036328/bdc8a85f6ca8225cfc6b552f9c41d608.png";
    static readonly JsonSerializerOptions Json=new(){DefaultIgnoreCondition=JsonIgnoreCondition.WhenWritingNull};
    string? identity;bool wasPlaying;long start,duration;
    public string? Build(Track? track,bool playing,long position,long durationMs,DiscordPresenceOptions options,DateTimeOffset now)
    {
        if(!options.Enabled||track==null){identity=null;wasPlaying=false;return null;}
        long at=now.ToUnixTimeSeconds(),length=Math.Max(0,durationMs>0?durationMs:track.DurationMs);
        position=Math.Clamp(position,0,length>0?length:long.MaxValue);
        long candidate=at-position/1000;
        string key=track.Source+":"+track.Id;
        if(identity!=key||!wasPlaying&&playing||Math.Abs(candidate-start)>2||duration!=length)start=candidate;
        identity=key;wasPlaying=playing;duration=length;
        if(!playing&&options.HidePaused)return null;
        string? link=TrackUrl(track),artwork=options.ShowArtwork?ImageUrl(track.Art):null;
        return JsonSerializer.Serialize(new{
            type=2,name="Hyse",status_display_type=options.Text=="app"?0:2,
            details=Text(track.Title),state=Text((playing?"":"Pausado · ")+track.Artist),
            details_url=link,
            timestamps=playing&&options.ShowTime?new{start,end=length>0?(long?)(start+(length+999)/1000):null}:null,
            assets=new{large_image=artwork??IconAsset,large_text=Text(track.AlbumName??track.Title),large_url=link,small_image=artwork!=null?IconAsset:null,small_text=artwork!=null?"Hyse · "+track.Source:null},
            buttons=options.ShowButton&&link!=null?new[]{new{label="Ouvir no "+track.Source,url=link}}:null
        },Json);
    }
    static string Text(string? text)
    {
        // Discord limits these fields to 128 UTF-8 bytes; never split a rune.
        var result=new StringBuilder();int bytes=0;
        foreach(var rune in (text??"").EnumerateRunes()){if(Rune.IsControl(rune))continue;if(bytes+rune.Utf8SequenceLength>128)break;result.Append(rune);bytes+=rune.Utf8SequenceLength;}
        return result.Length==0?"—":bytes<2?result+" ":result.ToString();
    }
    public static string? ImageUrl(string? value)=>Uri.TryCreate(value,UriKind.Absolute,out var uri)&&uri.Scheme=="https"&&uri.UserInfo.Length==0&&uri.AbsoluteUri.Length<=300?uri.AbsoluteUri:null;
    public static string? TrackUrl(Track track)
    {
        if(track.Source=="Spotify"&&track.OpenUri?.StartsWith("spotify:track:",StringComparison.Ordinal)==true)
        {
            string id=track.OpenUri[14..];if(id.Length==22&&id.All(char.IsAsciiLetterOrDigit))return "https://open.spotify.com/track/"+id;
        }
        if(!Uri.TryCreate(track.OpenUri,UriKind.Absolute,out var uri)||uri.Scheme!="https"||uri.UserInfo.Length>0||uri.Port!=443||uri.AbsoluteUri.Length>512)return null;
        return track.Source=="Spotify"&&uri.Host=="open.spotify.com"||track.Source=="SoundCloud"&&(uri.Host=="soundcloud.com"||uri.Host=="www.soundcloud.com")?uri.GetLeftPart(UriPartial.Path):null;
    }
}
