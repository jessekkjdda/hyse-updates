using System.Text.Json;
namespace GlassPlayer.Core;
public static class RadioDiscovery
{
    public static IReadOnlyList<Track> SpotifyQueue(JsonElement root,Track seed)
    {
        if(!root.TryGetProperty("currently_playing",out var current)||CatalogReader.S(current,"id")!=seed.Id||!root.TryGetProperty("queue",out var queue)||queue.ValueKind!=JsonValueKind.Array)return Array.Empty<Track>();
        var tracks=new List<Track>();foreach(var row in queue.EnumerateArray())
        {
            if(row.ValueKind!=JsonValueKind.Object||CatalogReader.S(row,"type")=="episode")continue;
            try{tracks.Add(SpotifyPlaylistReader.ToTrack(row));}catch(FormatException){}
        }
        return tracks.DistinctBy(t=>t.Id).Take(50).ToArray();
    }
    public static string[] Genres(JsonElement root,string artist)
    {
        if(!root.TryGetProperty("artists",out var page)||!page.TryGetProperty("items",out var rows)||rows.ValueKind!=JsonValueKind.Array)return Array.Empty<string>();
        // Metadata from a different homonymous search hit must not steer the radio.
        foreach(var row in rows.EnumerateArray())
        {
            if(row.ValueKind!=JsonValueKind.Object||RadioPlanner.Normalize(CatalogReader.S(row,"name"))!=RadioPlanner.Normalize(artist)||!row.TryGetProperty("genres",out var genres)||genres.ValueKind!=JsonValueKind.Array)continue;
            return genres.EnumerateArray().Where(e=>e.ValueKind==JsonValueKind.String).Select(e=>e.GetString()!).Where(s=>s.Length is >0 and <=100).Distinct(StringComparer.OrdinalIgnoreCase).Take(3).ToArray();
        }
        return Array.Empty<string>();
    }
}
