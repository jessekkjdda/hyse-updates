namespace GlassPlayer.Core;

// Radio is optional so pre-existing queue.json files retain their list behavior.
public sealed record QueueSession(List<Track> Queue,int Index,bool Radio=false);
