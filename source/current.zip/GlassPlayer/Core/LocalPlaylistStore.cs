using System.IO;
using System.Text.Json;
namespace GlassPlayer.Core;

public sealed record LocalPlaylist(string Id,string Name,string Description,List<Track> Tracks,DateTimeOffset UpdatedAt)
{
    public LibraryPlaylist Metadata=>new(Id,Name,Description,Tracks.FirstOrDefault(t=>t.Art!=null)?.Art,"local","Neste hyse",false,false,Tracks.Count,UpdatedAt.ToUnixTimeMilliseconds().ToString());
}
// Local playlists have a separate ID namespace and never pretend to be Spotify edits.
public sealed class LocalPlaylistStore(string path)
{
    readonly List<LocalPlaylist> lists=new();
    public void Load()
    {
        if(!File.Exists(path))return;
        if(new FileInfo(path).Length>32*1024*1024)throw new FormatException("A biblioteca local excede 32 MB.");
        var saved=JsonSerializer.Deserialize<List<LocalPlaylist>>(File.ReadAllText(path))??new();
        if(saved.Count>500||saved.Any(p=>!p.Id.StartsWith("local-")||p.Tracks.Count>10000))throw new FormatException("Biblioteca local inválida.");
        lists.Clear();lists.AddRange(saved);
    }
    public List<LibraryPlaylist> List()=>lists.OrderByDescending(p=>p.UpdatedAt).Select(p=>p.Metadata).ToList();
    LocalPlaylist Get(string id)=>lists.FirstOrDefault(p=>p.Id==id)??throw new ArgumentException("Playlist local não encontrada.");
    public PlaylistContent Open(string id){var p=Get(id);return new(p.Metadata,p.Tracks.ToList());}
    static void Validate(string name,string description){if(name.Trim().Length is <1 or >100||description.Length>300)throw new ArgumentException("Use nome de até 100 caracteres e descrição de até 300.");}
    public LibraryPlaylist Create(string name,string description)
    {
        Validate(name,description);if(lists.Count>=500)throw new ArgumentException("O limite é de 500 playlists locais.");
        var p=new LocalPlaylist("local-"+Guid.NewGuid().ToString("N"),name.Trim(),description,new(),DateTimeOffset.UtcNow);Commit(lists.Append(p).ToList());return p.Metadata;
    }
    void Replace(LocalPlaylist original,LocalPlaylist updated){var copy=lists.ToList();copy[copy.IndexOf(original)]=updated with{UpdatedAt=DateTimeOffset.UtcNow};Commit(copy);}
    public void Update(string id,string name,string description){Validate(name,description);var p=Get(id);Replace(p,p with{Name=name.Trim(),Description=description});}
    public void Add(string id,Track track){var p=Get(id);if(p.Tracks.Count>=10000)throw new ArgumentException("O limite é de 10.000 faixas.");if(!MediaIdentity.Supported(track)||track.OpenUri==null||!track.Available)throw new ArgumentException("Escolha uma faixa disponível.");Replace(p,p with{Tracks=p.Tracks.Append(track).ToList()});}
    public void Remove(string id,int index){var p=Get(id);if(index<0||index>=p.Tracks.Count)throw new ArgumentOutOfRangeException(nameof(index));var tracks=p.Tracks.ToList();tracks.RemoveAt(index);Replace(p,p with{Tracks=tracks});}
    public void Move(string id,int from,int to){var p=Get(id);if(from<0||to<0||from>=p.Tracks.Count||to>=p.Tracks.Count)throw new ArgumentOutOfRangeException(nameof(from));var tracks=p.Tracks.ToList();var t=tracks[from];tracks.RemoveAt(from);tracks.Insert(to,t);Replace(p,p with{Tracks=tracks});}
    public void Delete(string id){var p=Get(id);Commit(lists.Where(x=>x.Id!=p.Id).ToList());}
    void Commit(List<LocalPlaylist> updated)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);string temp=path+".tmp";File.WriteAllText(temp,JsonSerializer.Serialize(updated));File.Move(temp,path,true);lists.Clear();lists.AddRange(updated);
    }
}
