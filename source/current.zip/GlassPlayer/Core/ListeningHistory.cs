using System.IO;
using System.Text.Json;
namespace GlassPlayer.Core;

public sealed record ListeningEntry(string SessionId,Track Track,DateTimeOffset PlayedAt,long HeardMs)
{
    public string WhenText=>PlayedAt.ToLocalTime().ToString("dd/MM/yyyy · HH:mm");
}
public sealed class ListeningHistory
{
    readonly List<ListeningEntry> entries=new();
    Track? current;string sessionId="";long heard,lastPosition;double lastTime;bool lastPlaying,observed;
    DateTimeOffset began;
    public IReadOnlyList<ListeningEntry> Entries=>entries;
    public void Restore(IEnumerable<ListeningEntry> saved)
    {entries.Clear();entries.AddRange(saved.Where(e=>e is{Track:{OpenUri:not null},HeardMs:>=5000}&&MediaIdentity.Supported(e.Track)).OrderByDescending(e=>e.PlayedAt).Take(500));}
    public void Begin(Track track,DateTimeOffset at)
    {current=track;sessionId=Guid.NewGuid().ToString("N");heard=0;observed=false;lastPlaying=false;began=at;}
    public bool Observe(long position,bool playing,double now)
    {
        if(current==null)return false;
        if(observed&&lastPlaying&&playing)
        {
            double elapsed=Math.Clamp(now-lastTime,0,2500);long progress=position-lastPosition;
            if(progress>=0&&Math.Abs(progress-elapsed)<=900)heard+=(long)Math.Min(elapsed,progress);
        }
        observed=true;lastPosition=position;lastTime=now;lastPlaying=playing;
        if(heard<5000)return false;
        int index=entries.FindIndex(e=>e.SessionId==sessionId);
        if(index<0){entries.Insert(0,new(sessionId,current,began,heard));if(entries.Count>500)entries.RemoveAt(entries.Count-1);return true;}
        entries[index]=entries[index] with{HeardMs=heard};return false;
    }
    public void Clear(){entries.Clear();current=null;observed=false;}
}
public sealed class ListeningHistoryStore(string path)
{
    readonly SemaphoreSlim writer=new(1,1);
    public List<ListeningEntry> Load()
    {
        try{if(!File.Exists(path)||new FileInfo(path).Length>4*1024*1024)return new();return JsonSerializer.Deserialize<List<ListeningEntry>>(File.ReadAllText(path))?.Take(500).ToList()??new();}catch{return new();}
    }
    public async Task SaveAsync(IEnumerable<ListeningEntry> entries)
    {
        var snapshot=entries.Take(500).ToList();await writer.WaitAsync().ConfigureAwait(false);
        try{Directory.CreateDirectory(Path.GetDirectoryName(path)!);string temp=path+".tmp";await File.WriteAllTextAsync(temp,JsonSerializer.Serialize(snapshot)).ConfigureAwait(false);File.Move(temp,path,true);}
        finally{writer.Release();}
    }
}
