namespace GlassPlayer.Core;

public enum AppPage { Player, Search, Queue, Playlists, History, Settings, Import }
public sealed class PageState
{
    public AppPage Current {get;private set;}=AppPage.Player;
    public bool ShowsPlayer=>Current==AppPage.Player;
    public bool ShowsTrackList=>Current is AppPage.Search or AppPage.Queue;
    public void Navigate(AppPage page)=>Current=page;
}
