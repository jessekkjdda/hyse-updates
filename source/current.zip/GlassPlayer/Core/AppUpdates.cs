using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace GlassPlayer.Core;

public sealed record UpdateManifest(int Schema,string Product,string Platform,string Version,string DownloadUrl,long SizeBytes,string Sha256);
public sealed record PreparedUpdate(UpdateManifest Manifest,string DirectoryPath)
{
    public string InstallerPath=>Path.Combine(DirectoryPath,$"hyse-{Manifest.Version}-Setup.exe");
}

// Both the desktop and the isolated installer helper verify the same signed bytes.
public static class UpdateVerification
{
    public const int ManifestLimit=65536;
    public const long InstallerLimit=256L*1024*1024;
    public static Version ParseVersion(string value)
    {
        if(!Regex.IsMatch(value??"",@"^(0|[1-9]\d{0,4})\.(0|[1-9]\d{0,4})\.(0|[1-9]\d{0,4})\z"))throw new FormatException("Versão de atualização inválida.");
        return Version.Parse(value!);
    }
    public static UpdateManifest Verify(byte[] bytes,byte[] signature,string publicKey)
    {
        if(bytes.Length is 0 or >ManifestLimit||signature.Length is <256 or >1024)throw new FormatException("Manifesto de atualização inválido.");
        using var rsa=RSA.Create();rsa.ImportFromPem(publicKey);
        if(!rsa.VerifyData(bytes,signature,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1))throw new CryptographicException("A assinatura da atualização não confere.");
        using var json=JsonDocument.Parse(bytes);var names=new HashSet<string>(StringComparer.Ordinal);
        if(json.RootElement.ValueKind!=JsonValueKind.Object)throw new FormatException("Manifesto de atualização inválido.");
        foreach(var property in json.RootElement.EnumerateObject())if(!names.Add(property.Name))throw new FormatException("Campo de atualização duplicado.");
        var manifest=JsonSerializer.Deserialize<UpdateManifest>(bytes,new JsonSerializerOptions{PropertyNameCaseInsensitive=false,PropertyNamingPolicy=JsonNamingPolicy.CamelCase})??throw new FormatException("Manifesto vazio.");
        if(manifest.Schema!=1||manifest.Product!="hyse"||manifest.Platform!="windows-x64"||manifest.SizeBytes is <1024 or >InstallerLimit||!Regex.IsMatch(manifest.Sha256??"",@"^[a-f0-9]{64}\z"))throw new FormatException("Atualização incompatível.");
        ParseVersion(manifest.Version);
        if(manifest.DownloadUrl!=$"{UpdateTrust.Repository}/releases/download/v{manifest.Version}/hyse-{manifest.Version}-Setup.exe")throw new FormatException("Origem de atualização inválida.");
        return manifest;
    }
    public static async Task VerifyInstallerAsync(string path,UpdateManifest manifest,CancellationToken ct)
    {
        await using var file=new FileStream(path,FileMode.Open,FileAccess.Read,FileShare.Read,81920,true);
        if(file.Length!=manifest.SizeBytes)throw new IOException("O tamanho do instalador não confere.");
        var hash=await SHA256.HashDataAsync(file,ct);
        if(!CryptographicOperations.FixedTimeEquals(hash,Convert.FromHexString(manifest.Sha256)))throw new CryptographicException("O instalador está incompleto ou foi alterado.");
        file.Position=0;var header=new byte[2];if(await file.ReadAsync(header,ct)!=2||header[0]!='M'||header[1]!='Z')throw new FormatException("Instalador Windows inválido.");
    }
    public static bool RedirectAllowed(Uri uri)=>uri.Scheme=="https"&&uri.IsDefaultPort&&uri.UserInfo.Length==0&&uri.Fragment.Length==0&&
        (uri.Host=="github.com"&&uri.AbsolutePath.StartsWith("/jessekkjdda/hyse-updates/releases/",StringComparison.Ordinal)||uri.Host is "release-assets.githubusercontent.com" or "objects.githubusercontent.com" or "github-releases.githubusercontent.com");
}

public sealed class UpdateClient:IDisposable
{
    readonly HttpClient http;
    readonly string key;
    readonly SemaphoreSlim gate=new(1,1);
    public UpdateClient(HttpMessageHandler? handler=null,string? publicKey=null)
    {
        http=new(handler??new HttpClientHandler{AllowAutoRedirect=false}){Timeout=TimeSpan.FromMinutes(15)};
        http.DefaultRequestHeaders.UserAgent.ParseAdd("hyse-updater/0.16.1");key=publicKey??UpdateTrust.PublicKey;
    }
    async Task<HttpResponseMessage> GetAsync(Uri url,CancellationToken ct)
    {
        for(int hops=0;hops<6;hops++)
        {
            if(!UpdateVerification.RedirectAllowed(url))throw new IOException("Redirecionamento de atualização inválido.");
            var response=await http.GetAsync(url,HttpCompletionOption.ResponseHeadersRead,ct);
            if((int)response.StatusCode is 301 or 302 or 303 or 307 or 308)
            {
                var target=response.Headers.Location;response.Dispose();if(target==null)throw new IOException("Atualização sem destino.");url=new Uri(url,target);continue;
            }
            try{response.EnsureSuccessStatusCode();return response;}catch{response.Dispose();throw;}
        }
        throw new IOException("Muitos redirecionamentos de atualização.");
    }
    async Task<byte[]> SmallFileAsync(string url,int limit,CancellationToken ct)
    {
        using var response=await GetAsync(new(url),ct);if(response.Content.Headers.ContentLength>limit)throw new IOException("Resposta de atualização muito grande.");
        await using var input=await response.Content.ReadAsStreamAsync(ct);using var output=new MemoryStream();var buffer=new byte[8192];int n;
        while((n=await input.ReadAsync(buffer,ct))>0){if(output.Length+n>limit)throw new IOException("Resposta de atualização muito grande.");output.Write(buffer,0,n);}return output.ToArray();
    }
    public async Task<PreparedUpdate?> CheckAndDownloadAsync(string current,string cache,Action<string,int>? progress,CancellationToken ct)
    {
        await gate.WaitAsync(ct);
        try
        {
            var currentVersion=UpdateVerification.ParseVersion(current);
            var bytes=await SmallFileAsync(UpdateTrust.Feed,UpdateVerification.ManifestLimit,ct);
            var sig=await SmallFileAsync(UpdateTrust.FeedSignature,1024,ct);
            var manifest=UpdateVerification.Verify(bytes,sig,key);
            if(UpdateVerification.ParseVersion(manifest.Version)<=currentVersion)return null;
            string dir=Path.Combine(cache,manifest.Version+"-"+manifest.Sha256[..16]);Directory.CreateDirectory(dir);
            var update=new PreparedUpdate(manifest,dir);string part=update.InstallerPath+".part";
            try
            {
                bool cached=false;
                if(File.Exists(update.InstallerPath))try{await UpdateVerification.VerifyInstallerAsync(update.InstallerPath,manifest,ct);cached=true;}catch(Exception ex)when(ex is IOException or CryptographicException or FormatException){File.Delete(update.InstallerPath);}
                if(!cached)
                {
                    using var response=await GetAsync(new(manifest.DownloadUrl),ct);
                    if(response.Content.Headers.ContentLength is long length&&length!=manifest.SizeBytes)throw new IOException("O tamanho anunciado do instalador não confere.");
                    await using(var input=await response.Content.ReadAsStreamAsync(ct))
                    await using(var output=new FileStream(part,FileMode.Create,FileAccess.Write,FileShare.None,81920,true))
                    {
                        byte[] buffer=new byte[81920];long total=0;int n,last=-1;
                        while((n=await input.ReadAsync(buffer,ct))>0)
                        {
                            total+=n;if(total>manifest.SizeBytes)throw new IOException("Instalador excedeu o tamanho assinado.");await output.WriteAsync(buffer.AsMemory(0,n),ct);
                            int percent=(int)(total*100/manifest.SizeBytes);if(percent!=last){last=percent;progress?.Invoke(manifest.Version,percent);}
                        }
                        await output.FlushAsync(ct);
                    }
                    await UpdateVerification.VerifyInstallerAsync(part,manifest,ct);File.Move(part,update.InstallerPath,true);
                }
                await File.WriteAllBytesAsync(Path.Combine(dir,"hyse-update.json"),bytes,ct);
                await File.WriteAllBytesAsync(Path.Combine(dir,"hyse-update.sig"),sig,ct);
                return update;
            }
            finally{if(File.Exists(part))File.Delete(part);}
        }
        finally{gate.Release();}
    }
    public void Dispose()=>http.Dispose();
}
