using System.IO;
using System.Text.Json;

namespace GlassPlayer.Core;

public sealed record UpdatePlan(int ParentId,long ParentStarted,string InstallDirectory,string CurrentVersion,bool Restart);

public static class UpdateHandoff
{
    public const string MutexName="Local\\hyse.updater";
    public static bool ApplyOnExit(bool exiting,bool sessionEnding,bool automatic,bool ready)=>exiting&&!sessionEnding&&automatic&&ready;
    public static bool SameDirectory(string a,string b)=>string.Equals(Path.GetFullPath(a).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar),Path.GetFullPath(b).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar),StringComparison.OrdinalIgnoreCase);
    public static async Task<PreparedUpdate> ReadAsync(string dir,string current,CancellationToken ct)
    {
        var manifestPath=Path.Combine(dir,"hyse-update.json");var sigPath=Path.Combine(dir,"hyse-update.sig");
        if(new FileInfo(manifestPath).Length>UpdateVerification.ManifestLimit||new FileInfo(sigPath).Length>1024)throw new IOException("Atualização inválida.");
        var manifest=UpdateVerification.Verify(await File.ReadAllBytesAsync(manifestPath,ct),await File.ReadAllBytesAsync(sigPath,ct),UpdateTrust.PublicKey);
        if(UpdateVerification.ParseVersion(manifest.Version)<=UpdateVerification.ParseVersion(current))throw new IOException("A atualização não é mais recente.");
        var update=new PreparedUpdate(manifest,dir);await UpdateVerification.VerifyInstallerAsync(update.InstallerPath,manifest,ct);return update;
    }
    public static void WritePlan(string directory,UpdatePlan plan)
    {
        string target=Path.Combine(directory,"apply.json");File.WriteAllText(target+".tmp",JsonSerializer.Serialize(plan));File.Move(target+".tmp",target,true);
    }
}
