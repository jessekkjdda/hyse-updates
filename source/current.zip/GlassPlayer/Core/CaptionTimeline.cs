using System.Globalization;
namespace GlassPlayer.Core;

public sealed record CaptionGlyph(string Text, long StartMs, int FadeMs)
{
    public double OpacityAt(long position) => FadeMs == 0 ? 1 : Math.Clamp((position - StartMs) / (double)FadeMs, 0, 1);
}
public static class CaptionTimeline
{
    public static List<CaptionGlyph> Build(string text, long start, long end)
    {
        // Segment graphemes, not UTF-16 chars: accents, emoji and surrogate pairs stay intact.
        var elements = new List<string>(); var enumerator = StringInfo.GetTextElementEnumerator(text);
        while (enumerator.MoveNext()) { elements.Add(enumerator.GetTextElement()); if (elements.Count > 320) return new() { new CaptionGlyph(text, start, 180) }; }
        long span = Math.Clamp(end - start, 180, 60000);
        long reveal = Math.Min((long)(span * .82), Math.Clamp(elements.Count * 65L, 500, 4500));
        int count = elements.Count(e => !string.IsNullOrWhiteSpace(e)); double step = reveal / (double)Math.Max(1, count);
        int fade = (int)Math.Min(Math.Clamp(step * 2.2, 75, 230),Math.Max(1,span-reveal)); int index = 0;
        return elements.Select(element => string.IsNullOrWhiteSpace(element) ? new CaptionGlyph(element, start, 0) : new CaptionGlyph(element, start + (long)(index++ * step), fade)).ToList();
    }
    public static List<CaptionGlyph> Accurate(LyricLine line)
    {
        if(line.Words is not{Count:>0})return new(){new CaptionGlyph(line.Text,line.TimeMs,1)};
        return line.Words.Select(word=>new CaptionGlyph(word.Text,word.StartMs,(int)Math.Clamp(word.EndMs-word.StartMs,1,40))).ToList();
    }
    public static int ActiveLine(IReadOnlyList<LyricLine> lines,long position,int offset=0)
    {
        int index=LyricsParser.FindLine(lines,position,offset);
        if(index>=0&&(string.IsNullOrWhiteSpace(lines[index].Text)||lines[index].EndMs is {} end&&position+Math.Clamp(offset,-10000,10000)>=end))return -1;
        return index;
    }
    public static long EndOfLine(IReadOnlyList<LyricLine> lines, int index, long trackDuration)
    {
        if (index < 0 || index >= lines.Count) return 0;
        if(lines[index].EndMs is {} explicitEnd)return index+1<lines.Count?Math.Min(explicitEnd,lines[index+1].TimeMs):explicitEnd;
        return index + 1 < lines.Count ? lines[index + 1].TimeMs : Math.Max(lines[index].TimeMs + 1000, trackDuration > lines[index].TimeMs ? trackDuration : lines[index].TimeMs + 4500);
    }
}
