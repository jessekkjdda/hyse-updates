using System.Globalization;
using System.IO;
using YamlDotNet.RepresentationModel;
namespace GlassPlayer.Core;

public static class LyricsfileReader
{
    static YamlNode? Get(YamlMappingNode map,string name)=>map.Children.TryGetValue(new YamlScalarNode(name),out var value)?value:null;
    static string? Text(YamlMappingNode map,string name)=>(Get(map,name) as YamlScalarNode)?.Value;
    static long? Time(YamlMappingNode map,string name)
    {
        if(Get(map,name)==null)return null;
        if(long.TryParse(Text(map,name),NumberStyles.Integer,CultureInfo.InvariantCulture,out var n)&&n>=0&&n<=24*60*60*1000)return n;
        throw new FormatException("Marcação de tempo inválida: "+name+".");
    }
    public static List<LyricLine> Parse(string yaml)
    {
        if(yaml.Length>1024*1024)throw new FormatException("O documento de letras excede 1 MB.");
        var stream=new YamlStream();stream.Load(new StringReader(yaml));
        if(stream.Documents.Count!=1||stream.Documents[0].RootNode is not YamlMappingNode root||Get(root,"lines") is not YamlSequenceNode sequence)return new();
        if(sequence.Children.Count>2000)throw new FormatException("A letra excede 2.000 linhas.");
        var lines=new List<LyricLine>();int wordCount=0;
        foreach(var child in sequence.Children)
        {
            if(child is not YamlMappingNode line)continue;
            var start=Time(line,"start_ms");if(start==null)continue;
            string text=Text(line,"text")??"";long? end=Time(line,"end_ms");
            var words=new List<LyricWord>();
            if(Get(line,"words") is YamlSequenceNode parts)
            {
                if(parts.Children.Count>500)throw new FormatException("Uma linha excede o limite de palavras.");
                var raw=parts.Children.OfType<YamlMappingNode>().ToList();
                for(int i=0;i<raw.Count;i++)
                {
                    long? wordStart=Time(raw[i],"start_ms");if(wordStart==null)continue;
                    long wordEnd=Time(raw[i],"end_ms")??(i+1<raw.Count?Time(raw[i+1],"start_ms"):null)??end??wordStart.Value+150;
                    if(wordStart<start||wordEnd<wordStart||end is {} limit&&wordEnd>limit||words.Count>0&&wordStart<words[^1].StartMs)throw new FormatException("Tempos de palavra inválidos.");
                    words.Add(new(wordStart.Value,wordEnd,Text(raw[i],"text")??""));
                    if(++wordCount>30000)throw new FormatException("A letra excede o limite de palavras.");
                }
                // Words must reproduce the line; otherwise prefer its reliable line marker.
                if(string.Concat(words.Select(w=>w.Text)).Trim()!=text.Trim())words.Clear();
            }
            if(end!=null&&end<start)throw new FormatException("Fim de linha anterior ao início.");
            lines.Add(new(start.Value,text,end,words.Count==0?null:words));
        }
        return lines.OrderBy(l=>l.TimeMs).GroupBy(l=>l.TimeMs).Select(g=>g.Count()==1?g.First():new LyricLine(g.Key,string.Join("\n",g.Select(l=>l.Text)),g.All(l=>l.EndMs.HasValue)?g.Max(l=>l.EndMs):null)).ToList();
    }
}
