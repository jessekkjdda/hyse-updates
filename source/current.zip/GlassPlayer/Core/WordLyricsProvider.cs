using System.IO;
using System.Net;
using System.Net.Http;
using System.Text.Json;
using System.Text.RegularExpressions;
namespace GlassPlayer.Core;
public sealed class WordLyricsProvider:IDisposable
{
    readonly HttpClient http;readonly bool owns;readonly RecentCache<LyricsDocument?> cache=new(80,TimeSpan.FromHours(12));readonly SemaphoreSlim serial=new(1,1);DateTime backoff;
    public WordLyricsProvider(HttpClient? client=null){owns=client==null;http=client??new HttpClient{Timeout=TimeSpan.FromSeconds(12)};http.DefaultRequestHeaders.UserAgent.ParseAdd("hyse/0.12.0");}
    public async Task<LyricsDocument?> GetAsync(Track track,CancellationToken ct)
    {
        if(track.Source!="Spotify"||!Regex.IsMatch(track.Id,"^[A-Za-z0-9]{22}$"))return null;if(cache.TryGet(track.Id,out var hit))return hit;
        await serial.WaitAsync(ct);try
        {
            if(cache.TryGet(track.Id,out hit))return hit;if(DateTime.UtcNow<backoff)return null;
            using var response=await http.GetAsync("https://api.amll.dev/v1/lyrics/get?spotifyId="+Uri.EscapeDataString(track.Id),HttpCompletionOption.ResponseHeadersRead,ct);
            if(response.StatusCode==HttpStatusCode.NotFound){cache.Set(track.Id,null);return null;}
            if(response.StatusCode==HttpStatusCode.TooManyRequests){backoff=DateTime.UtcNow.AddSeconds(Math.Clamp(response.Headers.RetryAfter?.Delta?.TotalSeconds??30,1,3600));return null;}
            response.EnsureSuccessStatusCode();if(response.Content.Headers.ContentLength>2*1024*1024)throw new FormatException("Resposta de letras maior que o limite.");
            await using var stream=await response.Content.ReadAsStreamAsync(ct);using var buffer=new MemoryStream();var bytes=new byte[8192];int read;while((read=await stream.ReadAsync(bytes,ct))>0){if(buffer.Length+read>2*1024*1024)throw new FormatException("Resposta de letras maior que o limite.");await buffer.WriteAsync(bytes.AsMemory(0,read),ct);}
            using var json=JsonDocument.Parse(buffer.ToArray());var root=json.RootElement;if(!root.TryGetProperty("data",out var data)||!data.TryGetProperty("spotifyIds",out var ids)||ids.ValueKind!=JsonValueKind.Array||!ids.EnumerateArray().Any(e=>e.ValueKind==JsonValueKind.String&&e.GetString()==track.Id))return null;
            string xml=CatalogReader.S(data,"lyrics");if(xml.Length==0||CatalogReader.S(data,"format")!="ttml")return null;var lines=TtmlReader.Parse(xml);if(!lines.Any(l=>l.Words is{Count:>1})||track.DurationMs>0&&lines.Any(l=>l.TimeMs>track.DurationMs+15000))return null;
            var result=new LyricsDocument(track.Title,track.Artist,lines,null,false,"AMLL TTML"){SpicyTtml=xml};cache.Set(track.Id,result);return result;
        }
        finally{serial.Release();}
    }
    public void Dispose(){if(owns)http.Dispose();}
}
