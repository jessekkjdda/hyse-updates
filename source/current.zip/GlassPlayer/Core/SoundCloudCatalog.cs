using System.IO;
using System.Net;
using System.Net.Http;
using System.Text.Json;
using System.Text.RegularExpressions;
namespace GlassPlayer.Core;

public sealed class SoundCloudCatalog : IDisposable
{
    readonly HttpClient http;readonly HttpClient linkHttp=new(new HttpClientHandler{AllowAutoRedirect=false}){Timeout=TimeSpan.FromSeconds(12)};readonly bool ownsHttp;readonly SemaphoreSlim idGate=new(1,1),searchGate=new(1,1);string? client;DateTime clientAt,nextSearch,backoff;
    public SoundCloudCatalog(HttpClient? http=null){ownsHttp=http==null;this.http=http??new HttpClient{Timeout=TimeSpan.FromSeconds(16)};this.http.DefaultRequestHeaders.UserAgent.ParseAdd("hyse/0.12.0");}
    public static string PublicUrl(string raw)
    {
        if(!Uri.TryCreate(raw.Trim(),UriKind.Absolute,out var u)||u.Scheme!="https"||!u.IsDefaultPort||u.UserInfo.Length>0||u.Host is not("soundcloud.com" or "www.soundcloud.com"))throw new ArgumentException("Use um link público HTTPS do SoundCloud.");
        if(!Regex.IsMatch(u.AbsolutePath,"^/[A-Za-z0-9_%.-]+(?:/[A-Za-z0-9_%.-]+){0,2}/?$"))throw new ArgumentException("Link SoundCloud inválido.");
        return "https://soundcloud.com"+u.AbsolutePath.TrimEnd('/');
    }
    async Task<string> InputUrlAsync(string input,CancellationToken ct)
    {
        if(!Uri.TryCreate(input.Trim(),UriKind.Absolute,out var uri)||uri.Scheme!="https"||!uri.IsDefaultPort||uri.UserInfo.Length>0)throw new ArgumentException("Use um link HTTPS do SoundCloud.");
        if(uri.Host=="m.soundcloud.com")return PublicUrl("https://soundcloud.com"+uri.AbsolutePath);
        for(int i=0;i<6;i++)
        {
            if(uri.Host is "soundcloud.com" or "www.soundcloud.com")return PublicUrl(uri.AbsoluteUri);
            if(uri.Host is not("on.soundcloud.com" or "soundcloud.app.goo.gl"))throw new ArgumentException("O redirecionamento saiu do SoundCloud.");
            using var response=await linkHttp.GetAsync(uri,HttpCompletionOption.ResponseHeadersRead,ct);if((int)response.StatusCode is <300 or >=400||response.Headers.Location==null)throw new FormatException("O link curto SoundCloud não pôde ser resolvido.");
            uri=new Uri(uri,response.Headers.Location);if(uri.Scheme!="https"||!uri.IsDefaultPort||uri.UserInfo.Length>0)throw new FormatException("Redirecionamento SoundCloud inválido.");
        }
        throw new FormatException("O link curto SoundCloud redirecionou muitas vezes.");
    }
    async Task<string> TextAsync(string url,int maximum,CancellationToken ct)
    {
        using var response=await http.GetAsync(url,HttpCompletionOption.ResponseHeadersRead,ct);
        if(response.StatusCode==HttpStatusCode.TooManyRequests){backoff=DateTime.UtcNow.AddSeconds(Math.Clamp(response.Headers.RetryAfter?.Delta?.TotalSeconds??20,1,3600));throw new HttpRequestException("O SoundCloud pediu uma pausa. Aguarde antes de tentar novamente.",null,response.StatusCode);}
        response.EnsureSuccessStatusCode();if(response.Content.Headers.ContentLength>maximum)throw new FormatException("Resposta SoundCloud maior que o limite.");
        await using var stream=await response.Content.ReadAsStreamAsync(ct);using var copy=new MemoryStream();var buffer=new byte[8192];int read;while((read=await stream.ReadAsync(buffer,ct))>0){if(copy.Length+read>maximum)throw new FormatException("Resposta SoundCloud maior que o limite.");await copy.WriteAsync(buffer.AsMemory(0,read),ct);}return System.Text.Encoding.UTF8.GetString(copy.ToArray());
    }
    async Task<string> ClientAsync(CancellationToken ct)
    {
        await idGate.WaitAsync(ct);try
        {
            if(client!=null&&DateTime.UtcNow-clientAt<TimeSpan.FromMinutes(30))return client;
            var html=await TextAsync("https://soundcloud.com",4*1024*1024,ct);
            var scripts=Regex.Matches(html,"<script[^>]+src=[\"'](https://a-v2\\.sndcdn\\.com/assets/[^\"'?#]+\\.js)[\"']").Select(m=>m.Groups[1].Value).Distinct().Reverse().Take(7);
            foreach(var script in scripts)
            {
                var js=await TextAsync(script,6*1024*1024,ct);var match=Regex.Match(js,"client_id\\s*[:=]\\s*[\"']([A-Za-z0-9]{32})[\"']");
                if(match.Success){clientAt=DateTime.UtcNow;return client=match.Groups[1].Value;}
            }
            throw new FormatException("A busca pública do SoundCloud mudou. Tente novamente mais tarde.");
        }finally{idGate.Release();}
    }
    async Task<JsonDocument> ApiAsync(string path,CancellationToken ct)
    {
        if(DateTime.UtcNow<backoff)throw new HttpRequestException("Aguarde o intervalo solicitado pelo SoundCloud.",null,HttpStatusCode.TooManyRequests);
        if(!path.StartsWith('/')||path.StartsWith("//")||path.Contains('#'))throw new ArgumentException("Endereço SoundCloud inválido.");
        for(int attempt=0;attempt<2;attempt++)
        {
            string key=await ClientAsync(ct);
            try{var text=await TextAsync("https://api-v2.soundcloud.com"+path+(path.Contains('?')?"&":"?")+"client_id="+Uri.EscapeDataString(key),8*1024*1024,ct);return JsonDocument.Parse(text);}
            catch(HttpRequestException ex)when(attempt==0&&ex.StatusCode==HttpStatusCode.Unauthorized){await idGate.WaitAsync(ct);try{if(client==key){client=null;clientAt=default;}}finally{idGate.Release();}}
        }
        throw new HttpRequestException("O catálogo público do SoundCloud não autorizou a consulta.");
    }
    static string Id(JsonElement e){if(!e.TryGetProperty("id",out var id))return "";var value=id.ValueKind==JsonValueKind.String?id.GetString()??"":id.GetRawText();return Regex.IsMatch(value,"^[0-9]{1,20}$")?value:"";}
    static string? Art(JsonElement e)
    {
        string art=CatalogReader.S(e,"artwork_url");if(art.Length==0&&e.TryGetProperty("user",out var user))art=CatalogReader.S(user,"avatar_url");
        return art.Length==0?null:art.Replace("-large.","-t500x500.");
    }
    public static Track Track(JsonElement e)
    {
        string id=Id(e),title=CatalogReader.S(e,"title"),url=CatalogReader.S(e,"permalink_url");if(id.Length==0||title.Length==0)throw new FormatException("Música SoundCloud sem identificação.");
        string artist=e.TryGetProperty("publisher_metadata",out var publisher)?CatalogReader.S(publisher,"artist"):"";
        if(artist.Length==0&&e.TryGetProperty("user",out var user))artist=CatalogReader.S(user,"username");
        bool streamable=!e.TryGetProperty("streamable",out var stream)||stream.ValueKind!=JsonValueKind.False;
        string policy=CatalogReader.S(e,"policy");bool available=streamable&&policy is not("SNIP" or "BLOCK" or "BLOCKED");
        string canonical=PublicUrl(url);return new("sc:"+id,title,artist,Art(e),null,"SoundCloud",canonical,CatalogReader.N(e,"duration"),Available:available);
    }
    public static CatalogEntity Entity(JsonElement e)
    {
        string id=Id(e),kind=CatalogReader.S(e,"kind"),name=kind=="user"?CatalogReader.S(e,"username"):CatalogReader.S(e,"title");if(id.Length==0||name.Length==0)throw new FormatException("Item SoundCloud sem identificação.");
        string type=kind=="user"?"artist":e.TryGetProperty("is_album",out var album)&&album.ValueKind==JsonValueKind.True||CatalogReader.S(e,"playlist_type")=="album"?"album":"playlist";
        string subtitle=e.TryGetProperty("user",out var user)?CatalogReader.S(user,"username"):"Artista";
        string? art=kind=="user"?CatalogReader.S(e,"avatar_url"):Art(e);
        return new("sc:"+id,name,type,"SoundCloud",art?.Replace("-large.","-t500x500."),subtitle,PublicUrl(CatalogReader.S(e,"permalink_url")),CatalogReader.N(e,"track_count"));
    }
    public static CatalogPage ParseSearch(string text)
    {
        using var doc=JsonDocument.Parse(text);var root=doc.RootElement;var tracks=new List<Track>();var entities=new List<CatalogEntity>();
        if(!root.TryGetProperty("collection",out var rows)||rows.ValueKind!=JsonValueKind.Array)throw new FormatException("O SoundCloud não retornou os resultados da pesquisa.");
        foreach(var e in rows.EnumerateArray())try{if(CatalogReader.S(e,"kind")=="track")tracks.Add(Track(e));else if(CatalogReader.S(e,"kind") is "user" or "playlist")entities.Add(Entity(e));}catch(Exception ex)when(ex is FormatException or ArgumentException){}
        string? next=null;string href=CatalogReader.S(root,"next_href");if(href.Length>0)
        {
            if(!Uri.TryCreate(href,UriKind.Absolute,out var u)||u.Scheme!="https"||u.Host!="api-v2.soundcloud.com"||!u.IsDefaultPort||u.UserInfo.Length>0||u.AbsolutePath is not("/search" or "/search/tracks"))throw new FormatException("Paginação SoundCloud inesperada.");
            var match=Regex.Match(u.Query,"(?:[?&])offset=([^&]+)");if(match.Success)next=Uri.UnescapeDataString(match.Groups[1].Value);
        }
        return new(tracks.DistinctBy(t=>t.Id).ToList(),entities.DistinctBy(e=>(e.Kind,e.Id)).ToList(),NextCursor:next);
    }
    public async Task<CatalogPage> SearchAsync(string query,string offset,CancellationToken ct)
    {
        query=query.Trim();if(query.Length is <1 or >300||offset.Length>512)throw new ArgumentException("Pesquisa inválida.");
        await searchGate.WaitAsync(ct);try{var delay=nextSearch-DateTime.UtcNow;if(delay>TimeSpan.Zero)await Task.Delay(delay,ct);nextSearch=DateTime.UtcNow.AddMilliseconds(350);
        using var doc=await ApiAsync("/search?q="+Uri.EscapeDataString(query)+"&limit=20&offset="+Uri.EscapeDataString(offset),ct);return ParseSearch(doc.RootElement.GetRawText());}finally{searchGate.Release();}
    }
    public async Task<IReadOnlyList<Track>> RelatedAsync(Track seed,CancellationToken ct)
    {
        if(seed.Source!="SoundCloud"||!Regex.IsMatch(seed.Id,@"^sc:[0-9]{1,20}\z"))throw new ArgumentException("Faixa SoundCloud inválida.");
        using var doc=await ApiAsync("/tracks/"+seed.Id[3..]+"/related?limit=30&linked_partitioning=1",ct);
        return ParseRelated(doc.RootElement.GetRawText());
    }
    public static IReadOnlyList<Track> ParseRelated(string text)
    {
        using var doc=JsonDocument.Parse(text);var root=doc.RootElement;
        var rows=root.ValueKind==JsonValueKind.Array?root:root.GetProperty("collection");var tracks=new List<Track>();
        foreach(var item in rows.EnumerateArray())try{tracks.Add(Track(item));}catch(Exception ex)when(ex is FormatException or ArgumentException){}
        return tracks.DistinctBy(t=>t.Id).Take(30).ToArray();
    }
    public async Task<(CatalogEntity? Entity,List<Track> Tracks)> ResolveAsync(string url,CancellationToken ct)
    {
        url=await InputUrlAsync(url,ct);using var doc=await ApiAsync("/resolve?url="+Uri.EscapeDataString(url),ct);var root=doc.RootElement;string kind=CatalogReader.S(root,"kind");
        if(kind=="track")return(null,new(){Track(root)});
        var entity=Entity(root);if(kind=="user"){using var page=await ApiAsync("/users/"+Id(root)+"/tracks?limit=50&linked_partitioning=1",ct);var list=new List<Track>();foreach(var item in page.RootElement.GetProperty("collection").EnumerateArray())try{list.Add(Track(item));}catch(Exception ex)when(ex is FormatException or ArgumentException){}return(entity,list);}
        if(kind!="playlist"||!root.TryGetProperty("tracks",out var rows)||rows.ValueKind!=JsonValueKind.Array)throw new FormatException("O link não contém uma lista pública de músicas.");
        int expected=CatalogReader.N(root,"track_count");if(expected>10000||rows.GetArrayLength()!=expected)throw new FormatException("O SoundCloud expôs uma lista incompleta. Atualize para tentar novamente.");
        var raw=rows.EnumerateArray().Select(e=>e.Clone()).ToList();var hydrated=new Dictionary<string,Track>();var missing=raw.Where(e=>CatalogReader.S(e,"title").Length==0).Select(Id).Where(id=>id.Length>0).Distinct().ToList();
        foreach(var batch in missing.Chunk(40))
        {
            using var part=await ApiAsync("/tracks?ids="+string.Join(',',batch),ct);if(part.RootElement.ValueKind!=JsonValueKind.Array)throw new FormatException("O SoundCloud não retornou todas as músicas.");
            foreach(var item in part.RootElement.EnumerateArray())try{var t=Track(item);hydrated[t.Id[3..]]=t;}catch(Exception ex)when(ex is FormatException or ArgumentException){}
        }
        var tracks=new List<Track>();foreach(var item in raw)
        {
            try{tracks.Add(CatalogReader.S(item,"title").Length>0?Track(item):hydrated[Id(item)]);}
            catch(Exception ex)when(ex is FormatException or ArgumentException or KeyNotFoundException){tracks.Add(new("sc-unavailable:"+tracks.Count,"Faixa indisponível","SoundCloud",null,null,"SoundCloud",null,Available:false));}
        }
        return(entity,tracks);
    }
    public void Dispose(){if(ownsHttp)http.Dispose();linkHttp.Dispose();idGate.Dispose();searchGate.Dispose();}
}
