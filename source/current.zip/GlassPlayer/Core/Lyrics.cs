using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
namespace GlassPlayer.Core;

public sealed record LyricWord(long StartMs,long EndMs,string Text);
public sealed record LyricLine(long TimeMs, string Text,long? EndMs=null,List<LyricWord>? Words=null);
public sealed record LyricsDocument(string Title, string Artist, List<LyricLine> Lines, string? PlainText, bool Instrumental, string Source)
{
    // Preserve native TTML for the local, original Spicy parser in the host adapter.
    // Older cached documents without this field continue through the existing path.
    [System.Text.Json.Serialization.JsonIgnore(Condition=System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public string? SpicyTtml { get; init; }
    public bool Synced => Lines.Count > 0;
    public bool WordSynced=>Lines.Any(l=>l.Words is{Count:>0});
}

public static partial class LyricsParser
{
    [GeneratedRegex(@"\[(\d{1,3}):([0-5]\d)(?:[.:](\d{1,3}))?\]")]
    private static partial Regex Timestamp();
    [GeneratedRegex(@"\[offset:([+-]?\d+)\]", RegexOptions.IgnoreCase)]
    private static partial Regex Offset();
    [GeneratedRegex(@"<(\d{1,3}):([0-5]\d)(?:[.:](\d{1,3}))?>")]
    private static partial Regex WordTimestamp();
    public static List<LyricLine> Parse(string text)
    {
        if (text.Length > 1024 * 1024) throw new FormatException("O arquivo de letras excede 1 MB.");
        long offset = 0; var match = Offset().Match(text);
        if (match.Success && long.TryParse(match.Groups[1].Value, out var parsed)) offset = Math.Clamp(parsed, -60000, 60000);
        var lines = new List<LyricLine>();
        foreach (var row in text.Replace("\r", "").Split('\n'))
        {
            var timestamps = Timestamp().Matches(row); if (timestamps.Count == 0) continue;
            var raw = Timestamp().Replace(row, "").Trim();
            var marks=WordTimestamp().Matches(raw);
            var content = WordTimestamp().Replace(raw, "").Trim();
            foreach (Match stamp in timestamps)
            {
                var fraction = stamp.Groups[3].Value; var millis = fraction.Length == 0 ? 0 : int.Parse(fraction.PadRight(3, '0'), CultureInfo.InvariantCulture);
                long at = (int.Parse(stamp.Groups[1].Value, CultureInfo.InvariantCulture) * 60L + int.Parse(stamp.Groups[2].Value, CultureInfo.InvariantCulture)) * 1000 + millis;
                List<LyricWord>? words=null;long? end=null;
                if(marks.Count>0)
                {
                    long WordTime(Match m){var f=m.Groups[3].Value;return Math.Max(0,(long.Parse(m.Groups[1].Value)*60+long.Parse(m.Groups[2].Value))*1000+(f.Length==0?0:int.Parse(f.PadRight(3,'0')))-offset);}
                    var parsedWords=new List<LyricWord>();long previous=Math.Max(0,at-offset);
                    bool valid=raw[..marks[0].Index].Trim().Length==0;
                    for(int wi=0;wi<marks.Count;wi++)
                    {
                        var marker=marks[wi];long start=WordTime(marker);int after=marker.Index+marker.Length;
                        string word=raw[after..(wi+1<marks.Count?marks[wi+1].Index:raw.Length)];
                        long finish=wi+1<marks.Count?WordTime(marks[wi+1]):start;
                        if(start<previous||finish<start)valid=false;previous=start;
                        if(word.Length>0)parsedWords.Add(new(start,finish,word));else if(wi==marks.Count-1)end=start;
                    }
                    if(valid&&parsedWords.Count>0&&string.Concat(parsedWords.Select(w=>w.Text)).Trim()==content)words=parsedWords;
                    else end=null;
                }
                lines.Add(new(Math.Max(0, at - offset), content,end,words));
                if (lines.Count > 2000) throw new FormatException("O limite é de 2.000 linhas sincronizadas.");
            }
        }
        // Group duplicate timestamps so duets keep both voices without skipping a line.
        return lines.OrderBy(l => l.TimeMs).GroupBy(l => l.TimeMs).Select(g => g.Count()==1?g.First():new LyricLine(g.Key, string.Join("\n", g.Select(l => l.Text).Distinct()))).ToList();
    }
    public static int FindLine(IReadOnlyList<LyricLine> lines, long positionMs, int offsetMs = 0)
    {
        long target = positionMs + Math.Clamp(offsetMs, -10000, 10000); int lo = 0, hi = lines.Count - 1, result = -1;
        while (lo <= hi) { int mid = lo + (hi - lo) / 2; if (lines[mid].TimeMs <= target) { result = mid; lo = mid + 1; } else hi = mid - 1; }
        return result;
    }
    public static string Normalize(string text)
    {
        var output = new StringBuilder();
        foreach (char c in text.Normalize(NormalizationForm.FormD)) if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) output.Append(char.IsLetterOrDigit(c) ? char.ToLowerInvariant(c) : ' ');
        return string.Join(' ', output.ToString().Split(' ', StringSplitOptions.RemoveEmptyEntries));
    }
    public static string LookupTitle(string title) => Regex.Replace(title, @"\s*[\[(](?:official\s*(?:audio|video|music video|lyric video)|lyrics?|audio)[\])]", "", RegexOptions.IgnoreCase).Trim();
    public static bool Compatible(string title, string artist, int durationMs, string candidateTitle, string candidateArtist, double duration)
    {
        if (Normalize(LookupTitle(title)) != Normalize(LookupTitle(candidateTitle))) return false;
        var requested = Normalize(artist.Split(new[] { ",", ";", " feat. " }, StringSplitOptions.None)[0]); var actual = Normalize(candidateArtist);
        if (requested.Length == 0 || !(actual == requested || actual.StartsWith(requested + " ", StringComparison.Ordinal))) return false;
        return durationMs <= 0 || duration <= 0 || Math.Abs(duration - durationMs / 1000d) <= 1.5;
    }
}
