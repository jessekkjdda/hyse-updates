using System.Diagnostics;
using System.IO;

namespace GlassPlayer.Core;

public sealed class DiscordPresence:IDisposable
{
    readonly CancellationTokenSource lifetime=new();readonly object sync=new();readonly Task worker;
    readonly Func<CancellationToken,Task<Stream>> connect;readonly TimeSpan interval,retry;
    string? desired;bool enabled,disposed;volatile DiscordIpc? connection;
    string status="Aguardando reprodução";
    public string Status{get{lock(sync)return enabled?Volatile.Read(ref status):"Desativado";}}
    public DiscordPresence(Func<CancellationToken,Task<Stream>>? connect=null,TimeSpan? interval=null,TimeSpan? retry=null)
    {
        this.connect=connect??DiscordIpc.ConnectDesktopAsync;this.interval=interval??TimeSpan.FromMilliseconds(4500);this.retry=retry??TimeSpan.FromSeconds(5);
        worker=Task.Run(RunAsync);
    }
    public void Update(bool enabled,string? activity){lock(sync){this.enabled=enabled;desired=activity;}if(!enabled)connection?.Abort();}
    async Task RunAsync()
    {
        var time=Stopwatch.StartNew();TimeSpan next=TimeSpan.Zero;string? sent=null;bool hasSent=false;
        try
        {
            while(!lifetime.IsCancellationRequested)
            {
                bool active;string? value;lock(sync){active=enabled;value=desired;}
                if(!active)
                {
                    if(connection!=null){await connection.DisposeAsync();connection=null;}hasSent=false;Volatile.Write(ref status,"Desativado");
                }
                else if(connection==null&&value==null)Volatile.Write(ref status,"Aguardando reprodução");
                else
                {
                    try
                    {
                        if(connection==null){Volatile.Write(ref status,"Conectando…");connection=await DiscordIpc.OpenAsync(connect,lifetime.Token);hasSent=false;}
                        if(connection.Disconnected)throw new IOException("Discord disconnected.");
                        // Copy again after a potentially slow handshake; never publish its old song.
                        lock(sync){active=enabled;value=desired;}
                        if(active&&(!hasSent||value!=sent)&&time.Elapsed>=next)
                        {
                            next=time.Elapsed+interval;await connection.SetActivityAsync(value,lifetime.Token);sent=value;hasSent=true;
                        }
                        Volatile.Write(ref status,"Conectado");
                    }
                    catch(Exception ex)when(ex is IOException or TimeoutException or InvalidDataException or PlatformNotSupportedException or UnauthorizedAccessException)
                    {
                        if(connection!=null){await connection.DisposeAsync();connection=null;}hasSent=false;Volatile.Write(ref status,"Aguardando Discord");
                        await Task.Delay(retry,lifetime.Token);
                    }
                }
                await Task.Delay(250,lifetime.Token);
            }
        }
        catch(OperationCanceledException)when(lifetime.IsCancellationRequested){}
        finally{if(connection!=null){await connection.DisposeAsync();connection=null;}}
    }
    public void Dispose(){if(disposed)return;disposed=true;lifetime.Cancel();connection?.Abort();_ = worker.ContinueWith(_=>lifetime.Dispose(),TaskScheduler.Default);}
    public Task Completion=>worker;
}
