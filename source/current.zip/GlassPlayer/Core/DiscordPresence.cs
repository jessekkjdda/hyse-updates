using System.Diagnostics;
using System.IO;
using System.Text.Json;
namespace GlassPlayer.Core;
public sealed class DiscordPresence:IDisposable
{
    readonly CancellationTokenSource lifetime=new();readonly object sync=new();readonly Task worker;
    readonly Func<CancellationToken,Task<Stream>> connect;readonly TimeSpan interval,retry,health,refresh,healthTimeout;
    string? desired;bool enabled,disposed;volatile DiscordIpc? connection;int reconnect;
    string status="Aguardando reprodução";
    public string Status{get{lock(sync)return enabled?Volatile.Read(ref status):"Desativado";}}
    public DiscordPresence(Func<CancellationToken,Task<Stream>>? connect=null,TimeSpan? interval=null,TimeSpan? retry=null,TimeSpan? health=null,TimeSpan? refresh=null,TimeSpan? healthTimeout=null)
    {
        this.connect=connect??DiscordIpc.ConnectDesktopAsync;this.interval=interval??TimeSpan.FromMilliseconds(4500);this.retry=retry??TimeSpan.FromSeconds(5);
        this.healthTimeout=healthTimeout??TimeSpan.FromSeconds(8);this.health=health??TimeSpan.FromSeconds(15);this.refresh=refresh??TimeSpan.FromSeconds(60);worker=Task.Run(RunAsync);
    }
    public void Update(bool enabled,string? activity){lock(sync){this.enabled=enabled;desired=activity;}if(!enabled)connection?.Abort();}
    public void Reconnect(){Interlocked.Exchange(ref reconnect,1);connection?.Abort();}
    async Task RunAsync()
    {
        var time=Stopwatch.StartNew();TimeSpan next=TimeSpan.Zero,lastHealth=TimeSpan.Zero,lastSent=TimeSpan.Zero;string? sent=null;bool hasSent=false;
        try
        {
            while(!lifetime.IsCancellationRequested)
            {
                bool active;string? value;lock(sync){active=enabled;value=desired;}
                try
                {
                    if(Interlocked.Exchange(ref reconnect,0)!=0&&connection!=null){await connection.DisposeAsync();connection=null;hasSent=false;}
                    if(!active)
                    {
                        if(connection!=null){await connection.DisposeAsync();connection=null;}hasSent=false;Volatile.Write(ref status,"Desativado");
                    }
                    else if(connection==null&&value==null)Volatile.Write(ref status,"Aguardando reprodução");
                    else
                    {
                        if(connection==null){Volatile.Write(ref status,"Conectando…");connection=await DiscordIpc.OpenAsync(connect,lifetime.Token);hasSent=false;lastHealth=time.Elapsed;}
                        if(connection.Disconnected)throw new IOException("Discord disconnected.");
                        // Liveness checks do not consume activity update slots.
                        if(time.Elapsed-lastHealth>=health){await connection.PingAsync(lifetime.Token,healthTimeout);lastHealth=time.Elapsed;}
                        lock(sync){active=enabled;value=desired;}
                        if(active&&(!hasSent||value!=sent||value!=null&&time.Elapsed-lastSent>=refresh)&&time.Elapsed>=next)
                        {
                            next=time.Elapsed+interval;await connection.SetActivityAsync(value,lifetime.Token);sent=value;hasSent=true;lastSent=time.Elapsed;
                        }
                        if(hasSent)Volatile.Write(ref status,"Conectado");
                    }
                }
                catch(Exception ex)when(!lifetime.IsCancellationRequested&&ex is IOException or TimeoutException or InvalidDataException or PlatformNotSupportedException or UnauthorizedAccessException or ObjectDisposedException or OperationCanceledException or InvalidOperationException or JsonException)
                {
                    if(connection!=null){await connection.DisposeAsync();connection=null;}hasSent=false;Volatile.Write(ref status,"Aguardando Discord");await Task.Delay(retry,lifetime.Token);
                }
                await Task.Delay(250,lifetime.Token);
            }
        }
        catch(OperationCanceledException)when(lifetime.IsCancellationRequested){}
        finally{if(connection!=null){await connection.DisposeAsync();connection=null;}}
    }
    public void Dispose(){if(disposed)return;disposed=true;lifetime.Cancel();connection?.Abort();_ = worker.ContinueWith(_=>lifetime.Dispose(),TaskScheduler.Default);}
    public Task Completion=>worker;
}
