using System.Diagnostics;
using System.IO;
using System.Text.Json;
namespace GlassPlayer.Core;
public sealed record DiscordConnectionState(string Status,string Phase,bool Connected,string? Error,int? Code,int Compatibility,string? Endpoint,int Attempts);
public sealed class DiscordPresence:IDisposable
{
    readonly CancellationTokenSource lifetime=new();readonly object sync=new();readonly Task worker;
    readonly Func<CancellationToken,Task<DiscordIpc>> open;readonly TimeSpan interval,retry,refresh,activityTimeout;
    CancellationTokenSource? openingWork;string? desired;bool enabled,disposed;volatile DiscordIpc? connection;int reconnect;
    DiscordConnectionState state=new("Aguardando Discord","idle",false,null,null,0,null,0);
    public event Action? Changed;
    public DiscordConnectionState State{get{lock(sync)return enabled?state:state with{Status="Desativado",Connected=false};}}
    public string Status=>State.Status;
    public DiscordPresence(Func<CancellationToken,Task<Stream>>? connect=null,TimeSpan? interval=null,TimeSpan? retry=null,TimeSpan? refresh=null,TimeSpan? activityTimeout=null)
    {
        open=connect==null?DiscordIpc.OpenDesktopAsync:ct=>DiscordIpc.OpenAsync(connect,ct);
        this.activityTimeout=activityTimeout??TimeSpan.FromSeconds(8);this.interval=interval??TimeSpan.FromMilliseconds(4500);this.retry=retry??TimeSpan.FromSeconds(5);this.refresh=refresh??TimeSpan.FromSeconds(30);worker=Task.Run(RunAsync);
    }
    void Publish(string status,string phase,bool connected,string? error=null,int? code=null,int compatibility=0)
    {
        bool changed;lock(sync){var next=state with{Status=status,Phase=phase,Connected=connected,Error=error,Code=code,Compatibility=compatibility,Endpoint=connection?.Endpoint};changed=next!=state;state=next;}
        if(changed)try{Changed?.Invoke();}catch{}
    }
    public void Update(bool enabled,string? activity){lock(sync){this.enabled=enabled;desired=activity;}if(!enabled){CancelOpening();connection?.Abort();}}
    void CancelOpening(){try{Volatile.Read(ref openingWork)?.Cancel();}catch(ObjectDisposedException){}}
    public void Reconnect(){Interlocked.Exchange(ref reconnect,1);CancelOpening();connection?.Abort();}
    async Task RunAsync()
    {
        var time=Stopwatch.StartNew();TimeSpan next=TimeSpan.Zero,lastSent=TimeSpan.Zero;string? sent=null;bool hasSent=false;int compatibility=0;
        try
        {
            while(!lifetime.IsCancellationRequested)
            {
                bool active;string? value;lock(sync){active=enabled;value=desired;}
                try
                {
                    if(Interlocked.Exchange(ref reconnect,0)!=0&&connection!=null){await connection.DisposeAsync();connection=null;hasSent=false;compatibility=0;}
                    if(!active)
                    {
                        if(connection!=null){await connection.DisposeAsync();connection=null;}hasSent=false;compatibility=0;Publish("Desativado","disabled",false);
                    }
                    else
                    {
                        if(connection==null)
                        {
                            lock(sync)state=state with{Attempts=state.Attempts+1};
                            var previous=State;Publish("Conectando…","handshake",false,previous.Error,previous.Code);
                            using(var opening=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token))
                            {
                                Volatile.Write(ref openingWork,opening);
                                try{connection=await open(opening.Token);}finally{Interlocked.CompareExchange(ref openingWork,null,opening);}
                            }
                            hasSent=false;compatibility=0;Publish("Conectado","ready",true);
                        }
                        if(connection.Disconnected)throw connection.Failure??new IOException("Discord IPC disconnected.");
                        lock(sync){active=enabled;value=desired;}
                        if(active&&(!hasSent||value!=sent||value!=null&&time.Elapsed-lastSent>=refresh)&&time.Elapsed>=next)
                        {
                            next=time.Elapsed+interval;
                            try
                            {
                                await connection.SetActivityAsync(DiscordCompatibility.Apply(value,compatibility),lifetime.Token,activityTimeout);
                                sent=value;hasSent=true;lastSent=time.Elapsed;Publish(compatibility>0?"Conectado · modo compatível":"Conectado","ready",true,compatibility:compatibility);
                            }
                            catch(DiscordRpcError ex)when(!ex.Closed&&ex.Phase=="activity")
                            {
                                if(ex.Code==4000&&compatibility<2){compatibility++;hasSent=false;}
                                else{sent=value;hasSent=true;lastSent=time.Elapsed;}
                                Publish("Conectado · atividade recusada","activity",true,ex.Message,ex.Code,compatibility);
                            }
                        }
                    }
                }
                catch(Exception ex)when(!lifetime.IsCancellationRequested&&ex is IOException or TimeoutException or InvalidDataException or PlatformNotSupportedException or UnauthorizedAccessException or ObjectDisposedException or OperationCanceledException or InvalidOperationException or JsonException)
                {
                    if(connection!=null){await connection.DisposeAsync();connection=null;}hasSent=false;
                    lock(sync)active=enabled;if(!active||Volatile.Read(ref reconnect)!=0)continue;
                    var rpc=ex as DiscordRpcError;
                    string message=rpc?.Message??(ex is UnauthorizedAccessException?"Acesso negado à conexão do Discord.":ex is TimeoutException?"O Discord não respondeu dentro do prazo.":"Não foi possível abrir a conexão com o Discord do Windows.");
                    Publish(rpc!=null?"Conexão recusada pelo Discord":"Aguardando Discord",rpc?.Phase??"connection",false,message,rpc?.Code);
                    await Task.Delay(rpc is{Closed:true,Code:4002}&&retry<TimeSpan.FromSeconds(20)?TimeSpan.FromSeconds(20):retry,lifetime.Token);
                }
                await Task.Delay(250,lifetime.Token);
            }
        }
        catch(OperationCanceledException)when(lifetime.IsCancellationRequested){}
        finally{if(connection!=null){await connection.DisposeAsync();connection=null;}}
    }
    public void Dispose(){if(disposed)return;disposed=true;lifetime.Cancel();CancelOpening();connection?.Abort();_ = worker.ContinueWith(_=>lifetime.Dispose(),TaskScheduler.Default);}
    public Task Completion=>worker;
}
