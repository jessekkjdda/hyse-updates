using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
namespace GlassPlayer.Core;

public sealed class SpotifyApiTransport(HttpClient http,Func<CancellationToken,Task<string>> token,Action invalidate,TimeSpan? retryDelay=null)
{
    DateTime backoffUntil;
    public async Task<HttpResponseMessage> SendAsync(HttpMethod method,string path,object? body,CancellationToken ct)
    {
        if(DateTime.UtcNow<backoffUntil)throw new HttpRequestException($"Limite do Spotify. Aguarde {Math.Ceiling((backoffUntil-DateTime.UtcNow).TotalSeconds)}s.",null,HttpStatusCode.TooManyRequests);
        if(!path.StartsWith('/')||path.StartsWith("//")||path.Contains('#'))throw new ArgumentException("Caminho Spotify inválido.");
        int authRetries=0,readRetries=0;
        while(true)
        {
            ct.ThrowIfCancellationRequested();
            using var request=new HttpRequestMessage(method,"https://api.spotify.com/v1"+path){Version=HttpVersion.Version20,VersionPolicy=HttpVersionPolicy.RequestVersionOrLower};
            request.Headers.Authorization=new AuthenticationHeaderValue("Bearer",await token(ct));
            if(method!=HttpMethod.Get)request.Content=body==null?new StringContent(""):new StringContent(JsonSerializer.Serialize(body),Encoding.UTF8,"application/json");
            HttpResponseMessage response;
            try{response=await http.SendAsync(request,ct);}
            catch(OperationCanceledException) when(!ct.IsCancellationRequested)
            {
                if(method==HttpMethod.Get&&readRetries++==0){await Task.Delay(retryDelay??TimeSpan.FromMilliseconds(350),ct);continue;}
                throw new TimeoutException("O Spotify demorou para responder. Tente novamente.");
            }
            if(response.StatusCode==HttpStatusCode.Unauthorized&&authRetries++==0){response.Dispose();invalidate();continue;}
            if(method==HttpMethod.Get&&(int)response.StatusCode>=500&&readRetries++==0){response.Dispose();await Task.Delay(retryDelay??TimeSpan.FromMilliseconds(350),ct);continue;}
            if((int)response.StatusCode==429)
            {
                int seconds=(int)Math.Clamp(response.Headers.RetryAfter?.Delta?.TotalSeconds??(response.Headers.RetryAfter?.Date-DateTimeOffset.UtcNow)?.TotalSeconds??15,1,3600);backoffUntil=DateTime.UtcNow.AddSeconds(seconds);response.Dispose();
                throw new HttpRequestException($"Limite do Spotify. Aguarde {seconds}s antes de repetir.",null,HttpStatusCode.TooManyRequests);
            }
            return response;
        }
    }
}
