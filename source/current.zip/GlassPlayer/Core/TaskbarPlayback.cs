namespace GlassPlayer.Core;

public sealed record TaskbarPlayback(string Description,string ToggleLabel,bool Playing,bool CanToggle,bool CanPrevious,bool CanNext)
{
    public static TaskbarPlayback Create(Track? track,bool playing,bool canPrevious,bool canNext,bool busy=false)
    {
        bool available=track is{Available:true}&&MediaIdentity.Supported(track);
        return new(available?$"{track!.Title} · {track.Artist}":"hyse",playing?"Pausar":"Reproduzir",playing,available&&!busy,available&&canPrevious&&!busy,available&&canNext&&!busy);
    }
}
