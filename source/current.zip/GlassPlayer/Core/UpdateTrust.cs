namespace GlassPlayer.Core;

public static class UpdateTrust
{
    public const string Repository="https://github.com/jessekkjdda/hyse-updates";
    public const string Feed=Repository+"/releases/latest/download/hyse-update.json";
    public const string FeedSignature=Repository+"/releases/latest/download/hyse-update.sig";
    public const string PublicKey="""
-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAtk/ZQFQEI0hS7p6On54c
ZPYHSR/l0/4g0LpF10ZRHWDwok004uQeWCW0esbvRbeCW30BdUjCihsN4xy/fGx9
S5iVOMezvvF4t/BhmQ7fVqWbToHf8VKt+//SF2odnxxkpmbcAwVlNmOxX77i6une
mMMcF00Y393YusruPN++YMnaOfeWsgqp3TSgzDaXKE6PPtYHlMEMd0CBJhxF9qat
xG1UHiQQaDZ2Tz8mWgPuN0NOJUJufPryk0sgJ7NE7BGCfnZW5eu3oE8cKe6lQ+Ez
WaltY+1zDVxB7EgT+V8qPBSvKTVBaJr56EuSsZmR/aGb4K/rs/bpTQe24a5jjWln
aojkJoAxzTJAm3P/yRo+/+gommKatHkWBrNef6T3uVhJN/pJEFge+Wq3yAWhHRGo
p0j08u7kcVYo13xSyAEq2hqkkOVuRlKqYwtahjdo/KpYZb2U9TZoZUihfi2BkPVC
wq7ypMDlc40e5D/p0sg/UeQjrhGneTKxyN4DWAJKHVwVAgMBAAE=
-----END PUBLIC KEY-----
""";
}
