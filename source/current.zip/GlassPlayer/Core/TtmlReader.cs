using System.Globalization;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Linq;
namespace GlassPlayer.Core;
public static class TtmlReader
{
    static long? Time(string? value)
    {
        if(string.IsNullOrWhiteSpace(value))return null;double ms;
        if(value.EndsWith("ms",StringComparison.Ordinal)&&double.TryParse(value[..^2],NumberStyles.Float,CultureInfo.InvariantCulture,out var m))ms=m;
        else if(value.EndsWith('s')&&double.TryParse(value[..^1],NumberStyles.Float,CultureInfo.InvariantCulture,out var seconds))ms=seconds*1000;
        else if(double.TryParse(value,NumberStyles.Float,CultureInfo.InvariantCulture,out var bareSeconds))ms=bareSeconds*1000;
        else{var parts=value.Split(':');if(parts.Length is <2 or >3)throw new FormatException("Tempo TTML inválido.");double total=0;foreach(var part in parts){if(!double.TryParse(part,NumberStyles.Float,CultureInfo.InvariantCulture,out var n)||n<0)throw new FormatException("Tempo TTML inválido.");total=total*60+n;}ms=total*1000;}
        if(!double.IsFinite(ms)||ms<0||ms>86400000)throw new FormatException("Tempo TTML fora do limite.");return (long)Math.Round(ms);
    }
    static string? Attribute(XElement e,string key)=>e.Attributes().FirstOrDefault(a=>a.Name.LocalName==key)?.Value;
    public static List<LyricLine> Parse(string xml)
    {
        if(xml.Length>1024*1024)throw new FormatException("O arquivo de letras excede 1 MB.");
        using var source=new StringReader(xml);using var reader=XmlReader.Create(source,new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null,MaxCharactersInDocument=1024*1024,MaxCharactersFromEntities=0});
        XDocument doc;try{doc=XDocument.Load(reader,LoadOptions.PreserveWhitespace);}catch(XmlException ex){throw new FormatException("TTML inválido.",ex);}
        var result=new List<LyricLine>();int totalWords=0;
        foreach(var p in doc.Descendants().Where(e=>e.Name.LocalName=="p"))
        {
            if(result.Count>=2000)throw new FormatException("A letra excede 2.000 linhas.");
            long? start=Time(Attribute(p,"begin")),end=Time(Attribute(p,"end"));var text=new StringBuilder();var words=new List<LyricWord>();
            void Walk(XElement element,long? inheritedStart,long? inheritedEnd)
            {
                string role=Attribute(element,"role")??"";if(role.Contains("translation",StringComparison.OrdinalIgnoreCase)||role.Contains("roman",StringComparison.OrdinalIgnoreCase)||role.Contains("x-bg",StringComparison.OrdinalIgnoreCase)||element.Name.LocalName.Contains("translation",StringComparison.OrdinalIgnoreCase)||element.Name.LocalName.Contains("roman",StringComparison.OrdinalIgnoreCase))return;
                long? at=Time(Attribute(element,"begin"))??inheritedStart,until=Time(Attribute(element,"end"))??inheritedEnd;
                if(element!=p&&!element.Elements().Any()&&at!=null&&until!=null)
                {
                    if(until<at)throw new FormatException("Tempos de palavra TTML inválidos.");string value=element.Value;text.Append(value);words.Add(new(at.Value,until.Value,value));if(++totalWords>30000)throw new FormatException("A letra excede o limite de palavras.");return;
                }
                foreach(var node in element.Nodes())
                {
                    if(node is XText t){var value=t.Value.Replace('\r',' ').Replace('\n',' ');text.Append(value);if(words.Count>0)words[^1]=words[^1] with{Text=words[^1].Text+value};}
                    else if(node is XElement child&&child.Name.LocalName=="br"){text.Append(' ');if(words.Count>0)words[^1]=words[^1] with{Text=words[^1].Text+" "};}
                    else if(node is XElement childElement)Walk(childElement,at,until);
                }
            }
            Walk(p,start,end);string line=text.ToString().Trim();if(line.Length==0)continue;start??=words.Count>0?words.Min(w=>w.StartMs):null;if(start==null)continue;end??=words.Count>0?words.Max(w=>w.EndMs):null;
            if(words.Count>0){words[0]=words[0] with{Text=words[0].Text.TrimStart()};words[^1]=words[^1] with{Text=words[^1].Text.TrimEnd()};if(string.Concat(words.Select(w=>w.Text))!=line||words.Any(w=>w.StartMs<start||w.EndMs<w.StartMs||end!=null&&w.EndMs>end)||words.Zip(words.Skip(1)).Any(w=>w.First.StartMs>w.Second.StartMs))words.Clear();}
            if(end!=null&&end<start)throw new FormatException("Fim de linha TTML inválido.");result.Add(new(start.Value,line,end,words.Count>1?words:null));
        }
        return result.OrderBy(l=>l.TimeMs).ToList();
    }
}
