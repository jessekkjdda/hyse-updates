using System.Net;
using System.Net.Http;
using System.Text.Json;
using System.Text.RegularExpressions;
namespace GlassPlayer.Core;

public sealed record LibraryPlaylist(string Id,string Name,string Description,string? Art,string OwnerId,string OwnerName,bool Public,bool Collaborative,int Count,string? Snapshot)
{
    public string CountText=>$"{Count} faixas";
}
public sealed record PlaylistContent(LibraryPlaylist Playlist,List<Track> Tracks,bool Stable=true,string? Notice=null,bool ReadOnly=false,string Access="api");

public sealed class SpotifyLibraryClient(Func<HttpMethod,string,object?,CancellationToken,Task<string>> request)
{
    static void Id(string value){if(!Regex.IsMatch(value,"^[A-Za-z0-9]{22}$"))throw new ArgumentException("Playlist inválida.");}
    static string S(JsonElement e,string key)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(key,out var p)&&p.ValueKind==JsonValueKind.String?p.GetString()??"":"";
    static bool B(JsonElement e,string key)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(key,out var p)&&p.ValueKind==JsonValueKind.True;
    public static LibraryPlaylist Parse(JsonElement e)
    {
        string id=S(e,"id");Id(id);var owner=e.TryGetProperty("owner",out var o)?o:default;
        string? art=e.TryGetProperty("images",out var images)&&images.ValueKind==JsonValueKind.Array&&images.GetArrayLength()>0?S(images[0],"url"):null;
        int count=0;JsonElement collection;
        if(e.TryGetProperty("items",out collection)||e.TryGetProperty("tracks",out collection))if(collection.ValueKind==JsonValueKind.Object&&collection.TryGetProperty("total",out var total))total.TryGetInt32(out count);
        string description=WebUtility.HtmlDecode(Regex.Replace(S(e,"description"),"<[^>]*>",""));
        return new(id,S(e,"name"),description,art,owner.ValueKind==JsonValueKind.Object?S(owner,"id"):"",owner.ValueKind==JsonValueKind.Object?S(owner,"display_name"):"",B(e,"public"),B(e,"collaborative"),count,S(e,"snapshot_id"));
    }
    static string? Next(JsonElement page,string path)
    {
        var link=S(page,"next");if(link.Length==0)return null;
        if(!Uri.TryCreate(link,UriKind.Absolute,out var uri)||uri.Host!="api.spotify.com"||uri.Scheme!="https"||!uri.IsDefaultPort||uri.UserInfo.Length>0||uri.AbsolutePath!="/v1"+path)throw new FormatException("A paginação da biblioteca retornou um endereço inesperado.");
        return uri.PathAndQuery[3..];
    }
    public async Task<List<LibraryPlaylist>> MineAsync(CancellationToken ct)
    {
        string? next="/me/playlists?limit=50";var seen=new HashSet<string>();var output=new List<LibraryPlaylist>();
        while(next!=null)
        {
            ct.ThrowIfCancellationRequested();if(!seen.Add(next)||seen.Count>220)throw new FormatException("A biblioteca excede o limite de leitura.");
            using var doc=JsonDocument.Parse(await request(HttpMethod.Get,next,null,ct));
            foreach(var item in doc.RootElement.GetProperty("items").EnumerateArray())if(item.ValueKind==JsonValueKind.Object&&S(item,"id").Length==22)output.Add(Parse(item));
            next=Next(doc.RootElement,"/me/playlists");
        }
        return output;
    }
    public async Task<PlaylistContent> OpenAsync(string id,CancellationToken ct,Action<PlaylistContent>? progress=null)
    {
        Id(id);
        for(int attempt=0;;attempt++)
        {
            using var meta=JsonDocument.Parse(await request(HttpMethod.Get,"/playlists/"+id,null,ct));var playlist=Parse(meta.RootElement);
            progress?.Invoke(new(playlist,new(),Stable:false));
            JsonElement? embedded=null;
            if((meta.RootElement.TryGetProperty("items",out var page)||meta.RootElement.TryGetProperty("tracks",out page))&&page.ValueKind==JsonValueKind.Object&&page.TryGetProperty("items",out var entries)&&entries.ValueKind==JsonValueKind.Array)embedded=page;
            var tracks=await SpotifyPlaylistReader.ReadAsync(id,async(path,token)=>await request(HttpMethod.Get,path,null,token),ct,allowUnavailable:true,progress:(items,total)=>progress?.Invoke(new(playlist with{Count=total},items.ToList(),Stable:false)),initialPage:embedded);
            try
            {
                using var after=JsonDocument.Parse(await request(HttpMethod.Get,"/playlists/"+id,null,ct));
                var latest=Parse(after.RootElement);
                if(playlist.Snapshot is{Length:>0} snapshot&&latest.Snapshot!=snapshot)
                {
                    if(attempt==0)continue;
                    return new(latest with{Count=tracks.Count},tracks,false,"A playlist está mudando. Você pode ouvir as faixas carregadas; atualize antes de editar.");
                }
                return new(latest with{Count=tracks.Count},tracks);
            }
            catch(Exception ex) when(!ct.IsCancellationRequested&&ex is HttpRequestException or TimeoutException or OperationCanceledException) {return new(playlist with{Count=tracks.Count},tracks,false,"Faixas carregadas. Atualize para confirmar a versão da playlist antes de editar.");}
        }
    }
    public async Task<LibraryPlaylist> CreateAsync(string name,string description,bool isPublic,CancellationToken ct)
    {
        name=name.Trim();if(name.Length is <1 or >100)throw new ArgumentException("Use um nome de 1 a 100 caracteres.");
        if(description.Length>300)throw new ArgumentException("A descrição pode ter até 300 caracteres.");
        using var doc=JsonDocument.Parse(await request(HttpMethod.Post,"/me/playlists",new{name,description,@public=isPublic},ct));return Parse(doc.RootElement);
    }
    public async Task UpdateAsync(string id,string name,string description,bool isPublic,CancellationToken ct)
    {
        Id(id);name=name.Trim();if(name.Length is <1 or >100||description.Length>300)throw new ArgumentException("Confira nome e descrição da playlist.");
        await request(HttpMethod.Put,"/playlists/"+id,new{name,description,@public=isPublic},ct);
    }
    public async Task AddAsync(string id,string uri,CancellationToken ct)
    {
        Id(id);if(!Regex.IsMatch(uri,"^spotify:track:[A-Za-z0-9]{22}$"))throw new ArgumentException("Escolha uma música Spotify válida.");
        await request(HttpMethod.Post,"/playlists/"+id+"/items",new{uris=new[]{uri}},ct);
    }
    public async Task RemoveAsync(string id,string uri,string? snapshot,CancellationToken ct)
    {Id(id);if(!Regex.IsMatch(uri,"^spotify:track:[A-Za-z0-9]{22}$"))throw new ArgumentException("Faixa inválida.");await request(HttpMethod.Delete,"/playlists/"+id+"/items",new{items=new[]{new{uri}},snapshot_id=snapshot},ct);}
    public async Task MoveAsync(string id,int from,int to,int count,string? snapshot,CancellationToken ct)
    {
        Id(id);if(from<0||to<0||from>=count||to>=count)throw new ArgumentOutOfRangeException(nameof(from));if(from==to)return;
        await request(HttpMethod.Put,"/playlists/"+id+"/items",new{range_start=from,insert_before=to>from?to+1:to,range_length=1,snapshot_id=snapshot},ct);
    }
}
