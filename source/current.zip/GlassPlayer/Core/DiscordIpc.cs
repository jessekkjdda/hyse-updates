using System.Buffers.Binary;
using System.Collections.Concurrent;
using System.IO;
using System.IO.Pipes;
using System.Text.Json;

namespace GlassPlayer.Core;

public static class DiscordFrames
{
    public const int MaxLength=65536;
    public static async Task WriteAsync(Stream stream,int opcode,ReadOnlyMemory<byte> payload,CancellationToken ct)
    {
        if(payload.Length>MaxLength)throw new InvalidDataException("Discord frame too large.");
        var header=new byte[8];BinaryPrimitives.WriteInt32LittleEndian(header,opcode);BinaryPrimitives.WriteInt32LittleEndian(header.AsSpan(4),payload.Length);
        await stream.WriteAsync(header,ct);await stream.WriteAsync(payload,ct);await stream.FlushAsync(ct);
    }
    public static async Task<(int Opcode,byte[] Data)> ReadAsync(Stream stream,CancellationToken ct)
    {
        var header=new byte[8];await stream.ReadExactlyAsync(header,ct);
        int opcode=BinaryPrimitives.ReadInt32LittleEndian(header),length=BinaryPrimitives.ReadInt32LittleEndian(header.AsSpan(4));
        if(length<0||length>MaxLength||opcode is <0 or >4)throw new InvalidDataException("Invalid Discord frame.");
        var payload=new byte[length];await stream.ReadExactlyAsync(payload,ct);return(opcode,payload);
    }
}

// Local IPC only. No user tokens, bot tokens, OAuth credentials or public port.
public sealed class DiscordIpc:IAsyncDisposable
{
    readonly Stream stream;readonly CancellationTokenSource lifetime=new();readonly SemaphoreSlim writer=new(1,1);
    readonly TaskCompletionSource ready=new(TaskCreationOptions.RunContinuationsAsynchronously);
    readonly ConcurrentDictionary<string,TaskCompletionSource> pending=new();readonly Task reader;
    bool disposed;
    DiscordIpc(Stream stream){this.stream=stream;reader=ReadLoopAsync();}
    public bool Disconnected=>reader.IsCompleted;
    public static async Task<Stream> ConnectDesktopAsync(CancellationToken ct)
    {
        if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException();
        for(int n=0;n<10;n++)
        {
            ct.ThrowIfCancellationRequested();var pipe=new NamedPipeClientStream(".","discord-ipc-"+n,PipeDirection.InOut,PipeOptions.Asynchronous);
            try{await pipe.ConnectAsync(100,ct);return pipe;}
            catch(Exception ex)when(ex is IOException or TimeoutException or UnauthorizedAccessException){pipe.Dispose();}
            catch{pipe.Dispose();throw;}
        }
        throw new IOException("Discord desktop is not available.");
    }
    public static async Task<DiscordIpc> OpenAsync(Func<CancellationToken,Task<Stream>> connect,CancellationToken ct)
    {
        var ipc=new DiscordIpc(await connect(ct));
        try
        {
            await ipc.WriteAsync(0,JsonSerializer.SerializeToUtf8Bytes(new{v=1,client_id=DiscordActivity.ApplicationId}),ct);
            await ipc.ready.Task.WaitAsync(TimeSpan.FromSeconds(8),ct);return ipc;
        }
        catch{await ipc.DisposeAsync();throw;}
    }
    async Task WriteAsync(int opcode,ReadOnlyMemory<byte> data,CancellationToken ct)
    {
        await writer.WaitAsync(ct);try{await DiscordFrames.WriteAsync(stream,opcode,data,ct);}finally{writer.Release();}
    }
    public async Task SetActivityAsync(string? activity,CancellationToken ct)
    {
        if(Disconnected)throw new IOException("Discord IPC disconnected.");
        using var document=activity==null?null:JsonDocument.Parse(activity);
        string nonce=Guid.NewGuid().ToString("N");var response=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        pending[nonce]=response;
        try
        {
            if(Disconnected)throw new IOException("Discord IPC disconnected.");
            var data=JsonSerializer.SerializeToUtf8Bytes(new{cmd="SET_ACTIVITY",args=new{pid=Environment.ProcessId,activity=document?.RootElement},nonce});
            await WriteAsync(1,data,ct);await response.Task.WaitAsync(TimeSpan.FromSeconds(8),ct);
        }
        finally{pending.TryRemove(nonce,out _);}
    }
    async Task ReadLoopAsync()
    {
        try
        {
            while(!lifetime.IsCancellationRequested)
            {
                var frame=await DiscordFrames.ReadAsync(stream,lifetime.Token);
                if(frame.Opcode==3){await WriteAsync(4,frame.Data,lifetime.Token);continue;}
                if(frame.Opcode==4)continue;
                if(frame.Opcode==2)throw new IOException("Discord closed the IPC session.");
                if(frame.Opcode!=1)throw new InvalidDataException("Unexpected Discord opcode.");
                using var doc=JsonDocument.Parse(frame.Data);var data=doc.RootElement;
                string? evt=data.TryGetProperty("evt",out var eventName)&&eventName.ValueKind==JsonValueKind.String?eventName.GetString():null;
                if(evt=="READY")ready.TrySetResult();
                if(data.TryGetProperty("nonce",out var id)&&id.ValueKind==JsonValueKind.String&&pending.TryGetValue(id.GetString()!,out var response))
                {
                    if(evt=="ERROR")response.TrySetException(new IOException("Discord rejected the presence update."));
                    else if(data.TryGetProperty("cmd",out var cmd)&&cmd.GetString()=="SET_ACTIVITY")response.TrySetResult();
                }
                else if(evt=="ERROR"&&!ready.Task.IsCompleted)throw new IOException("Discord rejected the application ID.");
            }
        }
        catch(Exception ex)when(ex is IOException or OperationCanceledException or ObjectDisposedException or JsonException or InvalidDataException or InvalidOperationException or ArgumentException)
        {
            var error=new IOException("Discord IPC disconnected.",ex);ready.TrySetException(error);foreach(var request in pending.Values)request.TrySetException(error);
        }
    }
    public void Abort(){try{lifetime.Cancel();}catch(ObjectDisposedException){}stream.Dispose();}
    public async ValueTask DisposeAsync(){if(disposed)return;disposed=true;Abort();await reader;lifetime.Dispose();writer.Dispose();}
}
