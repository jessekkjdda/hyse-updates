using System.Buffers.Binary;
using System.Collections.Concurrent;
using System.IO;
using System.IO.Pipes;
using System.Text.Json;
using System.Text;

namespace GlassPlayer.Core;

public static class DiscordFrames
{
    public const int MaxLength=65536;
    public static async Task WriteAsync(Stream stream,int opcode,ReadOnlyMemory<byte> payload,CancellationToken ct)
    {
        if(payload.Length>MaxLength)throw new InvalidDataException("Discord frame too large.");
        var frame=new byte[8+payload.Length];BinaryPrimitives.WriteInt32LittleEndian(frame,opcode);BinaryPrimitives.WriteInt32LittleEndian(frame.AsSpan(4),payload.Length);payload.CopyTo(frame.AsMemory(8));
        await stream.WriteAsync(frame,ct);await stream.FlushAsync(ct);
    }
    public static async Task<(int Opcode,byte[] Data)> ReadAsync(Stream stream,CancellationToken ct)
    {
        var header=new byte[8];await stream.ReadExactlyAsync(header,ct);
        int opcode=BinaryPrimitives.ReadInt32LittleEndian(header),length=BinaryPrimitives.ReadInt32LittleEndian(header.AsSpan(4));
        if(length<0||length>MaxLength||opcode is <0 or >4)throw new InvalidDataException("Invalid Discord frame.");
        var payload=new byte[length];await stream.ReadExactlyAsync(payload,ct);return(opcode,payload);
    }
}

// Local IPC only. No user tokens, bot tokens, OAuth credentials or public port.
public sealed class DiscordIpc:IAsyncDisposable
{
    readonly Stream stream;readonly CancellationTokenSource lifetime=new();readonly SemaphoreSlim writer=new(1,1);
    readonly TaskCompletionSource ready=new(TaskCreationOptions.RunContinuationsAsynchronously);
    readonly ConcurrentDictionary<string,TaskCompletionSource> pending=new();readonly ConcurrentDictionary<string,TaskCompletionSource> pings=new();readonly Task reader;
    Exception? failure;bool disposed;
    public Exception? Failure=>Volatile.Read(ref failure);
    DiscordIpc(Stream stream){this.stream=stream;reader=ReadLoopAsync();}
    public bool Disconnected=>reader.IsCompleted;
    public string Endpoint{get;private set;}="custom";
    public static Task<DiscordIpc> OpenDesktopAsync(CancellationToken ct)
    {
        if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException();
        return OpenFirstAsync(Enumerable.Range(0,10).Select<int,Func<CancellationToken,Task<Stream>>>(index=>async token=>
        {
            return await ConnectWindowsPipeAsync("discord-ipc-"+index,token);
        }),ct);
    }
    public static async Task<Stream> ConnectWindowsPipeAsync(string name,CancellationToken ct)
    {
        var pipe=new NamedPipeClientStream(".",name,PipeDirection.InOut,PipeOptions.Asynchronous);
        try{await pipe.ConnectAsync(500,ct);return pipe;}catch{pipe.Dispose();throw;}
    }
    public static async Task<DiscordIpc> OpenFirstAsync(IEnumerable<Func<CancellationToken,Task<Stream>>> endpoints,CancellationToken ct,TimeSpan? timeout=null)
    {
        Exception? problem=null;int index=0;
        foreach(var endpoint in endpoints)
        {
            ct.ThrowIfCancellationRequested();using var attempt=CancellationTokenSource.CreateLinkedTokenSource(ct);attempt.CancelAfter(timeout??TimeSpan.FromSeconds(3));
            try{var ipc=await OpenAsync(endpoint,attempt.Token);ipc.Endpoint="discord-ipc-"+index;return ipc;}
            catch(OperationCanceledException)when(!ct.IsCancellationRequested){problem??=new TimeoutException("O Discord não concluiu o handshake.");}
            catch(Exception ex)when(ex is IOException or UnauthorizedAccessException or TimeoutException or ObjectDisposedException)
            {
                if(ex is DiscordRpcError||problem==null)problem=ex;
            }
            index++;
        }
        ct.ThrowIfCancellationRequested();throw problem??new IOException("Nenhuma conexão do Discord foi encontrada.");
    }
    public static async Task<Stream> ConnectDesktopAsync(CancellationToken ct)
    {
        if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException();
        for(int n=0;n<10;n++)
        {
            ct.ThrowIfCancellationRequested();var pipe=new NamedPipeClientStream(".","discord-ipc-"+n,PipeDirection.InOut,PipeOptions.Asynchronous);
            try{await pipe.ConnectAsync(100,ct);return pipe;}
            catch(Exception ex)when(ex is IOException or TimeoutException or UnauthorizedAccessException){pipe.Dispose();}
            catch{pipe.Dispose();throw;}
        }
        throw new IOException("Discord desktop is not available.");
    }
    public static async Task<DiscordIpc> OpenAsync(Func<CancellationToken,Task<Stream>> connect,CancellationToken ct)
    {
        var ipc=new DiscordIpc(await connect(ct));
        try
        {
            await ipc.WriteAsync(0,JsonSerializer.SerializeToUtf8Bytes(new{v=1,client_id=DiscordActivity.ApplicationId}),ct);
            await ipc.ready.Task.WaitAsync(TimeSpan.FromSeconds(8),ct);return ipc;
        }
        catch{await ipc.DisposeAsync();throw;}
    }
    async Task WriteAsync(int opcode,ReadOnlyMemory<byte> data,CancellationToken ct)
    {
        using var bounded=CancellationTokenSource.CreateLinkedTokenSource(ct,lifetime.Token);bounded.CancelAfter(TimeSpan.FromSeconds(8));
        try{await writer.WaitAsync(bounded.Token);try{await DiscordFrames.WriteAsync(stream,opcode,data,bounded.Token);}finally{writer.Release();}}
        catch(OperationCanceledException)when(!ct.IsCancellationRequested&&!lifetime.IsCancellationRequested){throw new TimeoutException("Discord write timed out.");}
    }
    public async Task SetActivityAsync(string? activity,CancellationToken ct,TimeSpan? timeout=null)
    {
        if(Disconnected)throw Failure??new IOException("Discord IPC disconnected.");
        using var document=activity==null?null:JsonDocument.Parse(activity);
        string nonce=Guid.NewGuid().ToString("N");var response=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        pending[nonce]=response;
        try
        {
            if(Disconnected)throw Failure??new IOException("Discord IPC disconnected.");
            var data=JsonSerializer.SerializeToUtf8Bytes(new{cmd="SET_ACTIVITY",args=new{pid=Environment.ProcessId,activity=document?.RootElement},nonce});
            await WriteAsync(1,data,ct);await response.Task.WaitAsync(timeout??TimeSpan.FromSeconds(8),ct);
        }
        finally{pending.TryRemove(nonce,out _);}
    }
    public async Task PingAsync(CancellationToken ct,TimeSpan? timeout=null)
    {
        if(Disconnected)throw Failure??new IOException("Discord IPC disconnected.");
        string nonce=Guid.NewGuid().ToString("N");var response=new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);pings[nonce]=response;
        try{await WriteAsync(3,Encoding.UTF8.GetBytes(nonce),ct);await response.Task.WaitAsync(timeout??TimeSpan.FromSeconds(8),ct);}
        finally{pings.TryRemove(nonce,out _);}
    }
    async Task ReadLoopAsync()
    {
        try
        {
            while(!lifetime.IsCancellationRequested)
            {
                var frame=await DiscordFrames.ReadAsync(stream,lifetime.Token);
                if(frame.Opcode==3){await WriteAsync(4,frame.Data,lifetime.Token);continue;}
                if(frame.Opcode==4){if(pings.TryGetValue(Encoding.UTF8.GetString(frame.Data),out var pong))pong.TrySetResult();continue;}
                if(frame.Opcode==2){using var close=JsonDocument.Parse(frame.Data);throw DiscordRpcError.Read(close.RootElement,ready.Task.IsCompletedSuccessfully?"connection":"handshake",true);}
                if(frame.Opcode!=1)throw new InvalidDataException("Unexpected Discord opcode.");
                using var doc=JsonDocument.Parse(frame.Data);var data=doc.RootElement;
                string? evt=data.TryGetProperty("evt",out var eventName)&&eventName.ValueKind==JsonValueKind.String?eventName.GetString():null;
                if(evt=="READY")ready.TrySetResult();
                if(data.TryGetProperty("nonce",out var id)&&id.ValueKind==JsonValueKind.String&&pending.TryGetValue(id.GetString()!,out var response))
                {
                    if(evt=="ERROR")response.TrySetException(DiscordRpcError.Read(data,"activity"));
                    else if(data.TryGetProperty("cmd",out var cmd)&&cmd.GetString()=="SET_ACTIVITY")response.TrySetResult();
                }
                else if(evt=="ERROR"&&!ready.Task.IsCompleted)throw DiscordRpcError.Read(data,"handshake");
            }
        }
        catch(Exception ex)when(ex is IOException or OperationCanceledException or ObjectDisposedException or JsonException or InvalidDataException or InvalidOperationException or ArgumentException or TimeoutException)
        {
            var error=ex as DiscordRpcError??new IOException("Discord IPC disconnected.",ex);Volatile.Write(ref failure,error);ready.TrySetException(error);foreach(var request in pending.Values.Concat(pings.Values))request.TrySetException(error);
        }
    }
    public void Abort(){try{lifetime.Cancel();}catch(ObjectDisposedException){}stream.Dispose();}
    public async ValueTask DisposeAsync(){if(disposed)return;disposed=true;Abort();await reader;lifetime.Dispose();writer.Dispose();}
}
