namespace GlassPlayer.Core;

public sealed class SilenceGate
{
    string? track;bool heard;double? quietAt;
    public double? QuietStartedAt=>quietAt;
    public bool Observe(string? trackId,bool enabled,bool local,bool measured,double peak,bool muted,double volume,bool playing,bool ended,bool fresh,double now)
    {
        if(track!=trackId){track=trackId;heard=false;quietAt=null;}
        if(!enabled||trackId==null||!local||!measured||!double.IsFinite(peak)||muted||!double.IsFinite(volume)||volume<=.01||!playing&&!ended||playing&&!fresh){quietAt=null;return false;}
        if(peak>.0001){heard=true;quietAt=null;return false;}
        if(!heard)return false;quietAt??=now;return now-quietAt>=650;
    }
    public void Reset(){track=null;heard=false;quietAt=null;}
}
