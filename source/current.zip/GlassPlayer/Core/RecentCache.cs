namespace GlassPlayer.Core;

public sealed class RecentCache<T>(int capacity, TimeSpan lifetime)
{
    readonly Dictionary<string, (T Value, DateTime At)> values = new(StringComparer.Ordinal);
    public bool TryGet(string key, out T value)
    {
        if (values.TryGetValue(key, out var entry) && DateTime.UtcNow - entry.At < lifetime) { values[key] = (entry.Value, DateTime.UtcNow); value = entry.Value; return true; }
        values.Remove(key); value = default!; return false;
    }
    public void Set(string key, T value)
    {
        values[key] = (value, DateTime.UtcNow);
        if (values.Count > capacity) values.Remove(values.OrderBy(p => p.Value.At).First().Key);
    }
    public void Clear() => values.Clear();
}
