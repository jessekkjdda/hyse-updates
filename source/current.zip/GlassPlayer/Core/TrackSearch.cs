using System.Text.Json;
namespace GlassPlayer.Core;

public sealed record TrackSearchPage(List<Track> Tracks,int Offset,int? NextOffset,int Total);
public static class TrackSearchReader
{
    public static TrackSearchPage Parse(string json,int offset)
    {
        using var doc=JsonDocument.Parse(json);
        if(!doc.RootElement.TryGetProperty("tracks",out var page)||page.ValueKind!=JsonValueKind.Object||!page.TryGetProperty("items",out var items)||items.ValueKind!=JsonValueKind.Array)throw new FormatException("O Spotify não retornou os resultados da pesquisa.");
        var tracks=new List<Track>();
        foreach(var item in items.EnumerateArray())
        {
            try{tracks.Add(SpotifyPlaylistReader.ToTrack(item));}
            catch(FormatException){/* One unavailable result must not discard the other songs. */}
        }
        int count=items.GetArrayLength();int total=page.TryGetProperty("total",out var n)&&n.TryGetInt32(out var value)?Math.Max(0,value):offset+count;
        bool next=page.TryGetProperty("next",out var link)&&link.ValueKind==JsonValueKind.String&&!string.IsNullOrWhiteSpace(link.GetString());
        return new(tracks.DistinctBy(t=>t.Id).ToList(),offset,next&&count>0?offset+count:null,total);
    }
}
public sealed class SearchRequestQueue<T>(Func<string,int,CancellationToken,Task<T>> fetch,TimeSpan? spacing=null)
{
    readonly SemaphoreSlim serial=new(1,1);
    DateTime next;
    public async Task<T> RunAsync(string query,int offset,CancellationToken pending,CancellationToken session)
    {
        await serial.WaitAsync(pending);
        try
        {
            var wait=next-DateTime.UtcNow;if(wait>TimeSpan.Zero)await Task.Delay(wait,pending);
            pending.ThrowIfCancellationRequested();session.ThrowIfCancellationRequested();
            next=DateTime.UtcNow+(spacing??TimeSpan.FromMilliseconds(450));
            // Finish a sent request; superseded queries only cancel while waiting.
            return await fetch(query,offset,session);
        }
        finally{serial.Release();}
    }
}
