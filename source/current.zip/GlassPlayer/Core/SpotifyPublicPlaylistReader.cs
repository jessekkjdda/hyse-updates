using System.IO;
using System.Net;
using System.Net.Http;
using System.Text.Json;
using System.Text.RegularExpressions;
namespace GlassPlayer.Core;

// Riff-style public embed metadata. No session tokens or private endpoints.
public sealed partial class SpotifyPublicPlaylistReader(HttpClient http)
{
    [GeneratedRegex("<script\\b(?=[^>]*\\bid=[\"']__NEXT_DATA__[\"'])[^>]*>(.*?)</script>",RegexOptions.Singleline|RegexOptions.IgnoreCase)]private static partial Regex NextData();
    static string S(JsonElement e,string name)=>e.ValueKind==JsonValueKind.Object&&e.TryGetProperty(name,out var x)&&x.ValueKind==JsonValueKind.String?x.GetString()??"":"";
    static string? Image(JsonElement e){if(e.ValueKind!=JsonValueKind.Object)return null;if(e.TryGetProperty("coverArt",out var cover)&&cover.TryGetProperty("sources",out var sources)&&sources.ValueKind==JsonValueKind.Array&&sources.GetArrayLength()>0)return S(sources[0],"url");return S(e,"image") is{Length:>0} value?value:null;}
    public static PlaylistContent Parse(string id,string html,LibraryPlaylist? known=null)
    {
        if(!Regex.IsMatch(id,"^[A-Za-z0-9]{22}$"))throw new ArgumentException("Playlist Spotify inválida.");if(html.Length>4*1024*1024)throw new FormatException("A página pública excede o limite de leitura.");
        var match=NextData().Match(html);if(!match.Success)throw new FormatException("A página pública não contém os dados da playlist.");
        using var doc=JsonDocument.Parse(match.Groups[1].Value);var props=doc.RootElement.GetProperty("props").GetProperty("pageProps");
        if(props.TryGetProperty("status",out var status)&&status.ValueKind==JsonValueKind.Number&&status.TryGetInt32(out var code)&&code>=400)throw new HttpRequestException("A playlist não está disponível na leitura pública do Spotify.",null,(HttpStatusCode)code);
        if(!props.TryGetProperty("state",out var state)||!state.TryGetProperty("data",out var data)||!data.TryGetProperty("entity",out var entity)||S(entity,"uri")!="spotify:playlist:"+id)throw new FormatException("A página pública não corresponde à playlist selecionada.");
        if(!entity.TryGetProperty("trackList",out var list)||list.ValueKind!=JsonValueKind.Array)throw new FormatException("O Spotify não expôs a lista pública de músicas.");
        int expected=known?.Count??0;if(entity.TryGetProperty("totalCount",out var total)&&total.TryGetInt32(out int count)&&count>=0)expected=count;
        if(expected>0&&list.GetArrayLength()!=expected||expected==0&&list.GetArrayLength()>=100)throw new FormatException($"O Spotify expôs somente {list.GetArrayLength()} faixas na página pública. Use a leitura pela sessão para carregar a playlist inteira.");
        var tracks=new List<Track>();foreach(var item in list.EnumerateArray())
        {
            string uri=S(item,"uri"),title=S(item,"title");if(title.Length==0)title=S(item,"name");
            bool available=Regex.IsMatch(uri,"^spotify:track:[A-Za-z0-9]{22}$")&&!(item.TryGetProperty("isPlayable",out var p)&&p.ValueKind==JsonValueKind.False);
            int duration=item.TryGetProperty("duration",out var durationValue)&&durationValue.TryGetInt32(out int ms)?Math.Max(0,ms):0;
            tracks.Add(new(available?uri[14..]:"unavailable-public-"+tracks.Count,title.Length>0?title:"Faixa indisponível",S(item,"subtitle"),Image(item)??Image(entity),null,"Spotify",available?uri:null,duration,Available:available));
        }
        var metadata=known??new LibraryPlaylist(id,S(entity,"name"),"",Image(entity),"",S(entity,"subtitle"),true,false,tracks.Count,null);
        return new(metadata with{Count=tracks.Count},tracks,true,"Leitura pública do Spotify. Para editar, atualize as permissões da conta.",true,"public");
    }
    public async Task<PlaylistContent> ReadAsync(string id,LibraryPlaylist? known,CancellationToken ct)
    {
        if(!Regex.IsMatch(id,"^[A-Za-z0-9]{22}$"))throw new ArgumentException("Playlist Spotify inválida.");
        using var request=new HttpRequestMessage(HttpMethod.Get,"https://open.spotify.com/embed/playlist/"+id);request.Headers.UserAgent.ParseAdd("hyse/0.12.0");
        using var response=await http.SendAsync(request,HttpCompletionOption.ResponseHeadersRead,ct);response.EnsureSuccessStatusCode();
        if(response.Content.Headers.ContentLength>4*1024*1024)throw new FormatException("A página pública excede o limite de leitura.");
        using var buffer=new MemoryStream();await using var stream=await response.Content.ReadAsStreamAsync(ct);var bytes=new byte[8192];int read;while((read=await stream.ReadAsync(bytes,ct))>0){if(buffer.Length+read>4*1024*1024)throw new FormatException("A página pública excede o limite de leitura.");await buffer.WriteAsync(bytes.AsMemory(0,read),ct);}return Parse(id,System.Text.Encoding.UTF8.GetString(buffer.ToArray()),known);
    }
}
