namespace GlassPlayer.Core;

public static class CloseBehavior
{
    public static bool HideToTray(bool exiting,bool sessionEnding,bool trayAvailable)=>!exiting&&!sessionEnding&&trayAvailable;
}
