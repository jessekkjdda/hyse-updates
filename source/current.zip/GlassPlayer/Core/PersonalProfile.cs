using System.IO;
using System.Text.Json;
namespace GlassPlayer.Core;

public sealed record PersonalProfile(string Name="",string Bio="");
public sealed class PersonalProfileStore(string directory)
{
    public PersonalProfile Load(){try{var file=Path.Combine(directory,"profile.json");if(!File.Exists(file)||new FileInfo(file).Length>16384)return new();var p=JsonSerializer.Deserialize<PersonalProfile>(File.ReadAllText(file));return p is{ Name.Length:<=60,Bio.Length:<=180}?p:new();}catch{return new();}}
    public PersonalProfile Save(string name,string bio)
    {
        name=name.Trim();bio=bio.Trim();if(name.Length>60||bio.Length>180||name.Any(char.IsControl)||bio.Any(c=>char.IsControl(c)&&c!='\n'))throw new ArgumentException("Use até 60 caracteres no nome e 180 na descrição.");
        Directory.CreateDirectory(directory);var value=new PersonalProfile(name,bio);var file=Path.Combine(directory,"profile.json");File.WriteAllText(file+".tmp",JsonSerializer.Serialize(value));File.Move(file+".tmp",file,true);return value;
    }
    static string Asset(string kind)=>kind is "avatar" or "banner"?kind+".png":throw new ArgumentException("Imagem de perfil inválida.");
    public void SetImage(string kind,byte[]? png)
    {
        string file=Path.Combine(directory,Asset(kind));if(png==null){if(File.Exists(file))File.Delete(file);return;}
        if(png.Length is <8 or >6*1024*1024||!png.AsSpan(0,8).SequenceEqual(new byte[]{137,80,78,71,13,10,26,10}))throw new ArgumentException("Use uma imagem PNG de até 6 MB.");
        Directory.CreateDirectory(directory);File.WriteAllBytes(file+".tmp",png);File.Move(file+".tmp",file,true);
    }
    public string? Image(string kind){var path=Path.Combine(directory,Asset(kind));try{return File.Exists(path)&&new FileInfo(path).Length<=6*1024*1024?"data:image/png;base64,"+Convert.ToBase64String(File.ReadAllBytes(path)):null;}catch{return null;}}
}
