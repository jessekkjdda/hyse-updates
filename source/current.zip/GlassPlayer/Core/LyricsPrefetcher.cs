namespace GlassPlayer.Core;

// One cancellable look-ahead job. It warms existing provider caches and never
// publishes lyrics, changes playback, advances the queue or retries failures.
public sealed class LyricsPrefetcher(Func<Track,CancellationToken,Task> warm,TimeSpan? delay=null):IDisposable
{
    CancellationTokenSource? source;
    Task running=Task.CompletedTask;
    string? scheduled,completed;
    DateTime completedAt;
    long version;
    bool disposed;
    public Task WhenIdle=>running;
    static string Key(Track track)=>track.Source+":"+track.Id;
    public void Schedule(Track? track)
    {
        if(disposed)return;
        if(track==null||!track.Available){Cancel();return;}
        string key=Key(track);
        if(scheduled==key&&!running.IsCompleted||completed==key&&DateTime.UtcNow-completedAt<TimeSpan.FromMinutes(5))return;
        Cancel();source=new CancellationTokenSource();scheduled=key;
        long generation=version;running=RunAsync(track,key,generation,source.Token);
    }
    async Task RunAsync(Track track,string key,long generation,CancellationToken ct)
    {
        try
        {
            await Task.Delay(delay??TimeSpan.FromSeconds(3),ct);
            ct.ThrowIfCancellationRequested();await warm(track,ct);ct.ThrowIfCancellationRequested();
            if(generation==version){completed=key;completedAt=DateTime.UtcNow;}
        }
        catch(OperationCanceledException)when(ct.IsCancellationRequested){}
        catch(Exception){/* Optional cache warming must never reach playback/UI errors. */}
        finally{if(generation==version)scheduled=null;}
    }
    public void Cancel(){version++;source?.Cancel();source?.Dispose();source=null;scheduled=null;}
    public async Task CancelAsync(){var previous=running;Cancel();await previous;}
    public void Dispose(){disposed=true;Cancel();}
}
