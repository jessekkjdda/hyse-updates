using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using GlassPlayer.Core;
namespace GlassPlayer;

// A TCP listener avoids the HTTP.sys URL reservations required on some Windows installations.
sealed class LoopbackLogin : IDisposable
{
    readonly TcpListener listener = new(IPAddress.Loopback, 5543);
    public LoopbackLogin()
    {
        try { listener.Start(8); } catch (SocketException ex) { throw new IOException("A porta local 5543 está ocupada. Feche outro login do hyse e tente novamente.", ex); }
    }
    public async Task<OAuthCallback> WaitAsync(string expectedState, CancellationToken ct)
    {
        while (true)
        {
            using var client = await listener.AcceptTcpClientAsync(ct);
            await using var stream = client.GetStream();
            using var requestTimeout = CancellationTokenSource.CreateLinkedTokenSource(ct); requestTimeout.CancelAfter(TimeSpan.FromSeconds(10));
            try
            {
                var bytes = new byte[16384]; int length = 0;
                while (length < bytes.Length)
                {
                    int read = await stream.ReadAsync(bytes.AsMemory(length), requestTimeout.Token); if (read == 0) break; length += read;
                    if (Encoding.ASCII.GetString(bytes, 0, length).Contains("\r\n\r\n", StringComparison.Ordinal)) break;
                }
                var header = Encoding.ASCII.GetString(bytes, 0, length); OAuthCallback? result = null;
                try
                {
                    if (!header.Contains("\r\n\r\n", StringComparison.Ordinal)) throw new FormatException();
                    result = OAuthCallback.Parse(header.Split("\r\n")[0], expectedState);
                }
                catch (FormatException) { }
                var page = Encoding.UTF8.GetBytes("<!doctype html><meta charset='utf-8'><title>hyse</title><body style='font:16px system-ui;background:#111;color:white;padding:10vw'><h1>" + (result?.Code != null ? "Autorização recebida" : "Autorização não concluída") + "</h1><p>Volte ao hyse.</p></body>");
                var response = Encoding.ASCII.GetBytes("HTTP/1.1 " + (result != null ? "200 OK" : "400 Bad Request") + "\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + page.Length + "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n");
                await stream.WriteAsync(response, requestTimeout.Token); await stream.WriteAsync(page, requestTimeout.Token);
                if (result != null) return result;
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested) { }
            catch (IOException) { }
        }
    }
    public void Dispose() => listener.Stop();
}
