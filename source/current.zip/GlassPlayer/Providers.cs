using GlassPlayer.Core;
using System.Text.RegularExpressions;
using System.Globalization;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Net.Http;
using System.Diagnostics;
using System.Net;
using System.Security.Cryptography;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;


namespace GlassPlayer;

public interface IProvider
{
    string Name { get; }
    bool Enabled { get; }
    Task<List<Track>> SearchAsync(string query, CancellationToken ct = default);
    /// <summary>Returns a URL the built-in player can stream, or null if the track must be opened elsewhere.</summary>
    Task<string?> ResolveAsync(Track t, CancellationToken ct = default);
}

static class Config
{
    static readonly Dictionary<string, string> file = Load();
    static string? userClient = AppSettings.Load().SpotifyClientId;
    static Dictionary<string, string> Load() { try { return JsonSerializer.Deserialize<Dictionary<string, string>>(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "config.json"))) ?? new(); } catch { return new(); } }
    public static string? Get(string key)
    {
        if (key == "SPOTIFY_CLIENT_ID" && !string.IsNullOrWhiteSpace(userClient)) return userClient;
        var env = Environment.GetEnvironmentVariable(key);
        return !string.IsNullOrWhiteSpace(env) ? env : file.GetValueOrDefault(key) is { Length: > 0 } v ? v : null;
    }
    public static void SetSpotify(string value) => userClient = value;
}
class Spotify : IProvider
{
    static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(25) };
    readonly SemaphoreSlim tokenGate = new(1, 1);
    CancellationTokenSource session = new();
    SpotifyApiTransport? transport;
    const string Redirect = "http://127.0.0.1:5543/callback";
    const string Scopes = "streaming user-read-email user-read-private user-read-playback-state user-modify-playback-state playlist-read-private playlist-read-collaborative playlist-modify-private playlist-modify-public";
    string? id => Config.Get("SPOTIFY_CLIENT_ID");
    string Store => Path.Combine(AppSettings.DirectoryPath, "spotify-" + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(id ?? "none")))[..16] + ".bin");
    string? access, refresh, deviceId;
    DateTime expires;
    bool useWeb;
    public HashSet<string>? GrantedScopes {get;private set;}
    public bool MissingPlaylistReadScopes=>GrantedScopes!=null&&(!GrantedScopes.Contains("playlist-read-private")||!GrantedScopes.Contains("playlist-read-collaborative"));
    public string Name => "Spotify";
    public bool Enabled => Regex.IsMatch(id ?? "", "^[a-fA-F0-9]{32}$");
    public static bool AutoLaunch = true;
    public static bool PreferDesktop;
    public WebPlayer? Web;
    public bool SignedIn => refresh != null || File.Exists(Store);
    public Task<string> GetTokenAsync() => TokenAsync();
    async Task<string> TokenAsync(CancellationToken ct = default, bool interactive = true)
    {
        if (!Enabled) throw new Exception("Configure seu Client ID do Spotify em Configurações.");
        using var linked = CancellationTokenSource.CreateLinkedTokenSource(ct, session.Token); ct = linked.Token;
        await tokenGate.WaitAsync(ct);
        try
        {
            if (access != null && DateTime.UtcNow < expires) return access;
            if (refresh == null) try { refresh = Encoding.UTF8.GetString(ProtectedData.Unprotect(File.ReadAllBytes(Store), null, DataProtectionScope.CurrentUser)); } catch { }
            if (refresh != null)
            {
                try { await ExchangeAsync(new() { ["grant_type"] = "refresh_token", ["refresh_token"] = refresh, ["client_id"] = id! }, ct); return access!; }
                catch (OperationCanceledException) { throw; }
                catch (UnauthorizedAccessException) { refresh = null; }
            }
            if (!interactive) throw new UnauthorizedAccessException("Conecte o Spotify nas configurações.");
            await LoginAsync(ct); return access!;
        }
        finally { tokenGate.Release(); }
    }
    public async Task WarmupAsync(CancellationToken ct)
    {
        if (!Enabled || !SignedIn) return;
        try { await TokenAsync(ct, false);if(!PreferDesktop&&Web!=null)await Web.StartAsync().WaitAsync(ct); } catch (OperationCanceledException) { } catch { }
    }
    async Task ExchangeAsync(Dictionary<string, string> form, CancellationToken ct)
    {
        using var response = await Http.PostAsync("https://accounts.spotify.com/api/token", new FormUrlEncodedContent(form), ct);
        if (response.StatusCode is HttpStatusCode.BadRequest or HttpStatusCode.Unauthorized) throw new UnauthorizedAccessException("A autorização Spotify expirou. Conecte novamente.");
        response.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct)); var r = doc.RootElement;
        access = r.GetProperty("access_token").GetString(); expires = DateTime.UtcNow.AddSeconds(r.GetProperty("expires_in").GetInt32() - 60);
        if(r.TryGetProperty("scope",out var granted)&&granted.ValueKind==JsonValueKind.String)GrantedScopes=(granted.GetString()??"").Split(' ',StringSplitOptions.RemoveEmptyEntries).ToHashSet(StringComparer.Ordinal);
        if (r.TryGetProperty("refresh_token", out var token)) refresh = token.GetString();
        if (refresh != null)
        {
            Directory.CreateDirectory(AppSettings.DirectoryPath);
            var temporary = Store + ".tmp"; await File.WriteAllBytesAsync(temporary, ProtectedData.Protect(Encoding.UTF8.GetBytes(refresh), null, DataProtectionScope.CurrentUser), ct); ct.ThrowIfCancellationRequested(); File.Move(temporary, Store, true);
        }
    }
    async Task LoginAsync(CancellationToken ct)
    {
        var verifier = Convert.ToBase64String(RandomNumberGenerator.GetBytes(64)).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        var challenge = Convert.ToBase64String(SHA256.HashData(Encoding.ASCII.GetBytes(verifier))).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        var state = Convert.ToHexString(RandomNumberGenerator.GetBytes(32));
        using var listener = new LoopbackLogin();
        var url = "https://accounts.spotify.com/authorize?" + string.Join("&", new Dictionary<string, string> { ["client_id"] = id!, ["response_type"] = "code", ["redirect_uri"] = Redirect, ["scope"] = Scopes, ["code_challenge_method"] = "S256", ["code_challenge"] = challenge, ["state"] = state, ["show_dialog"] = "true" }.Select(p => Uri.EscapeDataString(p.Key) + "=" + Uri.EscapeDataString(p.Value)));
        Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct); timeout.CancelAfter(TimeSpan.FromMinutes(3));
        var result = await listener.WaitAsync(state, timeout.Token);
        if (result.Error != null) throw new Exception("A conexão foi cancelada no Spotify: " + result.Error);
        await ExchangeAsync(new() { ["grant_type"] = "authorization_code", ["code"] = result.Code!, ["redirect_uri"] = Redirect, ["client_id"] = id!, ["code_verifier"] = verifier }, ct);
    }

    async Task<HttpResponseMessage> SendAsync(HttpMethod method,string path,object? body=null,CancellationToken ct=default)
    {
        using var linked=CancellationTokenSource.CreateLinkedTokenSource(ct,session.Token);
        transport??=new SpotifyApiTransport(Http,token=>TokenAsync(token),()=>access=null);
        return await transport.SendAsync(method,path,body,linked.Token);
    }
    public async Task<TrackSearchPage> SearchPageAsync(string q,int offset,CancellationToken ct=default)
    {
        using var response=await SendAsync(HttpMethod.Get,"/search?type=track&limit=10&offset="+Math.Clamp(offset,0,990)+"&q="+Uri.EscapeDataString(q),ct:ct);
        response.EnsureSuccessStatusCode();return TrackSearchReader.Parse(await response.Content.ReadAsStringAsync(ct),offset);
    }
    public async Task<string> CatalogRequestAsync(string path,CancellationToken ct){using var response=await SendAsync(HttpMethod.Get,path,ct:ct);response.EnsureSuccessStatusCode();return await response.Content.ReadAsStringAsync(ct);}
    public async Task<CatalogPage> SearchCatalogAsync(string q,int offset,CancellationToken ct)
    {
        using var response=await SendAsync(HttpMethod.Get,"/search?type=track,artist,album,playlist&limit=10&offset="+Math.Clamp(offset,0,990)+"&q="+Uri.EscapeDataString(q),ct:ct);
        response.EnsureSuccessStatusCode();return CatalogReader.Spotify(await response.Content.ReadAsStringAsync(ct),offset);
    }
    public async Task<List<Track>> SearchAsync(string q,CancellationToken ct=default)=>(await SearchPageAsync(q,0,ct)).Tracks;
    static Track ToTrack(JsonElement t) => GlassPlayer.Core.SpotifyPlaylistReader.ToTrack(t);
    public Task<List<Track>> PlaylistAsync(string playlistId, CancellationToken ct = default)
        => GlassPlayer.Core.SpotifyPlaylistReader.ReadAsync(playlistId, async (path, token) =>
        {
            using var response = await SendAsync(HttpMethod.Get, path, ct: token);
            if (response.StatusCode == HttpStatusCode.Forbidden) throw new Exception("O Spotify limitou a leitura. Use playlists que você possui ou nas quais colabora.");
            if (response.StatusCode == HttpStatusCode.NotFound) throw new Exception("Playlist não encontrada ou sem acesso para esta conta.");
            response.EnsureSuccessStatusCode(); return await response.Content.ReadAsStringAsync(token);
        }, ct);
    public Task<string?> ResolveAsync(Track t, CancellationToken ct = default) => Task.FromResult<string?>(null);
    public record Profile(string Name, string? Plan, string? Country, string? Image,string? Id=null);
    public string? UserId {get;private set;}
    public async Task ConnectAsync(CancellationToken ct = default) { await TokenAsync(ct); Web?.Reset(); }
    public void SignOut() { session.Cancel(); session.Dispose(); session = new(); access = refresh = null; UserId=null;GrantedScopes=null;expires = DateTime.MinValue; useWeb = false; deviceId = null; try { File.Delete(Store); } catch { } Web?.Reset(); }
    public async Task<Profile?> ProfileAsync()
    {
        if (!SignedIn) return null; using var response = await SendAsync(HttpMethod.Get, "/me"); response.EnsureSuccessStatusCode(); using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync()); var r = doc.RootElement;
        string? S(string key) => r.TryGetProperty(key, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;
        string? image = r.TryGetProperty("images", out var images) && images.ValueKind == JsonValueKind.Array && images.GetArrayLength() > 0 ? images[0].GetProperty("url").GetString() : null;
        UserId=S("id");return new(S("display_name") ?? S("id") ?? "Spotify", S("product"), S("country"), image,UserId);
    }
    async Task<(string Id, string Name)> PickDeviceAsync(CancellationToken ct)
    {
        bool launched = false;
        for (int attempt = 0; attempt < 7; attempt++)
        {
            using var response = await SendAsync(HttpMethod.Get, "/me/player/devices", ct: ct); response.EnsureSuccessStatusCode(); using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
            var devices = doc.RootElement.GetProperty("devices").EnumerateArray().Where(d => !d.GetProperty("is_restricted").GetBoolean() && !(PreferDesktop && d.GetProperty("id").GetString() == Web?.DeviceId)).ToList();
            var pick = devices.FirstOrDefault(d => d.GetProperty("type").GetString() == "Computer" && d.GetProperty("is_active").GetBoolean());
            if (pick.ValueKind == JsonValueKind.Undefined) pick = devices.FirstOrDefault(d => d.GetProperty("type").GetString() == "Computer");
            if (pick.ValueKind != JsonValueKind.Undefined) return (pick.GetProperty("id").GetString()!, pick.GetProperty("name").GetString() ?? "Spotify");
            if (AutoLaunch && attempt < 5) { if (!launched) { launched = true; try { Process.Start(new ProcessStartInfo("spotify:") { UseShellExecute = true }); } catch { } } await Task.Delay(1000, ct); continue; }
            pick = devices.FirstOrDefault(d => d.GetProperty("is_active").GetBoolean()); if (pick.ValueKind != JsonValueKind.Undefined) return (pick.GetProperty("id").GetString()!, pick.GetProperty("name").GetString() ?? "Spotify");
            break;
        }
        throw new Exception("Nenhum dispositivo Spotify disponível. Abra o Spotify e tente novamente.");
    }
    public async Task<string> PlayAsync(string uri, CancellationToken ct = default)
    {
        await TokenAsync(ct);
        if (!PreferDesktop && Web != null)
        {
            var webDevice = await Web.WaitReadyAsync(TimeSpan.FromSeconds(15), ct);
            if (webDevice != null)
            {
                Web.ClearState();
                for (int i = 0; i < 3; i++)
                {
                    using var r = await SendAsync(HttpMethod.Put, "/me/player/play?device_id=" + Uri.EscapeDataString(webDevice), new { uris = new[] { uri } }, ct);
                    if (r.IsSuccessStatusCode) { deviceId = webDevice; useWeb = true; return "hyse"; }
                    if (r.StatusCode == HttpStatusCode.Forbidden) throw new Exception("O Spotify recusou a reprodução. Confira Premium, permissões e usuários autorizados do aplicativo.");
                    if (r.StatusCode != HttpStatusCode.NotFound) break; await Task.Delay(700, ct);
                }
            }
        }
        useWeb = false; var device = await PickDeviceAsync(ct); deviceId = device.Id;
        using var transfer = await SendAsync(HttpMethod.Put, "/me/player", new { device_ids = new[] { device.Id }, play = false }, ct); transfer.EnsureSuccessStatusCode(); await Task.Delay(500, ct);
        using var response = await SendAsync(HttpMethod.Put, "/me/player/play?device_id=" + Uri.EscapeDataString(device.Id), new { uris = new[] { uri } }, ct);
        if (response.StatusCode == HttpStatusCode.Forbidden) throw new Exception("O Spotify recusou a reprodução. Confira Premium e permissões do aplicativo.");
        response.EnsureSuccessStatusCode(); return device.Name;
    }
    public bool UsesWebDevice => useWeb;
    async Task CommandAsync(string path, CancellationToken ct = default)
    {
        if (deviceId != null) path += (path.Contains('?') ? "&" : "?") + "device_id=" + Uri.EscapeDataString(deviceId);
        using var response = await SendAsync(HttpMethod.Put, path, ct: ct); response.EnsureSuccessStatusCode();
    }
    public async Task ReauthorizeAsync(CancellationToken ct)
    {
        await tokenGate.WaitAsync(ct);try{await LoginAsync(ct);}finally{tokenGate.Release();}
    }
    public async Task<string> LibraryRequestAsync(HttpMethod method,string path,object? body,CancellationToken ct)
    {
        using var response=await SendAsync(method,path,body,ct);
        string detail="";
        if(!response.IsSuccessStatusCode)
        {
            try{using var error=JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));if(error.RootElement.TryGetProperty("error",out var value)&&value.ValueKind==JsonValueKind.Object&&value.TryGetProperty("message",out var message))detail=message.GetString()??"";}catch(JsonException){}
            if(detail.Length>300)detail=detail[..300];
        }
        if(response.StatusCode==HttpStatusCode.Forbidden)throw new HttpRequestException("O Spotify recusou "+(method==HttpMethod.Get?"a leitura":"a edição")+" desta playlist (403). "+detail,null,response.StatusCode);
        if(response.StatusCode==HttpStatusCode.NotFound)throw new HttpRequestException("Playlist não encontrada ou indisponível para esta conta (404).",null,response.StatusCode);
        if(response.StatusCode is HttpStatusCode.Conflict or HttpStatusCode.PreconditionFailed)throw new HttpRequestException("A playlist mudou. Atualize a biblioteca e tente novamente.",null,response.StatusCode);
        response.EnsureSuccessStatusCode();var text=await response.Content.ReadAsStringAsync(ct);return string.IsNullOrWhiteSpace(text)?"{}":text;
    }
    public Task PauseAsync() => useWeb ? Web!.CallAsync("pause()") : CommandAsync("/me/player/pause");
    public Task ResumeAsync() => useWeb ? Web!.CallAsync("resume()") : CommandAsync("/me/player/play");
    public Task SeekAsync(int ms) => useWeb ? Web!.CallAsync($"seek({Math.Max(0, ms)})") : CommandAsync("/me/player/seek?position_ms=" + Math.Max(0, ms));
    public Task VolumeAsync(int pct, CancellationToken ct = default) => SetVolumeAsync(Math.Clamp(pct, 0, 100) / 100d, ct);
    public Task SetVolumeAsync(double level, CancellationToken ct = default)
    {
        level = Math.Clamp(level, 0, 1);
        return useWeb ? Web!.CallAsync("setVolume(" + level.ToString("0.0000", CultureInfo.InvariantCulture) + ")", ct) : CommandAsync("/me/player/volume?volume_percent=" + (int)Math.Round(level * 100), ct);
    }

    public async Task<(bool Playing, int Progress, int Duration, string? Uri)?> StateAsync()
    {
        if (useWeb) return Web?.Current();
        using var response = await SendAsync(HttpMethod.Get, "/me/player"); if (response.StatusCode == HttpStatusCode.NoContent) return null; response.EnsureSuccessStatusCode();
        using var doc = JsonDocument.Parse(await response.Content.ReadAsStringAsync()); var r = doc.RootElement;
        if (!r.TryGetProperty("item", out var item) || item.ValueKind != JsonValueKind.Object) return null;
        return (r.GetProperty("is_playing").GetBoolean(), r.GetProperty("progress_ms").GetInt32(), item.GetProperty("duration_ms").GetInt32(), item.GetProperty("uri").GetString());
    }
}

