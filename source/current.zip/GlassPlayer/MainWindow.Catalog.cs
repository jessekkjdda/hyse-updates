using System.IO;
using System.Net.Http;
using System.Text.Json;
using GlassPlayer.Core;
namespace GlassPlayer;
public partial class MainWindow
{
    static string EntityKey(CatalogEntity e)=>e.Source+"|"+e.Kind+"|"+e.Id;
    async Task<CatalogSearchResult> SearchCatalogAsync(string query,string source,int spotifyOffset,string scCursor,bool more,bool includeSpotify,bool includeSoundCloud,CancellationToken ct)
    {
        query=query.Trim();if(query.Length is <1 or >300||source is not("all" or "Spotify" or "SoundCloud"))throw new ArgumentException("Confira o termo da pesquisa.");
        async Task<(CatalogPage? Page,string? Notice)> SpotifyPage()
        {
            if(source=="SoundCloud"||!includeSpotify)return(null,null);
            if(!spotify.SignedIn)return(null,source=="Spotify"?"Conecte o Spotify para pesquisar neste catálogo.":null);
            try{return(await catalogSearches.RunAsync(query,spotifyOffset,ct,lifetime.Token),null);}catch(Exception ex)when(!ct.IsCancellationRequested){return(null,"Spotify: "+ex.Message);}
        }
        async Task<(CatalogPage? Page,string? Notice)> SoundCloudPage()
        {
            if(source=="Spotify"||!includeSoundCloud)return(null,null);
            try{return(await soundCloud.SearchAsync(query,scCursor,ct),null);}catch(Exception ex)when(!ct.IsCancellationRequested){return(null,"SoundCloud: "+ex.Message);}
        }
        var spotifyTask=SpotifyPage();var soundCloudTask=SoundCloudPage();await Task.WhenAll(spotifyTask,soundCloudTask);ct.ThrowIfCancellationRequested();var sp=await spotifyTask;var sc=await soundCloudTask;
        var tracks=(sp.Page?.Tracks??new()).Concat(sc.Page?.Tracks??new()).DistinctBy(t=>t.Id).ToList();var entities=(sp.Page?.Entities??new()).Concat(sc.Page?.Entities??new()).DistinctBy(EntityKey).ToList();
        Register(tracks);foreach(var entity in entities)catalogEntities[EntityKey(entity)]=entity;
        var ordered=tracks.OrderByDescending(t=>CatalogReader.Score(query,t.Title,t.Artist)).ToList();
        return new(ordered,entities,CatalogReader.Spotlight(query,ordered,entities),sp.Page?.NextOffset,sc.Page?.NextCursor,new[]{sp.Notice,sc.Notice}.OfType<string>().ToList());
    }
    async Task<object> OpenCatalogEntityAsync(string key,CancellationToken ct)
    {
        if(!catalogEntities.TryGetValue(key,out var entity))throw new ArgumentException("Pesquise o item novamente antes de abrir.");
        if(entity.Source=="SoundCloud")
        {
            var resolved=await soundCloud.ResolveAsync(entity.Url,ct);Register(resolved.Tracks);return new{entity,tracks=resolved.Tracks,entities=Array.Empty<CatalogEntity>(),notice=entity.Kind=="artist"?"Últimos envios públicos do artista.":"Playlist pública SoundCloud, disponível para reprodução."};
        }
        if(entity.Kind=="artist")
        {
            var page=await spotify.SearchCatalogAsync("artist:\""+entity.Name.Replace("\"","")+"\"",0,ct);Register(page.Tracks);foreach(var item in page.Entities)catalogEntities[EntityKey(item)]=item;
            return new{entity,tracks=page.Tracks,entities=page.Entities.Where(e=>e.Kind=="album").ToArray(),notice="Músicas e álbuns encontrados para este artista."};
        }
        if(entity.Kind!="album")throw new ArgumentException("Abra esta playlist pela biblioteca.");
        string? next="/albums/"+entity.Id+"/tracks?limit=50";var seen=new HashSet<string>();var tracks=new List<Track>();int expected=-1;
        while(next!=null)
        {
            ct.ThrowIfCancellationRequested();if(!seen.Add(next)||seen.Count>220)throw new FormatException("Paginação do álbum inválida.");
            using var doc=JsonDocument.Parse(await spotify.CatalogRequestAsync(next,ct));var page=doc.RootElement;
            int count=CatalogReader.N(page,"total");if(expected>=0&&count!=expected||count>10000)throw new FormatException("A contagem do álbum mudou durante a leitura.");expected=count;
            foreach(var item in page.GetProperty("items").EnumerateArray())try{tracks.Add(SpotifyPlaylistReader.ToTrack(item) with{Art=entity.Art,AlbumName=entity.Name});}catch(FormatException){tracks.Add(new("album-unavailable-"+tracks.Count,"Faixa indisponível","",entity.Art,null,"Spotify",null,Available:false));}
            string link=CatalogReader.S(page,"next");next=null;if(link.Length>0){if(!Uri.TryCreate(link,UriKind.Absolute,out var u)||u.Scheme!="https"||u.Host!="api.spotify.com"||u.UserInfo.Length>0||!u.IsDefaultPort||u.AbsolutePath!="/v1/albums/"+entity.Id+"/tracks")throw new FormatException("O álbum retornou uma página inesperada.");next=u.PathAndQuery[3..];}
        }
        if(tracks.Count!=expected)throw new FormatException("O álbum não foi lido por completo.");Register(tracks);return new{entity,tracks,entities=Array.Empty<CatalogEntity>(),notice=""};
    }
    static string SearchHistoryPath=>Path.Combine(AppSettings.DirectoryPath,"search-history.json");
    void LoadSearchHistory(){try{if(File.Exists(SearchHistoryPath)&&new FileInfo(SearchHistoryPath).Length<65536)recentSearches.AddRange((JsonSerializer.Deserialize<List<string>>(File.ReadAllText(SearchHistoryPath))??new()).Where(q=>q.Length is >0 and <=300).Distinct(StringComparer.OrdinalIgnoreCase).Take(20));}catch{}}
    async Task RememberSearchAsync(string query,CancellationToken ct){query=query.Trim();if(query.Length is <1 or >300)return;recentSearches.RemoveAll(q=>q.Equals(query,StringComparison.OrdinalIgnoreCase));recentSearches.Insert(0,query);if(recentSearches.Count>20)recentSearches.RemoveRange(20,recentSearches.Count-20);await SaveSearchHistoryAsync(ct);}
    async Task SaveSearchHistoryAsync(CancellationToken ct){var snapshot=recentSearches.ToArray();await searchHistoryWriter.WaitAsync(ct);try{Directory.CreateDirectory(AppSettings.DirectoryPath);var temp=SearchHistoryPath+".tmp";await File.WriteAllTextAsync(temp,JsonSerializer.Serialize(snapshot),ct);ct.ThrowIfCancellationRequested();File.Move(temp,SearchHistoryPath,true);}finally{searchHistoryWriter.Release();}}
}
