using System.Diagnostics;
using System.Runtime.InteropServices;
using NAudio.CoreAudioApi;
namespace GlassPlayer;

sealed record AudioLevelSnapshot(bool Available,float Peak,bool Muted)
{
    public static readonly AudioLevelSnapshot Unknown=new(false,0,false);
}
// Session peak meters only. No microphone, loopback recording or audio files.
sealed class WindowsAudioLevelMonitor:IDisposable
{
    readonly CancellationTokenSource stop=new();readonly Thread worker;AudioLevelSnapshot current=AudioLevelSnapshot.Unknown;
    public AudioLevelSnapshot Current=>Volatile.Read(ref current);
    public WindowsAudioLevelMonitor(){worker=new Thread(Run){IsBackground=true,Name="cncx-audio-meter"};worker.SetApartmentState(ApartmentState.MTA);worker.Start();}
    void Run()
    {
        var devices=new List<MMDevice>();var sessions=new List<(MMDevice Device,AudioSessionControl Session)>();DateTime refresh=DateTime.MinValue;
        try
        {
            using var enumerator=new MMDeviceEnumerator();
            while(!stop.IsCancellationRequested)
            {
                try
                {
                    if(DateTime.UtcNow>=refresh)
                    {
                        foreach(var s in sessions)SafeDispose(s.Session);sessions.Clear();foreach(var d in devices)SafeDispose(d);devices.Clear();
                        var owned=Descendants(Environment.ProcessId);
                        foreach(var device in enumerator.EnumerateAudioEndPoints(DataFlow.Render,DeviceState.Active))
                        {
                            bool used=false;
                            try
                            {
                                var all=device.AudioSessionManager.Sessions;
                                for(int i=0;i<all.Count;i++)
                                {
                                    var session=all[i];if(owned.Contains((int)session.GetProcessID)&&session.AudioMeterInformation!=null&&session.SimpleAudioVolume!=null){sessions.Add((device,session));used=true;}else SafeDispose(session);
                                }
                            }
                            catch{}
                            if(used)devices.Add(device);else SafeDispose(device);
                        }
                        refresh=DateTime.UtcNow.AddSeconds(2);
                    }
                    float peak=0;bool any=false,allMuted=true;
                    foreach(var item in sessions)
                    {
                        bool muted=item.Device.AudioEndpointVolume.Mute||item.Device.AudioEndpointVolume.MasterVolumeLevelScalar<=.01f||item.Session.SimpleAudioVolume.Mute||item.Session.SimpleAudioVolume.Volume<=.01f;
                        if(!muted){peak=Math.Max(peak,item.Session.AudioMeterInformation.MasterPeakValue);allMuted=false;}any=true;
                    }
                    Volatile.Write(ref current,new(any,peak,allMuted));
                }
                catch{Volatile.Write(ref current,AudioLevelSnapshot.Unknown);refresh=DateTime.MinValue;}
                stop.Token.WaitHandle.WaitOne(125);
            }
        }
        catch{Volatile.Write(ref current,AudioLevelSnapshot.Unknown);}
        finally{foreach(var s in sessions)SafeDispose(s.Session);foreach(var d in devices)SafeDispose(d);}
    }
    static void SafeDispose(IDisposable resource){try{resource.Dispose();}catch{}}
    [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)]struct ProcessEntry
    {
        public uint Size,Usage,Id;public UIntPtr Heap;public uint Module,Threads,Parent;public int Priority;public uint Flags;[MarshalAs(UnmanagedType.ByValTStr,SizeConst=260)]public string Name;
    }
    [DllImport("kernel32.dll",SetLastError=true)]static extern IntPtr CreateToolhelp32Snapshot(uint flags,uint id);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)]static extern bool Process32FirstW(IntPtr snapshot,ref ProcessEntry entry);
    [DllImport("kernel32.dll",CharSet=CharSet.Unicode)]static extern bool Process32NextW(IntPtr snapshot,ref ProcessEntry entry);
    [DllImport("kernel32.dll")]static extern bool CloseHandle(IntPtr handle);
    static HashSet<int> Descendants(int root)
    {
        var ids=new HashSet<int>{root};var map=new List<(int Id,int Parent)>();var snapshot=CreateToolhelp32Snapshot(2,0);if(snapshot==new IntPtr(-1))return ids;
        try{var entry=new ProcessEntry{Size=(uint)Marshal.SizeOf<ProcessEntry>(),Name=""};if(Process32FirstW(snapshot,ref entry))do{map.Add(((int)entry.Id,(int)entry.Parent));}while(Process32NextW(snapshot,ref entry));bool changed;do{changed=false;foreach(var p in map)if(ids.Contains(p.Parent))changed|=ids.Add(p.Id);}while(changed);return ids;}finally{CloseHandle(snapshot);}
    }
    public void Dispose(){stop.Cancel();}
}
