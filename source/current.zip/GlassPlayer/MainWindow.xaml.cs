using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Threading;
using System.Windows.Media;
using GlassPlayer.Core;
using Microsoft.Web.WebView2.Core;
using Microsoft.Win32;
namespace GlassPlayer;

public partial class MainWindow : Window
{
    static readonly JsonSerializerOptions Json=new(){PropertyNamingPolicy=JsonNamingPolicy.CamelCase};
    readonly AppSettings settings=AppSettings.Load();
    readonly Spotify spotify=new();
    readonly LyricsService lyrics=new();
    readonly WordLyricsProvider wordLyrics=new();
    readonly SoundCloudCatalog soundCloud=new();
    readonly SilenceGate silenceGate=new();
    double? lastQuietStart;long quietPosition;
    WindowsAudioLevelMonitor? levelMonitor;
    readonly Dictionary<string,CatalogEntity> catalogEntities=new();
    readonly List<string> recentSearches=new();
    readonly SemaphoreSlim searchHistoryWriter=new(1,1);
    readonly PlaybackQueue<Track> queue=new();
    readonly PlaybackClock clock=new();
    readonly ListeningHistory history=new();
    readonly ListeningHistoryStore historyStore=new(Path.Combine(AppSettings.DirectoryPath,"listening-history.json"));
    readonly LocalPlaylistStore local=new(Path.Combine(AppSettings.DirectoryPath,"local-playlists.json"));
    readonly Dictionary<string,Track> catalog=new();
    readonly Dictionary<string,CancellationTokenSource> requests=new();
    readonly Dictionary<string,PlaylistContent> opened=new();
    readonly Dictionary<string,LibraryPlaylist> knownPlaylists=new();
    readonly HttpClient publicHttp=new(){Timeout=TimeSpan.FromSeconds(15)};
    readonly SemaphoreSlim readerGate=new(1,1);
    readonly SemaphoreSlim mutationGate=new(1,1);
    readonly SemaphoreSlim playbackGate=new(1,1);
    readonly CancellationTokenSource lifetime=new();
    readonly DispatcherTimer timer=new(){Interval=TimeSpan.FromMilliseconds(400)};
    readonly DispatcherTimer audioTimer=new(){Interval=TimeSpan.FromMilliseconds(100)};
    readonly SpotifyLibraryClient library;
    readonly SearchRequestQueue<TrackSearchPage> searches;
    readonly SearchRequestQueue<CatalogPage> catalogSearches;
    WebPlayer? player;
    SoundCloudWebPlayer? scPlayer;string activeSource="Spotify";bool naturalEnded;
    Spotify.Profile? profile;
    CancellationTokenSource? trackWork;
    bool polling,loaded,closed,advancing;
    string? playbackError;
    long sequence,controlRevision;
    DateTime nextRemotePoll;
    public MainWindow()
    {
        InitializeComponent();lyricsPrefetch=new(WarmLyricsAsync);library=new(spotify.LibraryRequestAsync);searches=new(spotify.SearchPageAsync);catalogSearches=new(spotify.SearchCatalogAsync);
        if(settings.UiVersion<9){settings.UiVersion=9;settings.WindowWidth=1200;settings.WindowHeight=780;}
        if(settings.UiVersion<11)
        {
            settings.LyricsFontSize=32;settings.AnimationSpeed=1;
            settings.FadeSpeed=1.035;settings.FadeLeadMs=120;settings.UiVersion=11;
        }
        LoadSearchHistory();
        Width=Math.Clamp(settings.WindowWidth,820,Math.Max(820,SystemParameters.WorkArea.Width-24));Height=Math.Clamp(settings.WindowHeight,560,Math.Max(560,SystemParameters.WorkArea.Height-24));Topmost=settings.AlwaysOnTop;
        Spotify.PreferDesktop=settings.PreferSpotifyApp;Spotify.AutoLaunch=settings.LaunchSpotify;
        queue.Shuffle=settings.Shuffle;queue.Repeat=settings.Repeat;
        var saved=SessionStore.Load();Register(saved.Queue);if(saved.Queue.Count>0)queue.Start(saved.Queue,Math.Max(0,saved.Index));
        SetRadio(saved.Radio);InitializeTaskbar();
        history.Restore(historyStore.Load());Register(history.Entries.Select(e=>e.Track));
        try{local.Load();}catch(Exception ex){playbackError="Biblioteca local: "+ex.Message;}
        SourceInitialized+=(_,_)=>{ApplyWindowShape();tray=new TrayHost(this,RestoreWindow,ExitApplication);};SizeChanged+=(_,_)=>ApplyWindowShape();StateChanged+=(_,_)=>{ApplyWindowShape();Emit("window-state",WindowStatus());};DpiChanged+=(_,_)=>ApplyWindowShape();
        Loaded+=async(_,_)=>{_ = WatchUpdatesAsync();await InitializeAsync();};Closing+=OnClosing;timer.Tick+=async(_,_)=>await TickAsync();audioTimer.Tick+=(_,_)=>Emit("silence",SilenceStatus());
    }
    void ApplyWindowShape(){Browser.Margin=new Thickness(0);WindowShape.Apply(this,RootSurface,Math.Clamp(settings.CornerRadius,20,40));}
    object WindowStatus()=>new{maximized=WindowState==WindowState.Maximized};
    void MinimizeClick(object sender,RoutedEventArgs e)=>WindowState=WindowState.Minimized;
    void MaximizeClick(object sender,RoutedEventArgs e)=>WindowState=WindowState==WindowState.Maximized?WindowState.Normal:WindowState.Maximized;
    void CloseClick(object sender,RoutedEventArgs e)=>Close();
    async Task InitializeAsync()
    {
        try
        {
            var root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"cncx");
            var environment=await CoreWebView2Environment.CreateAsync(null,Path.Combine(root,"webview"),new CoreWebView2EnvironmentOptions("--autoplay-policy=no-user-gesture-required"));
            if(closed)return;await Browser.EnsureCoreWebView2Async(environment);if(closed)return;
            Browser.CoreWebView2.Settings.AreDefaultContextMenusEnabled=false;Browser.CoreWebView2.Settings.AreDevToolsEnabled=false;
            Browser.CoreWebView2.SetVirtualHostNameToFolderMapping("cncx.local",Path.Combine(AppContext.BaseDirectory,"Web"),CoreWebView2HostResourceAccessKind.DenyCors);
            Browser.CoreWebView2.NavigationStarting+=(_,e)=>{if(e.Uri!="https://cncx.local/index.html")e.Cancel=true;};
            Browser.CoreWebView2.NewWindowRequested+=(_,e)=>{e.Handled=true;};
            Browser.CoreWebView2.PermissionRequested+=(_,e)=>e.State=CoreWebView2PermissionState.Deny;
            Browser.CoreWebView2.WebMessageReceived+=OnMessage;
            player=new(Browser);spotify.Web=player;player.Ended+=OnMediaEnded;scPlayer=new(Browser);scPlayer.Ended+=OnMediaEnded;levelMonitor=new();
            Browser.CoreWebView2.Navigate("https://cncx.local/index.html");
        }
        catch(Exception ex){StartupStatus.Text="Falha ao abrir o hyse: "+ex.Message+"\nInstale o Microsoft Edge WebView2 Runtime e abra novamente.";Browser.Visibility=Visibility.Collapsed;}
    }
    void Emit(string type,object? data){if(!closed&&Browser.CoreWebView2!=null)Browser.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new{type,data},Json));}
    void Register(IEnumerable<Track> tracks){foreach(var t in tracks)if(MediaIdentity.Supported(t))catalog[t.Id]=t;}
    static string S(JsonElement args,string key,string fallback="")=>args.ValueKind==JsonValueKind.Object&&args.TryGetProperty(key,out var v)&&v.ValueKind==JsonValueKind.String?v.GetString()??fallback:fallback;
    static int I(JsonElement args,string key,int fallback=0)=>args.ValueKind==JsonValueKind.Object&&args.TryGetProperty(key,out var v)&&v.TryGetInt32(out var n)?n:fallback;
    static double D(JsonElement args,string key,double fallback=0)=>args.ValueKind==JsonValueKind.Object&&args.TryGetProperty(key,out var v)&&v.TryGetDouble(out var n)&&double.IsFinite(n)?n:fallback;
    static bool B(JsonElement args,string key,bool fallback=false)=>args.ValueKind==JsonValueKind.Object&&args.TryGetProperty(key,out var v)?v.ValueKind==JsonValueKind.True:fallback;
    Track TrackById(string id)=>catalog.TryGetValue(id,out var t)?t:throw new ArgumentException("Atualize a lista e selecione a música novamente.");
    async void OnMessage(object? sender,CoreWebView2WebMessageReceivedEventArgs e)
    {
        if(closed||e.Source!="https://cncx.local/index.html")return;
        string? id=null;CancellationTokenSource? cancellation=null;
        try
        {
            string raw=e.WebMessageAsJson;if(raw.Length>1024*1024)throw new ArgumentException("Pedido muito grande.");
            using var document=JsonDocument.Parse(raw);var m=document.RootElement;var type=S(m,"type");
            if(type=="window-drag"){WindowShape.Drag(this);return;}
            if(type=="window-resize"){WindowShape.Resize(this,S(m,"edge"));return;}
            if(type.StartsWith("sc-",StringComparison.Ordinal)){scPlayer?.Message(m);if(type=="sc-error")Emit("error",S(m,"error"));return;}
            if(type.StartsWith("sdk-",StringComparison.Ordinal)){player?.Message(m);if(type=="sdk-error")Emit("error","Dispositivo Spotify: "+S(m,"error"));return;}
            id=S(m,"id");if(!Regex.IsMatch(id,"^[a-zA-Z0-9-]{1,80}$"))return;
            if(type=="cancel"){if(requests.TryGetValue(id,out var pending))pending.Cancel();return;}
            if(type!="request"||requests.ContainsKey(id))return;
            cancellation=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token);requests[id]=cancellation;
            var result=await DispatchAsync(S(m,"method"),m.TryGetProperty("args",out var a)?a:default,id,cancellation.Token);
            cancellation.Token.ThrowIfCancellationRequested();Emit("response",new{id,ok=true,result});
        }
        catch(OperationCanceledException){if(id!=null)Emit("response",new{id,ok=false,error="Operação cancelada.",cancelled=true});}
        catch(Exception ex){if(id!=null)Emit("response",new{id,ok=false,error=ex.Message,code=ex is PlaylistAccessFailure?"playlist_access":null,diagnostics=(ex as PlaylistAccessFailure)?.Diagnostics});}
        finally{if(id!=null&&cancellation!=null){requests.Remove(id);cancellation.Dispose();}}
    }
    object Boot()=>new{version="0.14.0",windowState=WindowStatus(),settings,profile,personalProfile=PersonalView(),signedIn=spotify.SignedIn,configured=spotify.Enabled,queue=queue.Items,index=queue.Index,history=history.Entries,localPlaylists=local.List(),recentSearches,notice=playbackError};
    async Task<object?> DispatchAsync(string method,JsonElement a,string requestId,CancellationToken ct)
    {
        if(method=="queue.play")radioWork.Cancel();
        if(method is "queue.play" or "queue.next" or "queue.previous" or "playback.toggle" or "playback.seek" or "playback.volume" or "account.disconnect" or "settings.save")
        {
            await playbackGate.WaitAsync(ct);try{return await DispatchCoreAsync(method,a,requestId,ct);}finally{playbackGate.Release();}
        }
        return await DispatchCoreAsync(method,a,requestId,ct);
    }
    async Task<object?> DispatchCoreAsync(string method,JsonElement a,string requestId,CancellationToken ct)
    {
        switch(method)
        {
            case "window.tint":
                var color=Color.FromRgb((byte)Math.Clamp(I(a,"r",21),0,255),(byte)Math.Clamp(I(a,"g",21),0,255),(byte)Math.Clamp(I(a,"b",27),0,255));Background=new SolidColorBrush(color);return true;
            case "boot":
                loaded=true;UpdateDiscord();timer.Start();audioTimer.Start();_ = WarmupAsync();return Boot();
            case "sdk.token":if(!spotify.SignedIn)throw new UnauthorizedAccessException("Conecte o Spotify.");return await spotify.GetTokenAsync().WaitAsync(ct);
            case "account.connect":await spotify.ConnectAsync(ct);profile=await spotify.ProfileAsync();await spotify.WarmupAsync(ct);Emit("account",new{profile,signedIn=spotify.SignedIn,configured=spotify.Enabled});return profile;
            case "account.reauthorize":await spotify.ReauthorizeAsync(ct);profile=await spotify.ProfileAsync();Emit("account",new{profile,signedIn=true,configured=spotify.Enabled});return profile;
            case "account.disconnect":if(activeSource=="Spotify"){clock.Clear();trackWork?.Cancel();silenceGate.Reset();}spotify.SignOut();profile=null;PushState();Emit("account",new{profile,signedIn=false,configured=spotify.Enabled});return true;
            case "search.catalog":return await SearchCatalogAsync(S(a,"query"),S(a,"source","all"),I(a,"spotifyOffset"),S(a,"soundCloudCursor","0"),B(a,"more"),B(a,"includeSpotify",true),B(a,"includeSoundCloud",true),ct);
            case "search.history":return recentSearches.ToArray();
            case "search.remember":await RememberSearchAsync(S(a,"query"),ct);return true;
            case "search.history.clear":recentSearches.Clear();await SaveSearchHistoryAsync(ct);return true;
            case "catalog.open":return await OpenCatalogEntityAsync(S(a,"key"),ct);
            case "soundcloud.resolve":
                var resolved=await soundCloud.ResolveAsync(S(a,"url"),ct);Register(resolved.Tracks);if(resolved.Entity!=null)catalogEntities[EntityKey(resolved.Entity)]=resolved.Entity;return new{entity=resolved.Entity,tracks=resolved.Tracks};
            case "window.minimize":WindowState=WindowState.Minimized;return true;
            case "window.maximize":MaximizeClick(this,new RoutedEventArgs());return WindowStatus();
            case "window.close":Close();return true;
            case "search":
                var query=S(a,"query").Trim();if(query.Length is <1 or >300)return new TrackSearchPage(new(),0,null,0);
                var page=await searches.RunAsync(query,I(a,"offset"),ct,lifetime.Token);ct.ThrowIfCancellationRequested();Register(page.Tracks);return page;
            case "playlists.list":
                var remote=await library.MineAsync(ct);foreach(var p in remote)knownPlaylists[p.Id]=p;return local.List().Concat(remote).ToList();
            case "playlists.local":return local.List();
            case "playlist.open":
                var id=S(a,"id");if(!id.StartsWith("local-"))id=ImportLink.Parse(id.Length==22?"spotify:playlist:"+id:id).PlaylistId!;
                var content=id.StartsWith("local-")?local.Open(id):await OpenSpotifyPlaylistAsync(id,requestId,ct);
                Register(content.Tracks);opened[id]=content;return content;
            case "playlist.read-session":
                var sessionId=S(a,"id");if(sessionId.Length!=22)sessionId=ImportLink.Parse(sessionId).PlaylistId!;
                await readerGate.WaitAsync(ct);
                try
                {
                    if(profile==null)profile=await spotify.ProfileAsync();
                    var sessionContent=await SpotifySessionReader.ReadAsync(this,sessionId,knownPlaylists.GetValueOrDefault(sessionId),ct);
                    Register(sessionContent.Tracks);opened[sessionId]=sessionContent;knownPlaylists[sessionId]=sessionContent.Playlist;
                    await SaveSessionPlaylistAsync(sessionContent,ct);return sessionContent;
                }
                finally{readerGate.Release();}
            case "clipboard.copy":Clipboard.SetText(S(a,"text"));return true;
            case "playlist.create":
            case "playlist.update":
            case "playlist.add":
            case "playlist.remove":
            case "playlist.move":
            case "playlist.delete":
                await mutationGate.WaitAsync(ct);try{return await MutateAsync(method,a,ct);}finally{mutationGate.Release();}
            case "queue.play":
                var ids=a.GetProperty("ids").EnumerateArray().Select(x=>x.GetString()??"").Take(10001).ToList();var tracks=ids.Select(TrackById).ToList();int index=I(a,"index");
                if(index<0||index>=tracks.Count||!tracks[index].Available)throw new ArgumentException("A faixa selecionada está indisponível.");
                bool useRadio=B(a,"radio"),previousRadio=radioEnabled;
                if(useRadio){tracks=new(){tracks[index]};index=0;}
                var previousQueue=queue.Items.ToList();int previousIndex=queue.Index;SetRadio(useRadio);
                try{queue.Start(tracks,index);await PlayCurrentAsync(ct);return true;}
                catch{SetRadio(previousRadio);if(previousQueue.Count>0&&previousIndex>=0)queue.Start(previousQueue,previousIndex);else queue.Clear();PushState();throw;}
            case "queue.next":await AdvanceAsync(true,false);return true;
            case "queue.previous":await AdvanceAsync(true,true);return true;
            case "queue.mode":queue.Shuffle=B(a,"shuffle");queue.Repeat=(RepeatMode)Math.Clamp(I(a,"repeat"),0,2);settings.Shuffle=queue.Shuffle;settings.Repeat=queue.Repeat;settings.Save();lyricsPrefetch.Cancel();ScheduleNextLyrics();PushState();return true;
            case "playback.toggle":
                controlRevision++;
                if(clock.Uri==null){if(queue.Current!=null)await PlayCurrentAsync(ct);return true;}
                naturalEnded=false;if(clock.Playing){await PauseActiveAsync();clock.SetPlaying(false);}else{await ResumeActiveAsync();clock.SetPlaying(true);}PushState();return true;
            case "playback.seek":
                controlRevision++;
                int target=(int)Math.Clamp(I(a,"position"),0,clock.Duration);await SeekActiveAsync(target);naturalEnded=false;silenceGate.Reset();clock.Seek(target);PushState();return true;
            case "playback.volume":settings.Volume=Math.Clamp(D(a,"volume",.8),0,1);if(clock.Uri!=null)await VolumeActiveAsync(settings.Volume,ct);if(B(a,"commit",true))settings.Save();return true;
            case "history":return history.Entries;
            case "history.clear":history.Clear();await historyStore.SaveAsync(history.Entries);return true;
            case "lyrics.refresh":if(queue.Current!=null)await LoadLyricsAsync(queue.Current,true);return true;
            case "lyrics.import":return await ImportLyricsAsync(ct);
            case "lyrics.offset":
                if(queue.Current==null)return 0;int offset=Math.Clamp(I(a,"offset"),-10000,10000);settings.TrackOffsets[queue.Current.Id]=offset;settings.Save();return offset;
            case "profile.get":return PersonalView();
            case "profile.save":personal.Save(S(a,"name"),S(a,"bio"));return PersonalView();
            case "profile.image.pick":return PickPersonalImage(S(a,"kind"));
            case "profile.image.remove":personal.SetImage(S(a,"kind"),null);return PersonalView();
            case "app.info":return AppInformation();
            case "updates.status":return UpdateStatus();
            case "updates.check":return StartUpdateCheck();
            case "updates.restart":return RestartToUpdate();
            case "discord.status":return new{status=discord.Status};
            case "app.licenses":return AppLicenses();
            case "settings.save":SaveSettings(a);return settings;
            case "background.pick":return PickBackground();
            case "background.read":return ReadBackground();
            case "external.open":
                var url=S(a,"url");if(!Uri.TryCreate(url,UriKind.Absolute,out var uri)||uri.Scheme!="https"||uri.UserInfo.Length>0||!uri.IsDefaultPort||uri.Host is not("open.spotify.com" or "developer.spotify.com" or "github.com" or "soundcloud.com" or "www.soundcloud.com"))throw new ArgumentException("Endereço não permitido.");Process.Start(new ProcessStartInfo(url){UseShellExecute=true});return true;
            default:throw new ArgumentException("Ação desconhecida: "+method);
        }
    }
    string? SessionPlaylistPath(string id)
    {
        if(profile?.Id is not{Length:>0} userId||!Regex.IsMatch(id,"^[A-Za-z0-9]{22}$"))return null;
        var key=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(userId)))[..24];
        return Path.Combine(AppSettings.DirectoryPath,"playlist-sessions",key,id+".json");
    }
    PlaylistContent? LoadSessionPlaylist(string id)
    {
        var path=SessionPlaylistPath(id);if(path==null)return null;
        try
        {
            if(!File.Exists(path)||new FileInfo(path).Length>16*1024*1024)return null;
            var content=JsonSerializer.Deserialize<PlaylistContent>(File.ReadAllText(path),Json);
            if(content==null||content.Playlist.Id!=id||!content.ReadOnly||content.Access!="session"||content.Tracks.Count>10000||content.Tracks.Count!=content.Playlist.Count)return null;
            if(knownPlaylists.TryGetValue(id,out var latest)&&latest.Count!=content.Tracks.Count)return null;
            return content with{Notice="Playlist salva da sua sessão Spotify. Atualizar refaz a leitura na sessão."};
        }
        catch{return null;}
    }
    async Task SaveSessionPlaylistAsync(PlaylistContent content,CancellationToken ct)
    {
        var path=SessionPlaylistPath(content.Playlist.Id);if(path==null)return;Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temp=path+".tmp";await File.WriteAllTextAsync(temp,JsonSerializer.Serialize(content,Json),ct);ct.ThrowIfCancellationRequested();File.Move(temp,path,true);
    }
    async Task<PlaylistContent> OpenSpotifyPlaylistAsync(string id,string requestId,CancellationToken ct)
    {
        if(profile==null)profile=await spotify.ProfileAsync();
        if(LoadSessionPlaylist(id) is{} saved)return saved;
        void Progress(PlaylistContent content){knownPlaylists[id]=content.Playlist;Register(content.Tracks);Emit("playlist.progress",new{requestId,content});}
        HttpRequestException denied;
        try{return await library.OpenAsync(id,ct,Progress);}
        catch(HttpRequestException ex)when(ex.StatusCode is System.Net.HttpStatusCode.Forbidden or System.Net.HttpStatusCode.NotFound){denied=ex;}
        if(spotify.MissingPlaylistReadScopes)
        {
            Emit("playlist.stage",new{requestId,text="Atualizando permissões da conta Spotify…"});
            await spotify.ReauthorizeAsync(ct);profile=await spotify.ProfileAsync();Emit("account",new{profile,signedIn=true,configured=spotify.Enabled});
            try{return await library.OpenAsync(id,ct,Progress);}
            catch(HttpRequestException ex)when(ex.StatusCode is System.Net.HttpStatusCode.Forbidden or System.Net.HttpStatusCode.NotFound){denied=ex;}
        }
        string publicFailure;
        try{return await new SpotifyPublicPlaylistReader(publicHttp).ReadAsync(id,knownPlaylists.GetValueOrDefault(id),ct);}
        catch(Exception ex)when(!ct.IsCancellationRequested&&ex is HttpRequestException or FormatException or JsonException or TaskCanceledException){publicFailure=ex.Message;}
        knownPlaylists.TryGetValue(id,out var metadata);
        string diagnostics=$"hyse 0.12.0\nPlaylist: {id}\nConta conectada: {profile?.Id??"desconhecida"}\nDono: {metadata?.OwnerId??"não informado"}\nColaborativa: {metadata?.Collaborative}\nFaixas informadas: {metadata?.Count}\nScopes: {(spotify.GrantedScopes==null?"não informados pelo Spotify":string.Join(' ',spotify.GrantedScopes.Order()))}\nAPI: {denied.Message}\nLeitura pública: {publicFailure}";
        throw new PlaylistAccessFailure($"A API Spotify não liberou esta playlist ({(int)(denied.StatusCode??System.Net.HttpStatusCode.Forbidden)}). Abra pela sessão Spotify para ler as músicas da sua conta, ou atualize as permissões.",diagnostics);
    }
    async Task WarmupAsync()
    {
        try{profile=await spotify.ProfileAsync();if(closed)return;Emit("account",new{profile,signedIn=spotify.SignedIn,configured=spotify.Enabled});await spotify.WarmupAsync(lifetime.Token);}
        catch(Exception ex){Emit("error","Conexão Spotify: "+ex.Message);}
    }
    async Task<object> MutateAsync(string method,JsonElement a,CancellationToken ct)
    {
        string id=S(a,"id");bool isLocal=id.StartsWith("local-");
        if(method=="playlist.create")return S(a,"location")=="local"?local.Create(S(a,"name"),S(a,"description")):await library.CreateAsync(S(a,"name"),S(a,"description"),B(a,"public"),ct);
        if(method=="playlist.delete"){if(!isLocal)throw new ArgumentException("A exclusão está disponível apenas para playlists locais.");local.Delete(id);opened.Remove(id);return true;}
        if(!opened.TryGetValue(id,out var current))throw new ArgumentException("Abra a playlist antes de editar.");
        if(current.ReadOnly)throw new ArgumentException("A leitura pela sessão é somente para ouvir. Atualize as permissões Spotify para editar pela API.");
        if(!current.Stable)throw new ArgumentException("Atualize a playlist antes de editar.");
        if(!isLocal&&current.Playlist.OwnerId!=profile?.Id&&!current.Playlist.Collaborative)throw new ArgumentException("Esta playlist só permite leitura nesta conta.");
        switch(method)
        {
            case "playlist.update":if(isLocal)local.Update(id,S(a,"name"),S(a,"description"));else await library.UpdateAsync(id,S(a,"name"),S(a,"description"),B(a,"public"),ct);break;
            case "playlist.add":
                var track=TrackById(S(a,"trackId"));if(isLocal)local.Add(id,track);else{if(track.Source!="Spotify")throw new ArgumentException("Músicas SoundCloud podem ser adicionadas às playlists deste hyse.");await library.AddAsync(id,track.OpenUri!,ct);}break;
            case "playlist.remove":
                int at=I(a,"index",-1);if(at<0||at>=current.Tracks.Count)throw new ArgumentException("Selecione uma faixa da playlist.");
                if(isLocal)local.Remove(id,at);else await library.RemoveAsync(id,current.Tracks[at].OpenUri!,current.Playlist.Snapshot,ct);break;
            case "playlist.move":if(isLocal)local.Move(id,I(a,"from"),I(a,"to"));else await library.MoveAsync(id,I(a,"from"),I(a,"to"),current.Tracks.Count,current.Playlist.Snapshot,ct);break;
        }
        // Invalidate before the next edit: stale snapshots and positions never chain.
        opened.Remove(id);return new{refresh=true,id};
    }
    async void OnMediaEnded(string uri)
    {
        if(uri!=queue.Current?.OpenUri||advancing)return;advancing=true;
        try
        {
            await playbackGate.WaitAsync(lifetime.Token);
            try{if(uri!=queue.Current?.OpenUri)return;naturalEnded=true;clock.Update(clock.Duration,clock.Duration,false,uri,true);await AdvanceAsync(false,false);}
            finally{playbackGate.Release();}
        }
        catch(OperationCanceledException){}catch(Exception ex){Emit("error",ex.Message);}finally{advancing=false;}
    }
    Task PauseActiveAsync()=>activeSource=="SoundCloud"?scPlayer!.CallAsync("pause"):spotify.PauseAsync();
    Task ResumeActiveAsync()=>activeSource=="SoundCloud"?scPlayer!.CallAsync("resume"):spotify.ResumeAsync();
    Task SeekActiveAsync(int value)=>activeSource=="SoundCloud"?scPlayer!.CallAsync("seek",value):spotify.SeekAsync(value);
    Task VolumeActiveAsync(double value,CancellationToken ct)=>activeSource=="SoundCloud"?scPlayer!.CallAsync("volume",value,ct:ct):spotify.SetVolumeAsync(value,ct);
    async Task PlayCurrentAsync(CancellationToken ct)
    {
        var track=queue.Current;if(track==null)return;controlRevision++;lyricsPrefetch.Cancel();lyricsLoading.Cancel();
        trackWork?.Cancel();trackWork?.Dispose();trackWork=CancellationTokenSource.CreateLinkedTokenSource(ct,lifetime.Token);var token=trackWork.Token;
        if(clock.Uri!=null&&activeSource!=track.Source)await PauseActiveAsync();token.ThrowIfCancellationRequested();
        clock.Clear();naturalEnded=false;silenceGate.Reset();activeSource=track.Source;PushState();
        string device;
        if(track.Source=="SoundCloud"){await scPlayer!.PlayAsync(track,token);device="SoundCloud";}else device=await spotify.PlayAsync(track.OpenUri!,token);
        token.ThrowIfCancellationRequested();clock.Update(0,track.DurationMs,false,track.OpenUri,true);history.Begin(track,DateTimeOffset.UtcNow);playbackError=null;
        SessionStore.Save(queue.Items,queue.Index,radioEnabled);Emit("track",new{track,device,index=queue.Index,queue=queue.Items});PushState();_ = LoadLyricsAsync(track);await VolumeActiveAsync(settings.Volume,token);_ = WarmRadioAsync();
    }
    async Task AdvanceAsync(bool manual,bool previous)
    {
        if(previous&&clock.Position>3000){await SeekActiveAsync(0);clock.Seek(0);PushState();return;}
        if(!previous&&radioEnabled&&(queue.PeekNext(manual)==null||queue.Items.Count==1&&queue.Repeat==RepeatMode.All))await WarmRadioAsync();
        Track? next=previous?queue.Previous():queue.Next(manual);int attempts=0;
        while(next!=null&&!next.Available&&attempts++<queue.Items.Count)next=previous?queue.Previous():queue.Next(true);
        if(next==null||!next.Available){clock.SetPlaying(false);PushState();return;}await PlayCurrentAsync(lifetime.Token);
    }
    async Task TickAsync()
    {
        if(!loaded||polling||closed||clock.Uri==null||activeSource=="Spotify"&&!spotify.SignedIn)return;polling=true;
        try
        {
            if(activeSource=="Spotify"&&!spotify.UsesWebDevice&&DateTime.UtcNow<nextRemotePoll){PushState();return;}
            nextRemotePoll=DateTime.UtcNow.AddMilliseconds(1200);long revision=controlRevision;
            var state=activeSource=="SoundCloud"?scPlayer?.Current():await spotify.StateAsync();if(closed||revision!=controlRevision)return;
            if(state is{} s&&s.Uri==queue.Current?.OpenUri)
            {
                bool ended=activeSource=="Spotify"&&!spotify.UsesWebDevice&&clock.Playing&&!s.Playing&&s.Progress==0&&clock.Duration>0&&clock.Position>=clock.Duration-1500;
                clock.Update(s.Progress,s.Duration,s.Playing,s.Uri);if(ended&&!advancing){advancing=true;try{await playbackGate.WaitAsync(lifetime.Token);try{if(revision!=controlRevision)return;naturalEnded=true;await AdvanceAsync(false,false);}finally{playbackGate.Release();}}finally{advancing=false;}return;}
                if(history.Observe(clock.Position,s.Playing,Stopwatch.GetTimestamp()*1000d/Stopwatch.Frequency))await historyStore.SaveAsync(history.Entries);
            }
            PushState();
        }
        catch(Exception ex){clock.SetPlaying(false);if(playbackError!=ex.Message){playbackError=ex.Message;Emit("error",ex.Message);}PushState();}
        finally{polling=false;}
    }
    object SilenceStatus()
    {
        var levels=levelMonitor?.Current??AudioLevelSnapshot.Unknown;bool local=activeSource=="SoundCloud"||spotify.UsesWebDevice;
        bool fresh=activeSource=="SoundCloud"?scPlayer?.FreshPosition==true:player?.FreshPosition==true;
        double now=Stopwatch.GetTimestamp()*1000d/Stopwatch.Frequency;
        bool silent=silenceGate.Observe(queue.Current?.Id,settings.SilenceWordHighlight,local,levels.Available,levels.Peak,levels.Muted,settings.Volume,clock.Playing,naturalEnded,fresh,now);
        var quietStart=silenceGate.QuietStartedAt;if(quietStart!=lastQuietStart){lastQuietStart=quietStart;if(quietStart!=null)quietPosition=clock.Position;}
        return new{available=local&&levels.Available,audible=local&&levels.Available&&!levels.Muted&&levels.Peak>.0001&&settings.Volume>.01,silent,position=quietStart.HasValue?(long?)quietPosition:null};
    }
    void PushState(){UpdateDiscord();UpdateTaskbar();Emit("playback",new{sequence=++sequence,position=clock.Position,duration=clock.Duration,playing=clock.Playing,webDevice=activeSource=="Spotify"&&spotify.UsesWebDevice,source=activeSource,uri=clock.Uri,track=queue.Current,index=queue.Index,shuffle=queue.Shuffle,repeat=(int)queue.Repeat,volume=settings.Volume,silence=SilenceStatus()});}
    async Task<object?> ImportLyricsAsync(CancellationToken ct)
    {
        var track=queue.Current??throw new ArgumentException("Escolha uma música antes de importar a letra.");
        var picker=new OpenFileDialog{Filter="Letras sincronizadas|*.lrc;*.ttml;*.yaml;*.yml;*.lyricsfile|Texto|*.txt",Title="Importar letra para "+track.Title};if(picker.ShowDialog(this)!=true)return null;
        if(new FileInfo(picker.FileName).Length>1024*1024)throw new ArgumentException("O arquivo deve ter até 1 MB.");
        var text=await File.ReadAllTextAsync(picker.FileName,ct);var extension=Path.GetExtension(picker.FileName).ToLowerInvariant();var lines=extension==".ttml"?TtmlReader.Parse(text):extension is ".yaml" or ".yml" or ".lyricsfile"?LyricsfileReader.Parse(text):LyricsParser.Parse(text);
        if(track.Id==queue.Current?.Id&&track.Source==queue.Current?.Source){lyricsLoading.Cancel();lyricsBusy=false;await lyricsPrefetch.CancelAsync();}
        var document=new LyricsDocument(track.Title,track.Artist,lines,lines.Count==0?text:null,false,"Arquivo local"){SpicyTtml=extension==".ttml"?text:null};await lyrics.SaveOverrideAsync(track,document,ct);if(track.Id==queue.Current?.Id)Emit("lyrics",new{trackId=track.Id,document,offset=settings.TrackOffsets.GetValueOrDefault(track.Id)});ScheduleNextLyrics();return document;
    }
    void SaveSettings(JsonElement a)
    {
        string client=S(a,"clientId",settings.SpotifyClientId??"").Trim();if(client.Length>0&&!Regex.IsMatch(client,"^[a-fA-F0-9]{32}$"))throw new ArgumentException("O Client ID deve ter 32 caracteres hexadecimais.");
        if(a.TryGetProperty("clientId",out var suppliedClient)&&suppliedClient.ValueKind==JsonValueKind.String&&client!=(settings.SpotifyClientId??"")){spotify.SignOut();settings.SpotifyClientId=client;Config.SetSpotify(client);profile=null;if(activeSource=="Spotify"){clock.Clear();trackWork?.Cancel();silenceGate.Reset();}PushState();Emit("account",new{profile,signedIn=false,configured=spotify.Enabled});}
        string shape=S(a,"artworkShape",settings.ArtworkShape);if(shape is not("auto" or "rounded" or "square" or "circle" or "squircle" or "petal"))throw new ArgumentException("Formato de capa inválido.");settings.ArtworkShape=shape;
        settings.ArtworkScale=Math.Clamp(D(a,"artworkScale",settings.ArtworkScale),.75,1.2);
        settings.LowEffects=B(a,"lowEffects",settings.LowEffects);settings.ArtworkMotion=B(a,"artworkMotion",settings.ArtworkMotion);settings.AnimatedBackground=B(a,"animatedBackground",settings.AnimatedBackground);
        settings.BackgroundMotion=Math.Clamp(D(a,"backgroundMotion",settings.BackgroundMotion),.2,2);
        settings.FadeSpeed=Math.Clamp(D(a,"fadeSpeed",settings.FadeSpeed),.9,1.15);settings.FadeLeadMs=Math.Clamp(I(a,"fadeLeadMs",settings.FadeLeadMs),-750,750);
        settings.PreferWordLyrics=B(a,"preferWordLyrics",settings.PreferWordLyrics);
        settings.SilenceWordHighlight=B(a,"silenceWordHighlight",settings.SilenceWordHighlight);
        settings.AnimationSpeed=Math.Clamp(D(a,"animationSpeed",settings.AnimationSpeed),.5,2.5);settings.LyricsFontSize=Math.Clamp(D(a,"lyricsFontSize",settings.LyricsFontSize),20,58);
        settings.LyricsBlur=Math.Clamp(D(a,"lyricsBlur",settings.LyricsBlur),0,80);settings.LyricsTransparency=Math.Clamp(D(a,"lyricsTransparency",settings.LyricsTransparency),0,1);
        settings.LyricsMode="Fade";settings.ReducedMotion=B(a,"reducedMotion",settings.ReducedMotion);settings.LyricsAlbumBackground=B(a,"albumBackground",settings.LyricsAlbumBackground);
        settings.DiscordEnabled=B(a,"discordEnabled",settings.DiscordEnabled);settings.DiscordArtwork=B(a,"discordArtwork",settings.DiscordArtwork);
        settings.DiscordTime=B(a,"discordTime",settings.DiscordTime);settings.DiscordButton=B(a,"discordButton",settings.DiscordButton);settings.DiscordHidePaused=B(a,"discordHidePaused",settings.DiscordHidePaused);
        settings.DiscordText=S(a,"discordText",settings.DiscordText)=="app"?"app":"track";
        settings.AutomaticUpdates=B(a,"automaticUpdates",settings.AutomaticUpdates);
        settings.PreferSpotifyApp=B(a,"preferSpotifyApp",settings.PreferSpotifyApp);Spotify.PreferDesktop=settings.PreferSpotifyApp;settings.AlwaysOnTop=B(a,"alwaysOnTop",settings.AlwaysOnTop);Topmost=settings.AlwaysOnTop;settings.Save();UpdateDiscord();Emit("update",UpdateStatus());
    }
    object? PickBackground(){var picker=new OpenFileDialog{Filter="Imagem|*.png;*.jpg;*.jpeg;*.webp",Title="Fundo do hyse"};if(picker.ShowDialog(this)!=true)return null;if(new FileInfo(picker.FileName).Length>10*1024*1024)throw new ArgumentException("A imagem deve ter até 10 MB.");settings.BackgroundImage=picker.FileName;settings.LyricsAlbumBackground=false;settings.Save();return ReadBackground();}
    string? ReadBackground(){var file=settings.BackgroundImage;if(file==null||!File.Exists(file)||new FileInfo(file).Length>10*1024*1024)return null;string mime=Path.GetExtension(file).ToLowerInvariant() switch{".png"=>"image/png",".webp"=>"image/webp",_=>"image/jpeg"};return "data:"+mime+";base64,"+Convert.ToBase64String(File.ReadAllBytes(file));}
    void OnClosing(object? sender,System.ComponentModel.CancelEventArgs e)
    {
        if(closed)return;if(Core.CloseBehavior.HideToTray(exiting,sessionEnding,tray?.EnsureAvailable()==true)){e.Cancel=true;Hide();return;}closed=true;radioWork.Dispose();discord.Dispose();tray?.Dispose();lyricsPrefetch.Dispose();lyricsLoading.Dispose();timer.Stop();audioTimer.Stop();lifetime.Cancel();trackWork?.Cancel();player?.Dispose();scPlayer?.Dispose();levelMonitor?.Dispose();settings.WindowWidth=RestoreBounds.Width;settings.WindowHeight=RestoreBounds.Height;
        try{settings.Save();SessionStore.Save(queue.Items,queue.Index,radioEnabled);historyStore.SaveAsync(history.Entries).GetAwaiter().GetResult();}catch{}if(!restartForUpdate&&!installerExit&&UpdateHandoff.ApplyOnExit(exiting,sessionEnding,settings.AutomaticUpdates,preparedUpdate!=null))StartUpdateHelper(false);updates.Dispose();lyrics.Dispose();publicHttp.Dispose();wordLyrics.Dispose();soundCloud.Dispose();Browser.Dispose();
    }
}
