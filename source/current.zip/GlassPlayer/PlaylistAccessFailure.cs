namespace GlassPlayer;
sealed class PlaylistAccessFailure(string message,string diagnostics) : Exception(message)
{
    public string Diagnostics{get;}=diagnostics;
}
