using System.Net;
using System.Net.Http;
using System.Text.Json;
using GlassPlayer.Core;
namespace GlassPlayer;
public partial class MainWindow
{
    readonly LatestOperation radioWork=new();
    Task<int>? radioLoading;
    bool radioEnabled,spotifyRecommendationsUnavailable;
    DateTime nextRadioAttempt;
    readonly Dictionary<string,int> spotifyRadioOffsets=new(StringComparer.OrdinalIgnoreCase);
    readonly Dictionary<string,string> cloudRadioOffsets=new(StringComparer.OrdinalIgnoreCase);
    readonly Dictionary<string,string[]> radioGenres=new(StringComparer.OrdinalIgnoreCase);
    RadioPlanner? radioPlanner;
    void SetRadio(bool enabled){radioWork.Cancel();radioEnabled=enabled;radioLoading=null;nextRadioAttempt=DateTime.MinValue;}
    async Task<IReadOnlyList<Track>> RelatedTracksAsync(Track seed,CancellationToken ct)
    {
        if(seed.Source=="SoundCloud")
        {
            using var cloud=CancellationTokenSource.CreateLinkedTokenSource(ct);cloud.CancelAfter(TimeSpan.FromSeconds(4));
            try{return await soundCloud.RelatedAsync(seed,cloud.Token);}catch(OperationCanceledException)when(!ct.IsCancellationRequested){return Array.Empty<Track>();}
        }
        // Prefer the real queue supplied by Spotify for this exact playing song.
        try
        {
            using var request=CancellationTokenSource.CreateLinkedTokenSource(ct);request.CancelAfter(TimeSpan.FromSeconds(3));
            using var doc=JsonDocument.Parse(await spotify.CatalogRequestAsync("/me/player/queue",request.Token));
            var native=RadioDiscovery.SpotifyQueue(doc.RootElement,seed);if(native.Count>0)return native;
        }
        catch(OperationCanceledException)when(!ct.IsCancellationRequested){}catch(Exception ex)when(ex is HttpRequestException or JsonException or FormatException or InvalidOperationException){}
        if(!spotifyRecommendationsUnavailable)
        {
            try
            {
                using var request=CancellationTokenSource.CreateLinkedTokenSource(ct);request.CancelAfter(TimeSpan.FromSeconds(4));
                using var doc=JsonDocument.Parse(await spotify.CatalogRequestAsync("/recommendations?limit=30&seed_tracks="+Uri.EscapeDataString(seed.Id),request.Token));
                var tracks=new List<Track>();foreach(var item in doc.RootElement.GetProperty("tracks").EnumerateArray())try{tracks.Add(SpotifyPlaylistReader.ToTrack(item));}catch(FormatException){}
                if(tracks.Count>0)return tracks;
            }
            catch(HttpRequestException ex)when(ex.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.NotFound or HttpStatusCode.Gone){spotifyRecommendationsUnavailable=true;}
            catch(OperationCanceledException)when(!ct.IsCancellationRequested){}
            catch(HttpRequestException){}
        }
        // Public catalog discovery when private recommendations are unavailable.
        // Genre metadata is optional; an empty metadata response falls through to artist pages.
        string artist=RadioPlanner.PrimaryArtist(seed.Artist);var found=new List<Track>();
        try
        {
            using var request=CancellationTokenSource.CreateLinkedTokenSource(ct);request.CancelAfter(TimeSpan.FromSeconds(5));
            if(!radioGenres.TryGetValue(artist,out var genres))
            {
                using var doc=JsonDocument.Parse(await spotify.CatalogRequestAsync("/search?type=artist&limit=5&q="+Uri.EscapeDataString(artist),request.Token));
                genres=RadioDiscovery.Genres(doc.RootElement,artist);if(radioGenres.Count>=100)radioGenres.Clear();radioGenres[artist]=genres;
            }
            foreach(string genre in genres.Take(2))found.AddRange(await SpotifyRadioPageAsync("genre:\""+genre.Replace('"',' ')+"\"",request.Token));
        }
        catch(OperationCanceledException)when(!ct.IsCancellationRequested){}catch(Exception ex)when(ex is HttpRequestException or JsonException or FormatException or InvalidOperationException){}
        ct.ThrowIfCancellationRequested();return found;
    }
    async Task<IReadOnlyList<Track>> SpotifyRadioPageAsync(string query,CancellationToken ct)
    {
        int offset=spotifyRadioOffsets.GetValueOrDefault(query);var songs=await spotify.SearchPageAsync(query,offset,ct);
        if(spotifyRadioOffsets.Count>200)spotifyRadioOffsets.Clear();spotifyRadioOffsets[query]=songs.NextOffset??0;return songs.Tracks;
    }
    async Task<IReadOnlyList<Track>> ArtistRadioAsync(string source,string artist,CancellationToken ct)
    {
        artist=artist.Replace('"',' ').Trim();if(artist.Length>120)artist=artist[..120];
        using var request=CancellationTokenSource.CreateLinkedTokenSource(ct);request.CancelAfter(TimeSpan.FromSeconds(3));
        try
        {
            if(source=="SoundCloud")
            {
                var page=await soundCloud.SearchAsync(artist,cloudRadioOffsets.GetValueOrDefault(artist,"0"),request.Token);
                if(cloudRadioOffsets.Count>200)cloudRadioOffsets.Clear();cloudRadioOffsets[artist]=page.NextCursor??"0";return page.Tracks;
            }
            return await SpotifyRadioPageAsync("artist:\""+artist+"\"",request.Token);
        }
        catch(OperationCanceledException)when(!ct.IsCancellationRequested){return Array.Empty<Track>();}
    }
    Task<int> WarmRadioAsync(bool force=false)
    {
        if(!radioEnabled||closed||queue.Current==null||queue.RemainingCount>6||queue.Repeat==RepeatMode.All&&queue.Items.Count>1)return Task.FromResult(0);
        if(radioLoading is{IsCompleted:false})return radioLoading;
        if(!force&&DateTime.UtcNow<nextRadioAttempt)return Task.FromResult(0);
        nextRadioAttempt=DateTime.UtcNow.AddSeconds(20);
        queue.TrimPlayed();var operation=radioWork.Begin();var seed=queue.Current;
        var heard=queue.Items.Concat(history.Entries.Take(40).Select(e=>e.Track)).ToArray();
        var known=history.Entries.Select(e=>e.Track).Concat(catalog.Values).Where(t=>t.Source==seed.Source).DistinctBy(t=>t.Id).Take(1000).ToArray();
        return radioLoading=FillRadioAsync(seed,heard,known,operation);
    }
    async Task<int> FillRadioAsync(Track seed,Track[] heard,Track[] known,(long Version,CancellationToken Token) operation)
    {
        using var work=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token,operation.Token);work.CancelAfter(TimeSpan.FromSeconds(40));
        try
        {
            radioPlanner??=new(RelatedTracksAsync,ArtistRadioAsync);var tracks=await radioPlanner.BuildAsync(seed,heard,known,work.Token);
            if(closed||!radioEnabled||!radioWork.IsCurrent(operation.Version)||tracks.Count==0)return 0;
            var unique=radioPlanner.Select(seed,tracks,queue.Items.Concat(history.Entries.Take(40).Select(e=>e.Track)),20,preserveOrder:true);
            if(unique.Count==0)return 0;Register(unique);queue.Append(unique);
            SessionStore.Save(queue.Items,queue.Index,radioEnabled);Emit("queue",new{queue=queue.Items,index=queue.Index});ScheduleNextLyrics();UpdateTaskbar();return unique.Count;
        }
        catch(OperationCanceledException){return 0;}catch(Exception){return 0;}
    }
}
