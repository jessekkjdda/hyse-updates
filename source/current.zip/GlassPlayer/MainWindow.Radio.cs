using System.Net;
using System.Net.Http;
using System.Text.Json;
using GlassPlayer.Core;

namespace GlassPlayer;

public partial class MainWindow
{
    readonly LatestOperation radioWork=new();
    Task? radioLoading;
    bool radioEnabled,spotifyRecommendationsUnavailable;
    readonly Dictionary<string,int> spotifyRadioOffsets=new(StringComparer.OrdinalIgnoreCase);
    readonly Dictionary<string,string> cloudRadioOffsets=new(StringComparer.OrdinalIgnoreCase);
    RadioPlanner? radioPlanner;
    void SetRadio(bool enabled){radioWork.Cancel();radioEnabled=enabled;radioLoading=null;}
    async Task<IReadOnlyList<Track>> RelatedTracksAsync(Track seed,CancellationToken ct)
    {
        if(seed.Source=="SoundCloud")return await soundCloud.RelatedAsync(seed,ct);
        if(spotifyRecommendationsUnavailable)return Array.Empty<Track>();
        try
        {
            using var doc=JsonDocument.Parse(await spotify.CatalogRequestAsync("/recommendations?limit=30&seed_tracks="+Uri.EscapeDataString(seed.Id),ct));
            var tracks=new List<Track>();
            foreach(var item in doc.RootElement.GetProperty("tracks").EnumerateArray())try{tracks.Add(SpotifyPlaylistReader.ToTrack(item));}catch(FormatException){}
            return tracks;
        }
        catch(HttpRequestException ex)when(ex.StatusCode is HttpStatusCode.Forbidden or HttpStatusCode.NotFound or HttpStatusCode.Gone)
        {spotifyRecommendationsUnavailable=true;return Array.Empty<Track>();}
    }
    async Task<IReadOnlyList<Track>> ArtistRadioAsync(string source,string artist,CancellationToken ct)
    {
        artist=artist.Replace('"',' ').Trim();if(artist.Length>120)artist=artist[..120];
        if(source=="SoundCloud")
        {
            var page=await soundCloud.SearchAsync(artist,cloudRadioOffsets.GetValueOrDefault(artist,"0"),ct);
            if(cloudRadioOffsets.Count>200)cloudRadioOffsets.Clear();cloudRadioOffsets[artist]=page.NextCursor??"0";return page.Tracks;
        }
        var songs=await spotify.SearchPageAsync("artist:\""+artist+"\"",spotifyRadioOffsets.GetValueOrDefault(artist),ct);
        if(spotifyRadioOffsets.Count>200)spotifyRadioOffsets.Clear();spotifyRadioOffsets[artist]=songs.NextOffset??0;return songs.Tracks;
    }
    Task WarmRadioAsync()
    {
        if(!radioEnabled||closed||queue.Current==null||queue.RemainingCount>4||queue.Repeat==RepeatMode.All&&queue.Items.Count>1)return Task.CompletedTask;
        if(radioLoading is{IsCompleted:false})return radioLoading;
        var operation=radioWork.Begin();var seed=queue.Current;
        var heard=queue.Items.Concat(history.Entries.Take(40).Select(e=>e.Track)).ToArray();
        var known=history.Entries.Select(e=>e.Track).Concat(catalog.Values).Where(t=>t.Source==seed.Source).DistinctBy(t=>t.Id).Take(1000).ToArray();
        return radioLoading=FillRadioAsync(seed,heard,known,operation);
    }
    async Task FillRadioAsync(Track seed,Track[] heard,Track[] known,(long Version,CancellationToken Token) operation)
    {
        using var work=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token,operation.Token);work.CancelAfter(TimeSpan.FromSeconds(12));
        try
        {
            radioPlanner??=new(RelatedTracksAsync,ArtistRadioAsync);
            var tracks=await radioPlanner.BuildAsync(seed,heard,known,work.Token);
            if(closed||!radioEnabled||!radioWork.IsCurrent(operation.Version)||tracks.Count==0)return;
            var unique=radioPlanner.Select(seed,tracks,queue.Items.Concat(history.Entries.Take(40).Select(e=>e.Track)),Math.Min(20,10000-queue.Items.Count));
            if(unique.Count==0)return;Register(unique);queue.Append(unique);
            SessionStore.Save(queue.Items,queue.Index,radioEnabled);Emit("queue",new{queue=queue.Items,index=queue.Index});ScheduleNextLyrics();UpdateTaskbar();
        }
        catch(OperationCanceledException){}catch(Exception){/* Optional discovery never changes the current playback state. */}
    }
}
