// Device samples and animation frames share performance.now(). Metadata/RPC
// samples are a fallback; they do not restart a fresh local device clock.
export class PlaybackTimeline{
  constructor(now=()=>performance.now()){this.now=now;this.uri=null;this.at=0;this.position=0;this.duration=0;this.playing=false;this.localAt=-Infinity;this.lastRaw=-1;this.pending=null;}
  sample(data,local=false){
    const now=this.now(),uri=data.uri||data.track?.openUri;if(!uri||!Number.isFinite(data.position))return false;
    if(!local&&uri===this.uri&&now-this.localAt<1000)return false;
    if(uri!==this.uri){this.pending=null;this.lastRaw=-1;this.localAt=-Infinity;this.uri=uri;}
    if(this.pending&&now-this.pending.at<1200&&Math.abs(data.position-this.pending.position)>Math.max(350,now-this.pending.at+250))return false;
    this.pending=null;if(local)this.localAt=now;
    const playing=!!data.playing,duration=Math.max(0,data.duration||0);
    if(playing&&this.playing&&data.position===this.lastRaw&&duration===this.duration)return true;
    const current=this.current,error=data.position-current;
    this.position=Math.max(0,Math.min(duration,Math.abs(error)<75&&playing&&this.playing&&this.at>0?current:data.position));this.lastRaw=data.position;this.at=now;this.duration=duration;this.playing=playing;return true;
  }
  get current(){return Math.max(0,Math.min(this.duration,this.position+(this.playing?Math.min(1600,Math.max(0,this.now()-this.at)):0)));}
  seek(position){this.position=Math.max(0,Math.min(this.duration,position));this.at=this.now();this.lastRaw=-1;this.pending={position:this.position,at:this.at};}
  reset(){this.uri=null;this.position=0;this.duration=0;this.playing=false;this.localAt=-Infinity;this.pending=null;this.lastRaw=-1;}
}
