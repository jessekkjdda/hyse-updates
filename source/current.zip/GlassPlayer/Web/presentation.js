export function coverShape(shape='rounded',identity=''){
  if(shape==='auto'){let hash=0;for(const c of identity)hash=(Math.imul(hash,31)+c.codePointAt(0))>>>0;shape=['rounded','circle','squircle','petal','square'][hash%5];}
  if(shape==='circle')return{radius:'50%',clip:'none'};
  if(shape==='square')return{radius:'2px',clip:'none'};
  if(shape==='squircle'){const points=[];for(let i=0;i<128;i++){const a=i/128*Math.PI*2,c=Math.cos(a),s=Math.sin(a);points.push(`${(50+49*Math.sign(c)*Math.sqrt(Math.abs(c))).toFixed(3)}% ${(50+49*Math.sign(s)*Math.sqrt(Math.abs(s))).toFixed(3)}%`);}return{radius:'0',clip:`polygon(${points.join(',')})`};}
  if(shape==='petal'){
    const points=[];for(let i=0;i<120;i++){const a=i/120*Math.PI*2,r=45+4*Math.cos(7*a);points.push(`${(50+r*Math.cos(a)).toFixed(3)}% ${(50+r*Math.sin(a)).toFixed(3)}%`);}return{radius:'0',clip:`polygon(${points.join(',')})`};
  }
  return{radius:'5%',clip:'none'};
}
export function applyCoverSettings(settings,root=document.documentElement,identity=''){const s=coverShape(settings.artworkShape,identity);root.style.setProperty('--cover-radius',s.radius);root.style.setProperty('--cover-clip',s.clip);root.style.setProperty('--cover-scale',String(Math.max(.75,Math.min(1.2,settings.artworkScale||1))));root.classList.toggle('artwork-static',settings.artworkMotion===false);}
export function formatSetting(value,unit=''){const n=Number(value);return `${Number.isFinite(n)?Number(n.toFixed(unit==='×'?2:unit===' px'||unit===' ms'?0:2)):0}${unit}`;}
