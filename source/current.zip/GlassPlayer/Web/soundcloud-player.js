import {post,localEvent} from './bridge.js';
let lastNativeAt=-Infinity,lastNativeKey='';
let activeLoadId=null,finishedForGeneration=false;
let widget=null,initializing=null,generation=0,readyForTrack=false,expectedId='',uri='',position=0,duration=0,playing=false,sampling=false,interval=null,pendingPlay=null;
const get=(method)=>new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(new Error('SoundCloud demorou para responder.')),3500);widget[method](value=>{clearTimeout(timeout);resolve(value);});});
function publish(){if(readyForTrack){localEvent('device-state',{source:'SoundCloud',uri,position,duration,playing});const now=performance.now(),key=`${uri}:${playing}:${duration}`;if(key!==lastNativeKey||now-lastNativeAt>=200){lastNativeAt=now;lastNativeKey=key;post({type:'sc-state',uri,position:Math.round(position),duration:Math.round(duration),playing});}}}
function acknowledge(id,ok,error){post({type:'sc-command',id,ok,error});}
function finishPending(error){if(pendingPlay){acknowledge(pendingPlay.id,false,error);pendingPlay=null;}}
async function loadSdk(){
  if(window.SC?.Widget)return;
  await new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='https://w.soundcloud.com/player/api.js';const timeout=setTimeout(()=>reject(new Error('Não foi possível abrir o player SoundCloud.')),12000);script.onload=()=>{clearTimeout(timeout);resolve();};script.onerror=()=>{clearTimeout(timeout);script.remove();reject(new Error('Falha ao carregar o SoundCloud.'));};document.head.append(script);});
}
async function init(firstUrl){
  if(widget)return;if(initializing)return initializing;
  initializing=(async()=>{
    await loadSdk();const frame=document.createElement('iframe');frame.id='soundcloud-media';frame.title='Player SoundCloud';frame.allow='autoplay';frame.src='https://w.soundcloud.com/player/?url='+encodeURIComponent(firstUrl)+'&auto_play=false&visual=false&show_artwork=false&sharing=false&download=false&buying=false';
    const host=document.querySelector('#media-host')||document.body;host.append(frame);widget=window.SC.Widget(frame);const events=window.SC.Widget.Events;
    await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(new Error('O player SoundCloud não ficou pronto.')),18000);widget.bind(events.READY,()=>{clearTimeout(timeout);resolve();});widget.bind(events.ERROR,()=>{clearTimeout(timeout);reject(new Error('Esta música não está disponível no player do SoundCloud.'));});});
    widget.bind(events.PLAY,async()=>{const epoch=generation;if(!readyForTrack)return;try{const sound=await get('getCurrentSound');if(epoch!==generation||String(sound?.id)!==expectedId)return;playing=true;duration=await get('getDuration');if(epoch!==generation)return;publish();if(pendingPlay){acknowledge(pendingPlay.id,true);pendingPlay=null;}}catch(error){finishPending(error.message);}});
    widget.bind(events.PAUSE,()=>{if(readyForTrack){playing=false;publish();}});
    widget.bind(events.PLAY_PROGRESS,event=>{if(!readyForTrack)return;position=Math.max(0,event.currentPosition||0);playing=true;publish();});
    widget.bind(events.SEEK,event=>{if(readyForTrack){position=Math.max(0,event.currentPosition||0);publish();}});
    widget.bind(events.FINISH,()=>{if(!readyForTrack||finishedForGeneration)return;finishedForGeneration=true;playing=false;position=duration;publish();post({type:'sc-ended',uri});});
    widget.bind(events.ERROR,()=>{playing=false;publish();const error='O SoundCloud não liberou esta música para reprodução. Confira a disponibilidade no site.';finishPending(error);post({type:'sc-error',error});});
    interval=setInterval(async()=>{if(!widget||!readyForTrack||sampling)return;sampling=true;const epoch=generation;try{const [at,paused]=await Promise.all([get('getPosition'),get('isPaused')]);if(epoch===generation){position=Math.max(0,at||0);playing=!paused;publish();}}catch{}finally{sampling=false;}},50);
  })().catch(error=>{initializing=null;widget=null;document.querySelector('#soundcloud-media')?.remove();throw error;});return initializing;
}
async function command({id,method,value,url,trackId}){
  try{
    if(method==='load'){
      const target=new URL(url);if(target.protocol!=='https:'||target.hostname!=='soundcloud.com'||target.username||target.password||!/^\d{1,20}$/.test(trackId))throw new Error('Música SoundCloud inválida.');
      finishPending('Reprodução substituída.');activeLoadId=id;finishedForGeneration=false;readyForTrack=false;const epoch=++generation;playing=false;position=0;uri=url;expectedId=trackId;
      await init(url);if(epoch!==generation)throw new Error('Reprodução substituída.');pendingPlay={id};
      widget.load(url,{auto_play:false,show_artwork:false,sharing:false,download:false,buying:false,callback:async()=>{
        try{const sound=await get('getCurrentSound');if(epoch!==generation)return;if(String(sound?.id)!==expectedId)throw new Error('O SoundCloud carregou outra música.');duration=await get('getDuration');if(epoch!==generation)return;readyForTrack=true;widget.play();}
        catch(error){if(epoch===generation)finishPending(error.message);}
      }});return;
    }
    if(!widget||!readyForTrack)throw new Error('Escolha uma música SoundCloud antes de usar o player.');
    if(method==='pause'){finishPending('Reprodução pausada.');widget.pause();playing=false;}
    else if(method==='resume'){finishPending('Comando substituído.');pendingPlay={id};widget.play();return;}
    else if(method==='seek'){position=Math.max(0,Math.min(duration,value));widget.seekTo(position);}
    else if(method==='volume')widget.setVolume(Math.max(0,Math.min(100,value*100)));
    else throw new Error('Comando SoundCloud inválido.');publish();acknowledge(id,true);
  }catch(error){acknowledge(id,false,error.message);}
}
function reset(){lastNativeAt=-Infinity;lastNativeKey='';activeLoadId=null;generation++;readyForTrack=false;playing=false;widget?.pause();finishPending('Reprodução encerrada.');}
window.cncxSoundCloud={command,reset,cancel:id=>{if(activeLoadId===id)reset();}};window.addEventListener('beforeunload',()=>{clearInterval(interval);reset();});
