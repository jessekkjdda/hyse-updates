// Runs only inside the separate Spotify window, at the exact playlist URL.
// Reads visible metadata/positions and scrolls the official virtualized list.
// It never reads cookies, localStorage, credentials, request headers or tokens.
function scanPlaylistPage(action){
  const id=action.id;
  if(location.origin!=='https://open.spotify.com'||!new RegExp('^/(?:intl-[a-z-]+/)?playlist/'+id+'/?$').test(location.pathname))return{status:'signin',items:[],total:0};
  const list=document.querySelector('[data-testid="playlist-tracklist"] [role="grid"], [data-testid="playlist-tracklist"][role="grid"], [data-testid="track-list"][role="grid"], main [role="grid"]');
  const allRows=[...(list||document).querySelectorAll('[data-testid="tracklist-row"], [role="row"]')].filter(row=>row.querySelector('a[href*="/track/"],a[href*="/episode/"]')||row.getAttribute('data-testid')==='tracklist-row');
  let scroll=null;
  for(let node=allRows[0]?.parentElement||list;node;node=node.parentElement){const style=getComputedStyle(node);if(node.scrollHeight>node.clientHeight+32&&/(auto|scroll)/.test(style.overflowY)){scroll=node;break;}}
  scroll??=document.querySelector('.main-view-container__scroll-node,[data-overlayscrollbars-viewport],.os-viewport')||document.scrollingElement;
  const heading=document.querySelector('main h1, [data-testid="playlist-page"] h1');
  let total=0;const countText=document.querySelector('[data-testid="playlist-page"]')?.innerText||document.querySelector('main')?.innerText?.slice(0,10000)||'';
  const countMatch=countText.match(/\b([\d][\d.,]*)\s+(?:songs?|tracks?|músicas?|faixas?)\b/i);if(countMatch)total=Number(countMatch[1].replace(/\D/g,''));
  const headers=(list?.querySelectorAll('[role="row"]')||[]);let headerCount=0;for(const row of headers)if(row.querySelector('[role="columnheader"]'))headerCount++;
  if(!total){const count=Number(list?.getAttribute('aria-rowcount'));if(Number.isInteger(count)&&count>0)total=count-headerCount;}
  const items=[];
  for(const row of allRows){
    const start=row.querySelector('[aria-colindex="1"],.main-trackList-rowSectionStart,[data-testid="track-number"]');
    let position=0;for(const text of [start?.innerText,row.querySelector('button')?.getAttribute('aria-label')]){const n=String(text||'').trim().match(/^(\d+)$/);if(n){position=Number(n[1]);break;}}
    if(!position){const aria=Number(row.getAttribute('aria-rowindex'));if(Number.isInteger(aria)&&aria>0)position=aria-headerCount;}
    if(position<1)continue;
    const link=row.querySelector('a[href*="/track/"]'),episode=row.querySelector('a[href*="/episode/"]');
    const match=link?.getAttribute('href')?.match(/\/track\/([A-Za-z0-9]{22})(?:[/?#]|$)/);
    const artists=[...row.querySelectorAll('a[href*="/artist/"]')].map(n=>n.textContent.trim()).filter(Boolean);
    const title=link?.textContent?.trim()||episode?.textContent?.trim()||row.querySelector('[data-testid="internal-track-link"]')?.textContent?.trim()||'Faixa indisponível';
    const album=row.querySelector('a[href*="/album/"]')?.textContent?.trim()||null;
    const image=row.querySelector('img');const art=image?.currentSrc||image?.src||null;
    const durations=[...row.querySelectorAll('[role="gridcell"],span,div')].map(n=>n.childElementCount===0?n.textContent.trim():'').filter(t=>/^\d{1,3}:\d\d$/.test(t));const parts=durations.at(-1)?.split(':').map(Number);const durationMs=parts?(parts[0]*60+parts[1])*1000:0;
    const available=!!match;
    items.push({position,track:{id:available?match[1]:'unavailable-session-'+position,title,artist:[...new Set(artists)].join(', ')||(episode?'Episódio':'Indisponível'),art,preview:null,source:'Spotify',openUri:available?'spotify:track:'+match[1]:null,durationMs,albumName:album,available}});
  }
  const top=scroll?.scrollTop||0,height=scroll?.clientHeight||0,max=Math.max(0,(scroll?.scrollHeight||0)-height);
  if(action.mode==='top'&&scroll)scroll.scrollTop=0;
  else if(action.mode==='next'&&scroll)scroll.scrollTop=Math.min(max,top+Math.max(180,height*.7));
  return{status:items.length?'ready':'waiting',title:heading?.textContent?.trim()||'',items,total,top,max,height,bottom:top>=max-4};
}
