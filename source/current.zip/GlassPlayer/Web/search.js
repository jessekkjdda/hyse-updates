import {request} from './bridge.js';
const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const key=e=>`${e.source}|${e.kind}|${e.id}`;
export function cards(container,entities,{openEntity,openPlaylist}){
  container.replaceChildren();for(const entity of entities){const button=document.createElement('button');button.className='catalog-card';button.innerHTML=`<div class="catalog-art ${entity.kind==='artist'?'round':''}">${entity.art?`<img src="${escape(entity.art)}" alt="" loading="lazy">`:'<span>♫</span>'}</div><strong>${escape(entity.name)}</strong><span>${escape(entity.subtitle||({artist:'Artista',album:'Álbum',playlist:'Playlist'})[entity.kind])}</span><small class="provider-tag">${escape(entity.source)}</small>`;button.onclick=()=>entity.kind==='playlist'&&entity.source==='Spotify'?openPlaylist(entity.id):openEntity(key(entity));container.append(button);}
}
export class SearchView{
  constructor(element,state,callbacks){this.element=element;this.state=state;this.callbacks=callbacks;this.version=0;this.abort=null;this.timer=null;this.destroyed=false;state.searchSource??='all';state.searchFilter??='all';state.searchCatalog??={tracks:[],entities:[],notices:[],spotlight:null,nextSpotify:null,nextSoundCloud:null};this.render();}
  render(){
    const s=this.state;this.element.innerHTML=`<section class="page-heading search-heading"><div><span class="eyebrow">DESCOBRIR</span><h1>Buscar</h1></div><div class="source-switch" aria-label="Catálogo">${[['all','Todos'],['Spotify','Spotify'],['SoundCloud','SoundCloud']].map(([value,title])=>`<button data-source="${value}" class="${s.searchSource===value?'selected':''}">${title}</button>`).join('')}</div></section><div class="search-box expanded-search">${this.callbacks.icon('search')}<input id="search" type="search" value="${escape(s.query)}" placeholder="Música, artista, álbum, playlist ou link" autocomplete="off" aria-label="Buscar músicas"><button class="button" id="search-submit">Buscar</button></div><div class="search-filters" role="group" aria-label="Tipos de resultado">${[['all','Tudo'],['track','Músicas'],['artist','Artistas'],['album','Álbuns'],['playlist','Playlists']].map(([kind,label])=>`<button data-filter="${kind}" class="${s.searchFilter===kind?'selected':''}">${label}</button>`).join('')}</div><div id="search-status" class="small-status sr-only" role="status"></div><div id="search-notices"></div><div id="search-content"></div><button class="button secondary" id="more-results" hidden>Carregar mais resultados</button>`;
    const input=this.element.querySelector('#search');input.oninput=()=>{s.query=input.value;clearTimeout(this.timer);this.abort?.abort();this.version++;if(!s.query.trim()){s.searchCatalog={tracks:[],entities:[],spotlight:null,notices:[]};this.results();return;}this.status('Aguardando pesquisa…');this.element.querySelector('#more-results').hidden=true;this.timer=setTimeout(()=>this.search(false),400);};
    input.onkeydown=e=>{if(e.key==='Enter'){clearTimeout(this.timer);this.search(false,true);}};this.element.querySelector('#search-submit').onclick=()=>{clearTimeout(this.timer);this.search(false,true);};this.element.querySelector('#more-results').onclick=()=>this.search(true);
    for(const button of this.element.querySelectorAll('[data-source]'))button.onclick=()=>{clearTimeout(this.timer);s.searchSource=button.dataset.source;for(const b of this.element.querySelectorAll('[data-source]'))b.classList.toggle('selected',b===button);if(s.query.trim())this.search(false);};
    for(const button of this.element.querySelectorAll('[data-filter]'))button.onclick=()=>{s.searchFilter=button.dataset.filter;for(const b of this.element.querySelectorAll('[data-filter]'))b.classList.toggle('selected',b===button);this.results();};
    this.results();
  }
  status(text){const el=this.element.querySelector('#search-status');if(el)el.textContent=text;}
  async search(more=false,remember=false){
    const q=this.state.query.trim();if(!q||this.destroyed)return;this.abort?.abort();this.abort=new AbortController();const epoch=++this.version;const old=this.state.searchCatalog;
    this.status('Pesquisando…');const moreButton=this.element.querySelector('#more-results');moreButton.disabled=true;
    try{
      if(!more&&/^https:\/\/(?:(?:www\.|m\.)?soundcloud\.com|on\.soundcloud\.com|soundcloud\.app\.goo\.gl)\//i.test(q)){
        const result=await request('soundcloud.resolve',{url:q},this.abort.signal);if(epoch!==this.version||this.destroyed)return;if(result.entity){this.callbacks.openEntity(key(result.entity));return;}if(result.tracks.length){this.state.searchCatalog={tracks:result.tracks,entities:[],spotlight:{track:result.tracks[0]},notices:[]};this.results();this.status('Música SoundCloud encontrada.');await this.callbacks.playTracks(result.tracks,0);return;}
      }
      if(!more&&/^https:\/\/open\.spotify\.com\/(?:intl-[a-z-]+\/)?playlist\//i.test(q)){this.callbacks.openPlaylist(q);return;}
      const result=await request('search.catalog',{query:q,source:this.state.searchSource,spotifyOffset:more?old.nextSpotify||0:0,soundCloudCursor:more?old.nextSoundCloud||'0':'0',more,includeSpotify:!more||old.nextSpotify!=null,includeSoundCloud:!more||old.nextSoundCloud!=null},this.abort.signal);
      if(epoch!==this.version||this.destroyed)return;
      if(more){result.tracks=[...old.tracks,...result.tracks.filter(t=>!old.tracks.some(x=>x.id===t.id))];result.entities=[...old.entities,...result.entities.filter(e=>!old.entities.some(x=>key(x)===key(e)))];result.spotlight=old.spotlight||result.spotlight;}
      this.state.searchCatalog=result;this.results();this.status(`${result.tracks.length} músicas · ${result.entities.length} artistas, álbuns e playlists`);
      if(remember){await request('search.remember',{query:q});this.state.recentSearches=[q,...(this.state.recentSearches||[]).filter(x=>x.toLowerCase()!==q.toLowerCase())].slice(0,20);}
    }catch(error){if(error.name!=='AbortError'&&epoch===this.version&&!this.destroyed){this.status(error.message);if(!more){this.state.searchCatalog={tracks:[],entities:[],notices:[]};this.results();}}}
    finally{if(epoch===this.version&&!this.destroyed)moreButton.disabled=false;}
  }
  results(){
    if(this.destroyed)return;const s=this.state,result=s.searchCatalog||{},container=this.element.querySelector('#search-content'),notices=this.element.querySelector('#search-notices'),filter=s.searchFilter;
    notices.replaceChildren();for(const text of result.notices||[]){const p=document.createElement('p');p.className='inline-error';p.textContent=text;notices.append(p);}
    const more=this.element.querySelector('#more-results');more.hidden=result.nextSpotify==null&&result.nextSoundCloud==null;
    if(!s.query.trim()){
      container.innerHTML=`<section id="recent-searches"><div class="section-label"><h2>Pesquisas recentes</h2><button class="text-button" id="clear-searches">Limpar</button></div><div class="query-chips"></div></section>`;
      const chips=container.querySelector('.query-chips');for(const query of s.recentSearches||[]){const b=document.createElement('button');b.textContent=query;b.onclick=()=>{s.query=query;this.element.querySelector('#search').value=query;this.search(false);};chips.append(b);}if(!chips.children.length){const p=document.createElement('p');p.className='small-status';p.textContent='Nenhuma pesquisa recente.';chips.append(p);}
      container.querySelector('#clear-searches').onclick=()=>this.callbacks.confirm('Limpar pesquisas?','As pesquisas salvas neste computador serão removidas.','Limpar',async()=>{await request('search.history.clear');s.recentSearches=[];this.results();});this.status('');return;
    }
    const tracks=result.tracks||[],entities=result.entities||[];if(!tracks.length&&!entities.length){container.innerHTML='<div class="search-empty"><h2>Nenhum resultado carregado.</h2><p>Tente o nome da música ou do artista.</p></div>';return;}
    container.replaceChildren();
    if(filter==='all'){
      const top=document.createElement('div');top.className='search-top-grid';const spot=result.spotlight;
      if(spot){const panel=document.createElement('section');panel.className='spotlight-section';panel.innerHTML='<h2>Destaque</h2><button class="spotlight-card"></button>';const data=spot.track||spot.entity;const card=panel.querySelector('button');card.innerHTML=`<div class="spotlight-art ${spot.entity?.kind==='artist'?'round':''}">${data.art?`<img src="${escape(data.art)}" alt="">`:'♫'}</div><h3>${escape(data.title||data.name)}</h3><p>${escape(data.artist||data.subtitle)}</p><span class="provider-tag">${escape(data.source)}</span><span class="spotlight-action">${this.callbacks.icon(spot.track?'play':'arrow')}</span>`;card.onclick=()=>spot.track?this.callbacks.playTracks(tracks,Math.max(0,tracks.findIndex(t=>t.id===spot.track.id))):spot.entity.kind==='playlist'&&spot.entity.source==='Spotify'?this.callbacks.openPlaylist(spot.entity.id):this.callbacks.openEntity(key(spot.entity));top.append(panel);}
      if(tracks.length){const section=document.createElement('section');section.className='search-song-preview';section.innerHTML='<h2>Músicas</h2><div class="song-preview-rows"></div>';this.callbacks.rows(section.lastElementChild,tracks.slice(0,5),tracks);top.append(section);}container.append(top);
    }
    if(filter==='track'){const section=document.createElement('section');section.innerHTML='<div class="section-label"><h2>Músicas</h2></div><div></div>';this.callbacks.rows(section.lastElementChild,tracks,tracks);container.append(section);}
    for(const[kind,label]of [['artist','Artistas'],['album','Álbuns'],['playlist','Playlists']]){
      if(filter!=='all'&&filter!==kind)continue;const items=entities.filter(e=>e.kind===kind);if(!items.length)continue;
      const section=document.createElement('section');section.className='catalog-section';section.innerHTML=`<div class="section-label"><h2>${label}</h2></div><div class="catalog-grid"></div>`;cards(section.lastElementChild,items,this.callbacks);container.append(section);
    }
    if(!container.children.length)container.innerHTML='<p class="small-status search-empty">Nenhum resultado deste tipo nas páginas carregadas. Use Carregar mais resultados.</p>';
  }
  destroy(){this.destroyed=true;this.version++;clearTimeout(this.timer);this.abort?.abort();}
}
