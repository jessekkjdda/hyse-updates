import {AmbientScene} from './ambient.js';
// Album sampling and the global surface palette follow Riff's theme approach.
// Riff © 2026 rootscripts, MIT. See licenses/Riff-LICENSE.txt.
let revision=0,currentArt='',customBackground=null;
const root=document.documentElement;
const canvas=document.querySelector('#ambient-canvas');const scene=canvas?new AmbientScene(canvas):null;
export function animateAmbient(now,playing){scene?.draw(now,playing);root.classList.toggle('is-playing',!!playing);}
export let nativeTint=()=>{};
export function setNativeTint(listener){nativeTint=listener;}
function rgbToHsl(r,g,b){r/=255;g/=255;b/=255;let max=Math.max(r,g,b),min=Math.min(r,g,b),l=(max+min)/2,d=max-min,h=0,s=0;if(d){s=d/(1-Math.abs(2*l-1));h=max===r?((g-b)/d)%6:max===g?(b-r)/d+2:(r-g)/d+4;h=(h*60+360)%360;}return[h,s*100,l*100];}
export function palette(r,g,b){const[h,s]=rgbToHsl(r,g,b);const sat=Math.max(15,Math.min(48,s));return{'--surface':`hsl(${h} ${sat*.35}% 10%)`,'--surface-high':`hsl(${h} ${sat*.4}% 18%)`,'--surface-hover':`hsl(${h} ${sat*.45}% 25%)`,'--accent':`hsl(${h} ${Math.max(40,sat)}% 78%)`,'--accent-ink':`hsl(${h} 35% 13%)`,'--text':`hsl(${h} 30% 94%)`,'--muted':`hsl(${h} 14% 69%)`,'--outline':`hsl(${h} 16% 40% / .34)`};}
export async function albumTheme(url,settings){
  currentArt=url||'';const id=++revision;applyBackground(settings);
  if(!url){for(const[k,v]of Object.entries(palette(107,116,146)))root.style.setProperty(k,v);return;}
  try{const img=new Image();img.crossOrigin='anonymous';await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;img.src=url;});if(id!==revision)return;const canvas=document.createElement('canvas');canvas.width=canvas.height=10;const ctx=canvas.getContext('2d',{willReadFrequently:true});ctx.drawImage(img,0,0,10,10);const pixels=ctx.getImageData(0,0,10,10).data;let r=0,g=0,b=0,count=0;for(let i=0;i<pixels.length;i+=4){if(pixels[i+3]<128)continue;r+=pixels[i];g+=pixels[i+1];b+=pixels[i+2];count++;}if(count){for(const[k,v]of Object.entries(palette(r/count,g/count,b/count)))root.style.setProperty(k,v);nativeTint({r:Math.round(14+r/count*.06),g:Math.round(14+g/count*.06),b:Math.round(14+b/count*.06)});}}catch{/* CORS-incompatible artwork keeps the last readable palette. */}
}
export function setCustomBackground(url,settings){customBackground=url;applyBackground(settings);}
export function applyBackground(settings){const url=settings.lyricsAlbumBackground!==false?currentArt:customBackground;const background=document.querySelector('#ambient-art');background.style.backgroundImage=url?`url(${JSON.stringify(url)})`:'none';root.style.setProperty('--ambient-blur',`${settings.lyricsBlur??35}px`);root.style.setProperty('--ambient-opacity',String(.48*(1-(settings.lyricsTransparency??.6))));root.style.setProperty('--lyric-duration',`${.48/(settings.animationSpeed||1)}s`);root.style.setProperty('--motion-duration',`${.28/(settings.animationSpeed||1)}s`);root.style.setProperty('--lyric-size',`${settings.lyricsFontSize||32}px`);root.classList.toggle('reduced-motion',!!settings.reducedMotion);root.classList.toggle('background-static',settings.animatedBackground===false);root.classList.toggle('low-effects',!!settings.lowEffects);scene?.configure(settings);scene?.image(url);}
