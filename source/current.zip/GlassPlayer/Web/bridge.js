const pending=new Map(),events=new Map();let serial=0;
const host=window.chrome?.webview;
export function on(type,listener){if(!events.has(type))events.set(type,new Set());events.get(type).add(listener);return()=>events.get(type)?.delete(listener);}
export function request(method,args={},signal){
  if(!host)return Promise.reject(new Error('Abra esta interface pelo hyse.exe.'));
  const id=`r-${++serial}`;
  const result=new Promise((resolve,reject)=>{
    let timer;
    const cleanup=()=>{clearTimeout(timer);signal?.removeEventListener('abort',abort);pending.delete(id);};
    const abort=()=>{host.postMessage({type:'cancel',id});cleanup();reject(new DOMException('Operação cancelada','AbortError'));};
    if(signal?.aborted){reject(new DOMException('Operação cancelada','AbortError'));return;}
    pending.set(id,{resolve:value=>{cleanup();resolve(value);},reject:error=>{cleanup();reject(error);}});
    // Account authorization has its own three minute loopback timeout.
    timer=setTimeout(()=>{host.postMessage({type:'cancel',id});cleanup();reject(new Error('O pedido demorou demais. Tente novamente.'));},method==='playlist.read-session'?900000:method.startsWith('account.')?200000:120000);
    signal?.addEventListener('abort',abort,{once:true});host.postMessage({type:'request',id,method,args});
  });
  result.requestId=id;return result;
}
export function localEvent(type,data){for(const listener of events.get(type)||[])listener(data);}
export function post(message){host?.postMessage(message);}
host?.addEventListener('message',event=>{
  const message=event.data;if(!message||typeof message!=='object')return;
  if(message.type==='response'){
    const reply=message.data,p=reply&&pending.get(reply.id);if(!p)return;
    if(reply.ok)p.resolve(reply.result);else{const error=reply.cancelled?new DOMException(reply.error,'AbortError'):new Error(reply.error||'A operação falhou.');if(!reply.cancelled)error.code=reply.code;error.diagnostics=reply.diagnostics;p.reject(error);}
  }else for(const listener of events.get(message.type)||[])listener(message.data);
});
