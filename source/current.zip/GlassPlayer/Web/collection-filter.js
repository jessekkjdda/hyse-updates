const normalize=value=>String(value??'').normalize('NFKD').replace(/\p{M}/gu,'').toLocaleLowerCase('pt-BR');
export function matchesCollection(query,...fields){const terms=normalize(query).trim().split(/\s+/).filter(Boolean),text=normalize(fields.join(' '));return terms.every(term=>text.includes(term));}
export function filterTracks(tracks,query){return tracks.map((track,index)=>({track,index})).filter(({track})=>matchesCollection(query,track.title,track.artist,track.albumName,track.source));}
