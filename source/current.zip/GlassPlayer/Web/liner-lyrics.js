// GlassPlayer/Web/lyric-timing.js
function activeLine(lines, position) {
  let lo = 0, hi = lines.length - 1, result = -1;
  while (lo <= hi) {
    let mid = lo + hi >> 1;
    if (lines[mid].timeMs <= position) {
      result = mid;
      lo = mid + 1;
    } else hi = mid - 1;
  }
  if (result < 0) return -1;
  const line = lines[result];
  return !line.text?.trim() || line.endMs != null && position >= line.endMs ? -1 : result;
}
var punctuation = /^[\s\p{P}]$/u;
var cjk = /^[\p{sc=Han}\p{sc=Hiragana}\p{sc=Katakana}\p{sc=Hangul}]$/u;
var mark = /^\p{M}$/u;
var cyrillicVowels = new Set("\u0430\u0435\u0451\u0438\u043E\u0443\u044B\u044D\u044E\u044F\u0454\u0456\u0457\u045E\u0463\u0475\u046B\u0467\u0469\u046D");
var latinExtra = /* @__PURE__ */ new Set(["\xE6", "\xF8", "\u0153", "\u0131"]);
function charWeight(c, next = "") {
  if ([",", ";", ":", "\u3001", "\uFF0C", "\uFF1B"].includes(c)) return 4.6;
  if ([".", "!", "?", "\u2014", "\u2013", "-", "\u2015", "\u2012", "\u3002", "\uFF01", "\uFF1F", "\u2026"].includes(c)) return 5.8;
  if (c === "." && next === ".") return 6;
  if (punctuation.test(c)) return 0.55;
  if (cjk.test(c)) return 2.8;
  if (mark.test(c)) return 2.6;
  const lower = c.toLowerCase();
  if (cyrillicVowels.has(lower)) return 2.5;
  const base = c.normalize("NFD")[0]?.toLowerCase();
  return "aeiouy".includes(base) || latinExtra.has(lower) ? 2.5 : 1;
}
function gradientWeights(text) {
  const chars = Array.from(text), cum = new Float64Array(chars.length + 1);
  for (let i = 0; i < chars.length; i++) {
    let weight = charWeight(chars[i], chars[i + 1] || "");
    if (i >= chars.length - 2) weight *= 1.18;
    cum[i + 1] = cum[i] + weight;
  }
  return { count: chars.length, cum, total: cum[chars.length] };
}
function effectiveDuration(start, end) {
  const raw = Math.max(450, end - start), tail = raw > 2200 ? Math.min(120, raw * 0.03) : 0;
  return Math.max(400, raw - tail);
}
function gradientProgress(weights, position, start, end) {
  const tau = Math.min(1, Math.max(0, (position - start) / effectiveDuration(start, end)));
  if (!weights.count || !weights.total || tau === 0 || tau === 1) return tau;
  const target = tau * weights.total;
  let low = 0, high = weights.count - 1, index = 0;
  while (low <= high) {
    const mid = low + high >> 1;
    if (weights.cum[mid + 1] <= target) low = mid + 1;
    else if (weights.cum[mid] > target) high = mid - 1;
    else {
      index = mid;
      break;
    }
  }
  const width = weights.cum[index + 1] - weights.cum[index], fraction = width > 0 ? (target - weights.cum[index]) / width : 0;
  return Math.min(1, Math.max(0, (index + fraction) / weights.count));
}
function isNote(text) {
  return /^[♪♫♬♩·\s]+$/u.test(text || "");
}
function lineTokens(line) {
  const words = line.words?.length && line.words.map((w) => w.text).join("") === line.text ? line.words : null, tokens = [];
  let base = 0;
  for (const part of words || [{ text: line.text || "" }]) {
    for (const match of part.text.matchAll(/\S+/gu)) tokens.push({ text: match[0], start: base + match.index, end: base + match.index + match[0].length, startMs: words ? part.startMs : null, endMs: words ? part.endMs : null });
    base += part.text.length;
  }
  return tokens;
}
function lineEnd(lines, index, duration) {
  const line = lines[index], end = line.endMs ?? lines[index + 1]?.timeMs ?? duration;
  return Number.isFinite(end) && end > line.timeMs ? end : line.timeMs + 4e3;
}
function sourceIndex(lines, position) {
  let a = 0, b = lines.length - 1, index = -1;
  while (a <= b) {
    const m = a + b >> 1;
    if (lines[m].timeMs <= position) {
      index = m;
      a = m + 1;
    } else b = m - 1;
  }
  return index;
}
function holdTarget(lines, position, duration = 0, lead = 0, speed = 1) {
  let i = sourceIndex(lines, position);
  while (i >= 0 && (!lines[i].text?.trim() || isNote(lines[i].text))) i--;
  if (i < 0) return null;
  const line = lines[i], tokens = lineTokens(line);
  if (!tokens.length) return null;
  if (tokens.some((t) => t.startMs != null)) {
    for (let t = tokens.length - 1; t >= 0; t--) if (tokens[t].startMs <= position) return { line: i, token: t };
    return null;
  }
  const end = lineEnd(lines, i, duration);
  if (position >= end) return { line: i, token: tokens.length - 1 };
  const visual = line.timeMs + Math.max(0, position - line.timeMs) * speed + lead, k = gradientProgress(gradientWeights(line.text), visual, line.timeMs, end), painted = k * Array.from(line.text).length;
  for (let t = tokens.length - 1; t >= 0; t--) if (Array.from(line.text.slice(0, tokens[t].start)).length < painted - 1e-6) return { line: i, token: t };
  return null;
}

// integration/estimated-line.ts
function estimatedLineParts(text, start, end, ratio = 1) {
  const weights = gradientWeights(text), span = Math.max(1, end - start), parts = [];
  if (!weights.total) return parts;
  let cursor = 0;
  for (const chunk of text.match(/\s+|\S+/gu) || []) {
    const from = cursor;
    cursor += Array.from(chunk).length;
    const at = start + span * weights.cum[from] / weights.total;
    const until = start + span * weights.cum[cursor] / weights.total;
    parts.push({ words: chunk, startTimeMs: at, durationMs: /^\s+$/u.test(chunk) ? 0 : (until - at) / ratio });
  }
  return parts;
}

// node_modules/fast-xml-parser/src/util.js
var nameStartChar = ":A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD";
var nameChar = nameStartChar + "\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040";
var nameRegexp = "[" + nameStartChar + "][" + nameChar + "]*";
var regexName = new RegExp("^" + nameRegexp + "$");
function getAllMatches(string, regex) {
  const matches = [];
  let match = regex.exec(string);
  while (match) {
    const allmatches = [];
    allmatches.startIndex = regex.lastIndex - match[0].length;
    const len = match.length;
    for (let index = 0; index < len; index++) {
      allmatches.push(match[index]);
    }
    matches.push(allmatches);
    match = regex.exec(string);
  }
  return matches;
}
var isName = function(string) {
  const match = regexName.exec(string);
  return !(match === null || typeof match === "undefined");
};
function isExist(v) {
  return typeof v !== "undefined";
}
var DANGEROUS_PROPERTY_NAMES = [
  // '__proto__',
  // 'constructor',
  // 'prototype',
  "hasOwnProperty",
  "toString",
  "valueOf",
  "__defineGetter__",
  "__defineSetter__",
  "__lookupGetter__",
  "__lookupSetter__"
];
var criticalProperties = ["__proto__", "constructor", "prototype"];

// node_modules/fast-xml-parser/src/validator.js
var defaultOptions = {
  allowBooleanAttributes: false,
  //A tag can have attributes without any value
  unpairedTags: []
};
function validate(xmlData, options) {
  options = Object.assign({}, defaultOptions, options);
  const tags = [];
  let tagFound = false;
  let reachedRoot = false;
  if (xmlData[0] === "\uFEFF") {
    xmlData = xmlData.substr(1);
  }
  for (let i = 0; i < xmlData.length; i++) {
    if (xmlData[i] === "<" && xmlData[i + 1] === "?") {
      i += 2;
      i = readPI(xmlData, i);
      if (i.err) return i;
    } else if (xmlData[i] === "<") {
      let tagStartPos = i;
      i++;
      if (xmlData[i] === "!") {
        i = readCommentAndCDATA(xmlData, i);
        continue;
      } else {
        let closingTag = false;
        if (xmlData[i] === "/") {
          closingTag = true;
          i++;
        }
        let tagName = "";
        for (; i < xmlData.length && xmlData[i] !== ">" && xmlData[i] !== " " && xmlData[i] !== "	" && xmlData[i] !== "\n" && xmlData[i] !== "\r"; i++) {
          tagName += xmlData[i];
        }
        tagName = tagName.trim();
        if (tagName[tagName.length - 1] === "/") {
          tagName = tagName.substring(0, tagName.length - 1);
          i--;
        }
        if (!validateTagName(tagName)) {
          let msg;
          if (tagName.trim().length === 0) {
            msg = "Invalid space after '<'.";
          } else {
            msg = "Tag '" + tagName + "' is an invalid name.";
          }
          return getErrorObject("InvalidTag", msg, getLineNumberForPosition(xmlData, i));
        }
        const result = readAttributeStr(xmlData, i);
        if (result === false) {
          return getErrorObject("InvalidAttr", "Attributes for '" + tagName + "' have open quote.", getLineNumberForPosition(xmlData, i));
        }
        let attrStr = result.value;
        i = result.index;
        if (attrStr[attrStr.length - 1] === "/") {
          const attrStrStart = i - attrStr.length;
          attrStr = attrStr.substring(0, attrStr.length - 1);
          const isValid = validateAttributeString(attrStr, options);
          if (isValid === true) {
            tagFound = true;
          } else {
            return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, attrStrStart + isValid.err.line));
          }
        } else if (closingTag) {
          if (!result.tagClosed) {
            return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' doesn't have proper closing.", getLineNumberForPosition(xmlData, i));
          } else if (attrStr.trim().length > 0) {
            return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' can't have attributes or invalid starting.", getLineNumberForPosition(xmlData, tagStartPos));
          } else if (tags.length === 0) {
            return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' has not been opened.", getLineNumberForPosition(xmlData, tagStartPos));
          } else {
            const otg = tags.pop();
            if (tagName !== otg.tagName) {
              let openPos = getLineNumberForPosition(xmlData, otg.tagStartPos);
              return getErrorObject(
                "InvalidTag",
                "Expected closing tag '" + otg.tagName + "' (opened in line " + openPos.line + ", col " + openPos.col + ") instead of closing tag '" + tagName + "'.",
                getLineNumberForPosition(xmlData, tagStartPos)
              );
            }
            if (tags.length == 0) {
              reachedRoot = true;
            }
          }
        } else {
          const isValid = validateAttributeString(attrStr, options);
          if (isValid !== true) {
            return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, i - attrStr.length + isValid.err.line));
          }
          if (reachedRoot === true) {
            return getErrorObject("InvalidXml", "Multiple possible root nodes found.", getLineNumberForPosition(xmlData, i));
          } else if (options.unpairedTags.indexOf(tagName) !== -1) {
          } else {
            tags.push({ tagName, tagStartPos });
          }
          tagFound = true;
        }
        for (i++; i < xmlData.length; i++) {
          if (xmlData[i] === "<") {
            if (xmlData[i + 1] === "!") {
              i++;
              i = readCommentAndCDATA(xmlData, i);
              continue;
            } else if (xmlData[i + 1] === "?") {
              i = readPI(xmlData, ++i);
              if (i.err) return i;
            } else {
              break;
            }
          } else if (xmlData[i] === "&") {
            const afterAmp = validateAmpersand(xmlData, i);
            if (afterAmp == -1)
              return getErrorObject("InvalidChar", "char '&' is not expected.", getLineNumberForPosition(xmlData, i));
            i = afterAmp;
          } else {
            if (reachedRoot === true && !isWhiteSpace(xmlData[i])) {
              return getErrorObject("InvalidXml", "Extra text at the end", getLineNumberForPosition(xmlData, i));
            }
          }
        }
        if (xmlData[i] === "<") {
          i--;
        }
      }
    } else {
      if (isWhiteSpace(xmlData[i])) {
        continue;
      }
      return getErrorObject("InvalidChar", "char '" + xmlData[i] + "' is not expected.", getLineNumberForPosition(xmlData, i));
    }
  }
  if (!tagFound) {
    return getErrorObject("InvalidXml", "Start tag expected.", 1);
  } else if (tags.length == 1) {
    return getErrorObject("InvalidTag", "Unclosed tag '" + tags[0].tagName + "'.", getLineNumberForPosition(xmlData, tags[0].tagStartPos));
  } else if (tags.length > 0) {
    return getErrorObject("InvalidXml", "Invalid '" + JSON.stringify(tags.map((t) => t.tagName), null, 4).replace(/\r?\n/g, "") + "' found.", { line: 1, col: 1 });
  }
  return true;
}
function isWhiteSpace(char) {
  return char === " " || char === "	" || char === "\n" || char === "\r";
}
function readPI(xmlData, i) {
  const start = i;
  for (; i < xmlData.length; i++) {
    if (xmlData[i] == "?" || xmlData[i] == " ") {
      const tagname = xmlData.substr(start, i - start);
      if (i > 5 && tagname === "xml") {
        return getErrorObject("InvalidXml", "XML declaration allowed only at the start of the document.", getLineNumberForPosition(xmlData, i));
      } else if (xmlData[i] == "?" && xmlData[i + 1] == ">") {
        i++;
        break;
      } else {
        continue;
      }
    }
  }
  return i;
}
function readCommentAndCDATA(xmlData, i) {
  if (xmlData.length > i + 5 && xmlData[i + 1] === "-" && xmlData[i + 2] === "-") {
    for (i += 3; i < xmlData.length; i++) {
      if (xmlData[i] === "-" && xmlData[i + 1] === "-" && xmlData[i + 2] === ">") {
        i += 2;
        break;
      }
    }
  } else if (xmlData.length > i + 8 && xmlData[i + 1] === "D" && xmlData[i + 2] === "O" && xmlData[i + 3] === "C" && xmlData[i + 4] === "T" && xmlData[i + 5] === "Y" && xmlData[i + 6] === "P" && xmlData[i + 7] === "E") {
    let angleBracketsCount = 1;
    for (i += 8; i < xmlData.length; i++) {
      if (xmlData[i] === "<") {
        angleBracketsCount++;
      } else if (xmlData[i] === ">") {
        angleBracketsCount--;
        if (angleBracketsCount === 0) {
          break;
        }
      }
    }
  } else if (xmlData.length > i + 9 && xmlData[i + 1] === "[" && xmlData[i + 2] === "C" && xmlData[i + 3] === "D" && xmlData[i + 4] === "A" && xmlData[i + 5] === "T" && xmlData[i + 6] === "A" && xmlData[i + 7] === "[") {
    for (i += 8; i < xmlData.length; i++) {
      if (xmlData[i] === "]" && xmlData[i + 1] === "]" && xmlData[i + 2] === ">") {
        i += 2;
        break;
      }
    }
  }
  return i;
}
var doubleQuote = '"';
var singleQuote = "'";
function readAttributeStr(xmlData, i) {
  let attrStr = "";
  let startChar = "";
  let tagClosed = false;
  for (; i < xmlData.length; i++) {
    if (xmlData[i] === doubleQuote || xmlData[i] === singleQuote) {
      if (startChar === "") {
        startChar = xmlData[i];
      } else if (startChar !== xmlData[i]) {
      } else {
        startChar = "";
      }
    } else if (xmlData[i] === ">") {
      if (startChar === "") {
        tagClosed = true;
        break;
      }
    }
    attrStr += xmlData[i];
  }
  if (startChar !== "") {
    return false;
  }
  return {
    value: attrStr,
    index: i,
    tagClosed
  };
}
var validAttrStrRegxp = new RegExp(`(\\s*)([^\\s=]+)(\\s*=)?(\\s*(['"])(([\\s\\S])*?)\\5)?`, "g");
function validateAttributeString(attrStr, options) {
  const matches = getAllMatches(attrStr, validAttrStrRegxp);
  const attrNames = {};
  for (let i = 0; i < matches.length; i++) {
    if (matches[i][1].length === 0) {
      return getErrorObject("InvalidAttr", "Attribute '" + matches[i][2] + "' has no space in starting.", getPositionFromMatch(matches[i]));
    } else if (matches[i][3] !== void 0 && matches[i][4] === void 0) {
      return getErrorObject("InvalidAttr", "Attribute '" + matches[i][2] + "' is without value.", getPositionFromMatch(matches[i]));
    } else if (matches[i][3] === void 0 && !options.allowBooleanAttributes) {
      return getErrorObject("InvalidAttr", "boolean attribute '" + matches[i][2] + "' is not allowed.", getPositionFromMatch(matches[i]));
    }
    const attrName = matches[i][2];
    if (!validateAttrName(attrName)) {
      return getErrorObject("InvalidAttr", "Attribute '" + attrName + "' is an invalid name.", getPositionFromMatch(matches[i]));
    }
    if (!Object.prototype.hasOwnProperty.call(attrNames, attrName)) {
      attrNames[attrName] = 1;
    } else {
      return getErrorObject("InvalidAttr", "Attribute '" + attrName + "' is repeated.", getPositionFromMatch(matches[i]));
    }
  }
  return true;
}
function validateNumberAmpersand(xmlData, i) {
  let re = /\d/;
  if (xmlData[i] === "x") {
    i++;
    re = /[\da-fA-F]/;
  }
  for (; i < xmlData.length; i++) {
    if (xmlData[i] === ";")
      return i;
    if (!xmlData[i].match(re))
      break;
  }
  return -1;
}
function validateAmpersand(xmlData, i) {
  i++;
  if (xmlData[i] === ";")
    return -1;
  if (xmlData[i] === "#") {
    i++;
    return validateNumberAmpersand(xmlData, i);
  }
  let count = 0;
  for (; i < xmlData.length; i++, count++) {
    if (xmlData[i].match(/\w/) && count < 20)
      continue;
    if (xmlData[i] === ";")
      break;
    return -1;
  }
  return i;
}
function getErrorObject(code, message, lineNumber) {
  return {
    err: {
      code,
      msg: message,
      line: lineNumber.line || lineNumber,
      col: lineNumber.col
    }
  };
}
function validateAttrName(attrName) {
  return isName(attrName);
}
function validateTagName(tagname) {
  return isName(tagname);
}
function getLineNumberForPosition(xmlData, index) {
  const lines = xmlData.substring(0, index).split(/\r?\n/);
  return {
    line: lines.length,
    // column number is last line's length + 1, because column numbering starts at 1:
    col: lines[lines.length - 1].length + 1
  };
}
function getPositionFromMatch(match) {
  return match.startIndex + match[1].length;
}

// node_modules/@nodable/entities/src/entities.js
var CURRENCY = {
  cent: "\xA2",
  pound: "\xA3",
  curren: "\xA4",
  yen: "\xA5",
  euro: "\u20AC",
  dollar: "$",
  fnof: "\u0192",
  inr: "\u20B9",
  af: "\u060B",
  birr: "\u1265\u122D",
  peso: "\u20B1",
  rub: "\u20BD",
  won: "\u20A9",
  yuan: "\xA5",
  cedil: "\xB8"
};
var XML = {
  amp: "&",
  apos: "'",
  gt: ">",
  lt: "<",
  quot: '"'
};
var COMMON_HTML = {
  nbsp: "\xA0",
  copy: "\xA9",
  reg: "\xAE",
  trade: "\u2122",
  mdash: "\u2014",
  ndash: "\u2013",
  hellip: "\u2026",
  laquo: "\xAB",
  raquo: "\xBB",
  lsquo: "\u2018",
  rsquo: "\u2019",
  ldquo: "\u201C",
  rdquo: "\u201D",
  bull: "\u2022",
  para: "\xB6",
  sect: "\xA7",
  deg: "\xB0",
  frac12: "\xBD",
  frac14: "\xBC",
  frac34: "\xBE"
};

// node_modules/@nodable/entities/src/EntityDecoder.js
var ENTITY_ACTION = Object.freeze({
  /** Resolve and expand the entity normally. */
  ALLOW: "allow",
  /** Silently skip this entity — it will not be registered. */
  BLOCK: "block",
  /** Throw an error, aborting entity registration entirely. */
  THROW: "throw"
});
var SPECIAL_CHARS = new Set("!?\\\\/[]$%{}^&*()<>|+");
function validateEntityName(name) {
  if (name[0] === "#") {
    throw new Error(`[EntityReplacer] Invalid character '#' in entity name: "${name}"`);
  }
  for (const ch of name) {
    if (SPECIAL_CHARS.has(ch)) {
      throw new Error(`[EntityReplacer] Invalid character '${ch}' in entity name: "${name}"`);
    }
  }
  return name;
}
function mergeEntityMaps(...maps) {
  const out = /* @__PURE__ */ Object.create(null);
  for (const map of maps) {
    if (!map) continue;
    for (const key of Object.keys(map)) {
      const raw = map[key];
      if (typeof raw === "string") {
        out[key] = raw;
      } else if (raw && typeof raw === "object" && raw.val !== void 0) {
        const val = raw.val;
        if (typeof val === "string") {
          out[key] = val;
        }
      }
    }
  }
  return out;
}
var LIMIT_TIER_EXTERNAL = "external";
var LIMIT_TIER_BASE = "base";
var LIMIT_TIER_ALL = "all";
function parseLimitTiers(raw) {
  if (!raw || raw === LIMIT_TIER_EXTERNAL) return /* @__PURE__ */ new Set([LIMIT_TIER_EXTERNAL]);
  if (raw === LIMIT_TIER_ALL) return /* @__PURE__ */ new Set([LIMIT_TIER_ALL]);
  if (raw === LIMIT_TIER_BASE) return /* @__PURE__ */ new Set([LIMIT_TIER_BASE]);
  if (Array.isArray(raw)) return new Set(raw);
  return /* @__PURE__ */ new Set([LIMIT_TIER_EXTERNAL]);
}
var NCR_LEVEL = Object.freeze({ allow: 0, leave: 1, remove: 2, throw: 3 });
var XML10_ALLOWED_C0 = /* @__PURE__ */ new Set([9, 10, 13]);
function parseNCRConfig(ncr) {
  if (!ncr) {
    return { xmlVersion: 1, onLevel: NCR_LEVEL.allow, nullLevel: NCR_LEVEL.remove };
  }
  const xmlVersion = ncr.xmlVersion === 1.1 ? 1.1 : 1;
  const onLevel = NCR_LEVEL[ncr.onNCR] ?? NCR_LEVEL.allow;
  const nullLevel = NCR_LEVEL[ncr.nullNCR] ?? NCR_LEVEL.remove;
  const clampedNull = Math.max(nullLevel, NCR_LEVEL.remove);
  return { xmlVersion, onLevel, nullLevel: clampedNull };
}
var EntityDecoder = class {
  /**
   * @param {object} [options]
   * @param {object|null}  [options.namedEntities]        — extra named entities merged into base map
   * @param {object}  [options.limit]                 — security limits
   * @param {number}       [options.limit.maxTotalExpansions=0]  — 0 = unlimited
   * @param {number}       [options.limit.maxExpandedLength=0]   — 0 = unlimited
   * @param {'external'|'base'|'all'|string[]} [options.limit.applyLimitsTo='external']
   *   Which entity tiers count against the security limits:
   *   - 'external' (default) — only input/runtime + persistent external entities
   *   - 'base'               — only DEFAULT_XML_ENTITIES + namedEntities
   *   - 'all'                — every entity regardless of tier
   *   - string[]             — explicit combination, e.g. ['external', 'base']
   * @param {((resolved: string, original: string) => string)|null} [options.postCheck=null]
   * @param {string[]} [options.remove=[]] — entity names (e.g. ['nbsp', '#13']) to delete (replace with empty string)
   * @param {string[]} [options.leave=[]]  — entity names to keep as literal (unchanged in output)
   * @param {object}   [options.ncr]       — Numeric Character Reference controls
   * @param {1.0|1.1}  [options.ncr.xmlVersion=1.0]
   *   XML version governing which codepoint ranges are restricted:
   *   - 1.0 — C0 controls U+0001–U+001F (except U+0009/000A/000D) are prohibited
   *   - 1.1 — C0 controls are allowed when written as NCRs; C1 (U+007F–U+009F) decoded as-is
   * @param {'allow'|'leave'|'remove'|'throw'} [options.ncr.onNCR='allow']
   *   Base action for numeric references. Severity order: allow < leave < remove < throw.
   *   For codepoint ranges that carry a minimum level (surrogates → remove, XML 1.0 C0 → remove),
   *   the effective action is max(onNCR, rangeMinimum).
   * @param {'remove'|'throw'} [options.ncr.nullNCR='remove']
   *   Action for U+0000 (null). 'allow' and 'leave' are clamped to 'remove' since null is never safe.
   * @param {((name: string, value: string) => 'allow'|'block'|'throw')|null} [options.onExternalEntity=null]
   *   Hook called when an external entity is registered via `setExternalEntities()` or
   *   `addExternalEntity()`. Return `ENTITY_ACTION.ALLOW` to accept the entity,
   *   `ENTITY_ACTION.BLOCK` to silently skip it, or `ENTITY_ACTION.THROW` to abort with an error.
   * @param {((name: string, value: string) => 'allow'|'block'|'throw')|null} [options.onInputEntity=null]
   *   Hook called when an input entity is registered via `addInputEntities()`. Return
   *   `ENTITY_ACTION.ALLOW` to accept, `ENTITY_ACTION.BLOCK` to silently skip, or
   *   `ENTITY_ACTION.THROW` to abort with an error.
   */
  constructor(options = {}) {
    this._limit = options.limit || {};
    this._maxTotalExpansions = this._limit.maxTotalExpansions || 0;
    this._maxExpandedLength = this._limit.maxExpandedLength || 0;
    this._postCheck = typeof options.postCheck === "function" ? options.postCheck : (r) => r;
    this._limitTiers = parseLimitTiers(this._limit.applyLimitsTo ?? LIMIT_TIER_EXTERNAL);
    this._numericAllowed = options.numericAllowed ?? true;
    this._baseMap = mergeEntityMaps(XML, options.namedEntities || null);
    this._externalMap = /* @__PURE__ */ Object.create(null);
    this._inputMap = /* @__PURE__ */ Object.create(null);
    this._totalExpansions = 0;
    this._expandedLength = 0;
    this._removeSet = new Set(options.remove && Array.isArray(options.remove) ? options.remove : []);
    this._leaveSet = new Set(options.leave && Array.isArray(options.leave) ? options.leave : []);
    const ncrCfg = parseNCRConfig(options.ncr);
    this._ncrXmlVersion = ncrCfg.xmlVersion;
    this._ncrOnLevel = ncrCfg.onLevel;
    this._ncrNullLevel = ncrCfg.nullLevel;
    this._onExternalEntity = typeof options.onExternalEntity === "function" ? options.onExternalEntity : null;
    this._onInputEntity = typeof options.onInputEntity === "function" ? options.onInputEntity : null;
  }
  // -------------------------------------------------------------------------
  // Private: registration hook dispatch
  // -------------------------------------------------------------------------
  /**
   * Invoke a registration hook for a single entity name/value pair.
   * Returns true when the entity should be accepted, false when it should be
   * silently skipped (BLOCK), and throws when the hook returns THROW.
   *
   * @param {((name: string, value: string) => 'allow'|'block'|'throw')|null} hook
   * @param {string} name
   * @param {string} value
   * @param {string} context  — used in error messages ('external' | 'input')
   * @returns {boolean}  true = accept, false = skip
   */
  _applyRegistrationHook(hook, name, value, context) {
    if (!hook) return true;
    const action = hook(name, value);
    if (action === ENTITY_ACTION.BLOCK) return false;
    if (action === ENTITY_ACTION.THROW) {
      throw new Error(
        `[EntityDecoder] Registration of ${context} entity "&${name};" was rejected by hook`
      );
    }
    return true;
  }
  // -------------------------------------------------------------------------
  // Persistent external entity registration
  // -------------------------------------------------------------------------
  /**
   * Replace the full set of persistent external entities.
   * All keys are validated — throws on invalid characters.
   * If `onExternalEntity` is set, it is called once per entry; entries that
   * return `ENTITY_ACTION.BLOCK` are silently omitted, `ENTITY_ACTION.THROW`
   * aborts the whole call.
   * @param {Record<string, string | { regex?: RegExp, val: string }>} map
   */
  setExternalEntities(map) {
    if (map) {
      for (const key of Object.keys(map)) {
        validateEntityName(key);
      }
    }
    if (!this._onExternalEntity) {
      this._externalMap = mergeEntityMaps(map);
      return;
    }
    const flat = mergeEntityMaps(map);
    const filtered = /* @__PURE__ */ Object.create(null);
    for (const [name, value] of Object.entries(flat)) {
      if (this._applyRegistrationHook(this._onExternalEntity, name, value, "external")) {
        filtered[name] = value;
      }
    }
    this._externalMap = filtered;
  }
  /**
   * Add a single persistent external entity.
   * If `onExternalEntity` is set it is called before the entity is stored;
   * `ENTITY_ACTION.BLOCK` silently skips storage, `ENTITY_ACTION.THROW` raises.
   * @param {string} key
   * @param {string} value
   */
  addExternalEntity(key, value) {
    validateEntityName(key);
    if (typeof value === "string" && value.indexOf("&") === -1) {
      if (this._applyRegistrationHook(this._onExternalEntity, key, value, "external")) {
        this._externalMap[key] = value;
      }
    }
  }
  // -------------------------------------------------------------------------
  // Input / runtime entity registration (per document)
  // -------------------------------------------------------------------------
  /**
   * Inject DOCTYPE entities for the current document.
   * Also resets per-document expansion counters.
   * If `onInputEntity` is set it is called once per entry; entries returning
   * `ENTITY_ACTION.BLOCK` are silently omitted, `ENTITY_ACTION.THROW` aborts.
   * @param {Record<string, string | { regx?: RegExp, regex?: RegExp, val: string }>} map
   */
  addInputEntities(map) {
    this._totalExpansions = 0;
    this._expandedLength = 0;
    if (!this._onInputEntity) {
      this._inputMap = mergeEntityMaps(map);
      return;
    }
    const flat = mergeEntityMaps(map);
    const filtered = /* @__PURE__ */ Object.create(null);
    for (const [name, value] of Object.entries(flat)) {
      if (this._applyRegistrationHook(this._onInputEntity, name, value, "input")) {
        filtered[name] = value;
      }
    }
    this._inputMap = filtered;
  }
  // -------------------------------------------------------------------------
  // Per-document reset
  // -------------------------------------------------------------------------
  /**
   * Wipe input/runtime entities and reset counters.
   * Call this before processing each new document.
   * @returns {this}
   */
  reset() {
    this._inputMap = /* @__PURE__ */ Object.create(null);
    this._totalExpansions = 0;
    this._expandedLength = 0;
    return this;
  }
  // -------------------------------------------------------------------------
  // XML version (can be set after construction, e.g. once parser reads <?xml?>)
  // -------------------------------------------------------------------------
  /**
   * Update the XML version used for NCR classification.
   * Call this as soon as the document's `<?xml version="...">` declaration is parsed.
   * @param {1.0|1.1|number} version
   */
  setXmlVersion(version) {
    this._ncrXmlVersion = version === 1.1 ? 1.1 : 1;
  }
  // -------------------------------------------------------------------------
  // Primary API
  // -------------------------------------------------------------------------
  /**
   * Replace all entity references in `str` in a single pass.
   *
   * @param {string} str
   * @returns {string}
   */
  decode(str) {
    if (typeof str !== "string" || str.length === 0) return str;
    if (str.indexOf("&") === -1) return str;
    const original = str;
    const chunks = [];
    const len = str.length;
    let last = 0;
    let i = 0;
    const limitExpansions = this._maxTotalExpansions > 0;
    const limitLength = this._maxExpandedLength > 0;
    const checkLimits = limitExpansions || limitLength;
    while (i < len) {
      if (str.charCodeAt(i) !== 38) {
        i++;
        continue;
      }
      let j = i + 1;
      while (j < len && str.charCodeAt(j) !== 59 && j - i <= 32) j++;
      if (j >= len || str.charCodeAt(j) !== 59) {
        i++;
        continue;
      }
      const token = str.slice(i + 1, j);
      if (token.length === 0) {
        i++;
        continue;
      }
      let replacement;
      let tier;
      if (this._removeSet.has(token)) {
        replacement = "";
        if (tier === void 0) {
          tier = LIMIT_TIER_EXTERNAL;
        }
      } else if (this._leaveSet.has(token)) {
        i++;
        continue;
      } else if (token.charCodeAt(0) === 35) {
        const ncrResult = this._resolveNCR(token);
        if (ncrResult === void 0) {
          i++;
          continue;
        }
        replacement = ncrResult;
        tier = LIMIT_TIER_BASE;
      } else {
        const resolved = this._resolveName(token);
        replacement = resolved?.value;
        tier = resolved?.tier;
      }
      if (replacement === void 0) {
        i++;
        continue;
      }
      if (i > last) chunks.push(str.slice(last, i));
      chunks.push(replacement);
      last = j + 1;
      i = last;
      if (checkLimits && this._tierCounts(tier)) {
        if (limitExpansions) {
          this._totalExpansions++;
          if (this._totalExpansions > this._maxTotalExpansions) {
            throw new Error(
              `[EntityReplacer] Entity expansion count limit exceeded: ${this._totalExpansions} > ${this._maxTotalExpansions}`
            );
          }
        }
        if (limitLength) {
          const delta = replacement.length - (token.length + 2);
          if (delta > 0) {
            this._expandedLength += delta;
            if (this._expandedLength > this._maxExpandedLength) {
              throw new Error(
                `[EntityReplacer] Expanded content length limit exceeded: ${this._expandedLength} > ${this._maxExpandedLength}`
              );
            }
          }
        }
      }
    }
    if (last < len) chunks.push(str.slice(last));
    const result = chunks.length === 0 ? str : chunks.join("");
    return this._postCheck(result, original);
  }
  // -------------------------------------------------------------------------
  // Private: limit tier check
  // -------------------------------------------------------------------------
  /**
   * Returns true if a resolved entity of the given tier should count
   * against the expansion/length limits.
   * @param {string} tier  — LIMIT_TIER_EXTERNAL | LIMIT_TIER_BASE
   * @returns {boolean}
   */
  _tierCounts(tier) {
    if (this._limitTiers.has(LIMIT_TIER_ALL)) return true;
    return this._limitTiers.has(tier);
  }
  // -------------------------------------------------------------------------
  // Private: entity resolution
  // -------------------------------------------------------------------------
  /**
   * Resolve a named entity token (without & and ;).
   * Priority: inputMap > externalMap > baseMap
   * Returns the resolved value tagged with its limit tier.
   *
   * @param {string} name
   * @returns {{ value: string, tier: string }|undefined}
   */
  _resolveName(name) {
    if (name in this._inputMap) return { value: this._inputMap[name], tier: LIMIT_TIER_EXTERNAL };
    if (name in this._externalMap) return { value: this._externalMap[name], tier: LIMIT_TIER_EXTERNAL };
    if (name in this._baseMap) return { value: this._baseMap[name], tier: LIMIT_TIER_BASE };
    return void 0;
  }
  /**
   * Classify a codepoint and return the minimum action level that must be applied.
   * Returns -1 when no minimum is imposed (normal allow path).
   *
   * Ranges checked (in priority order):
   *   1. U+0000            — null, governed by nullNCR (always ≥ remove)
   *   2. U+D800–U+DFFF     — surrogates, always prohibited (min: remove)
   *   3. U+0001–U+001F \ {0x09,0x0A,0x0D}  — XML 1.0 restricted C0 (min: remove)
   *      (skipped in XML 1.1 — C0 controls are allowed when written as NCRs)
   *
   * @param {number} cp  — codepoint
   * @returns {number}   — minimum NCR_LEVEL value, or -1 for no restriction
   */
  _classifyNCR(cp) {
    if (cp === 0) return this._ncrNullLevel;
    if (cp >= 55296 && cp <= 57343) return NCR_LEVEL.remove;
    if (this._ncrXmlVersion === 1) {
      if (cp >= 1 && cp <= 31 && !XML10_ALLOWED_C0.has(cp)) return NCR_LEVEL.remove;
    }
    return -1;
  }
  /**
   * Execute a resolved NCR action.
   *
   * @param {number} action   — NCR_LEVEL value
   * @param {string} token    — raw token (e.g. '#38') for error messages
   * @param {number} cp       — codepoint, used only for error messages
   * @returns {string|undefined}
   *   - decoded character string  → 'allow'
   *   - ''                        → 'remove'
   *   - undefined                 → 'leave' (caller must skip past '&' only)
   *   - throws Error              → 'throw'
   */
  _applyNCRAction(action, token, cp) {
    switch (action) {
      case NCR_LEVEL.allow:
        return String.fromCodePoint(cp);
      case NCR_LEVEL.remove:
        return "";
      case NCR_LEVEL.leave:
        return void 0;
      // signal: keep literal
      case NCR_LEVEL.throw:
        throw new Error(
          `[EntityDecoder] Prohibited numeric character reference &${token}; (U+${cp.toString(16).toUpperCase().padStart(4, "0")})`
        );
      default:
        return String.fromCodePoint(cp);
    }
  }
  /**
   * Full NCR resolution pipeline for a numeric token.
   *
   * Steps:
   *   1. Parse the codepoint (decimal or hex).
   *   2. Validate the raw codepoint range (NaN, <0, >0x10FFFF).
   *   3. If numericAllowed is false and no minimum restriction applies → leave as-is.
   *   4. Classify the codepoint to find the minimum required action level.
   *   5. Resolve effective action = max(onNCR, minimum).
   *   6. Apply and return.
   *
   * @param {string} token  — e.g. '#38', '#x26', '#X26'
   * @returns {string|undefined}
   *   - string (incl. '')  — replacement ('' = remove)
   *   - undefined          — leave original &token; as-is
   */
  _resolveNCR(token) {
    const second = token.charCodeAt(1);
    let cp;
    if (second === 120 || second === 88) {
      cp = parseInt(token.slice(2), 16);
    } else {
      cp = parseInt(token.slice(1), 10);
    }
    if (Number.isNaN(cp) || cp < 0 || cp > 1114111) return void 0;
    const minimum = this._classifyNCR(cp);
    if (!this._numericAllowed && minimum < NCR_LEVEL.remove) return void 0;
    const effective = minimum === -1 ? this._ncrOnLevel : Math.max(this._ncrOnLevel, minimum);
    return this._applyNCRAction(effective, token, cp);
  }
};

// node_modules/fast-xml-parser/src/xmlparser/OptionsBuilder.js
var defaultOnDangerousProperty = (name) => {
  if (DANGEROUS_PROPERTY_NAMES.includes(name)) {
    return "__" + name;
  }
  return name;
};
var defaultOptions2 = {
  preserveOrder: false,
  attributeNamePrefix: "@_",
  attributesGroupName: false,
  textNodeName: "#text",
  ignoreAttributes: true,
  removeNSPrefix: false,
  // remove NS from tag name or attribute name if true
  allowBooleanAttributes: false,
  //a tag can have attributes without any value
  //ignoreRootElement : false,
  parseTagValue: true,
  parseAttributeValue: false,
  trimValues: true,
  //Trim string values of tag and attributes
  cdataPropName: false,
  numberParseOptions: {
    hex: true,
    leadingZeros: true,
    eNotation: true,
    unicode: false
  },
  tagValueProcessor: function(tagName, val) {
    return val;
  },
  attributeValueProcessor: function(attrName, val) {
    return val;
  },
  stopNodes: [],
  //nested tags will not be parsed even for errors
  alwaysCreateTextNode: false,
  isArray: () => false,
  commentPropName: false,
  unpairedTags: [],
  processEntities: true,
  htmlEntities: false,
  entityDecoder: null,
  ignoreDeclaration: false,
  ignorePiTags: false,
  transformTagName: false,
  transformAttributeName: false,
  updateTag: function(tagName, jPath, attrs) {
    return tagName;
  },
  // skipEmptyListItem: false
  captureMetaData: false,
  maxNestedTags: 100,
  strictReservedNames: true,
  jPath: true,
  // if true, pass jPath string to callbacks; if false, pass matcher instance
  onDangerousProperty: defaultOnDangerousProperty
};
function validatePropertyName(propertyName, optionName) {
  if (typeof propertyName !== "string") {
    return;
  }
  const normalized = propertyName.toLowerCase();
  if (DANGEROUS_PROPERTY_NAMES.some((dangerous) => normalized === dangerous.toLowerCase())) {
    throw new Error(
      `[SECURITY] Invalid ${optionName}: "${propertyName}" is a reserved JavaScript keyword that could cause prototype pollution`
    );
  }
  if (criticalProperties.some((dangerous) => normalized === dangerous.toLowerCase())) {
    throw new Error(
      `[SECURITY] Invalid ${optionName}: "${propertyName}" is a reserved JavaScript keyword that could cause prototype pollution`
    );
  }
}
function normalizeProcessEntities(value, htmlEntities) {
  if (typeof value === "boolean") {
    return {
      enabled: value,
      // true or false
      maxEntitySize: 1e4,
      maxExpansionDepth: 1e4,
      maxTotalExpansions: Infinity,
      maxExpandedLength: 1e5,
      maxEntityCount: 1e3,
      allowedTags: null,
      tagFilter: null,
      appliesTo: "all"
    };
  }
  if (typeof value === "object" && value !== null) {
    return {
      enabled: value.enabled !== false,
      maxEntitySize: Math.max(1, value.maxEntitySize ?? 1e4),
      maxExpansionDepth: Math.max(1, value.maxExpansionDepth ?? 1e4),
      maxTotalExpansions: Math.max(1, value.maxTotalExpansions ?? Infinity),
      maxExpandedLength: Math.max(1, value.maxExpandedLength ?? 1e5),
      maxEntityCount: Math.max(1, value.maxEntityCount ?? 1e3),
      allowedTags: value.allowedTags ?? null,
      tagFilter: value.tagFilter ?? null,
      appliesTo: value.appliesTo ?? "all"
    };
  }
  return normalizeProcessEntities(true);
}
var buildOptions = function(options) {
  const built = Object.assign({}, defaultOptions2, options);
  const propertyNameOptions = [
    { value: built.attributeNamePrefix, name: "attributeNamePrefix" },
    { value: built.attributesGroupName, name: "attributesGroupName" },
    { value: built.textNodeName, name: "textNodeName" },
    { value: built.cdataPropName, name: "cdataPropName" },
    { value: built.commentPropName, name: "commentPropName" }
  ];
  for (const { value, name } of propertyNameOptions) {
    if (value) {
      validatePropertyName(value, name);
    }
  }
  if (built.onDangerousProperty === null) {
    built.onDangerousProperty = defaultOnDangerousProperty;
  }
  built.processEntities = normalizeProcessEntities(built.processEntities, built.htmlEntities);
  built.unpairedTagsSet = new Set(built.unpairedTags);
  if (built.stopNodes && Array.isArray(built.stopNodes)) {
    built.stopNodes = built.stopNodes.map((node) => {
      if (typeof node === "string" && node.startsWith("*.")) {
        return ".." + node.substring(2);
      }
      return node;
    });
  }
  return built;
};

// node_modules/fast-xml-parser/src/xmlparser/xmlNode.js
var METADATA_SYMBOL;
if (typeof Symbol !== "function") {
  METADATA_SYMBOL = "@@xmlMetadata";
} else {
  METADATA_SYMBOL = /* @__PURE__ */ Symbol("XML Node Metadata");
}
var XmlNode = class {
  constructor(tagname) {
    this.tagname = tagname;
    this.child = [];
    this[":@"] = /* @__PURE__ */ Object.create(null);
  }
  add(key, val) {
    if (key === "__proto__") key = "#__proto__";
    this.child.push({ [key]: val });
  }
  addChild(node, startIndex) {
    if (node.tagname === "__proto__") node.tagname = "#__proto__";
    if (node[":@"] && Object.keys(node[":@"]).length > 0) {
      this.child.push({ [node.tagname]: node.child, [":@"]: node[":@"] });
    } else {
      this.child.push({ [node.tagname]: node.child });
    }
    this.addStartIndex(startIndex);
  }
  addStartIndex(startIndex) {
    if (startIndex !== void 0) {
      this.child[this.child.length - 1][METADATA_SYMBOL] = { startIndex };
    }
  }
  addEndIndex(endIndex) {
    const lastChild = this.child[this.child.length - 1];
    if (lastChild !== void 0 && lastChild[METADATA_SYMBOL] !== void 0 && lastChild[METADATA_SYMBOL].endIndex === void 0) {
      lastChild[METADATA_SYMBOL].endIndex = endIndex;
    }
  }
  /** symbol used for metadata */
  static getMetaDataSymbol() {
    return METADATA_SYMBOL;
  }
};

// node_modules/xml-naming/src/index.js
var nameStartChar10 = ":A-Za-z_\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u037D\u037F-\u0486\u0488-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD";
var nameChar10 = nameStartChar10 + "\\-\\.\\d\xB7\u0300-\u036F\u203F-\u2040";
var nameStartChar11 = ":A-Za-z_\xC0-\u02FF\u0370-\u037D\u037F-\u0486\u0488-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}";
var nameChar11 = nameStartChar11 + "\\-\\.\\d\xB7\u0300-\u036F\u0487\u203F-\u2040";
var buildRegexes = (startChar, char, flags = "") => {
  const ncStart = startChar.replace(":", "");
  const ncChar = char.replace(":", "");
  const ncNamePat = `[${ncStart}][${ncChar}]*`;
  return {
    name: new RegExp(`^[${startChar}][${char}]*$`, flags),
    ncName: new RegExp(`^${ncNamePat}$`, flags),
    qName: new RegExp(`^${ncNamePat}(?::${ncNamePat})?$`, flags),
    nmToken: new RegExp(`^[${char}]+$`, flags),
    nmTokens: new RegExp(`^[${char}]+(?:\\s+[${char}]+)*$`, flags)
  };
};
var regexes10 = buildRegexes(nameStartChar10, nameChar10);
var regexes11 = buildRegexes(nameStartChar11, nameChar11, "u");
var nameStartCharAscii = ":A-Za-z_";
var nameCharAscii = nameStartCharAscii + "\\-\\.\\d";
var regexesAscii = buildRegexes(nameStartCharAscii, nameCharAscii);
var getRegexes = (xmlVersion = "1.0", asciiOnly = false) => {
  if (asciiOnly) return regexesAscii;
  return xmlVersion === "1.1" ? regexes11 : regexes10;
};
var qName = (str, { xmlVersion = "1.0", asciiOnly = false } = {}) => getRegexes(xmlVersion, asciiOnly).qName.test(str);

// node_modules/fast-xml-parser/src/xmlparser/DocTypeReader.js
var DocTypeReader = class {
  constructor(options, xmlVersion) {
    this.suppressValidationErr = !options;
    this.options = options;
    this.xmlVersion = xmlVersion || 1;
  }
  setXmlVersion(xmlVersion = 1) {
    this.xmlVersion = xmlVersion;
  }
  readDocType(xmlData, i) {
    const entities = /* @__PURE__ */ Object.create(null);
    let entityCount = 0;
    if (xmlData[i + 3] === "O" && xmlData[i + 4] === "C" && xmlData[i + 5] === "T" && xmlData[i + 6] === "Y" && xmlData[i + 7] === "P" && xmlData[i + 8] === "E") {
      i = i + 9;
      let angleBracketsCount = 1;
      let hasBody = false, comment = false;
      let quoteChar = null;
      let exp = "";
      for (; i < xmlData.length; i++) {
        if (quoteChar !== null) {
          if (xmlData[i] === quoteChar) quoteChar = null;
          exp += xmlData[i];
          continue;
        }
        if (!hasBody && !comment && (xmlData[i] === '"' || xmlData[i] === "'")) {
          quoteChar = xmlData[i];
          exp += xmlData[i];
          continue;
        }
        if (xmlData[i] === "<" && !comment) {
          if (hasBody && hasSeq(xmlData, "!ENTITY", i)) {
            i += 7;
            let entityName, val;
            [entityName, val, i] = this.readEntityExp(xmlData, i + 1, this.suppressValidationErr);
            if (val.indexOf("&") === -1) {
              if (this.options.enabled !== false && this.options.maxEntityCount != null && entityCount >= this.options.maxEntityCount) {
                throw new Error(
                  `Entity count (${entityCount + 1}) exceeds maximum allowed (${this.options.maxEntityCount})`
                );
              }
              entities[entityName] = val;
              entityCount++;
            }
          } else if (hasBody && hasSeq(xmlData, "!ELEMENT", i)) {
            i += 8;
            const { index } = this.readElementExp(xmlData, i + 1);
            i = index;
          } else if (hasBody && hasSeq(xmlData, "!ATTLIST", i)) {
            i += 8;
          } else if (hasBody && hasSeq(xmlData, "!NOTATION", i)) {
            i += 9;
            const { index } = this.readNotationExp(xmlData, i + 1, this.suppressValidationErr);
            i = index;
          } else if (hasSeq(xmlData, "!--", i)) comment = true;
          else throw new Error(`Invalid DOCTYPE`);
          angleBracketsCount++;
          exp = "";
        } else if (xmlData[i] === ">") {
          if (comment) {
            if (xmlData[i - 1] === "-" && xmlData[i - 2] === "-") {
              comment = false;
              angleBracketsCount--;
            }
          } else {
            angleBracketsCount--;
          }
          if (angleBracketsCount === 0) {
            break;
          }
        } else if (xmlData[i] === "[") {
          hasBody = true;
        } else {
          exp += xmlData[i];
        }
      }
      if (quoteChar !== null || angleBracketsCount !== 0) {
        throw new Error(`Unclosed DOCTYPE`);
      }
    } else {
      throw new Error(`Invalid Tag instead of DOCTYPE`);
    }
    return { entities, i };
  }
  readEntityExp(xmlData, i) {
    i = skipWhitespace(xmlData, i);
    const startIndex = i;
    while (i < xmlData.length && !/\s/.test(xmlData[i]) && xmlData[i] !== '"' && xmlData[i] !== "'") {
      i++;
    }
    let entityName = xmlData.substring(startIndex, i);
    validateEntityName2(entityName, { xmlVersion: this.xmlVersion });
    i = skipWhitespace(xmlData, i);
    if (!this.suppressValidationErr) {
      if (xmlData.substring(i, i + 6).toUpperCase() === "SYSTEM") {
        throw new Error("External entities are not supported");
      } else if (xmlData[i] === "%") {
        throw new Error("Parameter entities are not supported");
      }
    }
    let entityValue = "";
    [i, entityValue] = this.readIdentifierVal(xmlData, i, "entity");
    if (this.options.enabled !== false && this.options.maxEntitySize != null && entityValue.length > this.options.maxEntitySize) {
      throw new Error(
        `Entity "${entityName}" size (${entityValue.length}) exceeds maximum allowed size (${this.options.maxEntitySize})`
      );
    }
    i--;
    return [entityName, entityValue, i];
  }
  readNotationExp(xmlData, i) {
    i = skipWhitespace(xmlData, i);
    const startIndex = i;
    while (i < xmlData.length && !/\s/.test(xmlData[i])) {
      i++;
    }
    let notationName = xmlData.substring(startIndex, i);
    !this.suppressValidationErr && validateEntityName2(notationName, { xmlVersion: this.xmlVersion });
    i = skipWhitespace(xmlData, i);
    const identifierType = xmlData.substring(i, i + 6).toUpperCase();
    if (!this.suppressValidationErr && identifierType !== "SYSTEM" && identifierType !== "PUBLIC") {
      throw new Error(`Expected SYSTEM or PUBLIC, found "${identifierType}"`);
    }
    i += identifierType.length;
    i = skipWhitespace(xmlData, i);
    let publicIdentifier = null;
    let systemIdentifier = null;
    if (identifierType === "PUBLIC") {
      [i, publicIdentifier] = this.readIdentifierVal(xmlData, i, "publicIdentifier");
      i = skipWhitespace(xmlData, i);
      if (xmlData[i] === '"' || xmlData[i] === "'") {
        [i, systemIdentifier] = this.readIdentifierVal(xmlData, i, "systemIdentifier");
      }
    } else if (identifierType === "SYSTEM") {
      [i, systemIdentifier] = this.readIdentifierVal(xmlData, i, "systemIdentifier");
      if (!this.suppressValidationErr && !systemIdentifier) {
        throw new Error("Missing mandatory system identifier for SYSTEM notation");
      }
    }
    return { notationName, publicIdentifier, systemIdentifier, index: --i };
  }
  readIdentifierVal(xmlData, i, type) {
    let identifierVal = "";
    const startChar = xmlData[i];
    if (startChar !== '"' && startChar !== "'") {
      throw new Error(`Expected quoted string, found "${startChar}"`);
    }
    i++;
    const startIndex = i;
    while (i < xmlData.length && xmlData[i] !== startChar) {
      i++;
    }
    identifierVal = xmlData.substring(startIndex, i);
    if (xmlData[i] !== startChar) {
      throw new Error(`Unterminated ${type} value`);
    }
    i++;
    return [i, identifierVal];
  }
  readElementExp(xmlData, i) {
    i = skipWhitespace(xmlData, i);
    const startIndex = i;
    while (i < xmlData.length && !/\s/.test(xmlData[i])) {
      i++;
    }
    let elementName = xmlData.substring(startIndex, i);
    if (!this.suppressValidationErr && !qName(elementName, { xmlVersion: this.xmlVersion })) {
      throw new Error(`Invalid element name: "${elementName}"`);
    }
    i = skipWhitespace(xmlData, i);
    let contentModel = "";
    if (xmlData[i] === "E" && hasSeq(xmlData, "MPTY", i)) i += 4;
    else if (xmlData[i] === "A" && hasSeq(xmlData, "NY", i)) i += 2;
    else if (xmlData[i] === "(") {
      i++;
      const startIndex2 = i;
      while (i < xmlData.length && xmlData[i] !== ")") {
        i++;
      }
      contentModel = xmlData.substring(startIndex2, i);
      if (xmlData[i] !== ")") {
        throw new Error("Unterminated content model");
      }
    } else if (!this.suppressValidationErr) {
      throw new Error(`Invalid Element Expression, found "${xmlData[i]}"`);
    }
    return {
      elementName,
      contentModel: contentModel.trim(),
      index: i
    };
  }
  readAttlistExp(xmlData, i) {
    i = skipWhitespace(xmlData, i);
    let startIndex = i;
    while (i < xmlData.length && !/\s/.test(xmlData[i])) {
      i++;
    }
    let elementName = xmlData.substring(startIndex, i);
    validateEntityName2(elementName, { xmlVersion: this.xmlVersion });
    i = skipWhitespace(xmlData, i);
    startIndex = i;
    while (i < xmlData.length && !/\s/.test(xmlData[i])) {
      i++;
    }
    let attributeName = xmlData.substring(startIndex, i);
    if (!validateEntityName2(attributeName, { xmlVersion: this.xmlVersion })) {
      throw new Error(`Invalid attribute name: "${attributeName}"`);
    }
    i = skipWhitespace(xmlData, i);
    let attributeType = "";
    if (xmlData.substring(i, i + 8).toUpperCase() === "NOTATION") {
      attributeType = "NOTATION";
      i += 8;
      i = skipWhitespace(xmlData, i);
      if (xmlData[i] !== "(") {
        throw new Error(`Expected '(', found "${xmlData[i]}"`);
      }
      i++;
      let allowedNotations = [];
      while (i < xmlData.length && xmlData[i] !== ")") {
        const startIndex2 = i;
        while (i < xmlData.length && xmlData[i] !== "|" && xmlData[i] !== ")") {
          i++;
        }
        let notation = xmlData.substring(startIndex2, i);
        notation = notation.trim();
        if (!validateEntityName2(notation, { xmlVersion: this.xmlVersion })) {
          throw new Error(`Invalid notation name: "${notation}"`);
        }
        allowedNotations.push(notation);
        if (xmlData[i] === "|") {
          i++;
          i = skipWhitespace(xmlData, i);
        }
      }
      if (xmlData[i] !== ")") {
        throw new Error("Unterminated list of notations");
      }
      i++;
      attributeType += " (" + allowedNotations.join("|") + ")";
    } else {
      const startIndex2 = i;
      while (i < xmlData.length && !/\s/.test(xmlData[i])) {
        i++;
      }
      attributeType += xmlData.substring(startIndex2, i);
      const validTypes = ["CDATA", "ID", "IDREF", "IDREFS", "ENTITY", "ENTITIES", "NMTOKEN", "NMTOKENS"];
      if (!this.suppressValidationErr && !validTypes.includes(attributeType.toUpperCase())) {
        throw new Error(`Invalid attribute type: "${attributeType}"`);
      }
    }
    i = skipWhitespace(xmlData, i);
    let defaultValue = "";
    if (xmlData.substring(i, i + 8).toUpperCase() === "#REQUIRED") {
      defaultValue = "#REQUIRED";
      i += 8;
    } else if (xmlData.substring(i, i + 7).toUpperCase() === "#IMPLIED") {
      defaultValue = "#IMPLIED";
      i += 7;
    } else {
      [i, defaultValue] = this.readIdentifierVal(xmlData, i, "ATTLIST");
    }
    return {
      elementName,
      attributeName,
      attributeType,
      defaultValue,
      index: i
    };
  }
};
var skipWhitespace = (data, index) => {
  while (index < data.length && /\s/.test(data[index])) {
    index++;
  }
  return index;
};
function hasSeq(data, seq, i) {
  for (let j = 0; j < seq.length; j++) {
    if (seq[j] !== data[i + j + 1]) return false;
  }
  return true;
}
function validateEntityName2(name, xmlVersion) {
  if (qName(name, { xmlVersion }))
    return name;
  else
    throw new Error(`Invalid entity name ${name}`);
}

// node_modules/anynum/digitTable.js
var SCRIPT_ZEROS = [
  // Basic Latin (ASCII) — included for completeness / pass-through
  48,
  // 0-9
  // Arabic scripts
  1632,
  // Arabic-Indic ٠١٢٣٤٥٦٧٨٩
  1776,
  // Extended Arabic-Indic (Urdu/Persian/Sindhi) ۰۱۲۳
  // Indic scripts
  2406,
  // Devanagari ०१२३४५६७८९
  2534,
  // Bengali ০১২৩৪৫৬৭৮৯
  2662,
  // Gurmukhi ੦੧੨੩੪੫੬੭੮੯
  2790,
  // Gujarati ૦૧૨૩૪૫૬૭૮૯
  2918,
  // Odia ୦୧୨୩୪୫୬୭୮୯
  3046,
  // Tamil ௦௧௨௩௪௫௬௭௮௯
  3174,
  // Telugu ౦౧౨౩౪౫౬౭౮౯
  3302,
  // Kannada ೦೧೨೩೪೫೬೭೮೯
  3430,
  // Malayalam ൦൧൨൩൪൫൬൭൮൯
  3558,
  // Sinhala Archaic ෦෧෨෩෪෫෬෭෮෯
  // Southeast Asian scripts
  3664,
  // Thai ๐๑๒๓๔๕๖๗๘๙
  3792,
  // Lao ໐໑໒໓໔໕໖໗໘໙
  3872,
  // Tibetan ༠༡༢༣༤༥༦༧༨༩
  4160,
  // Myanmar ၀၁၂၃၄၅၆၇၈၉
  4240,
  // Myanmar Shan ႐႑႒႓႔႕႖႗႘႙
  6112,
  // Khmer ០១២៣៤៥៦៧៨៩
  6160,
  // Mongolian ᠐᠑᠒᠓᠔᠕᠖᠗᠘᠙
  6470,
  // Limbu ᥆᥇᥈᥉᥊᥋᥌᥍᥎᥏
  6608,
  // New Tai Lue ᧐᧑᧒᧓᧔᧕᧖᧗᧘᧙
  6784,
  // Tai Tham Hora ᪀᪁᪂᪃᪄᪅᪆᪇᪈᪉
  6800,
  // Tai Tham Tham ᪐᪑᪒᪓᪔᪕᪖᪗᪘᪙
  6992,
  // Balinese ᭐᭑᭒᭓᭔᭕᭖᭗᭘᭙
  7088,
  // Sundanese ᮰᮱᮲᮳᮴᮵᮶᮷᮸᮹
  7232,
  // Lepcha ᱀᱁᱂᱃᱄᱅᱆᱇᱈᱉
  7248,
  // Ol Chiki ᱐᱑᱒᱓᱔᱕᱖᱗᱘᱙
  // Fullwidth (CJK context)
  65296,
  // Fullwidth ０１２３４５６７８９
  // Mathematical digit variants (Unicode math block)
  120782,
  // Mathematical Bold
  120792,
  // Mathematical Double-Struck
  120802,
  // Mathematical Sans-Serif
  120812,
  // Mathematical Sans-Serif Bold
  120822,
  // Mathematical Monospace
  // Other scripts
  66720,
  // Osmanya 𐒠𐒡𐒢𐒣𐒤𐒥𐒦𐒧𐒨𐒩
  68912,
  // Hanifi Rohingya 𐴰𐴱𐴲𐴳𐴴𐴵𐴶𐴷𐴸𐴹
  69734,
  // Brahmi 𑁦𑁧𑁨𑁩𑁪𑁫𑁬𑁭𑁮𑁯
  69872,
  // Sora Sompeng 𑃰𑃱𑃲𑃳𑃴𑃵𑃶𑃷𑃸𑃹
  69942,
  // Chakma 𑄶𑄷𑄸𑄹𑄺𑄻𑄼𑄽𑄾𑄿
  70096,
  // Sharada 𑇐𑇑𑇒𑇓𑇔𑇕𑇖𑇗𑇘𑇙
  70384,
  // Khudawadi 𑋰𑋱𑋲𑋳𑋴𑋵𑋶𑋷𑋸𑋹
  70736,
  // Newa 𑑐𑑑𑑒𑑓𑑔𑑕𑑖𑑗𑑘𑑙
  70864,
  // Tirhuta 𑓐𑓑𑓒𑓓𑓔𑓕𑓖𑓗𑓘𑓙
  71248,
  // Modi 𑙐𑙑𑙒𑙓𑙔𑙕𑙖𑙗𑙘𑙙
  71360,
  // Takri 𑛀𑛁𑛂𑛃𑛄𑛅𑛆𑛇𑛈𑛉
  71472,
  // Ahom 𑜰𑜱𑜲𑜳𑜴𑜵𑜶𑜷𑜸𑜹
  71904,
  // Warang Citi 𑣠𑣡𑣢𑣣𑣤𑣥𑣦𑣧𑣨𑣩
  72016,
  // Dives Akuru 𑥐𑥑𑥒𑥓𑥔𑥕𑥖𑥗𑥘𑥙
  72688,
  // Khitan Small Script 𑯰𑯱𑯲𑯳𑯴𑯵𑯶𑯷𑯸𑯹
  72784,
  // Bhaiksuki 𑱐𑱑𑱒𑱓𑱔𑱕𑱖𑱗𑱘𑱙
  73040,
  // Masaram Gondi 𑵐𑵑𑵒𑵓𑵔𑵕𑵖𑵗𑵘𑵙
  73120,
  // Gunjala Gondi 𑶠𑶡𑶢𑶣𑶤𑶥𑶦𑶧𑶨𑶩
  73552,
  // Kawi 𑽐𑽑𑽒𑽓𑽔𑽕𑽖𑽗𑽘𑽙
  92768,
  // Mro 𖩠𖩡𖩢𖩣𖩤𖩥𖩦𖩧𖩨𖩩
  92864,
  // Tangsa 𖫀𖫁𖫂𖫃𖫄𖫅𖫆𖫇𖫈𖫉
  93008,
  // Pahawh Hmong 𖭐𖭑𖭒𖭓𖭔𖭕𖭖𖭗𖭘𖭙
  123200,
  // Nyiakeng Puachue Hmong 𞅀𞅁𞅂𞅃𞅄𞅅𞅆𞅇𞅈𞅉
  123632,
  // Wancho 𞋰𞋱𞋲𞋳𞋴𞋵𞋶𞋷𞋸𞋹
  124144,
  // Nag Mundari 𞓰𞓱𞓲𞓳𞓴𞓵𞓶𞓷𞓸𞓹
  125264,
  // Adlam 𞥐𞥑𞥒𞥓𞥔𞥕𞥖𞥗𞥘𞥙
  130032
  // Segmented digit symbols 🯰🯱🯲🯳🯴🯵🯶🯷🯸🯹
];
var NOT_DIGIT = 255;
var HIGH_MAP = /* @__PURE__ */ new Map();
var LOW_MAX = 65535;
var LOW_MIN = 1632;
var TABLE_OFFSET = LOW_MIN;
var TABLE_SIZE = LOW_MAX - LOW_MIN + 1;
var TABLE = new Uint8Array(TABLE_SIZE).fill(NOT_DIGIT);
for (const zero of SCRIPT_ZEROS) {
  for (let d = 0; d < 10; d++) {
    const cp = zero + d;
    if (cp <= LOW_MAX) {
      TABLE[cp - TABLE_OFFSET] = d;
    } else {
      HIGH_MAP.set(cp, d);
    }
  }
}

// node_modules/anynum/anynum.js
var CHAR_0 = 48;
var CHAR_9 = 57;
var CHAR_MINUS = 45;
var MINUS_SET = /* @__PURE__ */ new Set([8722, 65293, 65123]);
function anynum(str) {
  if (typeof str !== "string") return str;
  const len = str.length;
  if (len === 0) return str;
  let firstHit = -1;
  for (let i = 0; i < len; i++) {
    const cc = str.charCodeAt(i);
    if (cc >= CHAR_0 && cc <= CHAR_9 || cc === CHAR_MINUS) continue;
    if (cc < TABLE_OFFSET) {
      if (MINUS_SET.has(cc)) {
        firstHit = i;
        break;
      }
      continue;
    }
    if (cc >= 55296 && cc <= 56319) {
      if (i + 1 < len) {
        const low = str.charCodeAt(i + 1);
        if (low >= 56320 && low <= 57343) {
          const cp = 65536 + (cc - 55296 << 10) + (low - 56320);
          if (HIGH_MAP.has(cp)) {
            firstHit = i;
            break;
          }
        }
      }
      continue;
    }
    if (TABLE[cc - TABLE_OFFSET] !== NOT_DIGIT || MINUS_SET.has(cc)) {
      firstHit = i;
      break;
    }
  }
  if (firstHit === -1) return str;
  const chars = [];
  if (firstHit > 0) chars.push(str.slice(0, firstHit));
  for (let i = firstHit; i < len; i++) {
    const cc = str.charCodeAt(i);
    if (cc >= CHAR_0 && cc <= CHAR_9 || cc === CHAR_MINUS) {
      chars.push(str[i]);
      continue;
    }
    if (cc < TABLE_OFFSET) {
      chars.push(MINUS_SET.has(cc) ? "-" : str[i]);
      continue;
    }
    if (cc >= 55296 && cc <= 56319) {
      if (i + 1 < len) {
        const low = str.charCodeAt(i + 1);
        if (low >= 56320 && low <= 57343) {
          const cp = 65536 + (cc - 55296 << 10) + (low - 56320);
          const d2 = HIGH_MAP.get(cp);
          if (d2 !== void 0) {
            chars.push(String.fromCharCode(d2 + 48));
            i++;
            continue;
          }
        }
      }
      chars.push(str[i]);
      continue;
    }
    if (MINUS_SET.has(cc)) {
      chars.push("-");
      continue;
    }
    const d = TABLE[cc - TABLE_OFFSET];
    chars.push(d !== NOT_DIGIT ? String.fromCharCode(d + 48) : str[i]);
  }
  return chars.join("");
}
var anynum_default = anynum;

// node_modules/strnum/strnum.js
var hexRegex = /^[-+]?0x[a-fA-F0-9]+$/;
var binRegex = /^0b[01]+$/;
var octRegex = /^0o[0-7]+$/;
var numRegex = /^([\-\+])?(0*)([0-9]*(\.[0-9]*)?)$/;
var consider = {
  hex: true,
  binary: false,
  octal: false,
  leadingZeros: true,
  decimalPoint: ".",
  eNotation: true,
  //skipLike: /regex/,
  infinity: "original",
  // "null", "infinity" (Infinity type), "string" ("Infinity" (the string literal))
  unicode: false
};
function toNumber(str, options = {}) {
  options = Object.assign({}, consider, options);
  if (!str || typeof str !== "string") return str;
  let trimmedStr = str.trim();
  if (trimmedStr.length === 0) return str;
  else if (options.skipLike !== void 0 && options.skipLike.test(trimmedStr)) return str;
  else if (trimmedStr === "0") return 0;
  if (options.unicode) {
    trimmedStr = anynum_default(trimmedStr);
    if (trimmedStr === "0") return 0;
  }
  if (options.hex && hexRegex.test(trimmedStr)) {
    return parse_int(trimmedStr, 16);
  } else if (options.binary && binRegex.test(trimmedStr)) {
    return parse_int(trimmedStr, 2);
  } else if (options.octal && octRegex.test(trimmedStr)) {
    return parse_int(trimmedStr, 8);
  } else if (!isFinite(trimmedStr)) {
    const num = Number(trimmedStr);
    if (Number.isNaN(num)) return str;
    return handleInfinity(str, num, options);
  } else if (trimmedStr.includes("e") || trimmedStr.includes("E")) {
    return resolveEnotation(str, trimmedStr, options);
  } else {
    const match = numRegex.exec(trimmedStr);
    if (match) {
      const sign = match[1] || "";
      const leadingZeros = match[2];
      let numTrimmedByZeros = trimZeros(match[3]);
      const decimalAdjacentToLeadingZeros = sign ? (
        // 0., -00., 000.
        trimmedStr[leadingZeros.length + 1] === "."
      ) : trimmedStr[leadingZeros.length] === ".";
      if (!options.leadingZeros && (leadingZeros.length > 1 || leadingZeros.length === 1 && !decimalAdjacentToLeadingZeros)) {
        return str;
      } else {
        const num = Number(trimmedStr);
        const parsedStr = String(num);
        if (num === 0) return num;
        if (parsedStr.search(/[eE]/) !== -1) {
          if (options.eNotation) return num;
          else return str;
        } else if (trimmedStr.indexOf(".") !== -1) {
          if (parsedStr === "0") return num;
          else if (parsedStr === numTrimmedByZeros) return num;
          else if (parsedStr === `${sign}${numTrimmedByZeros}`) return num;
          else return str;
        }
        let n = leadingZeros ? numTrimmedByZeros : trimmedStr;
        if (leadingZeros) {
          return n === parsedStr || sign + n === parsedStr ? num : str;
        } else {
          return n === parsedStr || n === sign + parsedStr ? num : str;
        }
      }
    } else {
      return str;
    }
  }
}
var eNotationRegx = /^([-+])?(0*)(\d*(\.\d*)?[eE][-\+]?\d+)$/;
function resolveEnotation(str, trimmedStr, options) {
  if (!options.eNotation) return str;
  const notation = trimmedStr.match(eNotationRegx);
  if (notation) {
    let sign = notation[1] || "";
    const eChar = notation[3].indexOf("e") === -1 ? "E" : "e";
    const leadingZeros = notation[2];
    const eAdjacentToLeadingZeros = sign ? (
      // 0E.
      trimmedStr[leadingZeros.length + 1] === eChar
    ) : trimmedStr[leadingZeros.length] === eChar;
    if (leadingZeros.length > 1 && eAdjacentToLeadingZeros) return str;
    else if (leadingZeros.length === 1 && (notation[3].startsWith(`.${eChar}`) || notation[3][0] === eChar)) {
      return Number(trimmedStr);
    } else if (leadingZeros.length > 0) {
      if (options.leadingZeros && !eAdjacentToLeadingZeros) {
        return Number(trimmedStr);
      } else return str;
    } else {
      return Number(trimmedStr);
    }
  } else {
    return str;
  }
}
function trimZeros(numStr) {
  if (numStr && numStr.indexOf(".") !== -1) {
    let end = numStr.length;
    while (end > 0 && numStr.charCodeAt(end - 1) === 48) end--;
    numStr = numStr.slice(0, end);
    if (numStr === ".") numStr = "0";
    else if (numStr[0] === ".") numStr = "0" + numStr;
    else if (numStr[numStr.length - 1] === ".") numStr = numStr.substring(0, numStr.length - 1);
    return numStr;
  }
  return numStr;
}
function parse_int(numStr, base) {
  const str = numStr.trim();
  if (base === 2 || base === 8) numStr = str.substring(2);
  if (parseInt) return parseInt(numStr, base);
  else if (Number.parseInt) return Number.parseInt(numStr, base);
  else if (window && window.parseInt) return window.parseInt(numStr, base);
  else throw new Error("parseInt, Number.parseInt, window.parseInt are not supported");
}
function handleInfinity(str, num, options) {
  const isPositive = num === Infinity;
  switch (options.infinity.toLowerCase()) {
    case "null":
      return null;
    case "infinity":
      return num;
    // Return Infinity or -Infinity
    case "string":
      return isPositive ? "Infinity" : "-Infinity";
    case "original":
    default:
      return str;
  }
}

// node_modules/fast-xml-parser/src/ignoreAttributes.js
function getIgnoreAttributesFn(ignoreAttributes) {
  if (typeof ignoreAttributes === "function") {
    return ignoreAttributes;
  }
  if (Array.isArray(ignoreAttributes)) {
    return (attrName) => {
      for (const pattern of ignoreAttributes) {
        if (typeof pattern === "string" && attrName === pattern) {
          return true;
        }
        if (pattern instanceof RegExp && pattern.test(attrName)) {
          return true;
        }
      }
    };
  }
  return () => false;
}

// node_modules/path-expression-matcher/src/Expression.js
var Expression = class {
  /**
   * Create a new Expression
   * @param {string} pattern - Pattern string (e.g., "root.users.user", "..user[id]")
   * @param {Object} options - Configuration options
   * @param {string} options.separator - Path separator (default: '.')
   */
  constructor(pattern, options = {}, data) {
    this.pattern = pattern;
    this.separator = options.separator || ".";
    this.segments = this._parse(pattern);
    this.data = data;
    this._hasDeepWildcard = this.segments.some((seg) => seg.type === "deep-wildcard");
    this._hasAttributeCondition = this.segments.some((seg) => seg.attrName !== void 0);
    this._hasPositionSelector = this.segments.some((seg) => seg.position !== void 0);
  }
  /**
   * Parse pattern string into segments
   * @private
   * @param {string} pattern - Pattern to parse
   * @returns {Array} Array of segment objects
   */
  _parse(pattern) {
    const segments = [];
    let i = 0;
    let currentPart = "";
    while (i < pattern.length) {
      if (pattern[i] === this.separator) {
        if (i + 1 < pattern.length && pattern[i + 1] === this.separator) {
          if (currentPart.trim()) {
            segments.push(this._parseSegment(currentPart.trim()));
            currentPart = "";
          }
          segments.push({ type: "deep-wildcard" });
          i += 2;
        } else {
          if (currentPart.trim()) {
            segments.push(this._parseSegment(currentPart.trim()));
          }
          currentPart = "";
          i++;
        }
      } else {
        currentPart += pattern[i];
        i++;
      }
    }
    if (currentPart.trim()) {
      segments.push(this._parseSegment(currentPart.trim()));
    }
    return segments;
  }
  /**
   * Parse a single segment
   * @private
   * @param {string} part - Segment string (e.g., "user", "ns::user", "user[id]", "ns::user:first")
   * @returns {Object} Segment object
   */
  _parseSegment(part) {
    const segment = { type: "tag" };
    let bracketContent = null;
    let withoutBrackets = part;
    const bracketMatch = part.match(/^([^\[]+)(\[[^\]]*\])(.*)$/);
    if (bracketMatch) {
      withoutBrackets = bracketMatch[1] + bracketMatch[3];
      if (bracketMatch[2]) {
        const content = bracketMatch[2].slice(1, -1);
        if (content) {
          bracketContent = content;
        }
      }
    }
    let namespace = void 0;
    let tagAndPosition = withoutBrackets;
    if (withoutBrackets.includes("::")) {
      const nsIndex = withoutBrackets.indexOf("::");
      namespace = withoutBrackets.substring(0, nsIndex).trim();
      tagAndPosition = withoutBrackets.substring(nsIndex + 2).trim();
      if (!namespace) {
        throw new Error(`Invalid namespace in pattern: ${part}`);
      }
    }
    let tag = void 0;
    let positionMatch = null;
    if (tagAndPosition.includes(":")) {
      const colonIndex = tagAndPosition.lastIndexOf(":");
      const tagPart = tagAndPosition.substring(0, colonIndex).trim();
      const posPart = tagAndPosition.substring(colonIndex + 1).trim();
      const isPositionKeyword = ["first", "last", "odd", "even"].includes(posPart) || /^nth\(\d+\)$/.test(posPart);
      if (isPositionKeyword) {
        tag = tagPart;
        positionMatch = posPart;
      } else {
        tag = tagAndPosition;
      }
    } else {
      tag = tagAndPosition;
    }
    if (!tag) {
      throw new Error(`Invalid segment pattern: ${part}`);
    }
    segment.tag = tag;
    if (namespace) {
      segment.namespace = namespace;
    }
    if (bracketContent) {
      if (bracketContent.includes("=")) {
        const eqIndex = bracketContent.indexOf("=");
        segment.attrName = bracketContent.substring(0, eqIndex).trim();
        segment.attrValue = bracketContent.substring(eqIndex + 1).trim();
      } else {
        segment.attrName = bracketContent.trim();
      }
    }
    if (positionMatch) {
      const nthMatch = positionMatch.match(/^nth\((\d+)\)$/);
      if (nthMatch) {
        segment.position = "nth";
        segment.positionValue = parseInt(nthMatch[1], 10);
      } else {
        segment.position = positionMatch;
      }
    }
    return segment;
  }
  /**
   * Get the number of segments
   * @returns {number}
   */
  get length() {
    return this.segments.length;
  }
  /**
   * Check if expression contains deep wildcard
   * @returns {boolean}
   */
  hasDeepWildcard() {
    return this._hasDeepWildcard;
  }
  /**
   * Check if expression has attribute conditions
   * @returns {boolean}
   */
  hasAttributeCondition() {
    return this._hasAttributeCondition;
  }
  /**
   * Check if expression has position selectors
   * @returns {boolean}
   */
  hasPositionSelector() {
    return this._hasPositionSelector;
  }
  /**
   * Get string representation
   * @returns {string}
   */
  toString() {
    return this.pattern;
  }
};

// node_modules/path-expression-matcher/src/ExpressionSet.js
var ExpressionSet = class {
  constructor() {
    this._byDepthAndTag = /* @__PURE__ */ new Map();
    this._wildcardByDepth = /* @__PURE__ */ new Map();
    this._deepWildcards = [];
    this._deepByTerminalTag = /* @__PURE__ */ new Map();
    this._patterns = /* @__PURE__ */ new Set();
    this._sealed = false;
  }
  /**
   * Add an Expression to the set.
   * Duplicate patterns (same pattern string) are silently ignored.
   *
   * @param {import('./Expression.js').default} expression - A pre-constructed Expression instance
   * @returns {this} for chaining
   * @throws {TypeError} if called after seal()
   *
   * @example
   * set.add(new Expression('root.users.user'));
   * set.add(new Expression('..script'));
   */
  add(expression) {
    if (this._sealed) {
      throw new TypeError(
        "ExpressionSet is sealed. Create a new ExpressionSet to add more expressions."
      );
    }
    if (this._patterns.has(expression.pattern)) return this;
    this._patterns.add(expression.pattern);
    if (expression.hasDeepWildcard()) {
      const lastSeg2 = expression.segments[expression.segments.length - 1];
      if (lastSeg2 && lastSeg2.type !== "deep-wildcard" && lastSeg2.tag !== "*") {
        const tag2 = lastSeg2.tag;
        if (!this._deepByTerminalTag.has(tag2)) this._deepByTerminalTag.set(tag2, []);
        this._deepByTerminalTag.get(tag2).push(expression);
      } else {
        this._deepWildcards.push(expression);
      }
      return this;
    }
    const depth = expression.length;
    const lastSeg = expression.segments[expression.segments.length - 1];
    const tag = lastSeg?.tag;
    if (!tag || tag === "*") {
      if (!this._wildcardByDepth.has(depth)) this._wildcardByDepth.set(depth, []);
      this._wildcardByDepth.get(depth).push(expression);
    } else {
      const key = `${depth}:${tag}`;
      if (!this._byDepthAndTag.has(key)) this._byDepthAndTag.set(key, []);
      this._byDepthAndTag.get(key).push(expression);
    }
    return this;
  }
  /**
   * Add multiple expressions at once.
   *
   * @param {import('./Expression.js').default[]} expressions - Array of Expression instances
   * @returns {this} for chaining
   *
   * @example
   * set.addAll([
   *   new Expression('root.users.user'),
   *   new Expression('root.config.setting'),
   * ]);
   */
  addAll(expressions) {
    for (const expr of expressions) this.add(expr);
    return this;
  }
  /**
   * Check whether a pattern string is already present in the set.
   *
   * @param {import('./Expression.js').default} expression
   * @returns {boolean}
   */
  has(expression) {
    return this._patterns.has(expression.pattern);
  }
  /**
   * Number of expressions in the set.
   * @type {number}
   */
  get size() {
    return this._patterns.size;
  }
  /**
   * Seal the set against further modifications.
   * Useful to prevent accidental mutations after config is built.
   * Calling add() or addAll() on a sealed set throws a TypeError.
   *
   * @returns {this}
   */
  seal() {
    this._sealed = true;
    return this;
  }
  /**
   * Whether the set has been sealed.
   * @type {boolean}
   */
  get isSealed() {
    return this._sealed;
  }
  /**
   * Test whether the matcher's current path matches any expression in the set.
   *
   * Evaluation order (cheapest → most expensive):
   *  1. Exact depth + tag bucket  — O(1) lookup, typically 0–2 expressions
   *  2. Depth-only wildcard bucket — O(1) lookup, rare
   *  3. Deep-wildcard list         — always checked, but usually small
   *
   * @param {import('./Matcher.js').default} matcher - Matcher instance (or readOnly view)
   * @returns {boolean} true if any expression matches the current path
   *
   * @example
   * if (stopNodes.matchesAny(matcher)) {
   *   // handle stop node
   * }
   */
  matchesAny(matcher) {
    return this.findMatch(matcher) !== null;
  }
  /**
  * Find and return the first Expression that matches the matcher's current path.
  *
  * Uses the same evaluation order as matchesAny (cheapest → most expensive):
  *  1. Exact depth + tag bucket
  *  2. Depth-only wildcard bucket
  *  3. Deep-wildcard list
  *
  * @param {import('./Matcher.js').default} matcher - Matcher instance (or readOnly view)
  * @returns {import('./Expression.js').default | null} the first matching Expression, or null
  *
  * @example
  * const expr = stopNodes.findMatch(matcher);
  * if (expr) {
  *   // access expr.config, expr.pattern, etc.
  * }
  */
  findMatch(matcher) {
    const depth = matcher.getDepth();
    const tag = matcher.getCurrentTag();
    const exactKey = `${depth}:${tag}`;
    const exactBucket = this._byDepthAndTag.get(exactKey);
    if (exactBucket) {
      for (let i = 0; i < exactBucket.length; i++) {
        if (matcher.matches(exactBucket[i])) return exactBucket[i];
      }
    }
    const wildcardBucket = this._wildcardByDepth.get(depth);
    if (wildcardBucket) {
      for (let i = 0; i < wildcardBucket.length; i++) {
        if (matcher.matches(wildcardBucket[i])) return wildcardBucket[i];
      }
    }
    const deepBucket = this._deepByTerminalTag.get(tag);
    if (deepBucket) {
      for (let i = 0; i < deepBucket.length; i++) {
        if (matcher.matches(deepBucket[i])) return deepBucket[i];
      }
    }
    for (let i = 0; i < this._deepWildcards.length; i++) {
      if (matcher.matches(this._deepWildcards[i])) return this._deepWildcards[i];
    }
    return null;
  }
};

// node_modules/path-expression-matcher/src/Matcher.js
var MatcherView = class {
  /**
   * @param {Matcher} matcher - The parent Matcher instance to read from.
   */
  constructor(matcher) {
    this._matcher = matcher;
  }
  /**
   * Get the path separator used by the parent matcher.
   * @returns {string}
   */
  get separator() {
    return this._matcher.separator;
  }
  /**
   * Get current tag name.
   * @returns {string|undefined}
   */
  getCurrentTag() {
    const path = this._matcher.path;
    return path.length > 0 ? path[path.length - 1].tag : void 0;
  }
  /**
   * Get current namespace.
   * @returns {string|undefined}
   */
  getCurrentNamespace() {
    const path = this._matcher.path;
    return path.length > 0 ? path[path.length - 1].namespace : void 0;
  }
  /**
   * Get current node's attribute value.
   * @param {string} attrName
   * @returns {*}
   */
  getAttrValue(attrName) {
    const path = this._matcher.path;
    if (path.length === 0) return void 0;
    return path[path.length - 1].values?.[attrName];
  }
  /**
   * Check if current node has an attribute.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAttr(attrName) {
    const path = this._matcher.path;
    if (path.length === 0) return false;
    const current = path[path.length - 1];
    return current.values !== void 0 && attrName in current.values;
  }
  /**
   * Get the value of a "kept" attribute from the nearest ancestor (or
   * current node) that declared it via `push(tag, attrs, ns, { keep: [...] })`.
   * @param {string} attrName
   * @returns {*}
   */
  getAnyParentAttr(attrName) {
    return this._matcher.getAnyParentAttr(attrName);
  }
  /**
   * Check whether any ancestor (or the current node) kept the given
   * attribute via `push(tag, attrs, ns, { keep: [...] })`.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAnyParentAttr(attrName) {
    return this._matcher.hasAnyParentAttr(attrName);
  }
  /**
   * Get current node's sibling position (child index in parent).
   * @returns {number}
   */
  getPosition() {
    const path = this._matcher.path;
    if (path.length === 0) return -1;
    return path[path.length - 1].position ?? 0;
  }
  /**
   * Get current node's repeat counter (occurrence count of this tag name).
   * @returns {number}
   */
  getCounter() {
    const path = this._matcher.path;
    if (path.length === 0) return -1;
    return path[path.length - 1].counter ?? 0;
  }
  /**
   * Get current node's sibling index (alias for getPosition).
   * @returns {number}
   * @deprecated Use getPosition() or getCounter() instead
   */
  getIndex() {
    return this.getPosition();
  }
  /**
   * Get current path depth.
   * @returns {number}
   */
  getDepth() {
    return this._matcher.path.length;
  }
  /**
   * Get path as string.
   * @param {string} [separator] - Optional separator (uses default if not provided)
   * @param {boolean} [includeNamespace=true]
   * @returns {string}
   */
  toString(separator, includeNamespace = true) {
    return this._matcher.toString(separator, includeNamespace);
  }
  /**
   * Get path as array of tag names.
   * @returns {string[]}
   */
  toArray() {
    return this._matcher.path.map((n) => n.tag);
  }
  /**
   * Match current path against an Expression.
   * @param {Expression} expression
   * @returns {boolean}
   */
  matches(expression) {
    return this._matcher.matches(expression);
  }
  /**
   * Match any expression in the given set against the current path.
   * @param {ExpressionSet} exprSet
   * @returns {boolean}
   */
  matchesAny(exprSet) {
    return exprSet.matchesAny(this._matcher);
  }
};
var Matcher = class {
  /**
   * Create a new Matcher.
   * @param {Object} [options={}]
   * @param {string} [options.separator='.'] - Default path separator
   */
  constructor(options = {}) {
    this.separator = options.separator || ".";
    this.path = [];
    this.siblingStacks = [];
    this._pathStringCache = null;
    this._view = new MatcherView(this);
    this._keptAttrs = [];
  }
  /**
   * Push a new tag onto the path.
   * @param {string} tagName
   * @param {Object|null} [attrValues=null]
   * @param {string|null} [namespace=null]
   * @param {Object|null} [options=null]
   * @param {string[]} [options.keep] - Names of attributes (from attrValues)
   */
  push(tagName, attrValues = null, namespace = null, options = null) {
    this._pathStringCache = null;
    if (this.path.length > 0) {
      this.path[this.path.length - 1].values = void 0;
    }
    const currentLevel = this.path.length;
    let level = this.siblingStacks[currentLevel];
    if (!level) {
      level = { counts: /* @__PURE__ */ new Map(), total: 0 };
      this.siblingStacks[currentLevel] = level;
    }
    const siblingKey = namespace ? `${namespace}:${tagName}` : tagName;
    const counter = level.counts.get(siblingKey) || 0;
    const position = level.total;
    level.counts.set(siblingKey, counter + 1);
    level.total++;
    const node = {
      tag: tagName,
      position,
      counter
    };
    if (namespace !== null && namespace !== void 0) {
      node.namespace = namespace;
    }
    if (attrValues !== null && attrValues !== void 0) {
      node.values = attrValues;
    }
    this.path.push(node);
    const depth = this.path.length;
    const keep = options !== null ? options.keep : null;
    if (keep !== null && keep !== void 0 && keep.length > 0 && attrValues) {
      for (let i = 0; i < keep.length; i++) {
        const name = keep[i];
        if (attrValues[name] !== void 0) {
          this._keptAttrs.push({ depth, name, value: attrValues[name] });
        }
      }
    }
  }
  /**
   * Pop the last tag from the path.
   * @returns {Object|undefined} The popped node
   */
  pop() {
    if (this.path.length === 0) return void 0;
    this._pathStringCache = null;
    const node = this.path.pop();
    if (this.siblingStacks.length > this.path.length + 1) {
      this.siblingStacks.length = this.path.length + 1;
    }
    const poppedDepth = this.path.length + 1;
    while (this._keptAttrs.length > 0 && this._keptAttrs[this._keptAttrs.length - 1].depth >= poppedDepth) {
      this._keptAttrs.pop();
    }
    return node;
  }
  /**
   * Update current node's attribute values.
   * Useful when attributes are parsed after push.
   * @param {Object} attrValues
   */
  updateCurrent(attrValues) {
    if (this.path.length > 0) {
      const current = this.path[this.path.length - 1];
      if (attrValues !== null && attrValues !== void 0) {
        current.values = attrValues;
      }
    }
  }
  /**
   * Get current tag name.
   * @returns {string|undefined}
   */
  getCurrentTag() {
    return this.path.length > 0 ? this.path[this.path.length - 1].tag : void 0;
  }
  /**
   * Get current namespace.
   * @returns {string|undefined}
   */
  getCurrentNamespace() {
    return this.path.length > 0 ? this.path[this.path.length - 1].namespace : void 0;
  }
  /**
   * Get current node's attribute value.
   * @param {string} attrName
   * @returns {*}
   */
  getAttrValue(attrName) {
    if (this.path.length === 0) return void 0;
    return this.path[this.path.length - 1].values?.[attrName];
  }
  /**
   * Check if current node has an attribute.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAttr(attrName) {
    if (this.path.length === 0) return false;
    const current = this.path[this.path.length - 1];
    return current.values !== void 0 && attrName in current.values;
  }
  /**
   * Get the value of a "kept" attribute from the nearest ancestor (or
   * current node) that declared it via `push(tag, attrs, ns, { keep: [...] })`.
   * Unlike getAttrValue(), this works regardless of how deep the path has
   * gone since the attribute was pushed — but only for attribute names that
   * were explicitly marked with `keep` at push time. Cost is proportional to
   * the number of currently-kept attributes (typically 0-3), not path depth.
   * @param {string} attrName
   * @returns {*} the value, or undefined if no ancestor kept this attribute
   */
  getAnyParentAttr(attrName) {
    const kept = this._keptAttrs;
    for (let i = kept.length - 1; i >= 0; i--) {
      if (kept[i].name === attrName) return kept[i].value;
    }
    return void 0;
  }
  /**
   * Check whether any ancestor (or the current node) kept the given
   * attribute via `push(tag, attrs, ns, { keep: [...] })`.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAnyParentAttr(attrName) {
    const kept = this._keptAttrs;
    for (let i = kept.length - 1; i >= 0; i--) {
      if (kept[i].name === attrName) return true;
    }
    return false;
  }
  /**
   * Get current node's sibling position (child index in parent).
   * @returns {number}
   */
  getPosition() {
    if (this.path.length === 0) return -1;
    return this.path[this.path.length - 1].position ?? 0;
  }
  /**
   * Get current node's repeat counter (occurrence count of this tag name).
   * @returns {number}
   */
  getCounter() {
    if (this.path.length === 0) return -1;
    return this.path[this.path.length - 1].counter ?? 0;
  }
  /**
   * Get current node's sibling index (alias for getPosition).
   * @returns {number}
   * @deprecated Use getPosition() or getCounter() instead
   */
  getIndex() {
    return this.getPosition();
  }
  /**
   * Get current path depth.
   * @returns {number}
   */
  getDepth() {
    return this.path.length;
  }
  /**
   * Get path as string.
   * @param {string} [separator] - Optional separator (uses default if not provided)
   * @param {boolean} [includeNamespace=true]
   * @returns {string}
   */
  toString(separator, includeNamespace = true) {
    const sep2 = separator || this.separator;
    const isDefault = sep2 === this.separator && includeNamespace === true;
    if (isDefault) {
      if (this._pathStringCache !== null) {
        return this._pathStringCache;
      }
      const result = this.path.map(
        (n) => n.namespace ? `${n.namespace}:${n.tag}` : n.tag
      ).join(sep2);
      this._pathStringCache = result;
      return result;
    }
    return this.path.map(
      (n) => includeNamespace && n.namespace ? `${n.namespace}:${n.tag}` : n.tag
    ).join(sep2);
  }
  /**
   * Get path as array of tag names.
   * @returns {string[]}
   */
  toArray() {
    return this.path.map((n) => n.tag);
  }
  /**
   * Reset the path to empty.
   */
  reset() {
    this._pathStringCache = null;
    this.path = [];
    this.siblingStacks = [];
    this._keptAttrs = [];
  }
  /**
   * Match current path against an Expression.
   * @param {Expression} expression
   * @returns {boolean}
   */
  matches(expression) {
    const segments = expression.segments;
    if (segments.length === 0) {
      return false;
    }
    if (expression.hasDeepWildcard()) {
      return this._matchWithDeepWildcard(segments);
    }
    return this._matchSimple(segments);
  }
  /**
   * @private
   */
  _matchSimple(segments) {
    if (this.path.length !== segments.length) {
      return false;
    }
    for (let i = 0; i < segments.length; i++) {
      if (!this._matchSegment(segments[i], this.path[i], i === this.path.length - 1)) {
        return false;
      }
    }
    return true;
  }
  /**
   * @private
   */
  _matchWithDeepWildcard(segments) {
    let pathIdx = this.path.length - 1;
    let segIdx = segments.length - 1;
    while (segIdx >= 0 && pathIdx >= 0) {
      const segment = segments[segIdx];
      if (segment.type === "deep-wildcard") {
        segIdx--;
        if (segIdx < 0) {
          return true;
        }
        const nextSeg = segments[segIdx];
        let found = false;
        for (let i = pathIdx; i >= 0; i--) {
          if (this._matchSegment(nextSeg, this.path[i], i === this.path.length - 1)) {
            pathIdx = i - 1;
            segIdx--;
            found = true;
            break;
          }
        }
        if (!found) {
          return false;
        }
      } else {
        if (!this._matchSegment(segment, this.path[pathIdx], pathIdx === this.path.length - 1)) {
          return false;
        }
        pathIdx--;
        segIdx--;
      }
    }
    return segIdx < 0;
  }
  /**
   * @private
   */
  _matchSegment(segment, node, isCurrentNode) {
    if (segment.tag !== "*" && segment.tag !== node.tag) {
      return false;
    }
    if (segment.namespace !== void 0) {
      if (segment.namespace !== "*" && segment.namespace !== node.namespace) {
        return false;
      }
    }
    if (segment.attrName !== void 0) {
      if (!isCurrentNode) {
        return false;
      }
      if (!node.values || !(segment.attrName in node.values)) {
        return false;
      }
      if (segment.attrValue !== void 0) {
        if (String(node.values[segment.attrName]) !== String(segment.attrValue)) {
          return false;
        }
      }
    }
    if (segment.position !== void 0) {
      if (!isCurrentNode) {
        return false;
      }
      const counter = node.counter ?? 0;
      if (segment.position === "first" && counter !== 0) {
        return false;
      } else if (segment.position === "odd" && counter % 2 !== 1) {
        return false;
      } else if (segment.position === "even" && counter % 2 !== 0) {
        return false;
      } else if (segment.position === "nth" && counter !== segment.positionValue) {
        return false;
      }
    }
    return true;
  }
  /**
   * Match any expression in the given set against the current path.
   * @param {ExpressionSet} exprSet
   * @returns {boolean}
   */
  matchesAny(exprSet) {
    return exprSet.matchesAny(this);
  }
  /**
   * Create a snapshot of current state.
   * @returns {Object}
   */
  snapshot() {
    return {
      path: this.path.map((node) => ({ ...node })),
      siblingStacks: this.siblingStacks.map((level) => level ? { counts: new Map(level.counts), total: level.total } : level),
      keptAttrs: this._keptAttrs.map((entry) => ({ ...entry }))
    };
  }
  /**
   * Restore state from snapshot.
   * @param {Object} snapshot
   */
  restore(snapshot) {
    this._pathStringCache = null;
    this.path = snapshot.path.map((node) => ({ ...node }));
    this.siblingStacks = snapshot.siblingStacks.map((level) => level ? { counts: new Map(level.counts), total: level.total } : level);
    this._keptAttrs = (snapshot.keptAttrs || []).map((entry) => ({ ...entry }));
  }
  /**
   * Return the read-only {@link MatcherView} for this matcher.
   *
   * The same instance is returned on every call — no allocation occurs.
   * It always reflects the current parser state and is safe to pass to
   * user callbacks without risk of accidental mutation.
   *
   * @returns {MatcherView}
   *
   * @example
   * const view = matcher.readOnly();
   * // pass view to callbacks — it stays in sync automatically
   * view.matches(expr);       // ✓
   * view.getCurrentTag();     // ✓
   * // view.push(...)         // ✗ method does not exist — caught by TypeScript
   */
  readOnly() {
    return this._view;
  }
};

// node_modules/is-unsafe/src/contexts/html.js
var HTML_PATTERNS = [
  {
    id: "html-script-open",
    description: "<script opening tag",
    pattern: /<script[\s>/]/i
  },
  {
    id: "html-script-close",
    description: "<\/script closing tag",
    pattern: /<\/script[\s>]/i
  },
  {
    id: "html-javascript-protocol",
    description: "javascript: URI scheme (with optional whitespace/encoding)",
    // Handles j&#x61;vascript:, j\u0061vascript:, and whitespace variants
    pattern: /j[\t\n\r ]*a[\t\n\r ]*v[\t\n\r ]*a[\t\n\r ]*s[\t\n\r ]*c[\t\n\r ]*r[\t\n\r ]*i[\t\n\r ]*p[\t\n\r ]*t[\t\n\r ]*:/i
  },
  {
    id: "html-vbscript-protocol",
    description: "vbscript: URI scheme",
    pattern: /vbscript[\t\n\r ]*:/i
  },
  {
    id: "html-data-html",
    description: "data:text/html URI \u2014 can execute scripts in browsers",
    pattern: /data[\t\n\r ]*:[\t\n\r ]*text\/html/i
  },
  {
    id: "html-data-xhtml",
    description: "data:application/xhtml+xml URI",
    pattern: /data[\t\n\r ]*:[\t\n\r ]*application\/xhtml/i
  },
  {
    id: "html-data-svg",
    description: "data:image/svg+xml URI \u2014 can execute scripts",
    pattern: /data[\t\n\r ]*:[\t\n\r ]*image\/svg\+xml/i
  },
  {
    id: "html-inline-event-handler",
    description: "Inline event handler attributes: onclick=, onerror=, onload=, etc.",
    // \bon ensures we match a word boundary so "phonetic=" is not caught
    pattern: /\bon\w{1,30}\s*=/i
  },
  {
    id: "html-entity-obfuscated-script",
    description: "HTML-entity-encoded <script (e.g. &#x3C;script or &lt;script)",
    // Entities include optional trailing semicolon: &#x3C; or &#x3C (both valid in HTML5)
    pattern: /(?:&#x0*3[Cc];?|&#0*60;?|&lt;)\s*script/i
  },
  {
    id: "html-entity-obfuscated-javascript",
    description: 'HTML-entity-encoded javascript: (partial \u2014 catches common &#106; or &#x6a; for "j")',
    pattern: /(?:&#x0*6[Aa];?|&#0*106;?)\s*(?:&#x0*61;?|a)[\s\S]{0,80}script\s*:/i
  },
  {
    id: "html-style-expression",
    description: "CSS expression() \u2014 IE-era code execution in style attributes",
    pattern: /style[\s\S]{0,20}expression\s*\(/i
  },
  {
    id: "html-object-embed",
    description: "<object or <embed tags that can load active content",
    pattern: /<(?:object|embed)[\s>/]/i
  },
  {
    id: "html-base-tag",
    description: "<base href= \u2014 can hijack all relative URLs on a page",
    pattern: /<base[\s>]/i
  },
  {
    id: "html-meta-refresh",
    description: '<meta http-equiv="refresh" \u2014 can redirect users',
    pattern: /<meta[\s\S]{0,40}http-equiv[\s\S]{0,20}refresh/i
  },
  {
    id: "html-srcdoc",
    description: "srcdoc= attribute on iframes \u2014 embeds HTML that can run scripts",
    pattern: /srcdoc\s*=/i
  },
  {
    id: "html-iframe",
    description: "<iframe tag",
    pattern: /<iframe[\s>/]/i
  },
  {
    id: "html-form",
    description: "<form tag \u2014 can be used for phishing / credential harvesting injection",
    pattern: /<form[\s>/]/i
  }
];
var html_default = HTML_PATTERNS;

// node_modules/is-unsafe/src/contexts/xml.js
var XML_PATTERNS = [
  {
    id: "xml-cdata-injection",
    description: "CDATA section injection: <![CDATA[ breaks out of text node context",
    pattern: /<!\[CDATA\[/i
  },
  {
    id: "xml-cdata-close",
    description: "CDATA close sequence: ]]> can terminate an enclosing CDATA section",
    pattern: /\]\]>/
  },
  {
    id: "xml-processing-instruction",
    description: "XML processing instruction: <?xml-stylesheet or <?php etc.",
    pattern: /<\?(?:xml[\- ]|php|asp)/i
  },
  {
    id: "xml-doctype-injection",
    description: "DOCTYPE declaration embedded in content \u2014 can define entities",
    // Match <!DOCTYPE followed by end-of-string, whitespace, or [ (internal subset)
    pattern: /<!DOCTYPE(?:[\s[]|$)/i
  },
  {
    id: "xml-entity-system",
    description: "SYSTEM keyword \u2014 used in external entity declarations (XXE)",
    pattern: /\bSYSTEM\s+["']/i
  },
  {
    id: "xml-entity-public",
    description: "PUBLIC keyword \u2014 used in external entity declarations (XXE)",
    pattern: /\bPUBLIC\s+["']/i
  },
  {
    id: "xml-entity-declaration",
    description: "<!ENTITY declaration \u2014 defines entities, potential XXE or entity expansion",
    pattern: /<!ENTITY[\s%]/i
  },
  {
    id: "xml-billion-laughs",
    description: "Entity reference chaining / billion laughs: repeated &eX; style references",
    // Heuristic: 3+ consecutive entity refs suggests expansion attack
    pattern: /(?:&\w{1,20};){3,}/
  },
  {
    id: "xml-namespace-confusion",
    description: "xmlns: attribute injection \u2014 can redefine namespaces to confuse parsers",
    // pattern: /\bxmlns\s*(?::\w{1,40})?\s*=/i,
    pattern: /\bxmlns(?::\w{1,40})?\s*=/i
  },
  {
    id: "xml-comment-injection",
    description: "<!-- comment injection \u2014 can hide content from some parsers",
    pattern: /<!--/
  },
  {
    id: "xml-comment-close",
    description: "--> closes an enclosing XML comment",
    pattern: /-->/
  },
  {
    id: "xml-pi-close",
    description: "?> closes an enclosing processing instruction",
    pattern: /\?>/
  }
];
var xml_default = XML_PATTERNS;

// node_modules/is-unsafe/src/contexts/svg.js
var SVG_PATTERNS = [
  {
    id: "svg-script-element",
    description: "<script element inside SVG executes JavaScript",
    pattern: /<script[\s>/]/i
  },
  {
    id: "svg-xlink-href-javascript",
    description: "xlink:href with javascript: \u2014 classic SVG XSS via <a> or <use>",
    pattern: /xlink\s*:\s*href\s*=\s*["']?\s*javascript\s*:/i
  },
  {
    id: "svg-href-javascript",
    description: "href= with javascript: in SVG context (<a>, <animate>, etc.)",
    pattern: /href\s*=\s*["']?\s*javascript\s*:/i
  },
  {
    id: "svg-foreignobject",
    description: "<foreignObject embeds HTML inside SVG \u2014 can execute scripts",
    pattern: /<foreignObject[\s>/]/i
  },
  {
    id: "svg-use-external",
    description: "<use xlink:href or href pointing to external resource (non-fragment URL)",
    // Match <use with href= where the value starts with a non-# character (external URL)
    // [\"'][^#] catches quoted values not starting with #; [^\"'#\s>] catches unquoted
    pattern: /<use[\s\S]{0,60}(?:xlink\s*:\s*)?href\s*=\s*(?:["'][^#]|[^"'#\s>])/i
  },
  {
    id: "svg-animate-href",
    description: '<animate attributeName="href" \u2014 can dynamically change href to javascript:',
    pattern: /<animate[\s\S]{0,80}attributeName\s*=\s*["'][\s]*href["']/i
  },
  {
    id: "svg-animate-xlinkhref",
    description: '<animate attributeName="xlink:href"',
    pattern: /<animate[\s\S]{0,80}attributeName\s*=\s*["'][\s]*xlink\s*:\s*href["']/i
  },
  {
    id: "svg-set-javascript",
    description: '<set to="javascript:..." \u2014 sets an attribute to a javascript: URI',
    pattern: /<set[\s\S]{0,80}to\s*=\s*["']?\s*javascript\s*:/i
  },
  {
    id: "svg-event-handler",
    description: "SVG-specific event handler attributes: onload=, onerror=, onactivate=, etc.",
    pattern: /\bon(?:load|error|activate|begin|end|repeat|focus|blur|click|mouse\w{1,20}|key\w{1,20})\s*=/i
  },
  {
    id: "svg-handler-generic",
    description: "Generic on* handler catch-all for SVG attributes",
    pattern: /\bon\w{1,30}\s*=/i
  },
  {
    id: "svg-filter-feimage",
    description: "<feImage href= \u2014 filter primitive that can load external resources",
    pattern: /<feImage[\s\S]{0,80}(?:xlink\s*:\s*)?href\s*=/i
  },
  {
    id: "svg-image-external",
    description: "<image xlink:href with http/https or javascript protocol",
    pattern: /<image[\s\S]{0,80}(?:xlink\s*:\s*)?href\s*=\s*["']?\s*(?:https?|javascript)\s*:/i
  },
  {
    id: "svg-style-javascript",
    description: "style= attribute containing javascript: (e.g. background:url(javascript:...))",
    pattern: /style\s*=[\s\S]{0,60}javascript\s*:/i
  }
];
var svg_default = SVG_PATTERNS;

// node_modules/is-unsafe/src/contexts/sql.js
var SQL_PATTERNS = [
  {
    id: "sql-block-comment-open",
    description: "SQL block comment open: /* ... */ \u2014 unusual in legitimate user text",
    pattern: /\/\*/
  },
  {
    id: "sql-union-select",
    description: "UNION SELECT \u2014 most common SQL injection aggregation attack",
    pattern: /\bUNION\s{1,20}(?:ALL\s{1,20})?SELECT\b/i
  },
  {
    id: "sql-drop-table",
    description: "DROP TABLE \u2014 destructive DDL injection",
    pattern: /\bDROP\s{1,20}TABLE\b/i
  },
  {
    id: "sql-drop-database",
    description: "DROP DATABASE \u2014 destructive DDL injection",
    pattern: /\bDROP\s{1,20}DATABASE\b/i
  },
  {
    id: "sql-insert-into",
    description: "INSERT INTO \u2014 data injection",
    pattern: /\bINSERT\s{1,20}INTO\b/i
  },
  {
    id: "sql-delete-from",
    description: "DELETE FROM \u2014 data deletion injection",
    pattern: /\bDELETE\s{1,20}FROM\b/i
  },
  {
    id: "sql-update-set",
    description: "UPDATE ... SET \u2014 data modification injection",
    // Allows arbitrary content between UPDATE and SET (table name, alias, etc.)
    pattern: /\bUPDATE\b[\s\S]{1,60}\bSET\b/i
  },
  {
    id: "sql-exec-xp",
    description: "EXEC xp_ \u2014 MSSQL extended stored procedure execution",
    pattern: /\bEXEC(?:UTE)?\s{1,20}xp_/i
  },
  {
    id: "sql-tautology-string",
    description: `Classic string tautology: ' OR '1'='1 or " OR "1"="1"`,
    // Last quote is optional — injection may truncate it: ' OR '1'='1--
    pattern: /'\s{0,10}OR\s{0,10}'[^']{0,20}'\s*=\s*'[^']{0,20}/i
  },
  {
    id: "sql-tautology-numeric",
    description: "Numeric tautology: OR 1=1",
    pattern: /\bOR\s{1,10}1\s*=\s*1\b/i
  },
  {
    id: "sql-always-true-zero",
    description: "Numeric tautology: OR 0=0",
    pattern: /\bOR\s{1,10}0\s*=\s*0\b/i
  },
  {
    id: "sql-sleep-benchmark",
    description: "Time-based blind injection: SLEEP() or BENCHMARK()",
    pattern: /\b(?:SLEEP|BENCHMARK)\s*\(/i
  },
  {
    id: "sql-waitfor-delay",
    description: "MSSQL time-based blind injection: WAITFOR DELAY",
    pattern: /\bWAITFOR\s{1,20}DELAY\b/i
  },
  {
    id: "sql-char-function",
    description: "CHAR() function \u2014 used to obfuscate injected strings",
    pattern: /\bCHAR\s*\(\s*\d{1,3}/i
  },
  {
    id: "sql-information-schema",
    description: "INFORMATION_SCHEMA \u2014 reconnaissance query for table/column enumeration",
    pattern: /\bINFORMATION_SCHEMA\b/i
  }
];
var sql_default = SQL_PATTERNS;

// node_modules/is-unsafe/src/contexts/shell.js
var SHELL_PATTERNS = [
  {
    id: "shell-path-traversal-unix",
    description: "Unix path traversal: ../  \u2014 climbing the directory tree",
    pattern: /\.\.\//
  },
  {
    id: "shell-path-traversal-windows",
    description: "Windows path traversal: ..\\ \u2014 climbing the directory tree",
    pattern: /\.\.\\/
  },
  {
    id: "shell-path-traversal-encoded",
    description: "URL-encoded path traversal: %2e%2e or %2f variants",
    pattern: /%2e%2e|%2f\.\.|\.\.%2f/i
  },
  {
    id: "shell-null-byte",
    description: "Null byte injection: \\x00 or %00 \u2014 truncates strings in C-backed functions",
    pattern: /\x00|%00/
  },
  {
    id: "shell-semicolon",
    description: "Semicolon command separator: cmd1; cmd2",
    pattern: /;/
  },
  {
    id: "shell-pipe",
    description: "Pipe operator: cmd1 | cmd2",
    pattern: /\|/
  },
  {
    id: "shell-and-operator",
    description: "AND operator: cmd1 && cmd2",
    pattern: /&&/
  },
  {
    id: "shell-or-operator",
    description: "OR operator: cmd1 || cmd2",
    pattern: /\|\|/
  },
  {
    id: "shell-backtick",
    description: "Backtick command substitution: `cmd`",
    pattern: /`/
  },
  {
    id: "shell-dollar-paren",
    description: "Dollar-paren command substitution: $(cmd)",
    pattern: /\$\(/
  },
  {
    id: "shell-dollar-brace",
    description: "Dollar-brace variable expansion: ${var} \u2014 can be abused for injection",
    pattern: /\$\{/
  },
  {
    id: "shell-redirect-out",
    description: "Output redirection: cmd > file or cmd >> file",
    pattern: />{1,2}/
  },
  {
    id: "shell-redirect-in",
    description: "Input redirection: cmd < file",
    pattern: /</
  },
  {
    id: "shell-newline-injection",
    description: "Newline injection: \\n or \\r \u2014 can inject new shell commands",
    pattern: /[\n\r]/
  },
  {
    id: "shell-glob-star",
    description: "Glob expansion: * or ? \u2014 can expand to unintended files",
    // Only flag when combined with path separators to reduce false positives
    pattern: /[/\\][*?]/
  },
  {
    id: "shell-absolute-root",
    description: "Absolute root path injection: string starting with / or \\ (Windows UNC)",
    pattern: /^(?:\/|\\\\)/
  },
  {
    id: "shell-windows-drive",
    description: "Windows drive letter path injection: C:\\ or D:/",
    pattern: /^[a-zA-Z]:[/\\]/
  },
  {
    id: "shell-curl-wget",
    description: "curl/wget with URL or flags \u2014 can exfiltrate data or download payloads",
    // Require a URL scheme (http/https/ftp) or a flag (-) to reduce false positives
    // "curl is a tool" won't match; "curl http://..." or "curl -s ..." will
    pattern: /\b(?:curl|wget)\s+(?:https?:\/\/|ftp:\/\/|-)/i
  }
];
var shell_default = SHELL_PATTERNS;

// node_modules/is-unsafe/src/contexts/redos.js
var REDOS_PATTERNS = [
  {
    id: "redos-nested-quantifier-plus",
    description: "Nested + quantifier inside a group with outer quantifier: (a+)+, (.+b)*, etc.",
    // Matches any group containing a + quantifier, with an outer * or + — catches (a+)+, (.+b)*, etc.
    pattern: /\([^)]*\+[^)]*\)[+*]/
  },
  {
    id: "redos-nested-quantifier-star",
    description: "Nested * quantifier: (a*)* or (a*)+ \u2014 catastrophic backtracking",
    pattern: /\([^)]*\*[^)]*\)[*+]/
  },
  {
    id: "redos-nested-groups",
    description: "Doubly nested quantified groups: ((a+)+) \u2014 guaranteed catastrophic",
    pattern: /\(\([^)]{0,40}\)[+*]\)[+*]/
  },
  {
    id: "redos-alternation-overlap",
    description: "Overlapping alternation under quantifier: (a|a)+ \u2014 ambiguous NFA paths",
    // Detect repeated identical alternatives under a quantifier
    pattern: /\(([^|()]{1,20})\|(?:\1)(?:\|[^|()]{1,20}){0,5}\)[+*?]{1,2}/
  },
  {
    id: "redos-star-plus-concat",
    description: "(x*x)+ pattern \u2014 triggers super-linear backtracking",
    pattern: /\([^)]{0,10}\*[^)]{0,10}\)[+*]/
  },
  {
    id: "redos-dot-star-greedy",
    description: "(.*){n,} or (.+){n,} \u2014 repeated greedy dot quantifiers",
    pattern: /\(\.[*+]\)\{?\d/
  },
  {
    id: "redos-large-repetition",
    description: "Very large fixed or range repetition count {1000,} or {1000,n} \u2014 denial of service via backtracking",
    // Matches { followed by 4+ digits (≥1000), then optional ,digits }
    pattern: /\{\d{4,}(?:,\d*)?\}/
  },
  {
    id: "redos-catastrophic-alternation",
    description: "Long alternation with many similar branches \u2014 polynomial backtracking risk",
    // Heuristic: 10+ pipe-separated alternatives in a single group
    pattern: /\([^)]{0,200}(?:\|[^|)]{0,50}){9,}\)/
  }
];
var redos_default = REDOS_PATTERNS;

// node_modules/is-unsafe/src/contexts/nosql.js
var sep = `["'\\s]*:`;
var NOSQL_PATTERNS = [
  // ─── MongoDB $ operator injection ────────────────────────────────────────
  {
    id: "nosql-where-operator",
    description: "$where \u2014 executes arbitrary JavaScript server-side in MongoDB",
    pattern: new RegExp(`\\$where${sep}`, "i")
  },
  {
    id: "nosql-ne-operator",
    description: '$ne \u2014 "not equal" operator used to bypass equality checks',
    pattern: new RegExp(`\\$ne${sep}`, "i")
  },
  {
    id: "nosql-gt-operator",
    description: '$gt \u2014 "greater than" used to bypass password/value checks',
    pattern: new RegExp(`\\$gte?${sep}`, "i")
  },
  {
    id: "nosql-lt-operator",
    description: '$lt / $lte \u2014 "less than" bypass variants',
    pattern: new RegExp(`\\$lte?${sep}`, "i")
  },
  {
    id: "nosql-regex-operator",
    description: "$regex \u2014 can be used to extract data character by character (blind injection)",
    pattern: new RegExp(`\\$regex${sep}`, "i")
  },
  {
    id: "nosql-or-operator",
    description: "$or \u2014 logical OR; used to create always-true conditions",
    pattern: new RegExp(`\\$or${sep}\\s*\\[`, "i")
  },
  {
    id: "nosql-and-operator",
    description: "$and \u2014 logical AND operator injection",
    pattern: new RegExp(`\\$and${sep}\\s*\\[`, "i")
  },
  {
    id: "nosql-nor-operator",
    description: "$nor \u2014 logical NOR operator injection",
    pattern: new RegExp(`\\$nor${sep}\\s*\\[`, "i")
  },
  {
    id: "nosql-exists-operator",
    description: "$exists \u2014 can enumerate fields to determine schema",
    pattern: new RegExp(`\\$exists${sep}`, "i")
  },
  {
    id: "nosql-in-operator",
    description: "$in \u2014 matches any value in a list; can enumerate values",
    pattern: new RegExp(`\\$in${sep}\\s*\\[`, "i")
  },
  {
    id: "nosql-expr-operator",
    description: "$expr \u2014 allows aggregation expressions in queries (MongoDB 3.6+)",
    pattern: new RegExp(`\\$expr${sep}`, "i")
  },
  {
    id: "nosql-function-operator",
    description: "$function \u2014 executes arbitrary JavaScript in MongoDB 4.4+",
    pattern: new RegExp(`\\$function${sep}`, "i")
  },
  {
    id: "nosql-accumulator-operator",
    description: "$accumulator \u2014 custom aggregation with arbitrary JS execution",
    pattern: new RegExp(`\\$accumulator${sep}`, "i")
  },
  // ─── Prototype pollution ─────────────────────────────────────────────────
  {
    id: "nosql-proto-pollution",
    description: "__proto__ \u2014 prototype pollution via object key injection",
    pattern: /__proto__/
  },
  {
    id: "nosql-constructor-prototype",
    description: "constructor.prototype \u2014 alternative prototype pollution vector (dot notation or JSON key)",
    // Matches dot-notation (obj.constructor.prototype) and JSON key adjacency
    // ("constructor": {"prototype": ...})
    pattern: /constructor[\s"':.,{\[]*prototype/i
  },
  {
    id: "nosql-proto-bracket",
    description: '["__proto__"] \u2014 bracket-notation prototype pollution',
    pattern: /\[["']__proto__["']\]/
  }
];
var nosql_default = NOSQL_PATTERNS;

// node_modules/is-unsafe/src/contexts/log.js
var LOG_PATTERNS = [
  // ─── CRLF / newline injection ─────────────────────────────────────────────
  {
    id: "log-crlf-injection",
    description: "CRLF injection: literal \\r or \\n embeds fake log lines",
    pattern: /[\r\n]/
  },
  {
    id: "log-url-encoded-crlf",
    description: "URL-encoded CRLF: %0d, %0a, %0D, %0A \u2014 decoded by some log parsers",
    pattern: /%0[dDaA]/
  },
  {
    id: "log-unicode-newline",
    description: "Unicode newline variants: U+2028 (line separator), U+2029 (paragraph separator)",
    pattern: /[\u2028\u2029]/
  },
  // ─── Log4Shell / JNDI injection (CVE-2021-44228) ─────────────────────────
  {
    id: "log-log4shell-jndi",
    description: "Log4Shell: ${jndi:...} triggers remote code execution in Apache Log4j",
    pattern: /\$\{jndi\s*:/i
  },
  {
    id: "log-log4shell-obfuscated",
    description: "Obfuscated Log4Shell: ${::-j}... lookup-bypass prefix used to evade WAF detection",
    // ${::- is the Log4j lookup-bypass escape sequence; presence alone is suspicious
    pattern: /\$\{::-/
  },
  {
    id: "log-log4j-lookup",
    description: "Log4j lookup syntax: ${env:...}, ${sys:...}, ${ctx:...} \u2014 data exfiltration",
    pattern: /\$\{(?:env|sys|ctx|main|map|sd|web|docker|k8s|spring)\s*:/i
  },
  // ─── Server-Side Template Injection (SSTI) in log messages ───────────────
  {
    id: "log-ssti-double-brace",
    description: "SSTI double-brace: {{expression}} \u2014 Jinja2, Twig, Handlebars, etc.",
    pattern: /\{\{[\s\S]{0,80}\}\}/
  },
  {
    id: "log-ssti-hash-brace",
    description: "SSTI hash-brace: #{expression} \u2014 Thymeleaf, Velocity, Ruby ERB",
    pattern: /#\{[\s\S]{0,80}\}/
  },
  {
    id: "log-ssti-dollar-brace",
    description: "SSTI/EL injection: ${expression with operators or method calls} \u2014 JSP EL, Freemarker, SpEL",
    // Require that the ${...} content looks like an expression, not a plain variable name.
    // Flags if the content contains: . ( * + operators, or known SSTI keywords.
    // This avoids flagging ${PATH}, ${HOME} etc. (plain shell variables).
    pattern: /\$\{[^}]*(?:\.|\(|\*|\+|\bclass\b|\bruntime\b|\bprocess\b|\bexec\b)[^}]{0,80}\}/i
  },
  {
    id: "log-ssti-percent-tag",
    description: "SSTI ERB/ASP tag: <%= expression %> \u2014 Ruby ERB, ASP",
    pattern: /<%=[\s\S]{0,80}%>/
  },
  // ─── Null byte ────────────────────────────────────────────────────────────
  {
    id: "log-null-byte",
    description: "Null byte: \\x00 or %00 \u2014 can truncate log entries in C-backed loggers",
    pattern: /\x00|%00/
  },
  // ─── ANSI escape injection ────────────────────────────────────────────────
  {
    id: "log-ansi-escape",
    description: "ANSI escape sequence: ESC[ \u2014 can manipulate terminal output when logs are tailed",
    pattern: /\x1b\[/
  }
];
var log_default = LOG_PATTERNS;

// node_modules/is-unsafe/src/contexts/sql-strict.js
var SQL_STRICT_EXTRA = [
  {
    id: "sql-line-comment",
    description: "SQL line comment: -- followed by whitespace or end of string",
    pattern: /--(?:\s|$)/
  },
  {
    id: "sql-stacked-query",
    description: "Stacked queries: semicolon immediately followed by a SQL keyword",
    pattern: /;\s{0,10}(?:SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC)\b/i
  },
  {
    id: "sql-hex-encoding",
    description: "Hex-encoded string injection: 0x41414141 style (MySQL)",
    pattern: /\b0x[0-9a-f]{4,}/i
  }
];
var SQL_STRICT_PATTERNS = [...sql_default, ...SQL_STRICT_EXTRA];
var sql_strict_default = SQL_STRICT_PATTERNS;

// node_modules/is-unsafe/src/util/decode-entities.js
var NAMED = Object.freeze({
  colon: ":",
  Tab: "	",
  NewLine: "\n"
});
var ENTITY_RE = /&(?:#[xX]0*([0-9a-fA-F]{1,6});?|#0*([0-9]{1,7});?|([a-zA-Z][a-zA-Z0-9]{1,15});)/g;
function decodeEntities(input) {
  if (input.indexOf("&") === -1) return input;
  return input.replace(ENTITY_RE, (match, hex, dec, name) => {
    if (name !== void 0) {
      return Object.prototype.hasOwnProperty.call(NAMED, name) ? NAMED[name] : match;
    }
    const cp = hex !== void 0 ? parseInt(hex, 16) : parseInt(dec, 10);
    if (!Number.isFinite(cp) || cp > 1114111) return match;
    return String.fromCodePoint(cp);
  });
}

// node_modules/is-unsafe/src/index.js
html_default.label = "HTML";
xml_default.label = "XML";
svg_default.label = "SVG";
html_default.decodeEntities = true;
xml_default.decodeEntities = true;
svg_default.decodeEntities = true;
sql_default.label = "SQL";
sql_strict_default.label = "SQL-STRICT";
shell_default.label = "SHELL";
redos_default.label = "REDOS";
nosql_default.label = "NOSQL";
log_default.label = "LOG";
var VALID_CONTEXTS = Object.freeze({
  HTML: html_default,
  XML: xml_default,
  SVG: svg_default,
  SQL: sql_default,
  "SQL-STRICT": sql_strict_default,
  SHELL: shell_default,
  REDOS: redos_default,
  NOSQL: nosql_default,
  LOG: log_default
});
function assertString(value) {
  if (typeof value !== "string") {
    throw new TypeError(
      `is-unsafe: first argument must be a string, got ${typeof value}`
    );
  }
}
function assertContext(context) {
  if (context instanceof RegExp) return;
  if (Array.isArray(context)) {
    if (context.length === 0) {
      throw new TypeError("is-unsafe: context must not be an empty array");
    }
    if (Array.isArray(context[0])) {
      for (const list of context) {
        if (!Array.isArray(list) || list.length === 0) {
          throw new TypeError(
            "is-unsafe: each context in the array must be a non-empty pattern array (PatternList)"
          );
        }
      }
    }
    return;
  }
  throw new TypeError(
    `is-unsafe: second argument must be a PatternList (e.g. HTML), an array of PatternLists (e.g. [HTML, XML]), or a RegExp. Got: ${typeof context}`
  );
}
function normalise(context) {
  if (context instanceof RegExp) return { lists: null, regex: context };
  if (Array.isArray(context[0])) return { lists: context, regex: null };
  return { lists: [context], regex: null };
}
function decodedCopy(value, list) {
  if (!list.decodeEntities) return null;
  const decoded = decodeEntities(value);
  return decoded === value ? null : decoded;
}
function matchList(value, list) {
  const label = list.label ?? "CUSTOM";
  const decoded = decodedCopy(value, list);
  for (const rule of list) {
    if (rule.pattern.test(value) || decoded !== null && rule.pattern.test(decoded)) {
      return { context: label, id: rule.id, description: rule.description, pattern: rule.pattern };
    }
  }
  return null;
}
function isUnsafe(value, context) {
  assertString(value);
  assertContext(context);
  const { lists, regex } = normalise(context);
  if (regex) return regex.test(value);
  for (const list of lists) {
    if (matchList(value, list) !== null) return true;
  }
  return false;
}

// node_modules/fast-xml-parser/src/xmlparser/OrderedObjParser.js
function extractRawAttributes(prefixedAttrs, options) {
  if (!prefixedAttrs) return {};
  const attrs = options.attributesGroupName ? prefixedAttrs[options.attributesGroupName] : prefixedAttrs;
  if (!attrs) return {};
  const rawAttrs = {};
  for (const key in attrs) {
    if (key.startsWith(options.attributeNamePrefix)) {
      const rawName = key.substring(options.attributeNamePrefix.length);
      rawAttrs[rawName] = attrs[key];
    } else {
      rawAttrs[key] = attrs[key];
    }
  }
  return rawAttrs;
}
function extractNamespace(rawTagName) {
  if (!rawTagName || typeof rawTagName !== "string") return void 0;
  const colonIndex = rawTagName.indexOf(":");
  if (colonIndex !== -1 && colonIndex > 0) {
    const ns = rawTagName.substring(0, colonIndex);
    if (ns !== "xmlns") {
      return ns;
    }
  }
  return void 0;
}
var OrderedObjParser = class {
  constructor(options, externalEntities) {
    this.options = options;
    this.currentNode = null;
    this.tagsNodeStack = [];
    this.parseXml = parseXml;
    this.parseTextData = parseTextData;
    this.resolveNameSpace = resolveNameSpace;
    this.buildAttributesMap = buildAttributesMap;
    this.isItStopNode = isItStopNode;
    this.replaceEntitiesValue = replaceEntitiesValue;
    this.readStopNodeData = readStopNodeData;
    this.saveTextToParentTag = saveTextToParentTag;
    this.addChild = addChild;
    this.ignoreAttributesFn = getIgnoreAttributesFn(this.options.ignoreAttributes);
    this.entityExpansionCount = 0;
    this.currentExpandedLength = 0;
    this.doctypefound = false;
    let namedEntities = { ...XML };
    if (this.options.entityDecoder) {
      this.entityDecoder = this.options.entityDecoder;
    } else {
      if (typeof this.options.htmlEntities === "object") namedEntities = this.options.htmlEntities;
      else if (this.options.htmlEntities === true) namedEntities = { ...COMMON_HTML, ...CURRENCY };
      this.entityDecoder = new EntityDecoder({
        namedEntities: { ...namedEntities, ...externalEntities },
        numericAllowed: this.options.htmlEntities,
        limit: {
          maxTotalExpansions: this.options.processEntities.maxTotalExpansions,
          maxExpandedLength: this.options.processEntities.maxExpandedLength,
          applyLimitsTo: this.options.processEntities.appliesTo
        },
        // onExternalEntity: (name, value) => isUnsafe(value) ? 'block' : 'allow',
        onInputEntity: (name, value) => (
          //TODO: VALID_CONTEXTS.HTML should be set only if this.options.htmlEntities
          isUnsafe(value, [html_default, xml_default]) ? ENTITY_ACTION.BLOCK : ENTITY_ACTION.ALLOW
        )
        //postCheck: resolved => resolved
      });
    }
    this.matcher = new Matcher();
    this.readonlyMatcher = this.matcher.readOnly();
    this.isCurrentNodeStopNode = false;
    this.stopNodeExpressionsSet = new ExpressionSet();
    const stopNodesOpts = this.options.stopNodes;
    if (stopNodesOpts && stopNodesOpts.length > 0) {
      for (let i = 0; i < stopNodesOpts.length; i++) {
        const stopNodeExp = stopNodesOpts[i];
        if (typeof stopNodeExp === "string") {
          this.stopNodeExpressionsSet.add(new Expression(stopNodeExp));
        } else if (stopNodeExp instanceof Expression) {
          this.stopNodeExpressionsSet.add(stopNodeExp);
        }
      }
      this.stopNodeExpressionsSet.seal();
    }
  }
};
function parseTextData(val, tagName, jPath, dontTrim, hasAttributes, isLeafNode, escapeEntities) {
  const options = this.options;
  if (val !== void 0) {
    if (options.trimValues && !dontTrim) {
      val = val.trim();
    }
    if (val.length > 0) {
      if (!escapeEntities) val = this.replaceEntitiesValue(val, tagName, jPath);
      const jPathOrMatcher = options.jPath ? jPath.toString() : jPath;
      const newval = options.tagValueProcessor(tagName, val, jPathOrMatcher, hasAttributes, isLeafNode);
      if (newval === null || newval === void 0) {
        return val;
      } else if (typeof newval !== typeof val || newval !== val) {
        return newval;
      } else if (options.trimValues) {
        return parseValue(val, options.parseTagValue, options.numberParseOptions);
      } else {
        const trimmedVal = val.trim();
        if (trimmedVal === val) {
          return parseValue(val, options.parseTagValue, options.numberParseOptions);
        } else {
          return val;
        }
      }
    }
  }
}
function resolveNameSpace(tagname) {
  if (this.options.removeNSPrefix) {
    const tags = tagname.split(":");
    const prefix = tagname.charAt(0) === "/" ? "/" : "";
    if (tags[0] === "xmlns") {
      return "";
    }
    if (tags.length === 2) {
      tagname = prefix + tags[1];
    }
  }
  return tagname;
}
var attrsRegx = new RegExp(`([^\\s=]+)\\s*(=\\s*(['"])([\\s\\S]*?)\\3)?`, "gm");
function buildAttributesMap(attrStr, jPath, tagName, force = false) {
  const options = this.options;
  if (force === true || options.ignoreAttributes !== true && typeof attrStr === "string") {
    const matches = getAllMatches(attrStr, attrsRegx);
    const len = matches.length;
    const attrs = {};
    const processedVals = new Array(len);
    let hasRawAttrs = false;
    const rawAttrsForMatcher = {};
    for (let i = 0; i < len; i++) {
      const attrName = this.resolveNameSpace(matches[i][1]);
      const oldVal = matches[i][4];
      if (attrName.length && oldVal !== void 0) {
        let val = oldVal;
        if (options.trimValues) val = val.trim();
        val = this.replaceEntitiesValue(val, tagName, this.readonlyMatcher);
        processedVals[i] = val;
        rawAttrsForMatcher[attrName] = val;
        hasRawAttrs = true;
      }
    }
    if (hasRawAttrs && typeof jPath === "object" && jPath.updateCurrent) {
      jPath.updateCurrent(rawAttrsForMatcher);
    }
    const jPathStr = options.jPath ? jPath.toString() : this.readonlyMatcher;
    let hasAttrs = false;
    for (let i = 0; i < len; i++) {
      const attrName = this.resolveNameSpace(matches[i][1]);
      if (this.ignoreAttributesFn(attrName, jPathStr)) continue;
      let aName = options.attributeNamePrefix + attrName;
      if (attrName.length) {
        if (options.transformAttributeName) {
          aName = options.transformAttributeName(aName);
        }
        aName = sanitizeName(aName, options);
        if (matches[i][4] !== void 0) {
          const oldVal = processedVals[i];
          const newVal = options.attributeValueProcessor(attrName, oldVal, jPathStr);
          if (newVal === null || newVal === void 0) {
            attrs[aName] = oldVal;
          } else if (typeof newVal !== typeof oldVal || newVal !== oldVal) {
            attrs[aName] = newVal;
          } else {
            attrs[aName] = parseValue(oldVal, options.parseAttributeValue, options.numberParseOptions);
          }
          hasAttrs = true;
        } else if (options.allowBooleanAttributes) {
          attrs[aName] = true;
          hasAttrs = true;
        }
      }
    }
    if (!hasAttrs) return;
    if (options.attributesGroupName && !options.preserveOrder) {
      const attrCollection = {};
      attrCollection[options.attributesGroupName] = attrs;
      return attrCollection;
    }
    return attrs;
  }
}
var parseXml = function(xmlData) {
  xmlData = xmlData.replace(/\r\n?/g, "\n");
  const xmlObj = new XmlNode("!xml");
  let currentNode = xmlObj;
  let textData = "";
  this.matcher.reset();
  this.entityDecoder.reset();
  this.entityExpansionCount = 0;
  this.currentExpandedLength = 0;
  this.doctypefound = false;
  const options = this.options;
  const docTypeReader = new DocTypeReader(options.processEntities);
  const xmlLen = xmlData.length;
  for (let i = 0; i < xmlLen; i++) {
    const ch = xmlData[i];
    if (ch === "<") {
      const c1 = xmlData.charCodeAt(i + 1);
      if (c1 === 47) {
        const closeIndex = findClosingIndex(xmlData, ">", i, "Closing Tag is not closed.");
        let tagName = xmlData.substring(i + 2, closeIndex).trim();
        if (options.removeNSPrefix) {
          const colonIndex = tagName.indexOf(":");
          if (colonIndex !== -1) {
            tagName = tagName.substr(colonIndex + 1);
          }
        }
        tagName = transformTagName(options.transformTagName, tagName, "", options).tagName;
        if (currentNode) {
          textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
        }
        const lastTagName = this.matcher.getCurrentTag();
        if (tagName && options.unpairedTagsSet.has(tagName)) {
          throw new Error(`Unpaired tag can not be used as closing tag: </${tagName}>`);
        }
        if (lastTagName && options.unpairedTagsSet.has(lastTagName)) {
          this.matcher.pop();
          this.tagsNodeStack.pop();
        }
        this.matcher.pop();
        this.isCurrentNodeStopNode = false;
        currentNode = this.tagsNodeStack.pop() || xmlObj;
        if (options.captureMetaData && currentNode) {
          currentNode.addEndIndex(closeIndex + 1);
        }
        textData = "";
        i = closeIndex;
      } else if (c1 === 63) {
        let tagData = readTagExp(xmlData, i, false, "?>");
        if (!tagData) throw new Error("Pi Tag is not closed.");
        textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
        const attsMap = this.buildAttributesMap(tagData.tagExp, this.matcher, tagData.tagName, true);
        if (attsMap) {
          const ver = attsMap[this.options.attributeNamePrefix + "version"];
          this.entityDecoder.setXmlVersion(Number(ver) || 1);
          docTypeReader.setXmlVersion(Number(ver) || 1);
        }
        if (options.ignoreDeclaration && tagData.tagName === "?xml" || options.ignorePiTags) {
        } else {
          const childNode = new XmlNode(tagData.tagName);
          childNode.add(options.textNodeName, "");
          if (tagData.tagName !== tagData.tagExp && tagData.attrExpPresent && options.ignoreAttributes !== true) {
            childNode[":@"] = attsMap;
          }
          this.addChild(currentNode, childNode, this.readonlyMatcher, i);
          if (options.captureMetaData) {
            currentNode.addEndIndex(tagData.closeIndex + 2);
          }
        }
        i = tagData.closeIndex + 1;
      } else if (c1 === 33 && xmlData.charCodeAt(i + 2) === 45 && xmlData.charCodeAt(i + 3) === 45) {
        const endIndex = findClosingIndex(xmlData, "-->", i + 4, "Comment is not closed.");
        if (options.commentPropName) {
          const comment = xmlData.substring(i + 4, endIndex - 2);
          textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
          currentNode.add(options.commentPropName, [{ [options.textNodeName]: comment }]);
        }
        i = endIndex;
      } else if (c1 === 33 && xmlData.charCodeAt(i + 2) === 68) {
        if (this.doctypefound) throw new Error("Multiple DOCTYPE declarations found.");
        this.doctypefound = true;
        const result = docTypeReader.readDocType(xmlData, i);
        this.entityDecoder.addInputEntities(result.entities);
        i = result.i;
      } else if (c1 === 33 && xmlData.charCodeAt(i + 2) === 91) {
        const closeIndex = findClosingIndex(xmlData, "]]>", i, "CDATA is not closed.") - 2;
        const tagExp = xmlData.substring(i + 9, closeIndex);
        textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
        let val = this.parseTextData(tagExp, currentNode.tagname, this.readonlyMatcher, true, false, true, true);
        if (val == void 0) val = "";
        if (options.cdataPropName) {
          currentNode.add(options.cdataPropName, [{ [options.textNodeName]: tagExp }]);
        } else {
          currentNode.add(options.textNodeName, val);
        }
        i = closeIndex + 2;
      } else {
        let result = readTagExp(xmlData, i, options.removeNSPrefix);
        if (!result) {
          const context = xmlData.substring(Math.max(0, i - 50), Math.min(xmlLen, i + 50));
          throw new Error(`readTagExp returned undefined at position ${i}. Context: "${context}"`);
        }
        let tagName = result.tagName;
        const rawTagName = result.rawTagName;
        let tagExp = result.tagExp;
        let attrExpPresent = result.attrExpPresent;
        let closeIndex = result.closeIndex;
        ({ tagName, tagExp } = transformTagName(options.transformTagName, tagName, tagExp, options));
        if (options.strictReservedNames && (tagName === options.commentPropName || tagName === options.cdataPropName || tagName === options.textNodeName || tagName === options.attributesGroupName)) {
          throw new Error(`Invalid tag name: ${tagName}`);
        }
        if (currentNode && textData) {
          if (currentNode.tagname !== "!xml") {
            textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher, false);
          }
        }
        const lastTag = currentNode;
        if (lastTag && options.unpairedTagsSet.has(lastTag.tagname)) {
          currentNode = this.tagsNodeStack.pop();
          this.matcher.pop();
        }
        let isSelfClosing = false;
        if (tagExp.length > 0 && tagExp.lastIndexOf("/") === tagExp.length - 1) {
          isSelfClosing = true;
          if (tagName[tagName.length - 1] === "/") {
            tagName = tagName.substr(0, tagName.length - 1);
            tagExp = tagName;
          } else {
            tagExp = tagExp.substr(0, tagExp.length - 1);
          }
          attrExpPresent = tagName !== tagExp;
        }
        let prefixedAttrs = null;
        let rawAttrs = {};
        let namespace = void 0;
        namespace = extractNamespace(rawTagName);
        if (tagName !== xmlObj.tagname) {
          this.matcher.push(tagName, {}, namespace);
        }
        if (tagName !== tagExp && attrExpPresent) {
          prefixedAttrs = this.buildAttributesMap(tagExp, this.matcher, tagName);
          if (prefixedAttrs) {
            rawAttrs = extractRawAttributes(prefixedAttrs, options);
          }
        }
        if (tagName !== xmlObj.tagname) {
          this.isCurrentNodeStopNode = this.isItStopNode();
        }
        const startIndex = i;
        if (this.isCurrentNodeStopNode) {
          let tagContent = "";
          if (isSelfClosing) {
            i = result.closeIndex;
          } else if (options.unpairedTagsSet.has(tagName)) {
            i = result.closeIndex;
          } else {
            const result2 = this.readStopNodeData(xmlData, rawTagName, closeIndex + 1);
            if (!result2) throw new Error(`Unexpected end of ${rawTagName}`);
            i = result2.i;
            tagContent = result2.tagContent;
          }
          const childNode = new XmlNode(tagName);
          if (prefixedAttrs) {
            childNode[":@"] = prefixedAttrs;
          }
          childNode.add(options.textNodeName, tagContent);
          this.matcher.pop();
          this.isCurrentNodeStopNode = false;
          this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
          if (options.captureMetaData) {
            currentNode.addEndIndex(i + 1);
          }
        } else {
          if (isSelfClosing) {
            ({ tagName, tagExp } = transformTagName(options.transformTagName, tagName, tagExp, options));
            const childNode = new XmlNode(tagName);
            if (prefixedAttrs) {
              childNode[":@"] = prefixedAttrs;
            }
            this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
            if (options.captureMetaData) {
              currentNode.addEndIndex(closeIndex + 1);
            }
            this.matcher.pop();
            this.isCurrentNodeStopNode = false;
          } else if (options.unpairedTagsSet.has(tagName)) {
            const childNode = new XmlNode(tagName);
            if (prefixedAttrs) {
              childNode[":@"] = prefixedAttrs;
            }
            this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
            if (options.captureMetaData) {
              currentNode.addEndIndex(result.closeIndex + 1);
            }
            this.matcher.pop();
            this.isCurrentNodeStopNode = false;
            i = result.closeIndex;
            continue;
          } else {
            const childNode = new XmlNode(tagName);
            if (this.tagsNodeStack.length > options.maxNestedTags) {
              throw new Error("Maximum nested tags exceeded");
            }
            this.tagsNodeStack.push(currentNode);
            if (prefixedAttrs) {
              childNode[":@"] = prefixedAttrs;
            }
            this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
            currentNode = childNode;
          }
          textData = "";
          i = closeIndex;
        }
      }
    } else {
      textData += xmlData[i];
    }
  }
  return xmlObj.child;
};
function addChild(currentNode, childNode, matcher, startIndex) {
  if (!this.options.captureMetaData) startIndex = void 0;
  const jPathOrMatcher = this.options.jPath ? matcher.toString() : matcher;
  const result = this.options.updateTag(childNode.tagname, jPathOrMatcher, childNode[":@"]);
  if (result === false) {
  } else if (typeof result === "string") {
    childNode.tagname = result;
    currentNode.addChild(childNode, startIndex);
  } else {
    currentNode.addChild(childNode, startIndex);
  }
}
function replaceEntitiesValue(val, tagName, jPath) {
  const entityConfig = this.options.processEntities;
  if (!entityConfig || !entityConfig.enabled) {
    return val;
  }
  if (entityConfig.allowedTags) {
    const jPathOrMatcher = this.options.jPath ? jPath.toString() : jPath;
    const allowed = Array.isArray(entityConfig.allowedTags) ? entityConfig.allowedTags.includes(tagName) : entityConfig.allowedTags(tagName, jPathOrMatcher);
    if (!allowed) {
      return val;
    }
  }
  if (entityConfig.tagFilter) {
    const jPathOrMatcher = this.options.jPath ? jPath.toString() : jPath;
    if (!entityConfig.tagFilter(tagName, jPathOrMatcher)) {
      return val;
    }
  }
  return this.entityDecoder.decode(val);
}
function saveTextToParentTag(textData, parentNode, matcher, isLeafNode) {
  if (textData) {
    if (isLeafNode === void 0) isLeafNode = parentNode.child.length === 0;
    textData = this.parseTextData(
      textData,
      parentNode.tagname,
      matcher,
      false,
      parentNode[":@"] ? Object.keys(parentNode[":@"]).length !== 0 : false,
      isLeafNode
    );
    if (textData !== void 0 && textData !== "")
      parentNode.add(this.options.textNodeName, textData);
    textData = "";
  }
  return textData;
}
function isItStopNode() {
  if (this.stopNodeExpressionsSet.size === 0) return false;
  return this.matcher.matchesAny(this.stopNodeExpressionsSet);
}
function tagExpWithClosingIndex(xmlData, i, closingChar = ">") {
  let attrBoundary = 0;
  const len = xmlData.length;
  const closeCode0 = closingChar.charCodeAt(0);
  const closeCode1 = closingChar.length > 1 ? closingChar.charCodeAt(1) : -1;
  let result = "";
  let segmentStart = i;
  for (let index = i; index < len; index++) {
    const code = xmlData.charCodeAt(index);
    if (attrBoundary) {
      if (code === attrBoundary) attrBoundary = 0;
    } else if (code === 34 || code === 39) {
      attrBoundary = code;
    } else if (code === closeCode0) {
      if (closeCode1 !== -1) {
        if (xmlData.charCodeAt(index + 1) === closeCode1) {
          result += xmlData.substring(segmentStart, index);
          return { data: result, index };
        }
      } else {
        result += xmlData.substring(segmentStart, index);
        return { data: result, index };
      }
    } else if (code === 9 && !attrBoundary) {
      result += xmlData.substring(segmentStart, index) + " ";
      segmentStart = index + 1;
    }
  }
}
function findClosingIndex(xmlData, str, i, errMsg) {
  const closingIndex = xmlData.indexOf(str, i);
  if (closingIndex === -1) {
    throw new Error(errMsg);
  } else {
    return closingIndex + str.length - 1;
  }
}
function findClosingChar(xmlData, char, i, errMsg) {
  const closingIndex = xmlData.indexOf(char, i);
  if (closingIndex === -1) throw new Error(errMsg);
  return closingIndex;
}
function readTagExp(xmlData, i, removeNSPrefix, closingChar = ">") {
  const result = tagExpWithClosingIndex(xmlData, i + 1, closingChar);
  if (!result) return;
  let tagExp = result.data;
  const closeIndex = result.index;
  const separatorIndex = tagExp.search(/\s/);
  let tagName = tagExp;
  let attrExpPresent = true;
  if (separatorIndex !== -1) {
    tagName = tagExp.substring(0, separatorIndex);
    tagExp = tagExp.substring(separatorIndex + 1).trimStart();
  }
  const rawTagName = tagName;
  if (removeNSPrefix) {
    const colonIndex = tagName.indexOf(":");
    if (colonIndex !== -1) {
      tagName = tagName.substr(colonIndex + 1);
      attrExpPresent = tagName !== result.data.substr(colonIndex + 1);
    }
  }
  return {
    tagName,
    tagExp,
    closeIndex,
    attrExpPresent,
    rawTagName
  };
}
function readStopNodeData(xmlData, tagName, i) {
  const startIndex = i;
  let openTagCount = 1;
  const xmllen = xmlData.length;
  for (; i < xmllen; i++) {
    if (xmlData[i] === "<") {
      const c1 = xmlData.charCodeAt(i + 1);
      if (c1 === 47) {
        const closeIndex = findClosingChar(xmlData, ">", i, `${tagName} is not closed`);
        let closeTagName = xmlData.substring(i + 2, closeIndex).trim();
        if (closeTagName === tagName) {
          openTagCount--;
          if (openTagCount === 0) {
            return {
              tagContent: xmlData.substring(startIndex, i),
              i: closeIndex
            };
          }
        }
        i = closeIndex;
      } else if (c1 === 63) {
        const closeIndex = findClosingIndex(xmlData, "?>", i + 1, "StopNode is not closed.");
        i = closeIndex;
      } else if (c1 === 33 && xmlData.charCodeAt(i + 2) === 45 && xmlData.charCodeAt(i + 3) === 45) {
        const closeIndex = findClosingIndex(xmlData, "-->", i + 3, "StopNode is not closed.");
        i = closeIndex;
      } else if (c1 === 33 && xmlData.charCodeAt(i + 2) === 91) {
        const closeIndex = findClosingIndex(xmlData, "]]>", i, "StopNode is not closed.") - 2;
        i = closeIndex;
      } else {
        const tagData = readTagExp(xmlData, i, false);
        if (tagData) {
          const openTagName = tagData && tagData.tagName;
          if (openTagName === tagName && tagData.tagExp[tagData.tagExp.length - 1] !== "/") {
            openTagCount++;
          }
          i = tagData.closeIndex;
        }
      }
    }
  }
}
function parseValue(val, shouldParse, options) {
  if (shouldParse && typeof val === "string") {
    const newval = val.trim();
    if (newval === "true") return true;
    else if (newval === "false") return false;
    else return toNumber(val, options);
  } else {
    if (isExist(val)) {
      return val;
    } else {
      return "";
    }
  }
}
function transformTagName(fn, tagName, tagExp, options) {
  if (fn) {
    const newTagName = fn(tagName);
    if (tagExp === tagName) {
      tagExp = newTagName;
    }
    tagName = newTagName;
  }
  tagName = sanitizeName(tagName, options);
  return { tagName, tagExp };
}
function sanitizeName(name, options) {
  if (criticalProperties.includes(name)) {
    throw new Error(`[SECURITY] Invalid name: "${name}" is a reserved JavaScript keyword that could cause prototype pollution`);
  } else if (DANGEROUS_PROPERTY_NAMES.includes(name)) {
    return options.onDangerousProperty(name);
  }
  return name;
}

// node_modules/fast-xml-parser/src/xmlparser/node2json.js
var METADATA_SYMBOL2 = XmlNode.getMetaDataSymbol();
function stripAttributePrefix(attrs, prefix) {
  if (!attrs || typeof attrs !== "object") return {};
  if (!prefix) return attrs;
  const rawAttrs = {};
  for (const key in attrs) {
    if (key.startsWith(prefix)) {
      const rawName = key.substring(prefix.length);
      rawAttrs[rawName] = attrs[key];
    } else {
      rawAttrs[key] = attrs[key];
    }
  }
  return rawAttrs;
}
function prettify(node, options, matcher, readonlyMatcher) {
  return compress(node, options, matcher, readonlyMatcher);
}
function compress(arr, options, matcher, readonlyMatcher) {
  let text;
  const compressedObj = {};
  for (let i = 0; i < arr.length; i++) {
    const tagObj = arr[i];
    const property = propName(tagObj);
    if (property !== void 0 && property !== options.textNodeName) {
      const rawAttrs = stripAttributePrefix(
        tagObj[":@"] || {},
        options.attributeNamePrefix
      );
      matcher.push(property, rawAttrs);
    }
    if (property === options.textNodeName) {
      if (text === void 0) text = tagObj[property];
      else text += "" + tagObj[property];
    } else if (property === void 0) {
      continue;
    } else if (tagObj[property]) {
      let val = compress(tagObj[property], options, matcher, readonlyMatcher);
      const isLeaf = isLeafTag(val, options);
      if (Object.keys(val).length === 0 && options.alwaysCreateTextNode) {
        val[options.textNodeName] = "";
      }
      if (tagObj[":@"]) {
        assignAttributes(val, tagObj[":@"], readonlyMatcher, options);
      } else if (Object.keys(val).length === 1 && val[options.textNodeName] !== void 0 && !options.alwaysCreateTextNode) {
        val = val[options.textNodeName];
      } else if (Object.keys(val).length === 0) {
        if (options.alwaysCreateTextNode) val[options.textNodeName] = "";
        else val = "";
      }
      if (tagObj[METADATA_SYMBOL2] !== void 0 && typeof val === "object" && val !== null) {
        val[METADATA_SYMBOL2] = tagObj[METADATA_SYMBOL2];
      }
      if (compressedObj[property] !== void 0 && Object.prototype.hasOwnProperty.call(compressedObj, property)) {
        if (!Array.isArray(compressedObj[property])) {
          compressedObj[property] = [compressedObj[property]];
        }
        compressedObj[property].push(val);
      } else {
        const jPathOrMatcher = options.jPath ? readonlyMatcher.toString() : readonlyMatcher;
        if (options.isArray(property, jPathOrMatcher, isLeaf)) {
          compressedObj[property] = [val];
        } else {
          compressedObj[property] = val;
        }
      }
      if (property !== void 0 && property !== options.textNodeName) {
        matcher.pop();
      }
    }
  }
  if (typeof text === "string") {
    if (text.length > 0) compressedObj[options.textNodeName] = text;
  } else if (text !== void 0) compressedObj[options.textNodeName] = text;
  return compressedObj;
}
function propName(obj) {
  const keys = Object.keys(obj);
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    if (key !== ":@") return key;
  }
}
function assignAttributes(obj, attrMap, readonlyMatcher, options) {
  if (attrMap) {
    const keys = Object.keys(attrMap);
    const len = keys.length;
    for (let i = 0; i < len; i++) {
      const atrrName = keys[i];
      const rawAttrName = atrrName.startsWith(options.attributeNamePrefix) ? atrrName.substring(options.attributeNamePrefix.length) : atrrName;
      const jPathOrMatcher = options.jPath ? readonlyMatcher.toString() + "." + rawAttrName : readonlyMatcher;
      if (options.isArray(atrrName, jPathOrMatcher, true, true)) {
        obj[atrrName] = [attrMap[atrrName]];
      } else {
        obj[atrrName] = attrMap[atrrName];
      }
    }
  }
}
function isLeafTag(obj, options) {
  const { textNodeName } = options;
  const propCount = Object.keys(obj).length;
  if (propCount === 0) {
    return true;
  }
  if (propCount === 1 && (obj[textNodeName] || typeof obj[textNodeName] === "boolean" || obj[textNodeName] === 0)) {
    return true;
  }
  return false;
}

// node_modules/fast-xml-parser/src/xmlparser/XMLParser.js
var XMLParser = class {
  constructor(options) {
    this.externalEntities = {};
    this.options = buildOptions(options);
  }
  /**
   * Parse XML dats to JS object 
   * @param {string|Uint8Array} xmlData 
   * @param {boolean|Object} validationOption 
   */
  parse(xmlData, validationOption) {
    if (typeof xmlData !== "string" && xmlData.toString) {
      xmlData = xmlData.toString();
    } else if (typeof xmlData !== "string") {
      throw new Error("XML data is accepted in String or Bytes[] form.");
    }
    if (validationOption) {
      if (validationOption === true) validationOption = {};
      const result = validate(xmlData, validationOption);
      if (result !== true) {
        throw Error(`${result.err.msg}:${result.err.line}:${result.err.col}`);
      }
    }
    const orderedObjParser = new OrderedObjParser(this.options, this.externalEntities);
    const orderedResult = orderedObjParser.parseXml(xmlData);
    if (this.options.preserveOrder || orderedResult === void 0) return orderedResult;
    else return prettify(orderedResult, this.options, orderedObjParser.matcher, orderedObjParser.readonlyMatcher);
  }
  /**
   * Add Entity which is not by default supported by this library
   * @param {string} key 
   * @param {string} value 
   */
  addEntity(key, value) {
    if (value.indexOf("&") !== -1) {
      throw new Error("Entity value can't have '&'");
    } else if (key.indexOf("&") !== -1 || key.indexOf(";") !== -1) {
      throw new Error("An entity must be set without '&' and ';'. Eg. use '#xD' for '&#xD;'");
    } else if (value === "&") {
      throw new Error("An entity with value '&' is not permitted");
    } else {
      this.externalEntities[key] = value;
    }
  }
  /**
   * Returns a Symbol that can be used to access the metadata
   * property on a node.
   * 
   * If Symbol is not available in the environment, an ordinary property is used
   * and the name of the property is here returned.
   * 
   * The XMLMetaData property is only present when `captureMetaData`
   * is true in the options.
   */
  static getMetaDataSymbol() {
    return XmlNode.getMetaDataSymbol();
  }
};

// node_modules/fast-xml-parser/src/fxp.js
var XMLValidator = {
  validate
};

// integration/spicy-logger.ts
var SpicyLogger = class {
  constructor(source) {
    this.source = source;
  }
  source;
  write(level, args) {
    const messages = args.filter((v) => typeof v === "string").map((v) => v.replace(/<[^>]*>/g, "[XML]").slice(0, 180));
    if (level === "warn" || level === "error")
      console[level](`[cncx \xB7 ${this.source}]`, ...messages);
  }
  info(...args) {
    this.write("info", args);
  }
  debug(...args) {
    this.write("debug", args);
  }
  warn(...args) {
    this.write("warn", args);
  }
  error(...args) {
    this.write("error", args);
  }
};

// vendor/spicy/src/utils/Lyrics/Applyer/Utils/StripZeroWidth.ts
var ZeroWidthRegex = /[\u200B\u200E\u200F\u2060\uFEFF]/g;
function StripZeroWidth(text) {
  return text.replace(ZeroWidthRegex, "");
}

// vendor/spicy/src/utils/Lyrics/EmptyLines.ts
var HasLyricsText = (text) => typeof text === "string" && StripZeroWidth(text).trim() !== "";
var HasRenderableText = (entry) => HasLyricsText(entry?.Text) || HasLyricsText(entry?.TransliteratedText);

// vendor/spicy/src/utils/Lyrics/ttml/parser.ts
var ttmlLogger = new SpicyLogger("TTML Parser");
var isSpanObject = (span) => typeof span === "object" && span !== null;
var isVocalSpan = (span) => isSpanObject(span) && !span["ttm:role"];
var toArray = (value) => value == null ? [] : Array.isArray(value) ? value : [value];
var isSupportedLyricsType = (value) => value === "Static" || value === "Line" || value === "Syllable";
var decodeXmlEntities = (str) => {
  if (str.indexOf("&") === -1) return str;
  const named = {
    amp: "&",
    lt: "<",
    gt: ">",
    quot: '"',
    apos: "'",
    // Not an XML entity, but HTML habits put it in hand-written TTML.
    nbsp: "\xA0"
  };
  return str.replace(
    /&(?:#x([0-9a-fA-F]{1,6})|#([0-9]{1,7})|([a-zA-Z][a-zA-Z0-9]{0,31}));/g,
    (match, hex, dec, name) => {
      if (name !== void 0) {
        return Object.prototype.hasOwnProperty.call(named, name) ? named[name] : match;
      }
      const digits = hex ?? dec;
      if (digits === void 0) return match;
      const code = hex !== void 0 ? parseInt(hex, 16) : parseInt(digits, 10);
      if (!Number.isFinite(code)) return match;
      if (code <= 0 || code > 1114111) return match;
      if (code >= 55296 && code <= 57343) return match;
      if (code === 9 || code === 10 || code === 13) {
        return String.fromCodePoint(code);
      }
      if (code < 32) return match;
      try {
        return String.fromCodePoint(code);
      } catch {
        return match;
      }
    }
  );
};
var readText = (value) => value === void 0 || value === null ? "" : decodeXmlEntities(value.toString());
var parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "",
  trimValues: false,
  parseTagValue: false,
  parseAttributeValue: false,
  allowBooleanAttributes: false,
  processEntities: false
});
var createAdjacencyScanner = (xml) => {
  const bodyIndex = xml.indexOf("<body");
  const searchStart = bodyIndex === -1 ? 0 : bodyIndex;
  let cursor = searchStart;
  const tags = /* @__PURE__ */ new Map();
  const tagPattern = /<span\b[^>]*>/g;
  const beginPattern = /\sbegin\s*=\s*(["'])(.*?)\1/;
  const endPattern = /\send\s*=\s*(["'])(.*?)\1/;
  tagPattern.lastIndex = searchStart;
  for (let match = tagPattern.exec(xml); match !== null; match = tagPattern.exec(xml)) {
    const tag = match[0];
    const begin = tag.match(beginPattern)?.[2];
    const end = tag.match(endPattern)?.[2];
    if (begin === void 0 || end === void 0) continue;
    const tagEnd = match.index + tag.length;
    let adjacent;
    if (tag.endsWith("/>")) {
      adjacent = xml.charAt(tagEnd) === "<";
    } else {
      const closingIndex = xml.indexOf("</span>", tagEnd);
      adjacent = closingIndex !== -1 && xml.charAt(closingIndex + "</span>".length) === "<";
    }
    const key = `${begin}\0${end}`;
    const entry = { index: match.index, tagEnd, adjacent };
    const list = tags.get(key);
    if (list) list.push(entry);
    else tags.set(key, [entry]);
  }
  const firstFrom = (list, from) => {
    let low = 0;
    let high = list.length;
    while (low < high) {
      const mid = low + high >> 1;
      if (list[mid].index < from) low = mid + 1;
      else high = mid;
    }
    return list[low];
  };
  return {
    isImmediatelyFollowedByTag(begin, end) {
      if (begin == null || end == null || begin === "" || end === "") return false;
      const list = tags.get(`${begin}\0${end}`);
      if (!list) return false;
      const tag = firstFrom(list, cursor) ?? list[0];
      cursor = tag.tagEnd;
      return tag.adjacent;
    }
  };
};
var transliterationSpanKey = (lineKey, background, begin, end) => `${lineKey}\0${background ? "bg" : "lead"}\0${begin}\0${end}`;
function scanTransliterations(xml) {
  const lineTexts = /* @__PURE__ */ new Map();
  const wordEnds = /* @__PURE__ */ new Map();
  const bodyIndex = xml.indexOf("<body");
  const head = bodyIndex === -1 ? xml : xml.slice(0, bodyIndex);
  const blockPattern = /<transliterations\b[^>]*>([\s\S]*?)<\/transliterations>/g;
  const entryPattern = /<text\b([^>]*)>([\s\S]*?)<\/text>/g;
  const forPattern = /\bfor\s*=\s*(["'])(.*?)\1/;
  const bgPattern = /\bttm:role\s*=\s*(["'])x-bg\1/;
  const rolePattern = /\bttm:role\s*=/;
  const beginPattern = /(?:^|\s)begin\s*=\s*(["'])(.*?)\1/;
  const endPattern = /(?:^|\s)end\s*=\s*(["'])(.*?)\1/;
  const tokenPattern = /<(\/?)span\b([^>]*?)(\/?)>|<[^>]*>|[^<]+/g;
  for (const block of head.matchAll(blockPattern)) {
    for (const entry of block[1].matchAll(entryPattern)) {
      const key = entry[1].match(forPattern)?.[2];
      if (!key) continue;
      let text = "";
      const ends = /* @__PURE__ */ new Map();
      const vocals = {
        lead: { last: null, gap: false },
        bg: { last: null, gap: false }
      };
      const stack = [];
      const openSpan = (attrs) => {
        const top = stack[stack.length - 1];
        const bg = (top?.bg ?? false) || bgPattern.test(attrs);
        const begin = attrs.match(beginPattern)?.[2];
        const end = attrs.match(endPattern)?.[2];
        const timed = begin !== void 0 && end !== void 0 && !rolePattern.test(attrs) ? { key: transliterationSpanKey(key, bg, begin, end), text: "" } : null;
        return { bg, timed };
      };
      const closeSpan = (frame) => {
        if (!frame.timed) return;
        const spanText = decodeXmlEntities(frame.timed.text);
        const vocal = vocals[frame.bg ? "bg" : "lead"];
        if (vocal.last !== null && (vocal.gap || /^\s/.test(spanText))) {
          ends.set(vocal.last, true);
        }
        ends.set(frame.timed.key, /\s$/.test(spanText));
        vocal.last = frame.timed.key;
        vocal.gap = false;
      };
      for (const token of entry[2].matchAll(tokenPattern)) {
        const raw = token[0];
        const top = stack[stack.length - 1];
        if (!raw.startsWith("<")) {
          if (!top?.bg) text += raw;
          if (top?.timed) {
            top.timed.text += raw;
          } else if (/\s/.test(decodeXmlEntities(raw))) {
            vocals[top?.bg ? "bg" : "lead"].gap = true;
          }
        } else if (token[1] === "/") {
          const frame = stack.pop();
          if (frame) closeSpan(frame);
        } else if (raw.startsWith("<span")) {
          const frame = openSpan(token[2] ?? "");
          if (token[3] === "/") closeSpan(frame);
          else stack.push(frame);
        }
      }
      for (const [spanKey, endsWord] of ends) {
        if (!wordEnds.has(spanKey)) wordEnds.set(spanKey, endsWord);
      }
      const normalized = decodeXmlEntities(text).replace(/\s+/g, " ").trim();
      if (normalized === "") continue;
      const existing = lineTexts.get(key);
      lineTexts.set(key, existing ? `${existing} ${normalized}` : normalized);
    }
  }
  return { lineTexts, wordEnds };
}
var getDivs = (ttml) => {
  const body = ttml?.tt?.body;
  if (!body) return [];
  const divs = toArray(body.div).filter((div) => div != null && typeof div === "object");
  if (divs.length > 0) return divs;
  if (body.p != null) return [{ p: body.p }];
  return [];
};
function buildSyllables({
  siblings,
  transliterations,
  stripParentheses,
  scanner
}) {
  const syllables = [];
  const clean = (value) => stripParentheses ? value.trim().replace(/[()]/g, "").trim() : value.trim();
  siblings.forEach((node, index) => {
    if (!isVocalSpan(node)) return;
    const closingTagIsAdjacent = scanner.isImmediatelyFollowedByTag(node.begin, node.end);
    const rawText = readText(node["#text"]);
    if (rawText === "") return;
    const text = clean(rawText);
    if (text === "") return;
    let isPartOfWord = false;
    const nextNode = siblings[index + 1];
    if (closingTagIsAdjacent && isVocalSpan(nextNode)) {
      const nextText = readText(nextNode["#text"]);
      const endsWithComma = rawText.trim().endsWith(",");
      const endsWithWhitespace = /\s$/.test(rawText);
      if (!/^\s/.test(nextText) && !endsWithComma && !endsWithWhitespace) {
        isPartOfWord = true;
      }
    }
    const translit = findTransliteratedText(transliterations, node.begin, node.end);
    const translitText = translit ? clean(translit.text) : "";
    const startTime = convertTimeToSeconds(node.begin);
    syllables.push({
      Text: text,
      ...translitText !== "" ? { TransliteratedText: translitText } : {},
      // Left out when the span's word end is unknown, so the renderer falls
      // back to IsPartOfWord.
      ...translitText !== "" && translit?.endsWord !== void 0 ? { TransliteratedIsPartOfWord: !translit.endsWord } : {},
      IsPartOfWord: isPartOfWord,
      StartTime: startTime,
      EndTime: endAfter(startTime, convertTimeToSeconds(node.end))
    });
  });
  const last = syllables[syllables.length - 1];
  if (last?.TransliteratedText !== void 0) last.TransliteratedIsPartOfWord = false;
  return syllables;
}
var endAfter = (start, end) => start !== void 0 && end !== void 0 && end < start ? void 0 : end;
function fillSyllableTimes(syllables, lineStart, lineEnd2) {
  const nextStart = (after) => {
    for (let k = after + 1; k < syllables.length; k++) {
      const start = syllables[k].StartTime;
      if (start !== void 0) return start;
    }
    return lineEnd2;
  };
  const isUntimed = (syllable) => syllable.StartTime === void 0 && syllable.EndTime === void 0;
  let previousEnd = lineStart;
  let i = 0;
  while (i < syllables.length) {
    if (isUntimed(syllables[i])) {
      let j = i;
      while (j < syllables.length && isUntimed(syllables[j])) j++;
      const until = Math.max(nextStart(j - 1), previousEnd);
      const step = (until - previousEnd) / (j - i);
      for (let k = i; k < j; k++) {
        syllables[k].StartTime = previousEnd + step * (k - i);
        syllables[k].EndTime = k === j - 1 ? until : previousEnd + step * (k - i + 1);
      }
      previousEnd = until;
      i = j;
      continue;
    }
    const syllable = syllables[i];
    const start = syllable.StartTime ?? previousEnd;
    syllable.StartTime = start;
    syllable.EndTime = Math.max(syllable.EndTime ?? nextStart(i), start);
    previousEnd = syllable.EndTime;
    i++;
  }
}
function parseTTML(ttmlInput) {
  if (typeof ttmlInput !== "string" || ttmlInput.trim() === "") {
    ttmlLogger.warn("Refusing to parse empty or non-string TTML input");
    return null;
  }
  try {
    return convertTTML(ttmlInput);
  } catch (error) {
    ttmlLogger.error(
      "Unexpected error while converting TTML",
      error?.message ?? String(error)
    );
    return null;
  }
}
function convertTTML(ttmlInput) {
  let ttml;
  try {
    ttml = parser.parse(ttmlInput);
  } catch (parseError) {
    ttmlLogger.error("Failed to parse TTML XML", parseError?.message);
    return null;
  }
  if (!ttml?.tt || typeof ttml.tt !== "object" || !ttml.tt.body || typeof ttml.tt.body !== "object") {
    ttmlLogger.warn("Parsed XML is not a TTML document, rejecting");
    return null;
  }
  const divs = getDivs(ttml);
  if (divs.length === 0) {
    ttmlLogger.warn("TTML body contains no usable <div>/<p> content, rejecting");
    return null;
  }
  const timing = ttml.tt["itunes:timing"];
  let lyricsType;
  if (timing === "None") {
    lyricsType = "Static";
  } else if (timing === "Word") {
    lyricsType = "Syllable";
  } else if (timing === void 0) {
    lyricsType = inferLyricsType(ttml);
    ttmlLogger.debug("No itunes:timing attribute, inferred lyrics type from structure", { inferred: lyricsType });
  } else {
    lyricsType = timing;
  }
  if (!isSupportedLyricsType(lyricsType)) {
    ttmlLogger.warn("Unknown itunes:timing value, rejecting", { timing });
    return null;
  }
  ttmlLogger.debug(`Determined lyrics type: ${lyricsType}`);
  const SongWriters = GetSongWriters(ttml);
  const RawTransliterations = scanTransliterations(ttmlInput);
  const Transliterations = GetTransliterations(ttml, RawTransliterations.wordEnds);
  const base = SongWriters ? { SongWriters } : {};
  let lyricsJSON;
  const Agents = ttml.tt.head?.metadata?.["ttm:agent"];
  const PostAgents = toArray(Agents).filter((agent) => agent != null && typeof agent === "object");
  const isOppositeAlignedAgent = (agent) => {
    const agentId = agent["xml:id"];
    if (agentId === "v1") return false;
    if (agentId === "v2000" || agentId === "v2") return true;
    return false;
  };
  const TrackAgents = PostAgents.map((agent) => {
    return {
      Type: agent.type,
      Id: agent["xml:id"],
      OppositeAligned: isOppositeAlignedAgent(agent)
    };
  });
  switch (lyricsType) {
    case "Static": {
      ttmlLogger.debug("Processing static lyrics");
      const staticLyrics = { ...base, Type: "Static", Lines: [] };
      divs.forEach((div) => {
        if (div["itunes:songPart"] === "Instrumental" || div["itunes:songPart"] === "Outro") return;
        const divp = toArray(div.p);
        divp.forEach((p) => {
          if (p == null) return;
          const text = getLineText(p) ?? "";
          const roles = getInlineRoleTexts(p);
          const roman = roles.roman?.trim() ?? "";
          if (!HasLyricsText(text) && !HasLyricsText(roman)) return;
          const line = {
            Text: text.trim()
          };
          if (roman !== "") {
            line.TransliteratedText = roman;
            line.HasTransliterations = true;
          }
          if (roles.translation !== void 0 && roles.translation.trim() !== "") {
            line.TranslatedText = roles.translation.trim();
            line.HasTranslations = true;
          }
          staticLyrics.Lines.push(line);
        });
      });
      lyricsJSON = staticLyrics;
      break;
    }
    case "Line": {
      ttmlLogger.debug("Processing line-synced lyrics");
      const transliterationLineTexts = RawTransliterations.lineTexts;
      const buildLine = (p) => {
        const pSpans = p != null && typeof p === "object" && p.span ? toArray(p.span) : [];
        const vocalSpans = pSpans.filter(isVocalSpan);
        const begin = (typeof p === "object" ? p?.begin : void 0) ?? vocalSpans[0]?.begin;
        const end = (typeof p === "object" ? p?.end : void 0) ?? vocalSpans[vocalSpans.length - 1]?.end;
        const startTime = convertTimeToSeconds(begin);
        const endTime = convertTimeToSeconds(end);
        const line = {
          Type: "Vocal",
          OppositeAligned: false,
          Text: getLineText(p),
          StartTime: startTime,
          // A line ending before it begins ends where it begins.
          EndTime: startTime !== void 0 && endTime !== void 0 && endTime < startTime ? startTime : endTime
        };
        const roles = getInlineRoleTexts(p);
        const lineKey = p && typeof p === "object" ? p["itunes:key"] : void 0;
        const itmTranslit = lineKey ? Transliterations?.get(lineKey)?.spans : void 0;
        const rawTranslit = lineKey ? transliterationLineTexts.get(lineKey) : void 0;
        let translit;
        if (rawTranslit !== void 0 && rawTranslit !== "") {
          translit = rawTranslit;
        } else if (itmTranslit && itmTranslit.length > 0) {
          translit = itmTranslit.map((s) => s.text).join("");
        } else if (roles.roman !== void 0) {
          translit = roles.roman;
        }
        if (translit !== void 0 && translit.trim() !== "") {
          line.TransliteratedText = translit.trim();
          line.HasTransliterations = true;
        }
        if (roles.translation !== void 0 && roles.translation.trim() !== "") {
          line.TranslatedText = roles.translation.trim();
          line.HasTranslations = true;
        }
        return line;
      };
      const lineLyrics = {
        ...base,
        Type: "Line",
        StartTime: void 0,
        EndTime: void 0,
        Content: []
      };
      const timedDivs = divs.filter((div) => div["itunes:songPart"] !== "Instrumental");
      lineLyrics.Content = timedDivs.flatMap((div) => toArray(div.p).filter((p) => p != null).map(buildLine)).filter((line) => HasRenderableText(line));
      const firstDiv = timedDivs[0] ?? divs[0];
      const lastDiv = timedDivs[timedDivs.length - 1] ?? divs[divs.length - 1];
      lineLyrics.StartTime = convertTimeToSeconds(firstDiv?.begin) ?? lineLyrics.Content[0]?.StartTime;
      lineLyrics.EndTime = convertTimeToSeconds(lastDiv?.end) ?? lineLyrics.Content[lineLyrics.Content.length - 1]?.EndTime;
      lyricsJSON = lineLyrics;
      break;
    }
    case "Syllable": {
      ttmlLogger.debug("Processing syllable-synced lyrics");
      const scanner = createAdjacencyScanner(ttmlInput);
      const firstDiv = divs[0];
      let skippedEmptyLines = 0;
      const syllableLyrics = {
        ...base,
        Type: "Syllable",
        StartTime: convertTimeToSeconds(firstDiv?.begin),
        Content: []
      };
      divs.forEach((div) => {
        if (div["itunes:songPart"] === "Instrumental") return;
        const ps = toArray(div.p);
        ps.forEach((p) => {
          if (!p || typeof p !== "object") return;
          const pAgentId = p["ttm:agent"] || div["ttm:agent"] || ttml.tt.body["ttm:agent"];
          const trackAgent = pAgentId ? TrackAgents.find((a) => a.Id === pAgentId) : void 0;
          const isOpposite = trackAgent ? trackAgent.OppositeAligned : false;
          const lineKey = p["itunes:key"];
          const lineTranslitEntry = lineKey ? Transliterations?.get(lineKey) : void 0;
          const lineTranslit = lineTranslitEntry?.spans;
          const pStart = convertTimeToSeconds(p.begin);
          const pEnd = endAfter(pStart, convertTimeToSeconds(p.end));
          const vocal = {
            Type: "Vocal",
            OppositeAligned: isOpposite,
            Lead: {
              Syllables: [],
              StartTime: pStart,
              EndTime: pEnd
            }
          };
          const pSpans = toArray(p.span);
          vocal.Lead.Syllables = buildSyllables({
            siblings: pSpans,
            transliterations: lineTranslit,
            stripParentheses: false,
            scanner
          });
          const leadRoles = getInlineRoleTexts(p);
          const leadRoman = leadRoles.roman?.trim() ?? "";
          if (vocal.Lead.Syllables.length === 0) {
            const fallbackText = (getLineText(p) ?? "").trim();
            if (fallbackText !== "" || leadRoman !== "") {
              vocal.Lead.Syllables.push({
                Text: fallbackText,
                ...leadRoman !== "" ? { TransliteratedText: leadRoman, TransliteratedIsPartOfWord: false } : {},
                IsPartOfWord: false,
                StartTime: pStart,
                EndTime: pEnd
              });
            }
          }
          for (const syllable of vocal.Lead.Syllables) {
            if (typeof syllable.StartTime === "number" && (vocal.Lead.StartTime === void 0 || syllable.StartTime < vocal.Lead.StartTime)) {
              vocal.Lead.StartTime = syllable.StartTime;
            }
            if (typeof syllable.EndTime === "number" && (vocal.Lead.EndTime === void 0 || syllable.EndTime > vocal.Lead.EndTime)) {
              vocal.Lead.EndTime = syllable.EndTime;
            }
          }
          if (vocal.Lead.StartTime !== void 0) {
            vocal.Lead.EndTime = Math.max(vocal.Lead.EndTime ?? vocal.Lead.StartTime, vocal.Lead.StartTime);
            fillSyllableTimes(vocal.Lead.Syllables, vocal.Lead.StartTime, vocal.Lead.EndTime);
          }
          if (leadRoman !== "") {
            vocal.Lead.TransliteratedText = leadRoman;
          }
          if (leadRoles.translation !== void 0 && leadRoles.translation.trim() !== "") {
            vocal.Lead.TranslatedText = leadRoles.translation.trim();
            vocal.HasTranslations = true;
          }
          if (vocal.Lead.TransliteratedText !== void 0 || vocal.Lead.Syllables.some((s) => s.TransliteratedText !== void 0)) {
            vocal.HasTransliterations = true;
          }
          const filteredBgSpans = pSpans.filter(
            (span) => isSpanObject(span) && span["ttm:role"] === "x-bg"
          );
          if (filteredBgSpans.length > 0) {
            const backgrounds = [];
            filteredBgSpans.forEach((bgSpan) => {
              const bgLineKey = bgSpan["itunes:key"];
              const bgKeyTranslit = bgLineKey ? Transliterations?.get(bgLineKey) : void 0;
              const bgLineTranslit = pickBackgroundTransliterations(bgKeyTranslit, lineTranslitEntry);
              const bgSpanSpans = toArray(bgSpan.span);
              const bgVocalSpans = bgSpanSpans.filter(isVocalSpan);
              const bgRoles = extractRoleTexts(bgSpanSpans);
              const bgVocal = {
                Syllables: buildSyllables({
                  siblings: bgSpanSpans,
                  transliterations: bgLineTranslit,
                  stripParentheses: true,
                  scanner
                }),
                StartTime: void 0,
                EndTime: void 0
              };
              bgVocal.StartTime = convertTimeToSeconds(bgVocalSpans[0]?.begin) ?? convertTimeToSeconds(bgSpan.begin) ?? bgVocal.Syllables[0]?.StartTime;
              bgVocal.EndTime = convertTimeToSeconds(bgVocalSpans[bgVocalSpans.length - 1]?.end) ?? convertTimeToSeconds(bgSpan.end) ?? bgVocal.Syllables[bgVocal.Syllables.length - 1]?.EndTime;
              if (bgVocal.StartTime !== void 0) {
                bgVocal.EndTime = Math.max(bgVocal.EndTime ?? bgVocal.StartTime, bgVocal.StartTime);
                fillSyllableTimes(bgVocal.Syllables, bgVocal.StartTime, bgVocal.EndTime);
              }
              if (bgRoles.roman !== void 0 && bgRoles.roman.trim() !== "") {
                bgVocal.TransliteratedText = bgRoles.roman.trim();
              }
              if (bgRoles.translation !== void 0 && bgRoles.translation.trim() !== "") {
                bgVocal.TranslatedText = bgRoles.translation.trim();
                bgVocal.HasTranslations = true;
              }
              if (bgVocal.TransliteratedText !== void 0 || bgVocal.Syllables.some((s) => s.TransliteratedText !== void 0)) {
                bgVocal.HasTransliterations = true;
              }
              if (!bgVocal.Syllables.some((syllable) => HasRenderableText(syllable))) {
                return;
              }
              if (typeof bgVocal.EndTime === "number" && (vocal.Lead.EndTime === void 0 || bgVocal.EndTime > vocal.Lead.EndTime)) {
                vocal.Lead.EndTime = bgVocal.EndTime;
              }
              if (typeof bgVocal.StartTime === "number" && (vocal.Lead.StartTime === void 0 || bgVocal.StartTime < vocal.Lead.StartTime)) {
                vocal.Lead.StartTime = bgVocal.StartTime;
              }
              backgrounds.push(bgVocal);
            });
            if (backgrounds.length > 0) vocal.Background = backgrounds;
          }
          const isEmpty = !vocal.Lead.Syllables.some((syllable) => HasRenderableText(syllable)) && !(vocal.Background ?? []).some(
            (background) => background.Syllables.some((syllable) => HasRenderableText(syllable))
          );
          if (isEmpty) {
            skippedEmptyLines++;
            return;
          }
          syllableLyrics.Content.push(vocal);
        });
      });
      if (skippedEmptyLines > 0) {
        ttmlLogger.debug(`Skipped ${skippedEmptyLines} empty syllable line(s)`);
      }
      if (syllableLyrics.StartTime === void 0) {
        syllableLyrics.StartTime = syllableLyrics.Content[0]?.Lead?.StartTime;
      }
      let latestEnd;
      for (const content of syllableLyrics.Content) {
        const ends = [content.Lead?.EndTime, ...toArray(content.Background).map((bg) => bg?.EndTime)];
        for (const end of ends) {
          if (typeof end === "number" && (latestEnd === void 0 || end > latestEnd)) {
            latestEnd = end;
          }
        }
      }
      syllableLyrics.EndTime = latestEnd;
      lyricsJSON = syllableLyrics;
      break;
    }
    default:
      ttmlLogger.error(`Unsupported lyrics type: ${lyricsType}`);
      return null;
  }
  const rootItems = lyricsJSON.Type === "Static" ? lyricsJSON.Lines : lyricsJSON.Content;
  if (rootItems.length === 0) {
    ttmlLogger.warn("Conversion resulted in empty lyrics content");
    return null;
  }
  const getLead = (item) => "Lead" in item ? item.Lead : void 0;
  const getBackground = (item) => "Background" in item ? item.Background : void 0;
  const getOwnTranslit = (item) => "TransliteratedText" in item ? item.TransliteratedText : void 0;
  const getOwnTranslation = (item) => "TranslatedText" in item ? item.TranslatedText : void 0;
  const anyTranslit = rootItems.some(
    (item) => item?.HasTransliterations === true || getOwnTranslit(item) !== void 0 || getLead(item)?.TransliteratedText !== void 0 || getLead(item)?.Syllables?.some((s) => s?.TransliteratedText !== void 0) || getBackground(item)?.some((bg) => bg?.HasTransliterations || bg?.TransliteratedText !== void 0)
  );
  if (anyTranslit) lyricsJSON.HasTransliterations = true;
  if (!lyricsJSON.HasTranslations) {
    const anyTranslation = rootItems.some(
      (item) => item?.HasTranslations === true || getOwnTranslation(item) !== void 0 || getLead(item)?.TranslatedText !== void 0 || getBackground(item)?.some((bg) => bg?.HasTranslations || bg?.TranslatedText !== void 0)
    );
    if (anyTranslation) lyricsJSON.HasTranslations = true;
  }
  ttmlLogger.info("Successfully converted lyrics");
  return lyricsJSON;
}
var toFiniteSeconds = (value) => Number.isFinite(value) && value >= 0 ? value : void 0;
function convertTimeToSeconds(timeValue) {
  if (timeValue == null) return void 0;
  if (typeof timeValue === "number") return toFiniteSeconds(timeValue);
  const timeString = String(timeValue).trim();
  if (timeString === "") return void 0;
  if (timeString.includes(":")) {
    const parts = timeString.split(":");
    if (parts.length < 2 || parts.length > 4) {
      ttmlLogger.debug("Unparseable clock time in TTML, ignoring", { timeString });
      return void 0;
    }
    const reversed = parts.slice().reverse();
    const offset = parts.length === 4 ? 1 : 0;
    let seconds = 0;
    for (let i = offset; i < reversed.length; i++) {
      const part = parseFloat(reversed[i]);
      if (!Number.isFinite(part)) {
        ttmlLogger.debug("Unparseable clock time in TTML, ignoring", { timeString });
        return void 0;
      }
      seconds += part * Math.pow(60, i - offset);
    }
    return toFiniteSeconds(seconds);
  }
  const match = /^([+-]?(?:[0-9]+\.?[0-9]*|\.[0-9]+))(ms|h|m|s|f|t)?$/.exec(timeString);
  if (!match) {
    ttmlLogger.debug("Unparseable time value in TTML, ignoring", { timeString });
    return void 0;
  }
  const value = parseFloat(match[1]);
  if (!Number.isFinite(value)) return void 0;
  switch (match[2]) {
    case "ms":
      return toFiniteSeconds(value / 1e3);
    case "h":
      return toFiniteSeconds(value * 3600);
    case "m":
      return toFiniteSeconds(value * 60);
    case "s":
    case void 0:
      return toFiniteSeconds(value);
    default:
      ttmlLogger.debug("Unsupported TTML time metric, ignoring", { timeString });
      return void 0;
  }
}
function inferLyricsType(ttml) {
  const divs = getDivs(ttml);
  let sawTiming = false;
  for (const div of divs) {
    if (!div || div.p == null) continue;
    const ps = toArray(div.p);
    for (const p of ps) {
      if (!p || typeof p !== "object") continue;
      if (p.span) {
        const spans = toArray(p.span);
        const timedVocalSpans = spans.filter(
          (s) => isVocalSpan(s) && Boolean(s.begin)
        );
        if (timedVocalSpans.length > 1) return "Syllable";
        if (timedVocalSpans.length === 1) sawTiming = true;
      }
      if (p.begin) sawTiming = true;
    }
  }
  return sawTiming ? "Line" : "Static";
}
function GetSongWriters(ttml) {
  ttmlLogger.debug("Getting songwriters from TTML");
  const itm = ttml?.tt?.head?.metadata?.iTunesMetadata;
  const itmetadata = Array.isArray(itm) ? itm.find((i) => i?.songwriters) ?? itm[0] : itm;
  const SongWriters = itmetadata?.songwriters?.songwriter;
  if (!SongWriters) {
    ttmlLogger.debug("No songwriters found in TTML");
    return null;
  }
  const ProcessedSongWriters = toArray(SongWriters);
  const SongWritersOutput = ProcessedSongWriters.map((SongWriter) => {
    if (SongWriter == null) return null;
    const text = decodeXmlEntities(String(SongWriter)).trim();
    return text === "" ? null : text;
  }).filter((writer) => writer !== null);
  if (SongWritersOutput.length === 0) {
    ttmlLogger.debug("SongWriters - Not Found after mapping");
    return null;
  }
  ttmlLogger.debug("Found songwriters:", SongWritersOutput);
  return SongWritersOutput;
}
function GetTransliterations(ttml, wordEnds) {
  ttmlLogger.debug("Getting transliterations from TTML");
  const itm = ttml?.tt?.head?.metadata?.iTunesMetadata;
  if (!itm) return null;
  const map = /* @__PURE__ */ new Map();
  let sawTransliterationNode = false;
  toArray(itm).forEach((metadata) => {
    const transliteration = metadata?.transliterations?.transliteration;
    if (!transliteration) return;
    sawTransliterationNode = true;
    toArray(transliteration).forEach((block) => {
      toArray(block?.text).forEach((entry) => {
        const lineKey = entry?.for;
        if (!lineKey) return;
        const line = { spans: [], background: [] };
        collectTransliterationSpans(toArray(entry.span), line.spans, line.background, {
          lineKey,
          background: false,
          wordEnds
        });
        if (line.spans.length === 0 && line.background.length === 0) return;
        const existing = map.get(lineKey);
        if (existing) {
          existing.spans.push(...line.spans);
          existing.background.push(...line.background);
        } else {
          map.set(lineKey, line);
        }
      });
    });
  });
  if (!sawTransliterationNode) {
    ttmlLogger.debug("No transliterations found in TTML");
    return null;
  }
  if (map.size === 0) {
    ttmlLogger.warn("Transliterations present but produced no usable spans");
    return null;
  }
  ttmlLogger.debug(`Found transliterations for ${map.size} line(s)`);
  return map;
}
function collectTransliterationSpans(nodes, out, background, source) {
  nodes.forEach((node) => {
    if (!isSpanObject(node)) return;
    const children = toArray(node.span);
    if (children.length > 0) {
      const isBg = node["ttm:role"] === "x-bg";
      collectTransliterationSpans(
        children,
        isBg ? background : out,
        background,
        isBg ? { ...source, background: true } : source
      );
      return;
    }
    if (node.begin == null || node.end == null) return;
    out.push({
      begin: node.begin,
      end: node.end,
      beginSeconds: convertTimeToSeconds(node.begin),
      endSeconds: convertTimeToSeconds(node.end),
      text: readText(node["#text"]),
      endsWord: source.wordEnds.get(
        transliterationSpanKey(source.lineKey, source.background, node.begin, node.end)
      )
    });
  });
}
function pickBackgroundTransliterations(bgEntry, lineEntry) {
  for (const entry of [bgEntry, lineEntry]) {
    if (!entry) continue;
    if (entry.background.length > 0) return entry.background;
    if (entry.spans.length > 0) return entry.spans;
  }
  return void 0;
}
var TIME_MATCH_EPSILON = 2e-3;
function findTransliteratedText(spans, begin, end) {
  if (!Array.isArray(spans) || spans.length === 0) return void 0;
  if (begin == null || end == null || begin === "" || end === "") return void 0;
  const exact = spans.find((span) => span.begin === begin && span.end === end);
  if (exact) return exact;
  const beginSeconds = convertTimeToSeconds(begin);
  const endSeconds = convertTimeToSeconds(end);
  if (beginSeconds === void 0 || endSeconds === void 0) return void 0;
  return spans.find(
    (span) => span.beginSeconds !== void 0 && span.endSeconds !== void 0 && Math.abs(span.beginSeconds - beginSeconds) <= TIME_MATCH_EPSILON && Math.abs(span.endSeconds - endSeconds) <= TIME_MATCH_EPSILON
  );
}
function getLineText(p) {
  if (p == null) return void 0;
  if (typeof p === "string") return decodeXmlEntities(p);
  if (typeof p !== "object") return readText(p);
  if (p.span) {
    const spans = toArray(p.span);
    const mainTexts = spans.filter((s) => typeof s === "string" || isVocalSpan(s)).map((s) => typeof s === "string" ? decodeXmlEntities(s) : readText(s["#text"])).filter((text) => text !== "");
    if (mainTexts.length > 0) {
      return mainTexts.reduce((acc, cur, i) => {
        if (i === 0) return cur;
        const needsSpace = !/\s$/.test(acc) && !/^\s/.test(cur);
        return acc + (needsSpace ? " " : "") + cur;
      }, "");
    }
  }
  if (p["#text"] != null) return readText(p["#text"]);
  return void 0;
}
function extractRoleTexts(spans) {
  const result = { roman: void 0, translation: void 0 };
  if (!Array.isArray(spans)) return result;
  spans.forEach((s) => {
    if (!isSpanObject(s)) return;
    const role = s["ttm:role"];
    if (role === "x-roman" && result.roman === void 0) {
      result.roman = readText(s["#text"]);
    } else if (role === "x-translation" && result.translation === void 0) {
      result.translation = readText(s["#text"]);
    }
  });
  return result;
}
function getInlineRoleTexts(p) {
  if (!p || typeof p !== "object" || !p.span) return { roman: void 0, translation: void 0 };
  return extractRoleTexts(toArray(p.span));
}

// integration/spicy-ttml.ts
var prepared = /* @__PURE__ */ new WeakMap();
var textKey = (text) => StripZeroWidth(text).replace(/\s+/gu, "");
var millis = (seconds) => typeof seconds === "number" && Number.isFinite(seconds) && seconds >= 0 && seconds <= 86400 ? Math.round(seconds * 1e3) : void 0;
function vocalLine(vocal) {
  if (!Array.isArray(vocal.Syllables) || vocal.Syllables.length === 0) return null;
  const words = [];
  for (const [i, syllable] of vocal.Syllables.entries()) {
    const start2 = millis(syllable.StartTime), end2 = millis(syllable.EndTime);
    if (typeof syllable.Text !== "string" || !textKey(syllable.Text) || start2 === void 0 || end2 === void 0 || end2 < start2 || words.length && start2 < words[words.length - 1].startMs)
      return null;
    const gap = i < vocal.Syllables.length - 1 && !syllable.IsPartOfWord ? " " : "";
    words.push({ text: syllable.Text + gap, startMs: start2, endMs: end2 });
  }
  const start = millis(vocal.StartTime) ?? words[0].startMs;
  const end = millis(vocal.EndTime) ?? Math.max(...words.map((w) => w.endMs));
  if (end < start || words.some((w) => w.startMs < start || w.endMs > end)) return null;
  return { text: words.map((w) => w.text).join(""), timeMs: start, endMs: end, words };
}
function preservesTiming(baseline, candidate) {
  if (textKey(baseline.text) !== textKey(candidate.text)) return false;
  const original = baseline.words;
  if (!original?.length) return true;
  const words = candidate.words;
  if (!words?.length) return false;
  const boundaries = /* @__PURE__ */ new Map();
  let cursor = 0;
  for (const [index, word] of words.entries()) {
    const length = textKey(word.text).length;
    const previous = boundaries.get(cursor);
    boundaries.set(cursor, { start: word.startMs, end: previous?.end ?? word.startMs });
    cursor += length;
    boundaries.set(cursor, { start: words[index + 1]?.startMs ?? word.endMs, end: word.endMs });
  }
  cursor = 0;
  for (const word of original) {
    const length = textKey(word.text).length;
    if (length === 0) continue;
    const begin = boundaries.get(cursor), end = boundaries.get(cursor + length);
    if (!begin || !end || begin.start !== word.startMs || end.end !== word.endMs) return false;
    cursor += length;
  }
  return true;
}
function prepareSpicyDocument(document2) {
  const cached = prepared.get(document2);
  if (cached) return cached;
  const keep = () => {
    prepared.set(document2, document2);
    return document2;
  };
  const xml = document2.spicyTtml;
  if (document2.instrumental || typeof xml !== "string" || xml.length === 0 || xml.length > 1024 * 1024)
    return keep();
  if (/<!DOCTYPE|<!ENTITY/i.test(xml)) return keep();
  try {
    if (XMLValidator.validate(xml) !== true) return keep();
    const parsed = parseTTML(xml);
    if (parsed?.Type !== "Syllable" || parsed.Content.length > 2e3) return keep();
    const lines = [];
    let count = 0;
    for (const group of parsed.Content) {
      const lead = vocalLine(group.Lead);
      if (!lead) continue;
      if (lead.words?.length === 1 && /\S+\s+\S+/u.test(lead.text)) lead.words = void 0;
      const background = [];
      for (const vocal of group.Background ?? []) {
        const bg = vocalLine(vocal);
        if (bg) background.push(bg);
      }
      count += (lead.words?.length ?? 0) + background.reduce((n, b) => n + (b.words?.length ?? 0), 0);
      if (count > 3e4) return keep();
      lines.push({
        ...lead,
        agent: group.OppositeAligned ? "v2" : void 0,
        ...background.length ? { background } : {}
      });
    }
    lines.sort((a, b) => a.timeMs - b.timeMs);
    const baseline = document2.lines ?? [];
    if (!lines.length || !baseline.length || baseline.length > 2e3) return keep();
    const candidates = /* @__PURE__ */ new Map();
    for (const line of lines) {
      const key = `${line.timeMs}:${textKey(line.text)}`, group = candidates.get(key) ?? [];
      group.push(line);
      candidates.set(key, group);
    }
    const used = /* @__PURE__ */ new Set();
    let accepted = 0;
    const merged = baseline.map((original) => {
      const matches = (candidates.get(`${original.timeMs}:${textKey(original.text)}`) ?? []).filter((line2) => !used.has(line2) && line2.timeMs === original.timeMs && preservesTiming(original, line2));
      if (matches.length !== 1) return original;
      const line = matches[0];
      used.add(line);
      accepted++;
      return line;
    });
    if (!accepted) return keep();
    const result = { ...document2, lines: merged, synced: true, wordSynced: merged.some((l) => l.words?.length) };
    prepared.set(document2, result);
    prepared.set(result, result);
    return result;
  } catch {
    return keep();
  }
}

// vendor/liner/features/lyrics/canvas/tokens.ts
var LINE_SYNCED_DELAY_MS = 50;
var SPACE = /^\s+$/u;
function splitPart(part) {
  const chunks = part.words.match(/\s+|\S+/gu) ?? [];
  const letters = chunks.filter((chunk) => !SPACE.test(chunk)).reduce((total, chunk) => total + chunk.length, 0);
  let cursor = 0;
  return chunks.map((chunk) => {
    const background = part.isBackground === true;
    if (SPACE.test(chunk)) {
      return {
        text: chunk,
        startMs: 0,
        durationMs: 0,
        background,
        space: true
      };
    }
    const at = (offset) => part.startTimeMs + Math.round(part.durationMs * offset / letters);
    const startMs = at(cursor);
    cursor += chunk.length;
    return {
      text: chunk,
      startMs,
      durationMs: at(cursor) - startMs,
      background,
      space: false
    };
  });
}
function lineSyncedParts(text, startMs) {
  let wordIndex = 0;
  return (text.match(/\s+|\S+/gu) ?? []).map((chunk) => {
    const part = {
      startTimeMs: startMs + wordIndex * LINE_SYNCED_DELAY_MS,
      words: chunk,
      durationMs: 0
    };
    if (!SPACE.test(chunk)) wordIndex += 1;
    return part;
  });
}
function tokenize(parts) {
  return parts.flatMap(splitPart);
}
function groupTokens(tokens) {
  const items = [];
  let current = null;
  for (const token of tokens) {
    if (token.space) {
      current = null;
      items.push(token);
      continue;
    }
    if (!current || current.background !== token.background) {
      current = { background: token.background, tokens: [] };
      items.push(current);
    }
    current.tokens.push(token);
  }
  return items;
}
function isGroup(item) {
  return "tokens" in item;
}

// vendor/liner/features/lyrics/canvas/buildLines.ts
var RICHSYNC_SHIFT_MS = 150;
var LINE_SYNC_SHIFT_MS = 115;
var RTL = /[\p{Script=Arabic}\p{Script=Hebrew}\p{Script=Syriac}\p{Script=Thaana}\p{Script=Nko}\p{Script=Adlam}\p{Script=Mandaic}\p{Script=Hanifi_Rohingya}\p{Script=Samaritan}\p{Script=Yezidi}\p{Script=Mende_Kikakui}\p{Script=Old_Hungarian}]/u;
var LTR = /[\p{Script=Latin}\p{Script=Greek}\p{Script=Cyrillic}\p{Script=Han}\p{Script=Hangul}\p{Script=Hiragana}\p{Script=Katakana}]/u;
function alignFor(agent) {
  if (agent === "v2" || agent === "v3") return "end";
  if (agent === "v1000") return "center";
  return "start";
}
function isRtl(text) {
  for (const char of text) {
    if (RTL.test(char)) return true;
    if (LTR.test(char)) return false;
  }
  return false;
}
function hasTimedParts(lyrics) {
  return lyrics.some(
    (line) => !line.isInstrumental && line.parts?.some((part) => part.durationMs !== 0) === true
  );
}
function subtitleOf(line) {
  const text = line.translation?.text ?? line.romanization ?? null;
  return text && text.trim() ? text.trim() : null;
}
function hasTiming(lyrics) {
  return lyrics.some((line) => line.startTimeMs !== 0 || line.durationMs !== 0);
}
function buildLines(lyrics) {
  const lines = lyrics.map((line, index) => {
    const words = line.words ?? "";
    const parts = line.parts && line.parts.length > 0 ? line.parts : lineSyncedParts(words, line.startTimeMs);
    return {
      startMs: line.startTimeMs,
      durationMs: line.durationMs,
      endMs: line.startTimeMs + line.durationMs,
      nextStartMs: lyrics[index + 1]?.startTimeMs ?? Number.POSITIVE_INFINITY,
      align: alignFor(line.agent),
      rtl: isRtl(words),
      instrumental: Boolean(line.isInstrumental),
      tokens: line.isInstrumental ? [] : tokenize(parts),
      subtitle: subtitleOf(line)
    };
  });
  return {
    lines,
    shiftMs: hasTimedParts(lyrics) ? RICHSYNC_SHIFT_MS : LINE_SYNC_SHIFT_MS,
    timed: hasTiming(lyrics)
  };
}

// vendor/liner/features/lyrics/canvas/lineBitmaps.ts
var BITMAP_PAD = 24;
var LineBitmaps = class {
  bitmaps = /* @__PURE__ */ new Map();
  seen = /* @__PURE__ */ new Set();
  begin() {
    this.seen = /* @__PURE__ */ new Set();
  }
  keep(index) {
    this.seen.add(index);
  }
  get(index, key, width, height, dpr, paint) {
    this.seen.add(index);
    const pixelWidth = Math.max(1, Math.ceil(width * dpr));
    const pixelHeight = Math.max(1, Math.ceil((height + BITMAP_PAD * 2) * dpr));
    let bitmap = this.bitmaps.get(index);
    if (!bitmap) {
      const canvas = document.createElement("canvas");
      const ctx2 = canvas.getContext("2d");
      if (!ctx2) return null;
      bitmap = { canvas, ctx: ctx2, key: "" };
      this.bitmaps.set(index, bitmap);
    }
    const sized = bitmap.canvas.width === pixelWidth && bitmap.canvas.height === pixelHeight;
    if (sized && bitmap.key === key) return bitmap.canvas;
    if (!sized) {
      bitmap.canvas.width = pixelWidth;
      bitmap.canvas.height = pixelHeight;
    }
    const { ctx } = bitmap;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height + BITMAP_PAD * 2);
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    paint(ctx, BITMAP_PAD);
    bitmap.key = key;
    return bitmap.canvas;
  }
  end() {
    for (const index of this.bitmaps.keys()) {
      if (!this.seen.has(index)) this.bitmaps.delete(index);
    }
  }
  clear() {
    this.bitmaps.clear();
  }
};

// vendor/liner/features/lyrics/canvas/easing.ts
function clamp01(value) {
  return value < 0 ? 0 : value > 1 ? 1 : value;
}
function cubicBezier(x1, y1, x2, y2) {
  const ax = 3 * x1 - 3 * x2 + 1;
  const bx = 3 * x2 - 6 * x1;
  const cx = 3 * x1;
  const ay = 3 * y1 - 3 * y2 + 1;
  const by = 3 * y2 - 6 * y1;
  const cy = 3 * y1;
  const sampleX = (t) => ((ax * t + bx) * t + cx) * t;
  const sampleY = (t) => ((ay * t + by) * t + cy) * t;
  const slopeX = (t) => (3 * ax * t + 2 * bx) * t + cx;
  const solve = (x) => {
    let t = x;
    for (let i = 0; i < 6; i++) {
      const error = sampleX(t) - x;
      const slope = slopeX(t);
      if (Math.abs(error) < 1e-5 || Math.abs(slope) < 1e-6) break;
      t -= error / slope;
    }
    if (t >= 0 && t <= 1 && Math.abs(sampleX(t) - x) < 1e-4) return t;
    let low = 0;
    let high = 1;
    t = x;
    for (let i = 0; i < 20; i++) {
      if (sampleX(t) < x) low = t;
      else high = t;
      t = (low + high) / 2;
    }
    return t;
  };
  return (progress) => {
    const x = clamp01(progress);
    if (x === 0 || x === 1) return x;
    return sampleY(solve(x));
  };
}
var scrollEasing = cubicBezier(0.86, 0, 0.2, 1);
var fogEasing = cubicBezier(0.22, 1, 0.36, 1);
var cssEase = cubicBezier(0.25, 0.1, 0.25, 1);

// vendor/liner/features/lyrics/canvas/instrumentalNote.ts
var NOTE_PATH = "M10 21q-1.65 0-2.825-1.175T6 17t1.175-2.825T10 13q.575 0 1.063.138t.937.412V4q0-.425.288-.712T13 3h4q.425 0 .713.288T18 4v2q0 .425-.288.713T17 7h-3v10q0 1.65-1.175 2.825T10 21";
var NOTE_VIEWBOX = 24;
var WAVE_FLOOR = 4;
var WAVE_MID = 3;
var OSCILLATION_MS = 1250;
var WAVE_POINTS = [
  [1, 5, -1],
  [10, 14, 1],
  [18, 22, -1],
  [26, 30, 1]
];
var waveFlattenEasing = cubicBezier(0.42, 0, 1, 1);
var oscillationEasing = cubicBezier(0.42, 0, 0.58, 1);
var notePath = null;
function note() {
  notePath ??= new Path2D(NOTE_PATH);
  return notePath;
}
function amplitude(phaseMs) {
  const cycle = (phaseMs % OSCILLATION_MS + OSCILLATION_MS) % OSCILLATION_MS / OSCILLATION_MS;
  const eased = oscillationEasing(cycle);
  const towardLow = eased < 0.5 ? eased * 2 : 2 - eased * 2;
  return 1 - 2 * towardLow;
}
function waveClip(state) {
  const shift = state.shift * NOTE_VIEWBOX;
  const wave = amplitude(state.phaseMs);
  const y = (value) => WAVE_FLOOR + (value - WAVE_FLOOR) * state.height + shift;
  const path = new Path2D();
  path.moveTo(-4, y(WAVE_MID));
  for (const [control, end, direction] of WAVE_POINTS) {
    path.quadraticCurveTo(
      control,
      y(WAVE_MID + direction * wave),
      end,
      y(WAVE_MID)
    );
  }
  path.lineTo(30, 30 + shift);
  path.lineTo(-4, 30 + shift);
  path.closePath();
  path.rect(-4, 3.9 + shift, 34, 30);
  return path;
}

// vendor/liner/features/lyrics/canvas/exitClock.ts
var FADE_OUT_MS = 500;
var LINE_END_PAD_MS = 50;
var REWIND_MS = 200;
var seenAt = /* @__PURE__ */ new WeakMap();
function lineExitMs(line) {
  return Math.max(line.nextStartMs, line.endMs + LINE_END_PAD_MS);
}
function exitElapsedMs(line, timeMs, now) {
  const exit = lineExitMs(line);
  if (timeMs < exit) {
    if (timeMs < exit - REWIND_MS) seenAt.delete(line);
    return null;
  }
  const mediaElapsed = timeMs - exit;
  const seen = seenAt.get(line) ?? now - mediaElapsed;
  seenAt.set(line, seen);
  return Math.max(mediaElapsed, now - seen);
}
function exitFade(line, timeMs, now) {
  const elapsed = exitElapsedMs(line, timeMs, now);
  if (elapsed === null) return 1;
  return 1 - cssEase(clamp01(elapsed / FADE_OUT_MS));
}
function isExiting(line, timeMs, now) {
  const elapsed = exitElapsedMs(line, timeMs, now);
  return elapsed !== null && elapsed < FADE_OUT_MS + 50;
}

// vendor/liner/features/lyrics/canvas/timing.ts
var SWIPE_LEAD_RATIO = 0.1;
var SWIPE_DURATION_RATIO = 1.6;
var SWIPE_START_FROM = -0.2;
var SWIPE_START_TO = 1.4;
var SWIPE_WIDTH = 0.1;
var FADE_IN_MS = 330;
var SETUP_EARLY_MS = 2e3;
var LONG_WORD_MS = 1500;
var GLOW_RATIO = 1.2;
var GLOW_MIN_MS = 1200;
var GLOW_RADIUS_REM = 0.8;
function isLineSelected(line, timeMs) {
  return timeMs + SETUP_EARLY_MS >= line.startMs && timeMs < lineExitMs(line);
}
function sweepAt(token, elapsedMs) {
  const swipeMs = token.durationMs * SWIPE_DURATION_RATIO;
  const swipeTime = Math.min(
    elapsedMs + token.durationMs * SWIPE_LEAD_RATIO,
    swipeMs
  );
  return SWIPE_START_FROM + (SWIPE_START_TO - SWIPE_START_FROM) * swipeTime / swipeMs;
}
function glowAt(token, elapsedMs) {
  if (token.durationMs <= LONG_WORD_MS) return 0;
  const glowMs = Math.max(token.durationMs * GLOW_RATIO, GLOW_MIN_MS);
  if (elapsedMs >= glowMs) return 0;
  return GLOW_RADIUS_REM * (1 - cssEase(elapsedMs / glowMs));
}
function tokenHighlight(token, line, timeMs, now) {
  const exit = lineExitMs(line);
  if (timeMs < token.startMs || token.startMs > exit) return null;
  const elapsed = timeMs - token.startMs;
  if (timeMs >= exit) {
    const opacity = exitFade(line, timeMs, now);
    if (opacity <= 0) return null;
    return {
      opacity,
      solid: SWIPE_START_TO,
      clear: SWIPE_START_TO,
      glowRem: 0
    };
  }
  if (token.durationMs <= 0) {
    const opacity = cssEase(clamp01(elapsed / FADE_IN_MS));
    return {
      opacity,
      solid: SWIPE_START_TO,
      clear: SWIPE_START_TO,
      glowRem: 0
    };
  }
  const solid = sweepAt(token, elapsed);
  return {
    opacity: 1,
    solid,
    clear: solid + SWIPE_WIDTH,
    glowRem: glowAt(token, elapsed)
  };
}
function tokenSettleMs(token) {
  if (token.durationMs <= 0) return FADE_IN_MS;
  const sweep = token.durationMs * SWIPE_DURATION_RATIO;
  if (token.durationMs <= LONG_WORD_MS) return sweep;
  return Math.max(sweep, token.durationMs * GLOW_RATIO, GLOW_MIN_MS);
}
function isLineAnimating(line, timeMs, now) {
  const exiting = isExiting(line, timeMs, now);
  if (timeMs >= lineExitMs(line)) return exiting;
  if (!isLineSelected(line, timeMs)) return false;
  if (line.instrumental) return true;
  return line.tokens.some(
    (token) => !token.space && timeMs >= token.startMs - 50 && timeMs <= token.startMs + tokenSettleMs(token) + 50
  );
}

// vendor/liner/features/lyrics/canvas/instrumentalTiming.ts
var FILL_FADE_MS = 150;
var FILL_FROM = 0.78;
var FILL_TO = -0.04;
var REST_SHIFT = 0;
var WAVE_FROM = 1.2;
var WAVE_TO = 1e-4;
function instrumentalState(line, timeMs, waveEasing, now) {
  const elapsed = timeMs - line.startMs;
  const durationMs = Math.max(line.durationMs, 1);
  if (timeMs >= lineExitMs(line)) {
    const opacity = exitFade(line, timeMs, now);
    if (opacity <= 0) return null;
    return { opacity, shift: REST_SHIFT, height: WAVE_FROM, phaseMs: 0 };
  }
  if (!isLineSelected(line, timeMs)) return null;
  const progress = clamp01(elapsed / durationMs);
  return {
    opacity: elapsed < 0 ? 1 : cssEase(clamp01(elapsed / FILL_FADE_MS)),
    shift: FILL_FROM + (FILL_TO - FILL_FROM) * progress,
    height: WAVE_FROM + (WAVE_TO - WAVE_FROM) * waveEasing(progress),
    phaseMs: elapsed
  };
}

// vendor/liner/features/lyrics/canvas/drawWord.ts
function white(alpha) {
  return `rgba(255, 255, 255, ${Math.max(0, Math.min(1, alpha)).toFixed(3)})`;
}
function highlightStyle(paint, placed, highlight) {
  if (highlight.solid >= 1) return white(highlight.opacity);
  const width = Math.max(1, placed.width);
  const start = paint.rtl ? placed.x + width : placed.x;
  const end = paint.rtl ? placed.x : placed.x + width;
  const y = paint.top + placed.baseline;
  const gradient = paint.ctx.createLinearGradient(start, y, end, y);
  const solid = highlight.solid;
  const clear = highlight.clear + 1 / width;
  const alphaAt = (offset) => highlight.opacity * Math.max(0, Math.min(1, (clear - offset) / Math.max(1e-6, clear - solid)));
  gradient.addColorStop(0, white(alphaAt(0)));
  if (solid > 0 && solid < 1)
    gradient.addColorStop(solid, white(alphaAt(solid)));
  if (clear > 0 && clear < 1) gradient.addColorStop(clear, white(0));
  gradient.addColorStop(1, white(alphaAt(1)));
  return gradient;
}
function drawToken(paint, placed, highlight) {
  const { ctx } = paint;
  const y = Math.round((paint.top + placed.baseline) * paint.dpr) / paint.dpr;
  const text = placed.token.text;
  ctx.fillStyle = white(paint.base);
  ctx.fillText(text, placed.x, y);
  if (!highlight || highlight.opacity <= 0) return;
  if (highlight.clear <= 0) return;
  ctx.fillStyle = highlightStyle(paint, placed, highlight);
  if (highlight.glowRem > 0) {
    ctx.save();
    ctx.shadowColor = white(1);
    ctx.shadowBlur = highlight.glowRem * paint.remPx * paint.dpr;
    ctx.fillText(text, placed.x, y);
    ctx.restore();
    return;
  }
  ctx.fillText(text, placed.x, y);
}

// vendor/liner/features/lyrics/canvas/drawInstrumental.ts
var INACTIVE_ALPHA = 0.3;
var GLOW_SIGMA = 5;
var GLOW_ALPHA = 0.6;
var GLOW_PAD = 3;
var scratch = null;
function scratchCanvas(size) {
  scratch ??= document.createElement("canvas");
  if (scratch.width !== size || scratch.height !== size) {
    scratch.width = size;
    scratch.height = size;
  }
  const ctx = scratch.getContext("2d");
  ctx?.setTransform(1, 0, 0, 1, 0, 0);
  ctx?.clearRect(0, 0, size, size);
  return ctx;
}
function noteLeft(layout, size, frame) {
  const box = size * 4 / 3;
  const inset = (box - size) / 2;
  if (layout.line.align === "end") {
    return frame.left + frame.width + size / 3 - box + inset;
  }
  if (layout.line.align === "center") {
    return frame.left + (frame.width - box) / 2 + inset;
  }
  return frame.left - size / 3 + inset;
}
function drawInstrumental(ctx, layout, top, timeMs, type, frame, dpr, now) {
  const size = type.size;
  const scale = size / NOTE_VIEWBOX;
  const left = noteLeft(layout, size, frame);
  const noteTop = top + type.paddingY;
  ctx.save();
  ctx.translate(left, noteTop);
  ctx.scale(scale, scale);
  ctx.fillStyle = white(INACTIVE_ALPHA);
  ctx.fill(note());
  ctx.restore();
  const state = instrumentalState(layout.line, timeMs, waveFlattenEasing, now);
  if (!state) return;
  const pad = GLOW_PAD * GLOW_SIGMA * scale;
  const pixels = Math.ceil((size + pad * 2) * dpr);
  const fill = scratchCanvas(pixels);
  if (!fill || !scratch) return;
  fill.save();
  fill.scale(dpr, dpr);
  fill.translate(pad, pad);
  fill.scale(scale, scale);
  fill.clip(waveClip(state));
  fill.fillStyle = white(1);
  fill.fill(note());
  fill.restore();
  ctx.save();
  ctx.globalAlpha = state.opacity;
  ctx.shadowColor = white(GLOW_ALPHA);
  ctx.shadowBlur = GLOW_SIGMA * scale * 2 * dpr;
  ctx.drawImage(
    scratch,
    left - pad,
    noteTop - pad,
    size + pad * 2,
    size + pad * 2
  );
  ctx.restore();
}

// vendor/liner/features/lyrics/canvas/fonts.ts
var LYRICS_TYPOGRAPHY = {
  family: "Montserrat, system-ui, sans-serif",
  size: 32,
  weight: 600,
  lineHeight: 44.8,
  paddingY: 20,
  paddingX: 8
};
var BACKGROUND_SCALE = 0.75;
var SUBTITLE_SCALE = 0.8;
var SUBTITLE_GAP = 8;
function mainFont(type) {
  return `${type.weight} ${type.size}px ${type.family}`;
}
function backgroundFont(type) {
  return `500 ${type.size * BACKGROUND_SCALE}px ${type.family}`;
}
function subtitleFont(type) {
  return `${type.weight} ${type.size * SUBTITLE_SCALE}px ${type.family}`;
}
function resolveFamily(element) {
  const family = getComputedStyle(element).getPropertyValue("--font-montserrat-family").trim();
  return family ? `${family}, system-ui, sans-serif` : LYRICS_TYPOGRAPHY.family;
}
async function loadLyricsFonts(type, text) {
  if (typeof document === "undefined" || !document.fonts) return;
  await Promise.allSettled([
    document.fonts.load(mainFont(type), text),
    document.fonts.load(backgroundFont(type), text),
    document.fonts.load(subtitleFont(type), text)
  ]);
}

// vendor/liner/features/lyrics/canvas/drawLine.ts
var INACTIVE_ALPHA2 = 0.3;
var BACKGROUND_ALPHA = INACTIVE_ALPHA2 * 0.78;
var SUBTITLE_ALPHA = 0.6;
var REM_PX = 16;
var UNTIMED_HIGHLIGHT = {
  opacity: 1,
  solid: 1.4,
  clear: 1.4,
  glowRem: 0
};
function drawLine(ctx, layout, top, timeMs, type, dpr, now, timed = true) {
  const { line } = layout;
  ctx.direction = line.rtl ? "rtl" : "ltr";
  let current = "";
  for (const placed of layout.tokens) {
    const background = placed.token.background;
    const font = background ? backgroundFont(type) : mainFont(type);
    if (font !== current) {
      current = font;
      ctx.font = font;
    }
    drawToken(
      {
        ctx,
        top,
        rtl: line.rtl,
        base: background ? BACKGROUND_ALPHA : INACTIVE_ALPHA2,
        remPx: REM_PX,
        dpr
      },
      placed,
      timed ? tokenHighlight(placed.token, line, timeMs, now) : UNTIMED_HIGHLIGHT
    );
  }
  if (layout.subtitle.length === 0) return;
  ctx.font = subtitleFont(type);
  ctx.fillStyle = white(SUBTITLE_ALPHA);
  for (const text of layout.subtitle) {
    ctx.fillText(
      text.text,
      text.x,
      Math.round((top + text.baseline) * dpr) / dpr
    );
  }
}

// vendor/liner/features/lyrics/canvas/sceneLines.ts
function paintLine(frame, layout) {
  const { scene, timeMs, dpr, now } = frame;
  return (ctx, top) => {
    if (layout.line.instrumental) {
      drawInstrumental(
        ctx,
        layout,
        top,
        timeMs,
        scene.typography,
        scene.frame,
        dpr,
        now
      );
      return;
    }
    drawLine(ctx, layout, top, timeMs, scene.typography, dpr, now, scene.timed);
  };
}
function litState(layout, timeMs, timed) {
  if (!timed) return "static";
  if (timeMs >= lineExitMs(layout.line)) return "done";
  return String(
    layout.tokens.filter((placed) => placed.token.startMs <= timeMs).length
  );
}
function visibleLines(frame) {
  const { scene, motion, now, timeMs, dpr } = frame;
  const lines = [];
  scene.layouts.forEach((layout, index) => {
    const offset = motion.offsetFor(index, now);
    const exact = layout.top - motion.position + offset;
    const bottom = exact + layout.height + BITMAP_PAD;
    if (bottom < 0 || exact - BITMAP_PAD > scene.height) return;
    const live = scene.timed && isLineAnimating(layout.line, timeMs, now);
    const moving = offset !== 0 || motion.isWheelMoving();
    lines.push({
      index,
      layout,
      top: moving ? exact : Math.round(exact * dpr) / dpr,
      key: live ? `live:${now}` : `still:${scene.version}:${litState(layout, timeMs, scene.timed)}`,
      live,
      fading: live && timeMs >= lineExitMs(layout.line),
      moving
    });
  });
  return lines;
}
function lineBitmap(frame, line) {
  return frame.bitmaps.get(
    line.index,
    line.key,
    frame.scene.width,
    line.layout.height,
    frame.dpr,
    paintLine(frame, line.layout)
  );
}

// vendor/liner/features/lyrics/canvas/drawScene.ts
function canSplit(frame, lines) {
  if (frame.fog.isMoving(frame.now)) return false;
  if (lines.some((line) => line.moving)) return false;
  const { top, bottom } = frame.fog.insets(frame.scene.height, frame.now);
  const limit = frame.scene.height - bottom;
  return lines.filter((line) => line.live).every(
    (line) => line.top - BITMAP_PAD >= top && line.top + line.layout.height + BITMAP_PAD <= limit
  );
}
function paintBase(frame, lines) {
  const { ctx, scene, dpr, now } = frame;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, scene.width, scene.height);
  ctx.imageSmoothingEnabled = true;
  for (const line of lines) {
    const bitmap = lineBitmap(frame, line);
    if (!bitmap) continue;
    ctx.drawImage(
      bitmap,
      0,
      line.top - BITMAP_PAD,
      bitmap.width / dpr,
      bitmap.height / dpr
    );
  }
  frame.fog.draw(ctx, scene.width, scene.height, now);
}
function drawScene(frame, previous, live) {
  const lines = visibleLines(frame);
  const animating = lines.some((line) => line.live);
  const fading = lines.some((line) => line.fading);
  const split = canSplit(frame, lines);
  const baseLines = split ? lines.filter((line) => !line.live) : lines;
  const signature = (split ? "split|" : "full|") + baseLines.map((line) => `${line.index}@${line.top.toFixed(2)}#${line.key}`).join("|");
  frame.bitmaps.begin();
  for (const line of lines) frame.bitmaps.keep(line.index);
  if (signature !== previous || frame.fog.isMoving(frame.now)) {
    paintBase(frame, baseLines);
  }
  if (split) {
    const pieces = [];
    for (const line of lines.filter((entry) => entry.live)) {
      const bitmap = lineBitmap(frame, line);
      if (bitmap) {
        pieces.push({ bitmap, top: line.top, height: line.layout.height });
      }
    }
    live.draw(pieces, frame.scene.width, frame.dpr);
  } else {
    live.hide();
  }
  frame.bitmaps.end();
  return { animating, fading, signature };
}

// vendor/liner/features/lyrics/canvas/edgeFog.ts
var FOG_TOP = 0.22;
var FOG_BOTTOM = 0.26;
var FOG_TRANSITION_MS = 450;
function tweenValue(tween, now) {
  const progress = clamp01((now - tween.startedAt) / FOG_TRANSITION_MS);
  return tween.from + (tween.to - tween.from) * fogEasing(progress);
}
var EdgeFog = class {
  enabled = true;
  top = { from: 0, to: 0, startedAt: 0 };
  bottom = { from: FOG_BOTTOM, to: FOG_BOTTOM, startedAt: 0 };
  edges = "";
  track(atTop, atBottom, now) {
    this.update(atTop, atBottom, now);
    const edges = `${atTop}:${atBottom}`;
    if (edges === this.edges) return false;
    this.edges = edges;
    return true;
  }
  update(atTop, atBottom, now) {
    this.top = this.retarget(this.top, atTop ? 0 : FOG_TOP, now);
    this.bottom = this.retarget(this.bottom, atBottom ? 0 : FOG_BOTTOM, now);
  }
  insets(height, now) {
    if (!this.enabled) return { top: 0, bottom: 0 };
    return {
      top: tweenValue(this.top, now) * height,
      bottom: tweenValue(this.bottom, now) * height
    };
  }
  isMoving(now) {
    return now - this.top.startedAt < FOG_TRANSITION_MS || now - this.bottom.startedAt < FOG_TRANSITION_MS;
  }
  draw(ctx, width, height, now) {
    if (!this.enabled) return;
    const top = tweenValue(this.top, now) * height;
    const bottom = tweenValue(this.bottom, now) * height;
    ctx.save();
    ctx.globalCompositeOperation = "destination-out";
    if (top > 0.5) {
      const gradient = ctx.createLinearGradient(0, 0, 0, top);
      gradient.addColorStop(0, "rgba(0, 0, 0, 1)");
      gradient.addColorStop(1, "rgba(0, 0, 0, 0)");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, top);
    }
    if (bottom > 0.5) {
      const gradient = ctx.createLinearGradient(0, height - bottom, 0, height);
      gradient.addColorStop(0, "rgba(0, 0, 0, 0)");
      gradient.addColorStop(1, "rgba(0, 0, 0, 1)");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, height - bottom, width, bottom);
    }
    ctx.restore();
  }
  retarget(tween, to, now) {
    if (tween.to === to) return tween;
    return { from: tweenValue(tween, now), to, startedAt: now };
  }
};

// vendor/liner/features/lyrics/canvas/liveLayer.ts
var LiveLayer = class {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    canvas.style.visibility = "hidden";
  }
  canvas;
  ctx;
  shown = false;
  hide() {
    if (!this.shown) return;
    this.shown = false;
    this.canvas.style.visibility = "hidden";
  }
  draw(pieces, width, dpr) {
    const ctx = this.ctx;
    if (!ctx || pieces.length === 0) {
      this.hide();
      return;
    }
    const snap = (value, round) => round(value * dpr) / dpr;
    const top = snap(
      Math.min(...pieces.map((piece) => piece.top - BITMAP_PAD)),
      Math.floor
    );
    const bottom = snap(
      Math.max(...pieces.map((piece) => piece.top + piece.height + BITMAP_PAD)),
      Math.ceil
    );
    const pixelWidth = Math.max(1, Math.round(width * dpr));
    const pixelHeight = Math.max(1, Math.round((bottom - top) * dpr));
    if (this.canvas.width !== pixelWidth) this.canvas.width = pixelWidth;
    if (this.canvas.height !== pixelHeight) this.canvas.height = pixelHeight;
    const style = this.canvas.style;
    const height = `${bottom - top}px`;
    const transform = `translateY(${top}px)`;
    if (style.height !== height) style.height = height;
    if (style.transform !== transform) style.transform = transform;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, bottom - top);
    for (const piece of pieces) {
      ctx.drawImage(
        piece.bitmap,
        0,
        piece.top - top - BITMAP_PAD,
        piece.bitmap.width / dpr,
        piece.bitmap.height / dpr
      );
    }
    if (!this.shown) {
      this.shown = true;
      style.visibility = "visible";
    }
  }
};

// vendor/liner/shared/utils/windowVisibility.ts
var visible = true;
var subscribed = false;
var listeners = /* @__PURE__ */ new Set();
function applyWindowVisibility(next) {
  if (next === visible) return;
  visible = next;
  for (const listener of listeners) listener(visible);
}
function ensureSubscribed() {
  if (subscribed || typeof window === "undefined") return;
  subscribed = true;
  window.linerElectron?.onWindowStateChange?.((state) => {
    applyWindowVisibility(state.isVisible !== false);
  });
}
function isWindowVisible() {
  ensureSubscribed();
  return visible;
}
function onWindowVisibilityChange(listener) {
  ensureSubscribed();
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

// vendor/liner/features/lyrics/canvas/frameLoop.ts
var POLL_MS = 50;
var FrameLoop = class {
  constructor(tick) {
    this.tick = tick;
    this.stopWatchingVisibility = onWindowVisibilityChange((visible2) => {
      if (visible2) this.poke();
    });
  }
  tick;
  rafId = null;
  pollId = null;
  lastFrame = 0;
  stopWatchingVisibility;
  poke() {
    if (this.pollId !== null) {
      window.clearTimeout(this.pollId);
      this.pollId = null;
    }
    if (this.rafId !== null) return;
    this.rafId = requestAnimationFrame(this.onFrame);
  }
  dispose() {
    if (this.rafId !== null) cancelAnimationFrame(this.rafId);
    if (this.pollId !== null) window.clearTimeout(this.pollId);
    this.rafId = null;
    this.pollId = null;
    this.stopWatchingVisibility();
  }
  onFrame = (now) => {
    this.rafId = null;
    if (!isWindowVisible()) return;
    const elapsed = this.lastFrame === 0 ? 16 : Math.min(100, now - this.lastFrame);
    this.lastFrame = now;
    const demand = this.tick(now, elapsed);
    if (demand === "animate") {
      this.rafId = requestAnimationFrame(this.onFrame);
    } else if (demand === "poll") {
      this.pollId = window.setTimeout(() => {
        this.pollId = null;
        this.poke();
      }, POLL_MS);
    }
  };
};

// vendor/liner/features/lyrics/canvas/wrapRuns.ts
function chunkRuns(runs) {
  const chunks = [];
  let current = [];
  runs.forEach((run, index) => {
    current.push(index);
    if (run.breakAfter) {
      chunks.push(current);
      current = [];
    }
  });
  if (current.length > 0) chunks.push(current);
  return chunks;
}
function chunkInk(runs, chunk) {
  let width = 0;
  chunk.forEach((index, position) => {
    width += position === chunk.length - 1 ? runs[index].inkWidth : runs[index].width;
  });
  return width;
}
function wrapRuns(runs, maxWidth) {
  const placed = [];
  let row = 0;
  let x = 0;
  for (const chunk of chunkRuns(runs)) {
    if (x > 0 && x + chunkInk(runs, chunk) > maxWidth) {
      row += 1;
      x = 0;
    }
    for (const index of chunk) {
      if (x > 0 && x + runs[index].inkWidth > maxWidth) {
        row += 1;
        x = 0;
      }
      placed.push({ index, row, x });
      x += runs[index].width;
    }
  }
  return placed;
}
function rowExtents(runs, placed) {
  const extents = [];
  for (const item of placed) {
    const end = item.x + runs[item.index].inkWidth;
    extents[item.row] = Math.max(extents[item.row] ?? 0, end);
  }
  return extents;
}
function alignOffset(align, rowWidth, maxWidth) {
  if (align === "start") return 0;
  if (rowWidth > maxWidth) return (maxWidth - rowWidth) / 2;
  if (align === "end") return maxWidth - rowWidth;
  return (maxWidth - rowWidth) / 2;
}

// vendor/liner/features/lyrics/canvas/layoutBlock.ts
function blockRuns(tokens, font, measure) {
  const runs = [];
  let pendingSpace = "";
  for (const item of groupTokens(tokens)) {
    if (!isGroup(item)) {
      pendingSpace += item.text;
      continue;
    }
    if (runs.length > 0 && pendingSpace) {
      const width2 = measure.width(font, " ");
      runs.push({ width: width2, inkWidth: 0, breakAfter: true, tokens: [] });
    }
    pendingSpace = "";
    const width = item.tokens.reduce(
      (total, token) => total + measure.width(font, token.text),
      0
    );
    runs.push({
      width,
      inkWidth: width,
      breakAfter: false,
      tokens: item.tokens
    });
  }
  return runs;
}
function layoutBlock(line, tokens, font, measure, frame, baselineAt) {
  const runs = blockRuns(tokens, font, measure);
  const placed = wrapRuns(runs, frame.width);
  const extents = rowExtents(runs, placed);
  const align = line.rtl && line.align === "start" ? "end" : line.align;
  const result = [];
  for (const item of placed) {
    const run = runs[item.index];
    const rowWidth = extents[item.row] ?? 0;
    const shift = frame.left + alignOffset(align, rowWidth, frame.width);
    let cursor = item.x;
    for (const token of run.tokens) {
      const width = measure.width(font, token.text);
      const logical = line.rtl ? rowWidth - cursor - width : cursor;
      result.push({
        token,
        x: shift + logical,
        baseline: baselineAt(item.row),
        width
      });
      cursor += width;
    }
  }
  return { tokens: result, rows: extents.length };
}

// vendor/liner/features/lyrics/canvas/layoutLines.ts
function layoutSubtitle(line, measure, type, frame, top) {
  if (!line.subtitle) return { items: [], rows: 0 };
  const font = subtitleFont(type);
  const chunks = line.subtitle.match(/\S+\s*/g) ?? [];
  const runs = chunks.map((chunk) => ({
    width: measure.width(font, chunk),
    inkWidth: measure.width(font, chunk.trimEnd()),
    breakAfter: true
  }));
  const placed = wrapRuns(runs, frame.width);
  const extents = rowExtents(runs, placed);
  const align = line.rtl && line.align === "start" ? "end" : line.align;
  const rowHeight = type.size * SUBTITLE_SCALE * 1.3;
  const items = placed.map((item) => {
    const ink = runs[item.index].inkWidth;
    const rowWidth = extents[item.row];
    const logical = line.rtl ? rowWidth - item.x - ink : item.x;
    return {
      text: chunks[item.index].trimEnd(),
      x: frame.left + alignOffset(align, rowWidth, frame.width) + logical,
      baseline: top + item.row * rowHeight + rowHeight * 0.78
    };
  });
  return { items, rows: extents.length };
}
function layoutSung(line, measure, type, frame, top) {
  const font = mainFont(type);
  const ascent = Math.round(measure.ascent(font));
  const descent = Math.round(measure.descent(font));
  const baselineInRow = Math.floor((type.lineHeight - ascent - descent) / 2) + ascent;
  const rowBaseline = (row) => type.paddingY + row * type.lineHeight + baselineInRow;
  const main = layoutBlock(
    line,
    line.tokens.filter((token) => token.space || !token.background),
    font,
    measure,
    frame,
    rowBaseline
  );
  const background = layoutBlock(
    line,
    line.tokens.filter((token) => token.space || token.background),
    backgroundFont(type),
    measure,
    frame,
    (row) => rowBaseline(main.rows + row)
  );
  const rows = main.rows + background.rows;
  const textBottom = type.paddingY + rows * type.lineHeight;
  const subtitle = layoutSubtitle(
    line,
    measure,
    type,
    frame,
    textBottom + SUBTITLE_GAP
  );
  const subtitleHeight = subtitle.rows > 0 ? SUBTITLE_GAP + subtitle.rows * type.size * SUBTITLE_SCALE * 1.3 : 0;
  return {
    line,
    top,
    height: textBottom + subtitleHeight + type.paddingY,
    tokens: [...main.tokens, ...background.tokens],
    subtitle: subtitle.items
  };
}
function layoutLines(lines, measure, type, frame) {
  let top = frame.top;
  return lines.map((line) => {
    const layout = line.instrumental ? {
      line,
      top,
      height: type.paddingY * 2 + type.size,
      tokens: [],
      subtitle: []
    } : layoutSung(line, measure, type, frame, top);
    top += layout.height;
    return layout;
  });
}

// vendor/liner/features/lyrics/canvas/textMeasure.ts
function createTextMeasure(ctx) {
  const widths = /* @__PURE__ */ new Map();
  const metrics = /* @__PURE__ */ new Map();
  const metricsFor = (font) => {
    const cached = metrics.get(font);
    if (cached) return cached;
    ctx.font = font;
    const next = ctx.measureText("Hg");
    metrics.set(font, next);
    return next;
  };
  return {
    width: (font, text) => {
      const key = `${font}\0${text}`;
      const cached = widths.get(key);
      if (cached !== void 0) return cached;
      ctx.font = font;
      const value = ctx.measureText(text).width;
      widths.set(key, value);
      return value;
    },
    ascent: (font) => metricsFor(font).fontBoundingBoxAscent,
    descent: (font) => metricsFor(font).fontBoundingBoxDescent
  };
}

// vendor/liner/features/lyrics/canvas/scrollPlan.ts
var SCROLL_TIME_OFFSET_MS = 500;
var TARGET_RATIO = 0.37;
var EARLY_SCROLL_CONSIDER_MS = 540;
var ENDING_THRESHOLD_MS = 500;
function activeLineIndices(layouts, scrollTime) {
  const active = [];
  layouts.forEach(({ line }, index) => {
    if (scrollTime >= line.startMs - EARLY_SCROLL_CONSIDER_MS && (scrollTime < line.nextStartMs || scrollTime < line.endMs)) {
      active.push(index);
    }
  });
  return active.length > 0 || layouts.length === 0 ? active : [0];
}
function findAnchor(layouts, sung, scrollTime) {
  const running = sung.filter((index) => {
    const { line } = layouts[index];
    return line.startMs <= scrollTime && scrollTime < line.endMs;
  });
  const started = sung.filter(
    (index) => layouts[index].line.startMs <= scrollTime
  );
  return running.at(-1) ?? started.at(-1) ?? sung[0];
}
function scrollTarget(layouts, scrollTime, viewportHeight) {
  const active = activeLineIndices(layouts, scrollTime);
  const sung = active.filter(
    (index, position) => scrollTime < layouts[index].line.endMs - ENDING_THRESHOLD_MS || position === active.length - 1
  );
  const anchorIndex = findAnchor(layouts, sung, scrollTime);
  const first = layouts[sung[0]];
  const last = layouts[sung[sung.length - 1]];
  const anchor = layouts[anchorIndex];
  const centre = sung.reduce(
    (total, index) => total + layouts[index].top + layouts[index].height / 2,
    0
  ) / sung.length;
  let scrollTop = centre - viewportHeight * TARGET_RATIO;
  scrollTop = Math.max(scrollTop, last.top + last.height - viewportHeight);
  scrollTop = Math.min(scrollTop, last.top);
  scrollTop = Math.min(scrollTop, first.top);
  scrollTop = Math.max(scrollTop, anchor.top + anchor.height - viewportHeight);
  scrollTop = Math.min(scrollTop, anchor.top);
  return {
    active,
    scrollTop,
    anchor: anchorIndex,
    overflows: last.top + last.height - first.top > viewportHeight
  };
}
function maxScrollFor(layouts, viewportHeight) {
  const last = layouts[layouts.length - 1];
  if (!last) return 0;
  const content = last.top + last.height;
  const tail = 1 - TARGET_RATIO;
  const bottom = Math.max(
    last.top + last.height / 2 + viewportHeight * tail - content,
    viewportHeight - content,
    viewportHeight * tail - last.height / 2,
    0
  );
  return Math.max(0, content + Math.ceil(bottom) - viewportHeight);
}

// vendor/liner/features/lyrics/canvas/lyricsScene.ts
var SIDE_INSET = 24;
var TOP_INSET = 32;
var LyricsScene = class {
  constructor(ctx, host, onFontsReady) {
    this.ctx = ctx;
    this.onFontsReady = onFontsReady;
    this.typography = { ...LYRICS_TYPOGRAPHY, family: resolveFamily(host) };
    this.measure = createTextMeasure(ctx);
    document.fonts?.addEventListener("loadingdone", this.remeasure);
    void loadLyricsFonts(this.typography).then(this.remeasure);
  }
  ctx;
  onFontsReady;
  lines = [];
  shiftMs = 0;
  timed = true;
  layouts = [];
  width = 0;
  height = 0;
  typography = LYRICS_TYPOGRAPHY;
  measure;
  version = 0;
  remeasure = () => {
    this.measure = createTextMeasure(this.ctx);
    this.relayout();
    this.onFontsReady();
  };
  dispose() {
    document.fonts?.removeEventListener("loadingdone", this.remeasure);
  }
  get frame() {
    const left = SIDE_INSET + this.typography.paddingX;
    return { left, width: Math.max(1, this.width - left * 2), top: TOP_INSET };
  }
  setLyrics(lyrics) {
    const model = buildLines(lyrics);
    this.lines = model.lines;
    this.shiftMs = model.shiftMs;
    this.timed = model.timed;
    this.relayout();
    const text = lyrics.map((line) => line.words ?? "").join("\n");
    void loadLyricsFonts(this.typography, text);
  }
  setSize(width, height) {
    const widthChanged = width !== this.width;
    this.width = width;
    this.height = height;
    if (widthChanged) this.relayout();
  }
  relayout() {
    this.version += 1;
    this.layouts = this.width > 0 ? layoutLines(this.lines, this.measure, this.typography, this.frame) : [];
  }
  maxScroll() {
    return maxScrollFor(this.layouts, this.height);
  }
  lineAt(y, scroll) {
    const contentY = y + scroll;
    const index = this.layouts.findIndex(
      (layout) => contentY >= layout.top && contentY < layout.top + layout.height
    );
    return index >= 0 ? index : null;
  }
};

// vendor/liner/features/lyrics/canvas/scrollFollow.ts
var TIME_JUMP_MS = 500;
var ScrollFollower = class {
  committed = [];
  pinned = null;
  lastTimeMs = Number.NaN;
  forced = true;
  reset() {
    this.committed = [];
    this.pinned = null;
    this.forced = true;
  }
  decide(layouts, timeMs, viewportHeight) {
    if (layouts.length === 0) return null;
    const scrollTime = timeMs + SCROLL_TIME_OFFSET_MS;
    const jumped = Number.isNaN(this.lastTimeMs) || Math.abs(timeMs - this.lastTimeMs) > TIME_JUMP_MS;
    this.lastTimeMs = timeMs;
    const target = scrollTarget(layouts, scrollTime, viewportHeight);
    const entered = target.active.some(
      (index) => !this.committed.includes(index) && scrollTime >= layouts[index].line.startMs
    );
    const pinnedEnded = this.pinned !== null && this.pinned !== target.anchor && (!target.active.includes(this.pinned) || scrollTime >= layouts[this.pinned].line.endMs);
    if (!this.forced && !jumped && !entered && !pinnedEnded) return null;
    this.forced = false;
    this.committed = target.active;
    this.pinned = target.overflows ? target.anchor : null;
    return {
      scrollTop: target.scrollTop,
      anchor: target.active[target.active.length - 1] ?? 0
    };
  }
  apply(motion, layouts, timeMs, viewportHeight, pinnedTop, now) {
    const decision = this.decide(layouts, timeMs, viewportHeight);
    if (!decision) return;
    const target = pinnedTop ? 0 : decision.scrollTop;
    if (now === null) motion.jumpTo(target);
    else motion.glideTo(target, decision.anchor, now);
  }
};

// vendor/liner/features/lyrics/canvas/scrollMotion.ts
var BASE_DURATION_MS = 750;
var MAX_DURATION_MS = 1900;
var WHEEL_SMOOTHING_MS = 70;
var MIN_GLIDE_PX = 2;
function glideDuration(relativeIndex, delta) {
  const distance = Math.abs(relativeIndex);
  const above = relativeIndex < 0 && delta >= 0 || relativeIndex > 0 && delta < 0;
  if (above) return BASE_DURATION_MS + Math.min(distance, 6) * 20;
  return BASE_DURATION_MS + Math.log(distance + 2) * 80 + (distance + 1) * 20;
}
var ScrollMotion = class {
  position = 0;
  max = 0;
  glides = [];
  wheelTarget = null;
  setMax(max) {
    this.max = Math.max(0, max);
    this.position = this.clamp(this.position);
    if (this.wheelTarget !== null)
      this.wheelTarget = this.clamp(this.wheelTarget);
  }
  jumpTo(value) {
    this.position = this.clamp(value);
    this.glides = [];
    this.wheelTarget = null;
  }
  glideTo(value, anchor, now) {
    const target = this.clamp(value);
    this.wheelTarget = null;
    const delta = target - this.position;
    if (Math.abs(delta) <= MIN_GLIDE_PX) {
      this.position = target;
      return;
    }
    this.glides.push({ delta, startedAt: now, anchor });
    this.position = target;
  }
  wheel(delta) {
    this.wheelTarget = this.clamp((this.wheelTarget ?? this.position) + delta);
  }
  isWheelMoving() {
    return this.wheelTarget !== null && Math.abs(this.wheelTarget - this.position) >= 0.5;
  }
  step(now, elapsedMs) {
    this.glides = this.glides.filter(
      (glide) => now - glide.startedAt < MAX_DURATION_MS
    );
    if (this.wheelTarget === null) return;
    const remaining = this.wheelTarget - this.position;
    if (Math.abs(remaining) < 0.5) {
      this.position = this.wheelTarget;
      return;
    }
    const factor = 1 - Math.exp(-elapsedMs / WHEEL_SMOOTHING_MS);
    this.position += remaining * factor;
  }
  offsetFor(index, now) {
    let offset = 0;
    for (const glide of this.glides) {
      const progress = clamp01(
        (now - glide.startedAt) / glideDuration(index - glide.anchor, glide.delta)
      );
      offset += glide.delta * (1 - scrollEasing(progress));
    }
    return offset;
  }
  isMoving() {
    return this.glides.length > 0 || this.isWheelMoving();
  }
  atTop() {
    return this.position <= 4;
  }
  atBottom() {
    return this.max - this.position <= 4;
  }
  clamp(value) {
    return Math.min(this.max, Math.max(0, value));
  }
};

// vendor/liner/features/lyrics/canvas/lyricsCanvasRenderer.ts
var LyricsCanvasRenderer = class {
  constructor(canvas, liveCanvas, clock, onEdges) {
    this.canvas = canvas;
    this.clock = clock;
    this.onEdges = onEdges;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("2d canvas is not available");
    this.ctx = ctx;
    this.live = new LiveLayer(liveCanvas);
    this.loop = new FrameLoop(this.tick);
    this.scene = new LyricsScene(ctx, canvas, () => this.snap());
  }
  canvas;
  clock;
  onEdges;
  ctx;
  scene;
  motion = new ScrollMotion();
  follower = new ScrollFollower();
  fog = new EdgeFog();
  bitmaps = new LineBitmaps();
  loop;
  live;
  dpr = 1;
  following = true;
  pinnedTop = false;
  signature = "";
  setLyrics(lyrics) {
    this.scene.setLyrics(lyrics);
    this.motion.jumpTo(0);
    this.snap();
  }
  resize(width, height, dpr) {
    this.dpr = dpr;
    this.canvas.width = Math.max(1, Math.round(width * dpr));
    this.canvas.height = Math.max(1, Math.round(height * dpr));
    this.scene.setSize(width, height);
    this.snap();
  }
  setFogEnabled(enabled) {
    this.fog.enabled = enabled;
    this.signature = "";
    this.loop.poke();
  }
  setPinnedTop(pinned) {
    this.pinnedTop = pinned;
    this.follower.reset();
    this.loop.poke();
  }
  follow() {
    this.following = true;
    this.follower.reset();
    this.loop.poke();
  }
  wheel(deltaY) {
    this.following = false;
    this.motion.wheel(deltaY);
    this.loop.poke();
  }
  lineStartAt(y) {
    if (!this.scene.timed) return null;
    const index = this.scene.lineAt(y, this.motion.position);
    return index === null ? null : this.scene.lines[index].startMs;
  }
  invalidate() {
    this.loop.poke();
  }
  dispose() {
    this.loop.dispose();
    this.scene.dispose();
    this.bitmaps.clear();
  }
  lyricTimeMs() {
    return this.clock.timeMs() + this.scene.shiftMs;
  }
  followScroll(now) {
    if (!this.scene.timed) return;
    const { layouts, height } = this.scene;
    this.follower.apply(
      this.motion,
      layouts,
      this.lyricTimeMs(),
      height,
      this.pinnedTop,
      now
    );
  }
  snap() {
    this.signature = "";
    this.motion.setMax(this.scene.maxScroll());
    this.follower.reset();
    if (this.following) this.followScroll(null);
    this.loop.poke();
  }
  tick = (now, elapsedMs) => {
    if (this.following) this.followScroll(now);
    this.motion.step(now, elapsedMs);
    const atTop = this.motion.atTop();
    const atBottom = this.motion.atBottom();
    if (this.fog.track(atTop, atBottom, now)) this.onEdges(atTop, atBottom);
    const { animating, fading, signature } = drawScene(
      {
        ctx: this.ctx,
        scene: this.scene,
        motion: this.motion,
        fog: this.fog,
        bitmaps: this.bitmaps,
        dpr: this.dpr,
        now,
        timeMs: this.lyricTimeMs()
      },
      this.signature,
      this.live
    );
    this.signature = signature;
    if (this.motion.isMoving() || this.fog.isMoving(now) || fading)
      return "animate";
    if (!this.clock.playing()) return "idle";
    return animating ? "animate" : "poll";
  };
};

// integration/lyrics.ts
var isNote2 = (text) => !text.trim() || /^[♪♫♬♩·\s]+$/u.test(text);
function toLinerLyrics(document2, duration = 0, options = {}) {
  document2 = prepareSpicyDocument(document2);
  const ratio = Number.isFinite(options.fadeSpeed) ? Math.max(0.5, Math.min(2, options.fadeSpeed / 1.035)) : 1;
  const lyrics = [], sourceMap = [];
  const lines = document2.lines?.length ? document2.lines : (document2.plainText || "").split(/\r?\n/).filter(Boolean).map((text) => ({ text, timeMs: 0 }));
  const timed = document2.synced === true || document2.synced !== false && lines.some((l) => l.timeMs > 0 || l.endMs != null);
  if (document2.instrumental) return { lyrics: [{ words: "", startTimeMs: 0, durationMs: Math.max(1, duration), isInstrumental: true }], sourceMap: [-1], timed: true };
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i], start = timed ? Math.max(0, line.timeMs) : 0;
    const next = lines[i + 1]?.timeMs, end = timed ? Math.max(start + 1, line.endMs ?? next ?? (duration > start ? duration : start + 4e3)) : 0;
    if (i === 0 && timed && start > 500) lyrics.push({ words: "", startTimeMs: 0, durationMs: start, isInstrumental: true, sourceIndex: -1 });
    sourceMap[i] = lyrics.length;
    const sourceWords = line.words?.length && line.words.map((w) => w.text).join("") === line.text ? line.words : null;
    const usable = sourceWords?.every((w) => Number.isFinite(w.startMs) && Number.isFinite(w.endMs) && w.endMs >= w.startMs) && (sourceWords.some((w) => w.endMs > w.startMs) || sourceWords.some((w) => w.startMs !== sourceWords[0].startMs));
    const words = usable ? sourceWords : null;
    const estimated = !!timed && !isNote2(line.text || "") && !words;
    const estimateEnd = Number.isFinite(next) && next > start ? Math.min(end, next) : end;
    const parts = words ? words.map((w) => ({ words: w.text, startTimeMs: w.startMs, durationMs: Math.max(0, w.endMs - w.startMs) / ratio })) : estimated ? estimatedLineParts(line.text, start, estimateEnd, ratio) : null;
    let vocalEnd = end;
    for (const bg of line.background || []) {
      if (!parts || !bg.words?.length) continue;
      parts.push({ words: " ", startTimeMs: bg.timeMs, durationMs: 0, isBackground: true });
      parts.push(...bg.words.map((w) => ({ words: w.text, startTimeMs: w.startMs, durationMs: Math.max(0, w.endMs - w.startMs) / ratio, isBackground: true })));
      vocalEnd = Math.max(vocalEnd, bg.endMs ?? bg.timeMs);
    }
    lyrics.push({
      words: line.text || "",
      startTimeMs: start,
      durationMs: timed ? vocalEnd - start : 0,
      isInstrumental: isNote2(line.text || ""),
      sourceIndex: i,
      ...line.agent ? { agent: line.agent } : {},
      ...parts ? { parts } : {},
      ...estimated ? { estimatedTiming: true } : {}
    });
    if (timed && Number.isFinite(next) && vocalEnd < next - 250) lyrics.push({ words: "", startTimeMs: vocalEnd, durationMs: next - vocalEnd, isInstrumental: true, sourceIndex: -1 });
    else if (timed && i === lines.length - 1 && duration > vocalEnd + 750) lyrics.push({ words: "", startTimeMs: vocalEnd, durationMs: duration - vocalEnd, isInstrumental: true, sourceIndex: -1 });
  }
  const nativeShiftMs = buildLines(lyrics.map((line) => line.estimatedTiming ? { ...line, parts: void 0 } : line)).shiftMs;
  return { lyrics, sourceMap, timed, nativeShiftMs };
}
var LyricsView = class {
  element;
  document;
  onSeek;
  renderer;
  canvas;
  live;
  status;
  resizeObserver;
  mapping = [];
  estimatedLines = /* @__PURE__ */ new Set();
  durationMs = 0;
  position = 0;
  visualPosition = 0;
  playing = false;
  destroyed = false;
  quietAt = null;
  measuredAt = null;
  hold = null;
  settings = {};
  lastDuration = -1;
  timingSignature = "";
  appearance = "";
  stateKey = "";
  frameAt = 0;
  animationAt = 0;
  returning;
  manualUntil = 0;
  stopVisibility;
  constructor(element, document2, onSeek) {
    document2 = document2 ? prepareSpicyDocument(document2) : null;
    this.element = element;
    this.document = document2;
    this.onSeek = onSeek;
    this.canvas = window.document.createElement("canvas");
    this.live = window.document.createElement("canvas");
    this.canvas.className = "liner-lyrics-base";
    this.live.className = "liner-lyrics-live";
    this.canvas.setAttribute("aria-hidden", "true");
    this.live.setAttribute("aria-hidden", "true");
    this.status = window.document.createElement("span");
    this.status.className = "sr-only";
    this.status.setAttribute("aria-live", "off");
    element.dataset.renderer = "liner-original";
    element.replaceChildren(this.canvas, this.live, this.status);
    if (!document2 || !document2.instrumental && !document2.lines?.length && !document2.plainText) {
      this.message("Sem letra dispon\xEDvel");
      return;
    }
    try {
      this.renderer = new LyricsCanvasRenderer(this.canvas, this.live, { timeMs: () => this.visualPosition, playing: () => this.playing }, () => {
      });
    } catch (error) {
      this.message("O renderizador de letras n\xE3o p\xF4de iniciar.");
      console.error(error);
      return;
    }
    const engine = this.renderer, originalTick = engine.loop.tick, glide = engine.motion.glideTo.bind(engine.motion);
    engine.motion.glideTo = (value, anchor, now) => this.settings.reducedMotion ? engine.motion.jumpTo(value) : glide(value, anchor, now);
    engine.loop.tick = (now, elapsed) => {
      const speed = this.settings.animationSpeed || 1;
      this.animationAt = this.frameAt ? this.animationAt + (now - this.frameAt) * speed : now;
      this.frameAt = now;
      if (this.destroyed) return "idle";
      const demand = originalTick(this.animationAt, elapsed * speed);
      if (this.hold) this.paintHeld(this.animationAt);
      return demand;
    };
    this.remap();
    this.resize();
    if (typeof ResizeObserver !== "undefined") {
      this.resizeObserver = new ResizeObserver(() => this.resize());
      this.resizeObserver.observe(element);
    }
    element.addEventListener("wheel", this.wheel, { passive: false });
    element.addEventListener("pointerdown", this.pointerDown);
    element.addEventListener("pointermove", this.pointerMove);
    element.addEventListener("pointerup", this.pointerUp);
    element.addEventListener("pointercancel", this.pointerCancel);
    element.addEventListener("keydown", this.keyDown);
    element.tabIndex = 0;
    const visibility = () => applyWindowVisibility(!window.document.hidden);
    window.document.addEventListener("visibilitychange", visibility);
    visibility();
    this.stopVisibility = () => window.document.removeEventListener("visibilitychange", visibility);
  }
  message(text) {
    this.element.replaceChildren();
    const p = window.document.createElement("p");
    p.className = "lyrics-message";
    p.textContent = text;
    this.element.append(p);
  }
  remap() {
    if (!this.renderer || !this.document) return;
    const data = toLinerLyrics(this.document, this.durationMs, this.settings);
    this.mapping = data.sourceMap;
    this.estimatedLines = new Set(data.sourceMap.map((index, source) => data.lyrics[index]?.estimatedTiming ? source : -1).filter((i) => i >= 0));
    this.renderer.setLyrics(data.lyrics);
    this.renderer.scene.shiftMs = (data.nativeShiftMs ?? this.renderer.scene.shiftMs) + (this.settings.fadeLeadMs ?? 120) - 120;
    this.lastDuration = this.durationMs;
  }
  resize() {
    if (this.destroyed || !this.renderer) return;
    const rect = this.element.getBoundingClientRect();
    const width = Math.max(1, Math.round(rect.width || this.element.clientWidth || 600)), height = Math.max(1, Math.round(rect.height || this.element.clientHeight || 500));
    const dpr = Math.min(3, window.devicePixelRatio || 1);
    this.canvas.style.width = this.live.style.width = width + "px";
    this.canvas.style.height = height + "px";
    this.renderer.resize(width, height, dpr);
  }
  wheel = (e) => {
    if (!this.renderer) return;
    e.preventDefault();
    this.manualUntil = performance.now() + 4500;
    this.renderer.wheel(e.deltaY * (e.deltaMode === 1 ? 20 : e.deltaMode === 2 ? this.element.clientHeight || 500 : 1));
    clearTimeout(this.returning);
    this.returning = setTimeout(() => this.renderer?.follow(), 4500);
  };
  pointer = null;
  pointerDown = (e) => {
    if (e.button !== 0) return;
    this.pointer = { x: e.clientX, y: e.clientY, id: e.pointerId, dragged: false };
    this.element.setPointerCapture?.(e.pointerId);
  };
  pointerMove = (e) => {
    const p = this.pointer;
    if (!p || p.id !== e.pointerId || e.pointerType === "mouse") return;
    const delta = p.y - e.clientY;
    if (Math.abs(delta) > 5) {
      p.dragged = true;
      this.wheel({ preventDefault: () => e.preventDefault(), deltaY: delta, deltaMode: 0 });
      p.y = e.clientY;
    }
  };
  pointerUp = (e) => {
    const p = this.pointer;
    this.pointer = null;
    if (!p || p.id !== e.pointerId || p.dragged || !this.renderer) return;
    if (Math.abs(p.y - e.clientY) > 12 || Math.abs(p.x - e.clientX) > 12) return;
    const start = this.renderer.lineStartAt(e.clientY - this.element.getBoundingClientRect().top);
    if (start != null) {
      this.manualUntil = 0;
      this.renderer.follow();
      this.onSeek(start);
    }
  };
  pointerCancel = () => {
    this.pointer = null;
  };
  keyDown = (e) => {
    if (!this.renderer) return;
    if (e.key === "ArrowDown" || e.key === "ArrowUp") {
      e.preventDefault();
      this.wheel({ preventDefault() {
      }, deltaY: e.key === "ArrowDown" ? 90 : -90, deltaMode: 0 });
    } else if (e.key === "Escape") {
      this.renderer.follow();
    }
  };
  update(position, settings = {}, force = false) {
    if (this.destroyed || !this.renderer || !this.document) return;
    this.settings = settings;
    this.position = position;
    const previousPlaying = this.playing;
    this.playing = !!settings.playing;
    if (settings.timelineDurationMs && settings.timelineDurationMs !== this.durationMs) this.durationMs = settings.timelineDurationMs;
    const timingSignature = `${settings.fadeSpeed ?? 1.035}:${settings.fadeLeadMs ?? 120}`;
    if (this.lastDuration !== this.durationMs || timingSignature !== this.timingSignature) {
      this.timingSignature = timingSignature;
      this.remap();
    }
    const appearance = `${settings.lyricsFontSize || 32}`;
    if (appearance !== this.appearance) {
      this.appearance = appearance;
      const engine = this.renderer, size = settings.lyricsFontSize || 32;
      engine.scene.typography = { ...engine.scene.typography, size, lineHeight: size * 1.4 };
      engine.scene.relayout();
      this.resize();
    }
    const silent = !!settings.silenceActive, measured = settings.silencePositionMs, quiet = silent || settings.audioAvailable && Number.isFinite(measured);
    if (quiet) {
      if (this.quietAt == null || Number.isFinite(measured) && measured !== this.measuredAt || force && position < this.quietAt - 850) {
        this.quietAt = Number.isFinite(measured) ? Math.min(position, measured) : position;
        this.measuredAt = measured;
      }
    } else {
      this.quietAt = null;
      this.measuredAt = null;
    }
    this.visualPosition = this.quietAt ?? position;
    this.hold = silent && settings.silenceWordHighlight !== false ? holdTarget(this.document.lines || [], this.visualPosition, this.durationMs, settings.fadeLeadMs ?? 120, settings.fadeSpeed ?? 1.035) : null;
    if (this.hold && this.estimatedLines.has(this.hold.line)) {
      const line = this.renderer.scene.lines[this.mapping[this.hold.line]], tokens = line?.tokens.filter((t) => !t.space) || [];
      const at = this.visualPosition + this.renderer.scene.shiftMs;
      let token = -1;
      for (let i = 0; i < tokens.length; i++) if (tokens[i].startMs <= at) token = i;
      this.hold = token >= 0 ? { line: this.hold.line, token } : null;
    }
    const source = activeLine(this.document.lines || [], this.visualPosition);
    this.element.dataset.activeLine = source < 0 ? "" : String(source);
    this.element.dataset.silenceWord = this.heldText();
    const text = this.hold ? this.heldText() : source >= 0 ? this.document.lines[source].text : "";
    if (this.status.textContent !== text) this.status.textContent = text;
    const key = `${silent}:${this.hold?.line}:${this.hold?.token}:${quiet}:${settings.reducedMotion}:${settings.animationSpeed}`;
    if (force) {
      this.renderer.follow();
      this.renderer.resize(this.renderer.scene.width, this.renderer.scene.height, this.renderer.dpr);
    }
    if (force || previousPlaying !== this.playing || key !== this.stateKey || !this.playing && position !== this.lastPaintPosition) this.renderer.invalidate();
    this.stateKey = key;
    this.lastPaintPosition = position;
  }
  lastPaintPosition = -1;
  heldText() {
    if (!this.hold || !this.renderer) return "";
    const layout = this.renderer.scene.layouts[this.mapping[this.hold.line]];
    return layout?.tokens.filter((p) => !p.token.space)[this.hold.token]?.token.text || "";
  }
  paintHeld(now) {
    const e = this.renderer, source = this.mapping[this.hold.line], layout = e.scene.layouts[source];
    if (!layout) return;
    const placed = layout.tokens.filter((p) => !p.token.space)[this.hold.token];
    if (!placed) return;
    const scene = Object.create(e.scene);
    scene.timed = true;
    drawScene({ ctx: e.ctx, scene, motion: e.motion, fog: e.fog, bitmaps: e.bitmaps, dpr: e.dpr, now, timeMs: -Infinity }, "", e.live);
    e.ctx.setTransform(e.dpr, 0, 0, e.dpr, 0, 0);
    e.ctx.direction = layout.line.rtl ? "rtl" : "ltr";
    e.ctx.font = placed.token.background ? backgroundFont(e.scene.typography) : mainFont(e.scene.typography);
    const top = layout.top - e.motion.position + e.motion.offsetFor(source, now);
    drawToken({ ctx: e.ctx, top, rtl: layout.line.rtl, base: 0.3, remPx: 16, dpr: e.dpr }, placed, { opacity: 1, solid: 1.4, clear: 1.4, glowRem: 0 });
    e.signature = "";
  }
  debugSnapshot() {
    if (!this.renderer) return null;
    const e = this.renderer;
    return { scroll: e.motion.position, offsets: e.scene.layouts.map((_, i) => e.motion.offsetFor(i, this.animationAt)), lineCount: e.scene.lines.length, bitmapCount: e.bitmaps.bitmaps.size, visualPosition: this.visualPosition, hold: this.hold, sourceMap: [...this.mapping] };
  }
  destroy() {
    this.destroyed = true;
    clearTimeout(this.returning);
    this.resizeObserver?.disconnect();
    this.stopVisibility?.();
    if (this.renderer) {
      this.renderer.loop.poke = () => {
      };
      this.renderer.scene.onFontsReady = () => {
      };
      this.renderer.dispose();
    }
    this.element.removeEventListener("wheel", this.wheel);
    this.element.removeEventListener("pointerdown", this.pointerDown);
    this.element.removeEventListener("pointermove", this.pointerMove);
    this.element.removeEventListener("pointerup", this.pointerUp);
    this.element.removeEventListener("pointercancel", this.pointerCancel);
    this.element.removeEventListener("keydown", this.keyDown);
  }
};
export {
  LyricsView,
  toLinerLyrics
};
