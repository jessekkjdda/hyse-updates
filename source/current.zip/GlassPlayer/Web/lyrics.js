// Production view is the upstream Liner Canvas renderer plus the cncx host adapter.
export {LyricsView,toLinerLyrics} from './liner-lyrics.js';
// Compatibility helpers used by silence handling and historical parser tests.
export {activeLine,wordProgress,charWeight,gradientWeights,effectiveDuration,gradientProgress,holdTarget,bezier} from './lyric-timing.js';
