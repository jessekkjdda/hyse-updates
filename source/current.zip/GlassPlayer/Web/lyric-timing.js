export function activeLine(lines,position){let lo=0,hi=lines.length-1,result=-1;while(lo<=hi){let mid=(lo+hi)>>1;if(lines[mid].timeMs<=position){result=mid;lo=mid+1;}else hi=mid-1;}if(result<0)return-1;const line=lines[result];return !line.text?.trim()||(line.endMs!=null&&position>=line.endMs)?-1:result;}
export function wordProgress(word,position){return position<=word.startMs?0:position>=word.endMs?1:(position-word.startMs)/Math.max(1,word.endMs-word.startMs);}
const punctuation=/^[\s\p{P}]$/u,cjk=/^[\p{sc=Han}\p{sc=Hiragana}\p{sc=Katakana}\p{sc=Hangul}]$/u,mark=/^\p{M}$/u;
const cyrillicVowels=new Set('аеёиоуыэюяєіїўѣѵѫѧѩѭ'),latinExtra=new Set(['æ','ø','œ','ı']);
export function charWeight(c,next=''){
  if([',',';',':','、','，','；'].includes(c))return 4.6;
  if(['.','!','?','—','–','-','―','‒','。','！','？','…'].includes(c))return 5.8;
  if(c==='.'&&next==='.')return 6;
  if(punctuation.test(c))return .55;if(cjk.test(c))return 2.8;if(mark.test(c))return 2.6;
  const lower=c.toLowerCase();if(cyrillicVowels.has(lower))return 2.5;
  const base=c.normalize('NFD')[0]?.toLowerCase();return 'aeiouy'.includes(base)||latinExtra.has(lower)?2.5:1;
}
export function gradientWeights(text){const chars=Array.from(text),cum=new Float64Array(chars.length+1);for(let i=0;i<chars.length;i++){let weight=charWeight(chars[i],chars[i+1]||'');if(i>=chars.length-2)weight*=1.18;cum[i+1]=cum[i]+weight;}return{count:chars.length,cum,total:cum[chars.length]};}
export function effectiveDuration(start,end){const raw=Math.max(450,end-start),tail=raw>2200?Math.min(120,raw*.03):0;return Math.max(400,raw-tail);}
export function gradientProgress(weights,position,start,end){
  const tau=Math.min(1,Math.max(0,(position-start)/effectiveDuration(start,end)));if(!weights.count||!weights.total||tau===0||tau===1)return tau;
  const target=tau*weights.total;let low=0,high=weights.count-1,index=0;
  while(low<=high){const mid=(low+high)>>1;if(weights.cum[mid+1]<=target)low=mid+1;else if(weights.cum[mid]>target)high=mid-1;else{index=mid;break;}}
  const width=weights.cum[index+1]-weights.cum[index],fraction=width>0?(target-weights.cum[index])/width:0;return Math.min(1,Math.max(0,(index+fraction)/weights.count));
}
// Fade weights and effective duration above are unchanged from cncx 0.8,
// adapted from Riff (MIT). Playback timing remains the cncx 0.7 clock.
function isNote(text){return /^[♪♫♬♩·\s]+$/u.test(text||'');}
function lineTokens(line){
  const words=line.words?.length&&line.words.map(w=>w.text).join('')===line.text?line.words:null,tokens=[];let base=0;
  for(const part of words||[{text:line.text||''}]){for(const match of part.text.matchAll(/\S+/gu))tokens.push({text:match[0],start:base+match.index,end:base+match.index+match[0].length,startMs:words?part.startMs:null,endMs:words?part.endMs:null});base+=part.text.length;}return tokens;
}
function lineEnd(lines,index,duration){const line=lines[index],end=line.endMs??lines[index+1]?.timeMs??duration;return Number.isFinite(end)&&end>line.timeMs?end:line.timeMs+4000;}
function sourceIndex(lines,position){let a=0,b=lines.length-1,index=-1;while(a<=b){const m=(a+b)>>1;if(lines[m].timeMs<=position){index=m;a=m+1;}else b=m-1;}return index;}
export function holdTarget(lines,position,duration=0,lead=0,speed=1){
  let i=sourceIndex(lines,position);while(i>=0&&(!lines[i].text?.trim()||isNote(lines[i].text)))i--;if(i<0)return null;
  const line=lines[i],tokens=lineTokens(line);if(!tokens.length)return null;
  // The last started word is the one actually being sung. Waiting for its end
  // previously jumped back to an older word during a sustained syllable.
  if(tokens.some(t=>t.startMs!=null)){for(let t=tokens.length-1;t>=0;t--)if(tokens[t].startMs<=position)return{line:i,token:t};return null;}
  const end=lineEnd(lines,i,duration);if(position>=end)return{line:i,token:tokens.length-1};
  const visual=line.timeMs+Math.max(0,position-line.timeMs)*speed+lead,k=gradientProgress(gradientWeights(line.text),visual,line.timeMs,end),painted=k*Array.from(line.text).length;
  for(let t=tokens.length-1;t>=0;t--)if(Array.from(line.text.slice(0,tokens[t].start)).length<painted-1e-6)return{line:i,token:t};return null;
}

// Adapted from Riff customBezierEase (MIT), retained for compatibility checks.
export function bezier(t){if(t<=0)return 0;if(t>=1)return 1;let lo=0,hi=1,s=t;for(let i=0;i<14;i++){s=(lo+hi)/2;let inv=1-s,x=3*inv*inv*s*.786+s*s*s;if(x<t)lo=s;else hi=s;}let inv=1-s;return 3*inv*inv*s*.648+3*inv*s*s*.935+s*s*s;}
