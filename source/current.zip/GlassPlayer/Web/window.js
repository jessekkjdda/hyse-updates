import {on,post,request} from './bridge.js';
export function windowState(state){
  const b=document.querySelector('#window-maximize');if(!b)return;
  const maximized=!!state?.maximized;document.body.classList.toggle('window-maximized',maximized);b.setAttribute('aria-label',maximized?'Restaurar':'Maximizar');b.title=maximized?'Restaurar':'Maximizar';
  b.innerHTML=maximized?'<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M6 3h7v7M3 6h7v7H3Z"/></svg>':'<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="3.5" y="3.5" width="9" height="9" rx="1"/></svg>';
}
const drag=document.querySelector('#window-drag');
drag?.addEventListener('pointerdown',e=>{if(e.button===0&&e.isPrimary!==false){e.preventDefault();post({type:'window-drag'});}});
drag?.addEventListener('dblclick',()=>request('window.maximize').then(windowState).catch(()=>{}));
for(const action of ['minimize','maximize','close'])document.querySelector('#window-'+action)?.addEventListener('click',()=>request('window.'+action).then(state=>{if(action==='maximize')windowState(state);}).catch(()=>{}));
on('window-state',windowState);

for(const grip of document.querySelectorAll('.window-resize'))grip.addEventListener('pointerdown',e=>{if(e.button===0&&e.isPrimary!==false&&!document.body.classList.contains('window-maximized')){e.preventDefault();e.stopPropagation();post({type:'window-resize',edge:grip.dataset.edge});}});
