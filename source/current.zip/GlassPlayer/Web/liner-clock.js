// integration/media-state.ts
var mediaState = { fallbackPosition: 0 };
var usePlayerStore = { getState: () => ({ positionMs: mediaState.fallbackPosition }) };

// vendor/liner/features/player/hooks/mediaClock.ts
var MAX_CARRY_MS = 100;
function audioElement() {
  return document.getElementById("liner-audio");
}
function isRunning(audio2) {
  return !audio2.paused && !audio2.ended && audio2.readyState > 2;
}
function createMediaClock() {
  let anchor = null;
  return {
    timeMs: () => {
      const audio2 = audioElement();
      if (!audio2 || Number.isNaN(audio2.currentTime)) {
        anchor = null;
        return usePlayerStore.getState().positionMs;
      }
      const mediaMs = audio2.currentTime * 1e3;
      const frameMs = performance.now();
      if (!isRunning(audio2) || !anchor || anchor.mediaMs !== mediaMs) {
        anchor = { mediaMs, frameMs, rate: audio2.playbackRate };
        return mediaMs;
      }
      const carried = Math.min(
        Math.max(frameMs - anchor.frameMs, 0),
        MAX_CARRY_MS
      );
      return anchor.mediaMs + carried * anchor.rate;
    },
    playing: () => {
      const audio2 = audioElement();
      return Boolean(audio2 && !audio2.paused);
    }
  };
}

// integration/media-clock.ts
var changedAt = 0;
var coarseSample = false;
var coarseCadence = false;
var sample = null;
var activeUri = "";
var clock = createMediaClock();
var audio = null;
var allowLocal = true;
var playing = false;
function sampled() {
  return allowLocal && !coarseSample && !coarseCadence && sample?.uri === activeUri && performance.now() - sample.at < 1500 ? sample : null;
}
function ensureAudio() {
  if (audio?.isConnected) return;
  audio = document.createElement("audio");
  audio.id = "liner-audio";
  audio.hidden = true;
  audio.muted = true;
  audio.setAttribute("aria-hidden", "true");
  audio.preload = "none";
  Object.defineProperties(audio, {
    currentTime: { get: () => {
      const s = sampled();
      return s ? s.position / 1e3 : Number.NaN;
    } },
    paused: { get: () => !(sampled()?.playing ?? playing) },
    ended: { get: () => {
      const s = sampled();
      return !!s && s.duration > 0 && s.position >= s.duration && !s.playing;
    } },
    readyState: { get: () => sampled() ? 4 : 0 },
    playbackRate: { get: () => 1 }
  });
  (document.getElementById("media-host") || document.body).append(audio);
}
function sampleLinerClock(data) {
  if (!data?.uri || !Number.isFinite(data.position)) return;
  const now = performance.now();
  if (!sample || sample.uri !== data.uri || sample.position !== data.position || !data.playing) {
    coarseCadence = !!sample && sample.uri === data.uri && sample.playing && data.playing && now - changedAt > 100;
    changedAt = now;
    coarseSample = false;
  } else if (data.playing && now - changedAt > 100) coarseSample = true;
  sample = { ...data, position: Math.max(0, data.position), duration: Math.max(0, data.duration || 0), at: now };
}
function seekLinerClock(position, uri, duration, isPlaying) {
  activeUri = uri;
  coarseSample = false;
  coarseCadence = false;
  changedAt = performance.now();
  if (sample?.uri === uri) sample = { uri, position: Math.max(0, position), duration, playing: isPlaying, at: performance.now() };
  else sample = null;
  clock = createMediaClock();
}
function resetLinerClock() {
  sample = null;
  coarseSample = false;
  coarseCadence = false;
  changedAt = 0;
  activeUri = "";
  clock = createMediaClock();
}
function linerPosition(uri, fallback, duration, isPlaying, direct = true) {
  ensureAudio();
  if (uri !== activeUri) {
    activeUri = uri;
    clock = createMediaClock();
  }
  allowLocal = direct;
  playing = isPlaying;
  mediaState.fallbackPosition = fallback;
  const value = clock.timeMs();
  return Math.max(0, Math.min(duration || 0, Number.isFinite(value) ? value : fallback));
}
export {
  linerPosition,
  resetLinerClock,
  sampleLinerClock,
  seekLinerClock
};
