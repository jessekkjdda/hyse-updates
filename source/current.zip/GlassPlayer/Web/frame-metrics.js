// Bounded measurements of the UI animation loop; never changes playback time.
export class FrameMetrics {
  constructor(capacity=240){this.capacity=Math.max(2,Math.min(600,capacity));this.intervals=[];this.work=[];this.last=null;}
  reset(){this.intervals.length=0;this.work.length=0;this.last=null;}
  sample(now,work=0,visible=true){
    if(!visible||!Number.isFinite(now)){this.last=null;return;}
    const previous=this.last;this.last=now;
    if(previous===null||now<=previous)return;
    this.intervals.push(now-previous);this.work.push(Number.isFinite(work)?Math.max(0,work):0);
    if(this.intervals.length>this.capacity){this.intervals.shift();this.work.shift();}
  }
  snapshot(){
    const n=this.intervals.length;if(!n)return null;
    const sorted=[...this.intervals].sort((a,b)=>a-b),p95=sorted[Math.ceil(n*.95)-1];
    return{samples:n,fps:1000/(this.intervals.reduce((a,b)=>a+b,0)/n),p95Ms:p95,
      worstMs:sorted[n-1],slowFrames:this.intervals.filter(ms=>ms>1000/30+1).length,
      workP95Ms:[...this.work].sort((a,b)=>a-b)[Math.ceil(n*.95)-1]};
  }
}
