import {request,post,localEvent} from './bridge.js';
let lastNativeAt=-Infinity,lastNativeKey='';
let player=null,starting=null,generation=0,version=0,sampling=false,previous=null,interval=null;
function state(s){
  if(!s)return;
  const uri=s.track_window?.current_track?.uri||null,now=performance.now();
  if(previous&&previous.uri===uri&&previous.playing&&s.paused&&s.position===0&&previous.duration>0&&previous.position+Math.min(now-previous.at,1200)>=previous.duration-1000)post({type:'sdk-ended',uri});
  previous={uri,playing:!s.paused,position:s.position,duration:s.duration,at:now};
  localEvent('device-state',{source:'Spotify',position:s.position,duration:s.duration,playing:!s.paused,uri:s.track_window?.current_track?.uri});const key=`${uri}:${s.paused}:${s.duration}`;if(key!==lastNativeKey||now-lastNativeAt>=200){lastNativeAt=now;lastNativeKey=key;post({type:'sdk-state',uri,playing:!s.paused,position:Math.round(s.position),duration:Math.round(s.duration)});}
}
async function load(){
  if(window.Spotify?.Player)return;
  await new Promise((resolve,reject)=>{
    const script=document.createElement('script');script.src='https://sdk.scdn.co/spotify-player.js';let timer=setTimeout(()=>reject(new Error('O SDK Spotify não respondeu.')),12000);
    window.onSpotifyWebPlaybackSDKReady=()=>{clearTimeout(timer);resolve();};script.onerror=()=>{clearTimeout(timer);script.remove();reject(new Error('Falha ao carregar o dispositivo Spotify.'));};document.head.append(script);
  });
}
async function start(){
  if(starting)return starting;
  const epoch=generation;
  starting=(async()=>{
    try{
      await load();if(epoch!==generation)return;
      player=new window.Spotify.Player({name:'hyse',volume:.8,getOAuthToken:callback=>request('sdk.token').then(token=>{if(epoch===generation)callback(token);}).catch(error=>post({type:'sdk-error',error:error.message}))});
      player.addListener('ready',({device_id})=>{if(epoch===generation)post({type:'sdk-ready',device:device_id});});
      player.addListener('not_ready',()=>{if(epoch===generation){starting=null;post({type:'sdk-unavailable'});}});
      player.addListener('player_state_changed',s=>{if(epoch!==generation)return;version++;state(s);});
      for(const kind of ['initialization_error','authentication_error','account_error','playback_error'])player.addListener(kind,({message})=>{if(epoch===generation)post({type:'sdk-error',error:message});});
      if(!await player.connect())throw new Error('O dispositivo Spotify não conectou.');
      clearInterval(interval);interval=setInterval(async()=>{if(!player||sampling||epoch!==generation)return;sampling=true;let v=version;try{let s=await player.getCurrentState();if(v===version&&epoch===generation)state(s);}catch{}finally{sampling=false;}},50);
    }catch(error){if(epoch===generation){starting=null;post({type:'sdk-error',error:error.message});}}
  })();return starting;
}
function reset(){lastNativeAt=-Infinity;lastNativeKey='';generation++;version++;clearInterval(interval);player?.disconnect();player=null;starting=null;previous=null;sampling=false;}
async function command({id,method,value}){
  version++;if(method==='seek')previous=null;
  try{if(!player)throw new Error('Dispositivo Spotify desconectado.');if(!['pause','resume','seek','setVolume'].includes(method))throw new Error('Comando inválido.');await(value==null?player[method]():player[method](value));version++;post({type:'sdk-command',id,ok:true});}
  catch(error){version++;post({type:'sdk-command',id,ok:false,error:error.message});}
}
window.cncxSdk={start,reset,command};window.addEventListener('beforeunload',reset);
