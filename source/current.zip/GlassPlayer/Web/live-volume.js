// One audio command at a time; the latest drag position replaces queued samples.
// Visual slider movement remains immediate and independent of network latency.
export class LiveVolume {
  constructor(send,onError,interval=40){this.send=send;this.onError=onError;this.interval=interval;this.pending=null;this.running=null;this.nextAt=0;}
  set(value,commit=false){
    if(!Number.isFinite(value))return;
    this.pending={volume:Math.max(0,Math.min(1,value)),commit};
    if(!this.running)this.running=Promise.resolve().then(()=>this.drain()).finally(()=>{this.running=null;if(this.pending)this.set(this.pending.volume,this.pending.commit);});
    return this.running;
  }
  async drain(){
    while(this.pending){
      const wait=this.nextAt-Date.now();if(wait>0)await new Promise(resolve=>setTimeout(resolve,wait));
      const value=this.pending;this.pending=null;
      this.nextAt=Date.now()+this.interval;
      try{await this.send(value);}catch(error){this.onError?.(error);}
    }
  }
  get whenIdle(){return(async()=>{while(this.running)await this.running;})();}
}
