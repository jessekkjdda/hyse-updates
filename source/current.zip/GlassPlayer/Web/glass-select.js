let sequence=0;
const instances=new WeakMap();

// Keep the real select for FormData, validation and the existing native bridge.
// The popup is rendered by the app so Windows never supplies a white option menu.
export function enhanceSelects(container=document){
  for(const select of container.querySelectorAll('select')){
    if(instances.has(select))continue;
    const selectedValue=select.value;
    const wrapper=document.createElement('div'),button=document.createElement('button');
    wrapper.className='glass-select';button.type='button';button.className='glass-select-trigger';
    button.setAttribute('role','combobox');button.setAttribute('aria-haspopup','listbox');
    button.setAttribute('aria-expanded','false');
    const label=select.getAttribute('aria-label')||select.closest('label')?.firstChild?.textContent?.trim()||'Selecionar';
    button.setAttribute('aria-label',label);
    const popup=document.createElement('div');popup.className='glass-select-popup';popup.id=`glass-options-${++sequence}`;
    popup.setAttribute('role','listbox');popup.setAttribute('aria-label',label);popup.hidden=true;
    button.setAttribute('aria-controls',popup.id);
    select.before(wrapper);wrapper.append(button,select);select.hidden=true;select.tabIndex=-1;select.value=selectedValue;
    let active=0,opened=false,topLayer=false,search='',searchAt=0;
    const available=()=>[...select.options].map((o,i)=>o.disabled?-1:i).filter(i=>i>=0);
    function sync(){button.textContent=select.options[select.selectedIndex]?.textContent||label;button.disabled=select.disabled;}
    function position(){
      const rect=button.getBoundingClientRect(),height=Math.min(popup.scrollHeight||264,264),vw=window.innerWidth,vh=window.innerHeight;
      const width=Math.min(Math.max(rect.width,190),Math.max(100,vw-24));
      let top=rect.bottom+7;if(top+height>vh-12)top=Math.max(12,rect.top-height-7);
      let left=Math.max(12,Math.min(rect.left,vw-width-12));
      // A modal dialog establishes a containing block for its glass backdrop.
      const dialog=select.closest('dialog');if(dialog&&!topLayer){const bounds=dialog.getBoundingClientRect();left-=bounds.left;top-=bounds.top;}
      popup.style.left=`${left}px`;popup.style.top=`${top}px`;popup.style.width=`${width}px`;
    }
    function paint(){for(const option of popup.children){const i=+option.dataset.index;option.setAttribute('aria-selected',String(i===select.selectedIndex));option.classList.toggle('active',i===active);}button.setAttribute('aria-activedescendant',`${popup.id}-${active}`);popup.querySelector('.active')?.scrollIntoView?.({block:'nearest'});}
    function close(focus=false){
      if(!opened)return;opened=false;button.setAttribute('aria-expanded','false');button.removeAttribute('aria-activedescendant');
      if(typeof popup.hidePopover==='function'&&topLayer)popup.hidePopover();
      topLayer=false;
      popup.hidden=true;popup.remove();document.removeEventListener('pointerdown',outside,true);document.removeEventListener('scroll',reposition,true);window.removeEventListener('resize',reposition);if(focus&&button.isConnected)button.focus();
    }
    function choose(index){if(!select.options[index]||select.options[index].disabled)return;select.selectedIndex=index;sync();close(true);select.dispatchEvent(new Event('input',{bubbles:true}));select.dispatchEvent(new Event('change',{bubbles:true}));}
    function open(){
      if(opened||select.disabled)return;opened=true;active=available().includes(select.selectedIndex)?select.selectedIndex:available()[0];popup.replaceChildren();
      for(const [i,option] of [...select.options].entries()){
        const row=document.createElement('button');row.type='button';row.className='glass-select-option';row.dataset.index=String(i);row.id=`${popup.id}-${i}`;row.setAttribute('role','option');row.disabled=option.disabled;row.tabIndex=-1;row.textContent=option.textContent;row.onclick=()=>choose(i);popup.append(row);
      }
      (select.closest('dialog')||document.body).append(popup);popup.hidden=false;
      // Popover support avoids clipping by page scroll containers; fallback stays functional.
      if(typeof popup.showPopover==='function'){popup.setAttribute('popover','manual');try{popup.showPopover();topLayer=true;}catch{popup.removeAttribute('popover');}}
      button.setAttribute('aria-expanded','true');position();paint();button.focus();
      document.addEventListener('pointerdown',outside,true);document.addEventListener('scroll',reposition,true);window.addEventListener('resize',reposition);
    }
    function outside(e){if(!wrapper.contains(e.target)&&!popup.contains(e.target))close();}
    function reposition(){if(!button.isConnected)close();else position();}
    button.onclick=()=>opened?close():open();
    button.onkeydown=e=>{
      const choices=available();if(!choices.length)return;
      if(e.key==='Escape'&&opened){e.preventDefault();e.stopPropagation();close(true);return;}
      if(e.key==='Tab'){close();return;}
      if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){
        e.preventDefault();if(!opened)open();const index=choices.indexOf(active);
        active=e.key==='Home'?choices[0]:e.key==='End'?choices.at(-1):choices[(index+(e.key==='ArrowDown'?1:-1)+choices.length)%choices.length];paint();return;
      }
      if(e.key==='Enter'||e.key===' '){e.preventDefault();if(opened)choose(active);else open();return;}
      if(e.key.length===1&&!e.ctrlKey&&!e.metaKey){const now=performance.now();search=now-searchAt>700?e.key:search+e.key;searchAt=now;if(!opened)open();const found=choices.find(i=>select.options[i].textContent.toLocaleLowerCase().startsWith(search.toLocaleLowerCase()));if(found!=null){active=found;paint();}}
    };
    select.addEventListener('change',sync);select.addEventListener('input',sync);sync();
    instances.set(select,{destroy(){close();select.removeEventListener('change',sync);select.removeEventListener('input',sync);instances.delete(select);}});
  }
}

export function disposeSelects(container){for(const select of container.querySelectorAll('select'))instances.get(select)?.destroy();}
