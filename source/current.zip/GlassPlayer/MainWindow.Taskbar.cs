using System.Text.Json;
using System.Windows.Media;
using System.Windows.Shell;
using GlassPlayer.Core;

namespace GlassPlayer;

public partial class MainWindow
{
    ThumbButtonInfo? taskPrevious,taskToggle,taskNext;
    TaskbarPlayback? taskbarState;
    bool taskbarBusy;
    static readonly ImageSource taskPlayImage=TaskImage("M5,3 L13,8 5,13 Z");
    static readonly ImageSource taskPauseImage=TaskImage("M4,3 H7 V13 H4 Z M9,3 H12 V13 H9 Z");
    static ImageSource TaskImage(string path)
    {
        var group=new DrawingGroup();group.Children.Add(new GeometryDrawing(Brushes.Transparent,null,new RectangleGeometry(new(0,0,16,16))));
        group.Children.Add(new GeometryDrawing(Brushes.White,null,Geometry.Parse(path)));var image=new DrawingImage(group);image.Freeze();return image;
    }
    void InitializeTaskbar()
    {
        taskPrevious=new(){Description="Anterior",DismissWhenClicked=false,ImageSource=TaskImage("M3,3 H5 V13 H3 Z M13,3 L5,8 13,13 Z")};
        taskToggle=new(){Description="Reproduzir",DismissWhenClicked=false,ImageSource=taskPlayImage};
        taskNext=new(){Description="Próxima",DismissWhenClicked=false,ImageSource=TaskImage("M11,3 H13 V13 H11 Z M3,3 L11,8 3,13 Z")};
        taskPrevious.Click+=async(_,_)=>await TaskbarActionAsync("queue.previous");taskToggle.Click+=async(_,_)=>await TaskbarActionAsync("playback.toggle");taskNext.Click+=async(_,_)=>await TaskbarActionAsync("queue.next");
        TaskbarItemInfo=new(){Description="hyse",ThumbButtonInfos=new(){taskPrevious,taskToggle,taskNext}};UpdateTaskbar();
    }
    void UpdateTaskbar()
    {
        if(closed||taskToggle==null||TaskbarItemInfo==null)return;
        var next=TaskbarPlayback.Create(queue.Current,clock.Playing,queue.HasPrevious||clock.Position>3000||queue.Repeat==RepeatMode.All,queue.RemainingCount>0||queue.Repeat==RepeatMode.All||radioEnabled,taskbarBusy);
        if(next==taskbarState)return;taskbarState=next;TaskbarItemInfo.Description=next.Description;taskToggle.Description=next.ToggleLabel;taskToggle.ImageSource=next.Playing?taskPauseImage:taskPlayImage;
        taskPrevious!.IsEnabled=next.CanPrevious;taskToggle.IsEnabled=next.CanToggle;taskNext!.IsEnabled=next.CanNext;
    }
    async Task TaskbarActionAsync(string action)
    {
        if(closed||taskbarBusy)return;taskbarBusy=true;UpdateTaskbar();
        try{await DispatchAsync(action,JsonSerializer.SerializeToElement(new{}),"taskbar",lifetime.Token);}
        catch(OperationCanceledException){}catch(Exception ex){Emit("error",ex.Message);}finally{taskbarBusy=false;UpdateTaskbar();}
    }
}
