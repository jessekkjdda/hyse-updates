using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Web.WebView2.Wpf;
using GlassPlayer.Core;
namespace GlassPlayer;

// The SDK lives in the visible frontend. Resetting the device never reloads the UI.
sealed class WebPlayer(WebView2 web) : IDisposable
{
    TaskCompletionSource<string?> ready=NewReady();
    readonly PlaybackClock clock=new();
    readonly Dictionary<string,TaskCompletionSource<bool>> commands=new();
    bool disposed,started;long lastRaw=-1;double rawAt;
    public bool FreshPosition=>System.Diagnostics.Stopwatch.GetTimestamp()*1000d/System.Diagnostics.Stopwatch.Frequency-rawAt<900;
    public string? DeviceId{get;private set;}
    public event Action<string>? Ended;
    static TaskCompletionSource<string?> NewReady()=>new(TaskCreationOptions.RunContinuationsAsynchronously);
    public async Task StartAsync(){if(disposed||started)return;started=true;await web.CoreWebView2.ExecuteScriptAsync("window.cncxSdk.start()");}
    public async Task<string?> WaitReadyAsync(TimeSpan timeout,CancellationToken ct=default){await StartAsync();try{return await ready.Task.WaitAsync(timeout,ct);}catch(TimeoutException){return null;}}
    public void Reset(){started=false;DeviceId=null;clock.Clear();ready.TrySetResult(null);ready=NewReady();foreach(var c in commands.Values)c.TrySetCanceled();commands.Clear();if(!disposed&&web.CoreWebView2!=null)_=web.CoreWebView2.ExecuteScriptAsync("window.cncxSdk.reset()");}
    public void Message(JsonElement m)
    {
        switch(m.GetProperty("type").GetString())
        {
            case "sdk-ready":DeviceId=m.GetProperty("device").GetString();ready.TrySetResult(DeviceId);break;
            case "sdk-unavailable":DeviceId=null;started=false;ready.TrySetResult(null);ready=NewReady();break;
            case "sdk-error":started=false;ready.TrySetResult(null);ready=NewReady();break;
            case "sdk-command":if(commands.TryGetValue(m.GetProperty("id").GetString()??"",out var c)){if(m.GetProperty("ok").GetBoolean())c.TrySetResult(true);else c.TrySetException(new Exception(m.GetProperty("error").GetString()));}break;
            case "sdk-state":var raw=m.GetProperty("position").GetInt32();if(lastRaw!=raw){lastRaw=raw;rawAt=System.Diagnostics.Stopwatch.GetTimestamp()*1000d/System.Diagnostics.Stopwatch.Frequency;}clock.Update(m.GetProperty("position").GetInt32(),m.GetProperty("duration").GetInt32(),m.GetProperty("playing").GetBoolean(),m.GetProperty("uri").GetString());break;
            case "sdk-ended":Ended?.Invoke(m.GetProperty("uri").GetString()??"");break;
        }
    }
    public async Task CallAsync(string command,CancellationToken ct=default)
    {
        var match=Regex.Match(command,@"^(pause|resume|seek|setVolume)\(([0-9.]*)\)$");if(!match.Success)throw new ArgumentException("Comando de reprodução inválido.");
        var id=Guid.NewGuid().ToString("N");var completion=new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);commands[id]=completion;
        try
        {
            var argument=match.Groups[2].Value;double? value=argument.Length==0?null:double.Parse(argument,System.Globalization.CultureInfo.InvariantCulture);
            await web.CoreWebView2.ExecuteScriptAsync("window.cncxSdk.command("+JsonSerializer.Serialize(new{id,method=match.Groups[1].Value,value})+")");
            await completion.Task.WaitAsync(TimeSpan.FromSeconds(8),ct);
            if(command=="pause()")clock.SetPlaying(false);else if(command=="resume()")clock.SetPlaying(true);else if(match.Groups[1].Value=="seek")clock.Seek((int)value!);
        }
        finally{commands.Remove(id);}
    }
    public void ClearState()=>clock.Clear();
    public(bool Playing,int Progress,int Duration,string? Uri)? Current()=>clock.Uri==null?null:(clock.Playing,(int)clock.Position,(int)clock.Duration,clock.Uri);
    public void Dispose(){disposed=true;foreach(var c in commands.Values)c.TrySetCanceled();commands.Clear();ready.TrySetResult(null);}
}
