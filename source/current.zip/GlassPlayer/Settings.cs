using System.IO;
using System.Text.Json;
using GlassPlayer.Core;
namespace GlassPlayer;

class AppSettings
{
    public bool Autoplay { get; set; } = true;
    public bool LaunchSpotify { get; set; } = true;
    public bool AmbientGlow { get; set; } = true;
    public bool RememberVolume { get; set; } = true;
    public double Volume { get; set; } = .8;
    public bool ReducedMotion { get; set; }
    public bool LowEffects { get; set; }
    public bool AlwaysOnTop { get; set; }
    public bool GlobalHotkeys { get; set; } = true;
    public bool Shuffle { get; set; }
    public RepeatMode Repeat { get; set; }
    public string Theme { get; set; } = "Chromium";
    public double GlassOpacity { get; set; } = .16;
    public double CornerRadius { get; set; } = 34;
    public double ArtworkRadius { get; set; } = 34;
    public double ArtworkSize { get; set; } = 260;
    public string? BackgroundImage { get; set; }
    public double WindowWidth { get; set; } = 1060;
    public double WindowHeight { get; set; } = 720;
    public string? SpotifyClientId { get; set; }
    public bool PreferSpotifyApp { get; set; }
    public bool DiscordEnabled {get;set;}=true;
    public bool DiscordArtwork {get;set;}=true;
    public bool DiscordTime {get;set;}=true;
    public bool DiscordButton {get;set;}=true;
    public bool DiscordHidePaused {get;set;}
    public string DiscordText {get;set;}="track";
    public bool AutomaticUpdates {get;set;}=true;
    public bool LyricsOpen { get; set; }
    public double LyricsFontSize { get; set; } = 32;
    public int LyricsOffsetMs { get; set; }
    public int UiVersion { get; set; } = 6;
    public string ArtworkShape {get;set;}="rounded";
    public double ArtworkScale {get;set;}=1;
    public bool ArtworkMotion {get;set;}=true;
    public bool AnimatedBackground {get;set;}=true;
    public double BackgroundMotion {get;set;}=1;
    public double FadeSpeed {get;set;}=1.035;
    public int FadeLeadMs {get;set;}=120;
    public bool PreferWordLyrics {get;set;}=true;
    public bool SilenceWordHighlight {get;set;}=true;
    public double AnimationSpeed {get;set;}=1;
    public double LyricsTransparency {get;set;}=.35;
    public double LyricsBlur {get;set;}=35;
    public double LyricsDepth {get;set;}=.5;
    public bool LyricsAlbumBackground {get;set;}=true;
    public string? LyricsBackgroundImage {get;set;}
    public Dictionary<string,int> TrackOffsets {get;set;}=new();
    public string LyricsMode { get; set; } = "Fade";
    public int LyricsFadeMs { get; set; } = 180;
    public static readonly string DirectoryPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "cncx");
    static readonly string FilePath = Path.Combine(DirectoryPath, "settings.json");
    public static AppSettings Load()
    {
        try { var settings = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath)) ?? new(); return settings; }
        catch { return new(); }
    }
    public void Save()
    {
        Directory.CreateDirectory(DirectoryPath);
        var tmp = FilePath + ".tmp";
        File.WriteAllText(tmp, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
        File.Move(tmp, FilePath, true);
    }
}
