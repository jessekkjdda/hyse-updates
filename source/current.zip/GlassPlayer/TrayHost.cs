using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Interop;
using System.Windows.Media;
namespace GlassPlayer;

// Windows notification area, with a stable owner window and Explorer restart recovery.
sealed class TrayHost:IDisposable
{
    const uint Callback=0x8000+71;
    readonly Window owner;
    readonly Action restore,exit;
    readonly HwndSource source;
    readonly nint icon;
    readonly bool ownsIcon;
    readonly uint taskbarCreated=RegisterWindowMessage("TaskbarCreated");
    readonly ContextMenu menu;
    NotifyIconData data;
    bool disposed;
    public bool Available{get;private set;}
    public TrayHost(Window owner,Action restore,Action exit)
    {
        this.owner=owner;this.restore=restore;this.exit=exit;
        var hwnd=new WindowInteropHelper(owner).Handle;source=HwndSource.FromHwnd(hwnd);
        icon=LoadImage(0,System.IO.Path.Combine(AppContext.BaseDirectory,"hyse.ico"),1,32,32,0x10);
        ownsIcon=icon!=0;if(icon==0)icon=LoadIcon(0,(nint)32512);
        data=new(){Size=(uint)Marshal.SizeOf<NotifyIconData>(),Window=hwnd,Id=1,Flags=1|2|4|128,Message=Callback,Icon=icon,Tip="hyse",Info="",InfoTitle=""};
        menu=new ContextMenu{Foreground=Brushes.White,BorderBrush=new SolidColorBrush(Color.FromArgb(45,220,215,230)),BorderThickness=new Thickness(1),Padding=new Thickness(5)};
        menu.Resources[SystemColors.HighlightBrushKey]=new SolidColorBrush(Color.FromRgb(62,58,68));
        var open=new MenuItem{Header="Abrir hyse",Padding=new Thickness(12,7,16,7)};
        var leave=new MenuItem{Header="Sair",Padding=new Thickness(12,7,16,7)};
        open.Click+=(_,_)=>restore();leave.Click+=(_,_)=>exit();menu.Items.Add(open);menu.Items.Add(leave);
        menu.Closed+=(_,_)=>{if(!disposed)ShellNotifyIcon(3,ref data);};
        source.AddHook(Hook);Add();
    }
    void Add()
    {
        if(disposed)return;Available=ShellNotifyIcon(0,ref data);
        if(Available){data.Version=4;ShellNotifyIcon(4,ref data);}
    }
    public bool EnsureAvailable(){if(!Available)Add();return Available;}
    nint Hook(nint hwnd,int message,nint wParam,nint lParam,ref bool handled)
    {
        if((uint)message==taskbarCreated){Available=false;Add();}
        if((uint)message==DesktopInstance.ActivateMessage){owner.Dispatcher.BeginInvoke(restore);handled=true;}
        if((uint)message==DesktopInstance.ExitMessage){owner.Dispatcher.BeginInvoke(((MainWindow)owner).ExitForInstaller);handled=true;}
        if((uint)message==Callback)
        {
            int action=(int)((long)lParam&0xffff);
            if(action is 0x400 or 0x401 or 0x202)restore();
            else if(action==0x7b)
            {
                SetForegroundWindow(hwnd);menu.Background=owner.Background??new SolidColorBrush(Color.FromRgb(29,27,33));
                menu.Placement=PlacementMode.MousePoint;menu.IsOpen=true;
            }
            handled=true;
        }
        return 0;
    }
    public void Dispose(){if(disposed)return;disposed=true;menu.IsOpen=false;ShellNotifyIcon(2,ref data);Available=false;source.RemoveHook(Hook);if(ownsIcon)DestroyIcon(icon);}
    [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)]
    struct NotifyIconData
    {
        public uint Size;public nint Window;public uint Id,Flags,Message;public nint Icon;
        [MarshalAs(UnmanagedType.ByValTStr,SizeConst=128)]public string Tip;
        public uint State,StateMask;
        [MarshalAs(UnmanagedType.ByValTStr,SizeConst=256)]public string Info;
        public uint Version;
        [MarshalAs(UnmanagedType.ByValTStr,SizeConst=64)]public string InfoTitle;
        public uint InfoFlags;public Guid Guid;public nint BalloonIcon;
    }
    [DllImport("shell32.dll",EntryPoint="Shell_NotifyIconW",CharSet=CharSet.Unicode)]static extern bool ShellNotifyIcon(uint message,ref NotifyIconData data);
    [DllImport("user32.dll",EntryPoint="RegisterWindowMessageW",CharSet=CharSet.Unicode)]static extern uint RegisterWindowMessage(string name);
    [DllImport("user32.dll")]static extern bool SetForegroundWindow(nint window);
    [DllImport("user32.dll",EntryPoint="LoadImageW",CharSet=CharSet.Unicode)]static extern nint LoadImage(nint instance,string name,uint type,int width,int height,uint flags);
    [DllImport("user32.dll",EntryPoint="LoadIconW")]static extern nint LoadIcon(nint instance,nint resource);
    [DllImport("user32.dll")]static extern bool DestroyIcon(nint icon);
}
