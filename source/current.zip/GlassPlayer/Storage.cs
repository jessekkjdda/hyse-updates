using System.IO;
using System.Text.Json;
namespace GlassPlayer;

static class SessionStore
{
    record Session(List<Track> Queue, int Index);
    static string FilePath => Path.Combine(AppSettings.DirectoryPath, "queue.json");
    public static (List<Track> Queue, int Index) Load()
    {
        try
        {
            if (new FileInfo(FilePath).Length > 8 * 1024 * 1024) return (new(), -1);
            var s = JsonSerializer.Deserialize<Session>(File.ReadAllText(FilePath));
            if (s is null || s.Queue.Count > 10000) return (new(), -1);
            var valid = s.Queue.Where(t => GlassPlayer.Core.MediaIdentity.Supported(t)).ToList();
            return (valid, Math.Clamp(s.Index, 0, Math.Max(0, valid.Count - 1)));
        }
        catch { return (new(), -1); }
    }
    public static void Save(IEnumerable<Track> queue, int index)
    {
        Directory.CreateDirectory(AppSettings.DirectoryPath);
        var temporary = FilePath + ".tmp";
        File.WriteAllText(temporary, JsonSerializer.Serialize(new Session(queue.ToList(), index)));
        File.Move(temporary, FilePath, true);
    }
}
