using System.IO;
using System.Text.Json;
namespace GlassPlayer;

static class SessionStore
{
    static string FilePath => Path.Combine(AppSettings.DirectoryPath, "queue.json");
    public static (List<Track> Queue, int Index, bool Radio) Load()
    {
        try
        {
            if (new FileInfo(FilePath).Length > 8 * 1024 * 1024) return (new(), -1, false);
            var s = JsonSerializer.Deserialize<Core.QueueSession>(File.ReadAllText(FilePath));
            if (s is null || s.Queue.Count > 10000) return (new(), -1, false);
            var valid = s.Queue.Where(t => GlassPlayer.Core.MediaIdentity.Supported(t)).ToList();
            return (valid, Math.Clamp(s.Index, 0, Math.Max(0, valid.Count - 1)), s.Radio && valid.Count > 0);
        }
        catch { return (new(), -1, false); }
    }
    public static void Save(IEnumerable<Track> queue, int index, bool radio=false)
    {
        Directory.CreateDirectory(AppSettings.DirectoryPath);
        var temporary = FilePath + ".tmp";
        File.WriteAllText(temporary, JsonSerializer.Serialize(new Core.QueueSession(queue.ToList(), index, radio)));
        File.Move(temporary, FilePath, true);
    }
}
