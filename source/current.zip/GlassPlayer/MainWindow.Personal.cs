using System.IO;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using GlassPlayer.Core;
namespace GlassPlayer;
public partial class MainWindow
{
    readonly PersonalProfileStore personal=new(Path.Combine(AppSettings.DirectoryPath,"profile"));
    object PersonalView(){var p=personal.Load();return new{name=p.Name,bio=p.Bio,avatar=personal.Image("avatar"),banner=personal.Image("banner")};}
    object PickPersonalImage(string kind)
    {
        if(kind is not("avatar" or "banner"))throw new ArgumentException("Imagem de perfil inválida.");
        var picker=new OpenFileDialog{Filter="Imagem|*.png;*.jpg;*.jpeg;*.webp",Title=kind=="avatar"?"Foto de perfil":"Banner do perfil"};if(picker.ShowDialog(this)!=true)return PersonalView();
        if(new FileInfo(picker.FileName).Length>10*1024*1024)throw new ArgumentException("A imagem deve ter até 10 MB.");
        try
        {
            using var input=File.OpenRead(picker.FileName);var metadata=BitmapDecoder.Create(input,BitmapCreateOptions.DelayCreation,BitmapCacheOption.None);if(metadata.Frames.Count==0||(long)metadata.Frames[0].PixelWidth*metadata.Frames[0].PixelHeight>60000000)throw new ArgumentException("A imagem excede o limite de 60 megapixels.");input.Position=0;var image=new BitmapImage();image.BeginInit();image.CacheOption=BitmapCacheOption.OnLoad;var frame=metadata.Frames[0];double scale=Math.Min(1,Math.Min((kind=="avatar"?512d:1600d)/frame.PixelWidth,(kind=="avatar"?512d:900d)/frame.PixelHeight));image.DecodePixelWidth=Math.Max(1,(int)Math.Round(frame.PixelWidth*scale));image.StreamSource=input;image.EndInit();image.Freeze();
            if(image.PixelHeight>8000)throw new ArgumentException("Escolha uma imagem com proporção menos alongada.");
            var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(image));using var output=new MemoryStream();encoder.Save(output);personal.SetImage(kind,output.ToArray());return PersonalView();
        }
        catch(ArgumentException){throw;}catch{throw new ArgumentException("Essa imagem não pôde ser aberta. Use PNG ou JPG.");}
    }
    object AppInformation()=>new{version="0.16.1",system="Windows x64",lyrics="LRCLIB · AMLL TTML",runtime=Environment.Version.ToString(),localAudio=levelMonitor?.Current.Available==true};
    string AppLicenses()
    {
        var files=new[]{"NOTICE.md","LICENSE","licenses/Riff-LICENSE.txt","licenses/NAudio-LICENSE.txt","licenses/YamlDotNet-LICENSE.txt","licenses/Inter-OFL.txt","licenses/Montserrat-OFL.txt","licenses/Liner-LICENSE.txt","licenses/Spicy-Lyrics-LICENSE.txt","licenses/fast-xml-parser-LICENSE.txt","licenses/react-LICENSE.txt","licenses/react-dom-LICENSE.txt","licenses/scheduler-LICENSE.txt","licenses/framer-motion-LICENSE.txt","licenses/motion-dom-LICENSE.txt","licenses/motion-utils-LICENSE.txt"};
        return string.Join("\n\n",files.Select(f=>{var p=Path.Combine(AppContext.BaseDirectory,f);return File.Exists(p)?f+"\n\n"+File.ReadAllText(p):"";}));
    }
}
