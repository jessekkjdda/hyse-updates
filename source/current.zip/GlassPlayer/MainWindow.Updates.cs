using System.Diagnostics;
using System.IO;
using System.Text.Json;
using GlassPlayer.Core;
using Microsoft.Win32;

namespace GlassPlayer;

public partial class MainWindow
{
    const string CurrentVersion="0.14.0";
    readonly UpdateClient updates=new();
    readonly string updateCache=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"hyse","updates");
    PreparedUpdate? preparedUpdate;
    bool updateBusy,restartForUpdate,installerExit;
    string updateStage="idle",updateMessage="Ainda não verificado.";
    string? updateVersion;
    int updatePercent;
    bool IsInstalled()
    {
        try{return Registry.GetValue(@"HKEY_CURRENT_USER\Software\hyse","InstallDir",null) is string dir&&UpdateHandoff.SameDirectory(dir,AppContext.BaseDirectory);}
        catch{return false;}
    }
    object UpdateStatus()=>new{state=updateStage,message=updateMessage,version=updateVersion,percent=updatePercent,enabled=settings.AutomaticUpdates,installed=IsInstalled(),busy=updateBusy,ready=preparedUpdate!=null};
    void SetUpdateStatus(string stage,string message,string? version=null,int percent=0)
    {
        if(closed)return;updateStage=stage;updateMessage=message;updateVersion=version;updatePercent=percent;Emit("update",UpdateStatus());
    }
    async Task WatchUpdatesAsync()
    {
        try
        {
            string result=Path.Combine(updateCache,"last-result.json");
            if(File.Exists(result)&&new FileInfo(result).Length<=8192)
            {
                using var json=JsonDocument.Parse(await File.ReadAllTextAsync(result,lifetime.Token));
                if(json.RootElement.TryGetProperty("ok",out var ok)&&ok.ValueKind==JsonValueKind.False)SetUpdateStatus("error","A última atualização não foi concluída. Tente novamente em App info.");
            }
            await Task.Delay(TimeSpan.FromSeconds(15),lifetime.Token);
            using var timer=new PeriodicTimer(TimeSpan.FromHours(6));
            do{if(settings.AutomaticUpdates&&IsInstalled())await CheckUpdatesAsync();}while(await timer.WaitForNextTickAsync(lifetime.Token));
        }
        catch(OperationCanceledException){}catch(Exception){if(!closed)SetUpdateStatus("error","Não foi possível verificar atualizações. Tente novamente em App info.");}
    }
    object StartUpdateCheck()
    {
        if(!updateBusy)_ = CheckUpdatesAsync();return UpdateStatus();
    }
    async Task CheckUpdatesAsync()
    {
        if(updateBusy||closed)return;
        if(!IsInstalled()){SetUpdateStatus("portable","Instale o hyse para ativar as atualizações automáticas.");return;}
        updateBusy=true;SetUpdateStatus("checking","Verificando atualizações…");
        try
        {
            var ready=await updates.CheckAndDownloadAsync(CurrentVersion,updateCache,(version,percent)=>Dispatcher.BeginInvoke(()=>SetUpdateStatus("downloading",$"Baixando {version} · {percent}%",version,percent)),lifetime.Token);
            preparedUpdate=ready;
            SetUpdateStatus(ready==null?"current":"ready",ready==null?"Você está na versão mais recente.":"Atualização pronta. Será instalada ao sair.",ready?.Manifest.Version,ready==null?0:100);
        }
        catch(OperationCanceledException){if(!closed)SetUpdateStatus("idle","Verificação interrompida.");}
        catch(Exception){SetUpdateStatus(preparedUpdate!=null?"ready":"error",preparedUpdate!=null?"Atualização pronta. Será instalada ao sair.":"Falha ao verificar ou baixar. Sua instalação atual foi mantida.",preparedUpdate?.Manifest.Version);}
        finally{updateBusy=false;if(!closed)Emit("update",UpdateStatus());}
    }
    bool StartUpdateHelper(bool restart)
    {
        if(preparedUpdate==null||!IsInstalled())return false;
        try
        {
            var dir=preparedUpdate.DirectoryPath;string helper=Path.Combine(dir,"hyse-update.exe");
            File.Copy(Path.Combine(AppContext.BaseDirectory,"hyse-update.exe"),helper,true);
            using var process=Process.GetCurrentProcess();
            UpdateHandoff.WritePlan(dir,new(process.Id,process.StartTime.ToUniversalTime().Ticks,Path.TrimEndingDirectorySeparator(AppContext.BaseDirectory),CurrentVersion,restart));
            using var helperProcess=Process.Start(new ProcessStartInfo(helper){UseShellExecute=false,WorkingDirectory=dir,CreateNoWindow=true})??throw new IOException("O atualizador não iniciou.");return true;
        }
        catch{SetUpdateStatus("error","O atualizador não iniciou. Tente novamente após abrir o aplicativo.");return false;}
    }
    bool RestartToUpdate()
    {
        if(preparedUpdate==null||updateBusy)return false;
        // Start before closing, so launch errors leave the player usable.
        if(!StartUpdateHelper(true))return false;
        restartForUpdate=true;ExitApplication();return true;
    }
}
