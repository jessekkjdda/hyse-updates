using System.Runtime.InteropServices;
namespace GlassPlayer;

static class DesktopInstance
{
    public const string MutexName="Local\\hyse.desktop";
    public static readonly uint ActivateMessage=RegisterWindowMessage("hyse.desktop.activate");
    public static readonly uint ExitMessage=RegisterWindowMessage("hyse.desktop.exit");
    public static void Signal(bool exit)
    {
        nint window=FindWindow(null,"hyse");
        if(window!=0){GetWindowThreadProcessId(window,out uint process);AllowSetForegroundWindow(process);PostMessage(window,exit?ExitMessage:ActivateMessage,0,0);}
        else PostMessage((nint)0xffff,exit?ExitMessage:ActivateMessage,0,0);
    }
    [DllImport("user32.dll",EntryPoint="RegisterWindowMessageW",CharSet=CharSet.Unicode)]static extern uint RegisterWindowMessage(string name);
    [DllImport("user32.dll",EntryPoint="FindWindowW",CharSet=CharSet.Unicode)]static extern nint FindWindow(string? className,string title);
    [DllImport("user32.dll",EntryPoint="PostMessageW")]static extern bool PostMessage(nint window,uint message,nint wParam,nint lParam);
    [DllImport("user32.dll")]static extern uint GetWindowThreadProcessId(nint window,out uint process);
    [DllImport("user32.dll")]static extern bool AllowSetForegroundWindow(uint process);
}
