using System.Text.Json;
using GlassPlayer.Core;
namespace GlassPlayer;
public partial class MainWindow
{
    readonly DiscordActivity discordActivity=new();
    readonly DiscordPresence discord=new();
    string? discordStatus;
    void InitializeDiscord()=>discord.Changed+=()=>{if(!closed)_=Dispatcher.InvokeAsync(PublishDiscordStatus);};
    void PublishDiscordStatus()
    {
        if(!loaded||closed)return;var state=discord.State;string serialized=JsonSerializer.Serialize(state,Json);
        if(serialized!=discordStatus){discordStatus=serialized;Emit("discord",state);}
    }
    string DiscordDiagnostics()=>JsonSerializer.Serialize(new{applicationId=DiscordActivity.ApplicationId,connection=discord.State},new JsonSerializerOptions{WriteIndented=true,PropertyNamingPolicy=JsonNamingPolicy.CamelCase});
    void UpdateDiscord()
    {
        var options=new DiscordPresenceOptions(settings.DiscordEnabled,settings.DiscordArtwork,settings.DiscordTime,settings.DiscordButton,settings.DiscordHidePaused,settings.DiscordText);
        discord.Update(options.Enabled,discordActivity.Build(clock.Uri==queue.Current?.OpenUri?queue.Current:null,clock.Playing,clock.Position,clock.Duration,options,DateTimeOffset.UtcNow));
        PublishDiscordStatus();
    }
}
