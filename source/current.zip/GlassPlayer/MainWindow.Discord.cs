using GlassPlayer.Core;
namespace GlassPlayer;

public partial class MainWindow
{
    readonly DiscordActivity discordActivity=new();
    readonly DiscordPresence discord=new();
    string? discordStatus;
    void UpdateDiscord()
    {
        var options=new DiscordPresenceOptions(settings.DiscordEnabled,settings.DiscordArtwork,settings.DiscordTime,settings.DiscordButton,settings.DiscordHidePaused,settings.DiscordText);
        discord.Update(options.Enabled,discordActivity.Build(clock.Uri==queue.Current?.OpenUri?queue.Current:null,clock.Playing,clock.Position,clock.Duration,options,DateTimeOffset.UtcNow));
        string status=discord.Status;if(status!=discordStatus){discordStatus=status;Emit("discord",new{status});}
    }
}
