using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shell;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;
using GlassPlayer.Core;
namespace GlassPlayer;

sealed class SpotifySessionReader
{
    static readonly JsonSerializerOptions Json=new(){PropertyNamingPolicy=JsonNamingPolicy.CamelCase,PropertyNameCaseInsensitive=true};
    sealed record Snapshot(string Status,List<PlaylistScanItem> Items,int Total,string? Title,double Top,double Max,bool Bottom);
    public static async Task<PlaylistContent> ReadAsync(Window owner,string id,LibraryPlaylist? known,CancellationToken cancellation)
    {
        if(!System.Text.RegularExpressions.Regex.IsMatch(id,"^[A-Za-z0-9]{22}$"))throw new ArgumentException("Playlist inválida.");
        using var stop=CancellationTokenSource.CreateLinkedTokenSource(cancellation);var ct=stop.Token;
        var result=new TaskCompletionSource<PlaylistContent>(TaskCreationOptions.RunContinuationsAsynchronously);
        var root=new Grid{Background=new SolidColorBrush(Color.FromRgb(21,21,27))};root.RowDefinitions.Add(new(){Height=new GridLength(36)});root.RowDefinitions.Add(new(){Height=new GridLength(1,GridUnitType.Star)});root.RowDefinitions.Add(new(){Height=GridLength.Auto});
        var title=new TextBlock{Text="Spotify · abrir playlist existente",Foreground=Brushes.Gainsboro,FontSize=12,Margin=new Thickness(18,0,0,0),VerticalAlignment=VerticalAlignment.Center};root.Children.Add(title);
        var close=new Button{Content="✕",Width=46,Height=36,HorizontalAlignment=HorizontalAlignment.Right,Background=Brushes.Transparent,Foreground=Brushes.Gainsboro,BorderThickness=new Thickness(0)};WindowChrome.SetIsHitTestVisibleInChrome(close,true);root.Children.Add(close);
        var web=new WebView2{Margin=new Thickness(6,0,6,0),DefaultBackgroundColor=System.Drawing.Color.FromArgb(18,18,18)};Grid.SetRow(web,1);root.Children.Add(web);
        var footer=new Grid{Margin=new Thickness(18,13,18,15)};footer.ColumnDefinitions.Add(new(){Width=new GridLength(1,GridUnitType.Star)});footer.ColumnDefinitions.Add(new(){Width=GridLength.Auto});footer.ColumnDefinitions.Add(new(){Width=GridLength.Auto});Grid.SetRow(footer,2);root.Children.Add(footer);
        var status=new TextBlock{Text="Entre no Spotify, se necessário. Depois clique em Ler músicas. A sessão fica neste computador.",Foreground=Brushes.Gainsboro,TextWrapping=TextWrapping.Wrap,VerticalAlignment=VerticalAlignment.Center,Margin=new Thickness(0,0,18,0)};footer.Children.Add(status);
        var openPlaylist=new Button{Content="Abrir playlist",Padding=new Thickness(14,10,14,10),Margin=new Thickness(0,0,8,0),IsEnabled=false};Grid.SetColumn(openPlaylist,1);footer.Children.Add(openPlaylist);
        var read=new Button{Content="Ler músicas",Padding=new Thickness(20,10,20,10),MinWidth=125,IsEnabled=false};Grid.SetColumn(read,2);footer.Children.Add(read);
        var window=new Window{Title="Spotify · hyse",Owner=owner,Width=1000,Height=760,MinWidth=740,MinHeight=540,WindowStyle=WindowStyle.None,ResizeMode=ResizeMode.CanResize,WindowStartupLocation=WindowStartupLocation.CenterOwner,Content=root,Background=root.Background};
        WindowChrome.SetWindowChrome(window,new(){CaptionHeight=36,ResizeBorderThickness=new Thickness(6),GlassFrameThickness=new Thickness(0),CornerRadius=new CornerRadius(34),UseAeroCaptionButtons=false});
        window.SourceInitialized+=(_,_)=>WindowShape.Apply(window,root,34);window.SizeChanged+=(_,_)=>WindowShape.Apply(window,root,34);window.StateChanged+=(_,_)=>WindowShape.Apply(window,root,34);close.Click+=(_,_)=>window.Close();
        bool closed=false,reading=false;
        openPlaylist.Click+=(_,_)=>{if(!reading&&web.CoreWebView2!=null)web.CoreWebView2.Navigate("https://open.spotify.com/playlist/"+id);};
        window.Closed+=(_,_)=>{closed=true;stop.Cancel();web.Dispose();result.TrySetCanceled(cancellation.IsCancellationRequested?cancellation:new CancellationToken(true));};
        using var registration=cancellation.Register(()=>owner.Dispatcher.BeginInvoke(()=>{if(!closed)window.Close();}));
        string script=await File.ReadAllTextAsync(Path.Combine(AppContext.BaseDirectory,"Web","spotify-reader.js"),ct);
        async Task<Snapshot> Page(string mode)
        {
            ct.ThrowIfCancellationRequested();var args=JsonSerializer.Serialize(new{id,mode},Json);var raw=await web.CoreWebView2.ExecuteScriptAsync("(()=>{"+script+";return scanPlaylistPage("+args+");})()");ct.ThrowIfCancellationRequested();return JsonSerializer.Deserialize<Snapshot>(raw,Json)??throw new FormatException("O Spotify ainda não exibiu a lista.");
        }
        read.Click+=async(_,_)=>
        {
            if(reading||!read.IsEnabled)return;reading=true;read.IsEnabled=false;openPlaylist.IsEnabled=false;
            try
            {
                var scan=new PlaylistScan(known?.Count??0);await Page("top");await Task.Delay(450,ct);int still=0,waiting=0;double lastTop=-1;string name=known?.Name??"Playlist Spotify";
                for(int step=0;step<420;step++)
                {
                    var page=await Page("read");if(page.Status=="signin")throw new FormatException("Entre na conta Spotify que tem acesso a esta playlist e clique em Ler músicas novamente.");
                    if(page.Status=="waiting"&&(page.Items==null||page.Items.Count==0))
                    {
                        if(waiting++>=60)throw new TimeoutException("A lista de músicas ainda não apareceu. Abra a playlist nesta janela e tente novamente.");
                        status.Text="Aguardando o Spotify carregar a lista de músicas…";await Task.Delay(500,ct);continue;
                    }
                    waiting=0;if(scan.ExpectedCount==0&&page.Total>0)scan.SetExpectedCount(page.Total);
                    if(page.Title is{Length:>0})name=page.Title;int before=scan.Count;scan.Add(page.Items??new());
                    status.Text=$"Lendo {scan.Count} de {scan.ExpectedCount} faixas… Mantenha esta janela aberta.";
                    if(scan.Complete)
                    {
                        var tracks=scan.Finish();var metadata=known??new LibraryPlaylist(id,name,"",tracks.FirstOrDefault(t=>t.Art!=null)?.Art,"","Spotify",false,false,tracks.Count,null);
                        var content=new PlaylistContent(metadata with{Name=name,Count=tracks.Count},tracks,true,"Playlist lida pela sua sessão Spotify. Edição pela API permanece indisponível para esta playlist.",true,"session");
                        result.TrySetResult(content);window.Close();return;
                    }
                    if(page.Bottom&&before==scan.Count&&Math.Abs(page.Top-lastTop)<2)still++;else still=0;
                    if(still>=5)throw new FormatException($"A página exibiu {scan.Count} de {scan.ExpectedCount} faixas. Atualize a página do Spotify e repita a leitura; nenhuma lista incompleta foi salva.");
                    lastTop=page.Top;await Page("next");await Task.Delay(300,ct);
                }
                throw new TimeoutException("A leitura demorou demais. Confira se a playlist está aberta nesta janela e tente novamente.");
            }
            catch(OperationCanceledException){if(!closed)window.Close();}
            catch(Exception ex){if(!closed)status.Text=ex.Message;}
            finally{reading=false;if(!closed){read.IsEnabled=true;openPlaylist.IsEnabled=true;}}
        };
        window.Show();
        try
        {
            var profile=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"cncx","spotify-reader");
            var environment=await CoreWebView2Environment.CreateAsync(null,profile);ct.ThrowIfCancellationRequested();await web.EnsureCoreWebView2Async(environment);ct.ThrowIfCancellationRequested();
            web.CoreWebView2.Settings.AreDevToolsEnabled=false;web.CoreWebView2.Settings.AreDefaultContextMenusEnabled=false;
            web.CoreWebView2.NewWindowRequested+=(_,e)=>{e.Handled=true;if(Uri.TryCreate(e.Uri,UriKind.Absolute,out var target)&&target.Scheme=="https"&&target.IsDefaultPort&&target.UserInfo.Length==0&&(target.Host=="accounts.spotify.com"||target.Host=="open.spotify.com"))web.CoreWebView2.Navigate(e.Uri);};
            web.CoreWebView2.NavigationStarting+=(_,e)=>{if(!Uri.TryCreate(e.Uri,UriKind.Absolute,out var target)||target.Scheme!="https"||!target.IsDefaultPort||target.UserInfo.Length>0||target.Host is not("open.spotify.com" or "accounts.spotify.com"))e.Cancel=true;};
            web.CoreWebView2.NavigationCompleted+=(_,_)=>{if(!closed){read.IsEnabled=!reading;openPlaylist.IsEnabled=!reading;}};
            web.CoreWebView2.Navigate("https://open.spotify.com/playlist/"+id);
        }
        catch(Exception ex){if(!closed){status.Text="Falha ao abrir a sessão Spotify: "+ex.Message;read.IsEnabled=false;}}
        return await result.Task;
    }
}
