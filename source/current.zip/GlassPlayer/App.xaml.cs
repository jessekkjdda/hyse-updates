using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;

namespace GlassPlayer;

public partial class App : Application
{
    Mutex? instance;
    bool ownsInstance;
    protected override void OnStartup(StartupEventArgs e)
    {
        instance=new Mutex(true,DesktopInstance.MutexName,out ownsInstance);
        bool exitOnly=e.Args.Contains("--exit-for-update",StringComparer.Ordinal);
        if(!ownsInstance||exitOnly){if(!ownsInstance)DesktopInstance.Signal(exitOnly);Shutdown();return;}
        if(Semaphore.TryOpenExisting(GlassPlayer.Core.UpdateHandoff.MutexName,out var updating)){updating.Dispose();Shutdown();return;}
        base.OnStartup(e);
        var window=new MainWindow();MainWindow=window;
        SessionEnding+=(_,_)=>window.AllowSessionExit();window.Show();
    }
    protected override void OnExit(ExitEventArgs e)
    {
        if(ownsInstance)instance?.ReleaseMutex();instance?.Dispose();base.OnExit(e);
    }
    public App()
    {
        try
        {
            var root = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var old = Path.Combine(root, "ZavGlass"); var current = Path.Combine(root, "cncx");
            if (Directory.Exists(old) && !Directory.Exists(current))
            {
                Directory.CreateDirectory(current);
                foreach (var name in new[] { "settings.json", "queue.json" }.Concat(Directory.GetFiles(old, "spotify-*.bin").Select(Path.GetFileName)!))
                {
                    if (name == null) continue; var file = Path.Combine(old, name); if (File.Exists(file)) File.Copy(file, Path.Combine(current, name), false);
                }
                var settings = AppSettings.Load(); settings.CornerRadius = Math.Max(34, settings.CornerRadius); settings.ArtworkRadius = Math.Max(34, settings.ArtworkRadius); settings.UiVersion = 2; settings.Save();
            }
        }
        catch (Exception ex) { System.Diagnostics.Trace.WriteLine(ex); }

        DispatcherUnhandledException += (_, e) =>
        {
            Report(e.Exception);
            e.Handled = true;
            if (MainWindow == null || !MainWindow.IsLoaded) Shutdown(); // failed while starting
        };
        AppDomain.CurrentDomain.UnhandledException += (_, e) => Report(e.ExceptionObject as Exception);
        TaskScheduler.UnobservedTaskException += (_, e) => e.SetObserved();
    }

    static void Report(Exception? ex)
    {
        string path = "";
        try
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "cncx");
            Directory.CreateDirectory(dir);
            path = Path.Combine(dir, "crash.log");
            File.AppendAllText(path, $"{DateTime.Now}\n{ex}\n\n");
        }
        catch { }
        MessageBox.Show("O hyse encontrou um problema:\n\n" + ex?.Message + (path.Length > 0 ? "\n\nDetalhes em:\n" + path : ""), "hyse");
    }
}
