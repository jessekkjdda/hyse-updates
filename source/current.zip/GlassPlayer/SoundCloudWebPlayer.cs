using System.Diagnostics;
using System.Text.Json;
using Microsoft.Web.WebView2.Wpf;
using GlassPlayer.Core;
namespace GlassPlayer;
sealed class SoundCloudWebPlayer(WebView2 web):IDisposable
{
    readonly PlaybackClock clock=new();readonly Dictionary<string,TaskCompletionSource<bool>> pending=new();bool disposed;long lastRaw=-1;double rawAt;
    public event Action<string>? Ended;
    public bool FreshPosition=>Now-rawAt<900;
    static double Now=>Stopwatch.GetTimestamp()*1000d/Stopwatch.Frequency;
    public void Message(JsonElement m)
    {
        switch(m.GetProperty("type").GetString())
        {
            case "sc-command":if(pending.TryGetValue(m.GetProperty("id").GetString()??"",out var promise)){if(m.GetProperty("ok").GetBoolean())promise.TrySetResult(true);else promise.TrySetException(new Exception(m.GetProperty("error").GetString()));}break;
            case "sc-state":var position=m.GetProperty("position").GetInt32();if(position!=lastRaw){lastRaw=position;rawAt=Now;}clock.Update(position,m.GetProperty("duration").GetInt32(),m.GetProperty("playing").GetBoolean(),m.GetProperty("uri").GetString());break;
            case "sc-ended":Ended?.Invoke(m.GetProperty("uri").GetString()??"");break;
        }
    }
    public async Task CallAsync(string method,double? value=null,Track? track=null,CancellationToken ct=default)
    {
        if(disposed||web.CoreWebView2==null)throw new InvalidOperationException("O player ainda não está pronto.");
        var id=Guid.NewGuid().ToString("N");var completion=new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);pending[id]=completion;
        try
        {
            await web.CoreWebView2.ExecuteScriptAsync("window.cncxSoundCloud.command("+JsonSerializer.Serialize(new{id,method,value,url=track?.OpenUri,trackId=track?.Id.StartsWith("sc:")==true?track.Id[3..]:null})+")");
            await completion.Task.WaitAsync(TimeSpan.FromSeconds(method=="load"?45:8),ct);
            if(method=="pause")clock.SetPlaying(false);else if(method=="resume")clock.SetPlaying(true);else if(method=="seek")clock.Seek((long)(value??0));
        }
        catch
        {
            if(method=="load"&&!disposed&&web.CoreWebView2!=null)await web.CoreWebView2.ExecuteScriptAsync("window.cncxSoundCloud.cancel("+JsonSerializer.Serialize(id)+")");throw;
        }
        finally{pending.Remove(id);}
    }
    public async Task PlayAsync(Track track,CancellationToken ct){clock.Clear();lastRaw=-1;rawAt=0;await CallAsync("load",track:track,ct:ct);}
    public(bool Playing,int Progress,int Duration,string? Uri)? Current()=>clock.Uri==null?null:(clock.Playing,(int)clock.Position,(int)clock.Duration,clock.Uri);
    public void Dispose(){disposed=true;foreach(var p in pending.Values)p.TrySetCanceled();pending.Clear();}
}
