using System.IO;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using GlassPlayer.Core;
namespace GlassPlayer;

sealed class LyricsService : IDisposable
{
    readonly HttpClient http;
    readonly SemaphoreSlim requests = new(1, 1);
    DateTime nextRequest;
    readonly RecentCache<LyricsDocument?> memory = new(60, TimeSpan.FromMinutes(30));
    readonly string cacheDir;
    readonly TimeSpan spacing;
    public LyricsService(HttpClient? client = null, string? cachePath = null, TimeSpan? requestSpacing = null)
    {
        cacheDir = cachePath ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "cncx", "lyrics"); spacing = requestSpacing ?? TimeSpan.FromMilliseconds(1100);
        http = client ?? new HttpClient() { Timeout = TimeSpan.FromSeconds(12) };
        http.DefaultRequestHeaders.UserAgent.ParseAdd("hyse/0.12.0 (GlassPlayer fork; https://github.com/Jonzu00/GlassPlayer)");
    }
    static Track LookupTrack(Track track)
    {
        string prefix=track.Artist+" - ";return track.Source=="SoundCloud"&&track.Artist.Length>0&&track.Title.StartsWith(prefix,StringComparison.OrdinalIgnoreCase)?track with{Title=track.Title[prefix.Length..].Trim()}:track;
    }
    static string LegacyKey(Track t) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(t.Title + "\n" + t.Artist + "\n" + t.DurationMs / 1000)));
    static string Key(Track t)=>LegacyKey(t)+"-v9-"+Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(t.AlbumName??"")))[..12];
    public bool HasLocalOverride(Track track)=>File.Exists(Path.Combine(cacheDir,"overrides",LegacyKey(LookupTrack(track))+".json"));
    public async Task<LyricsDocument?> GetAsync(Track track, CancellationToken ct, bool force = false)
    {
        track=LookupTrack(track);var key = Key(track);
        var custom = Path.Combine(cacheDir, "overrides", LegacyKey(track) + ".json");
        if (File.Exists(custom) && new FileInfo(custom).Length < 1024 * 1024) { var local = JsonSerializer.Deserialize<LyricsDocument>(await File.ReadAllTextAsync(custom, ct)); if (local != null) return local; }
        if (!force && memory.TryGet(key, out var hit)) return hit;
        var file = Path.Combine(cacheDir, key + ".json");
        try { if (!force && File.Exists(file) && new FileInfo(file).Length < 1024 * 1024 && DateTime.UtcNow - File.GetLastWriteTimeUtc(file) < TimeSpan.FromDays(14)) { var cached = JsonSerializer.Deserialize<LyricsDocument>(await File.ReadAllTextAsync(file, ct)); if (cached != null) { memory.Set(key, cached); return cached; } } } catch (OperationCanceledException) { throw; } catch { }
        string artist = track.Artist.Split(new[] { ",", ";" }, StringSplitOptions.None)[0].Trim();
        var query = "track_name=" + Uri.EscapeDataString(LyricsParser.LookupTitle(track.Title)) + "&artist_name=" + Uri.EscapeDataString(artist);
        if(!string.IsNullOrEmpty(track.AlbumName))query+="&album_name="+Uri.EscapeDataString(track.AlbumName);
        if (track.DurationMs is > 0 and <= 3600000) query += "&duration=" + (track.DurationMs / 1000d).ToString("0.###", System.Globalization.CultureInfo.InvariantCulture);
        LyricsDocument? result = null;
        using (var exact = await GetJsonAsync("get?" + query, ct)) if (exact != null) result = Parse(exact.RootElement, track);
        if (result?.Instrumental!=true&&(result == null||!result.Synced))
        {
            try
            {
                using var search = await GetJsonAsync("search?track_name=" + Uri.EscapeDataString(LyricsParser.LookupTitle(track.Title)) + "&artist_name=" + Uri.EscapeDataString(artist), ct);
                if(search?.RootElement.ValueKind==JsonValueKind.Array)
                {
                    var better=search.RootElement.EnumerateArray().Take(20).Where(item=>Matches(item,track)).Where(item=>string.IsNullOrEmpty(track.AlbumName)||string.IsNullOrEmpty(S(item,"albumName"))||LyricsParser.Normalize(S(item,"albumName")!)==LyricsParser.Normalize(track.AlbumName)).OrderByDescending(item=>S(item,"albumName")==track.AlbumName).Select(item=>Parse(item,track)).Where(item=>item!=null).OrderByDescending(item=>item!.Synced).ThenByDescending(item=>item!.WordSynced).FirstOrDefault();
                    if(better!=null&&(result==null||better.WordSynced||!result.Synced&&better.Synced))result=better;
                }
            }
            catch(Exception ex)when(result!=null&&!ct.IsCancellationRequested&&ex is HttpRequestException or FormatException or JsonException or TaskCanceledException){/* Keep the exact match when the optional word-timing lookup fails. */}
        }
        memory.Set(key, result);
        if (result != null)
        {
            try
            {
                Directory.CreateDirectory(cacheDir); await File.WriteAllTextAsync(file + ".tmp", JsonSerializer.Serialize(result), ct); ct.ThrowIfCancellationRequested(); File.Move(file + ".tmp", file, true);
                foreach (var old in new DirectoryInfo(cacheDir).GetFiles("*.json").OrderByDescending(f => f.LastWriteTimeUtc).Skip(160)) try { old.Delete(); } catch { }
            }
            catch (OperationCanceledException) { throw; }
            catch { }
        }
        return result;
    }
    public async Task SaveOverrideAsync(Track track, LyricsDocument document, CancellationToken ct)
    {
        track=LookupTrack(track);var directory = Path.Combine(cacheDir, "overrides"); Directory.CreateDirectory(directory); var path = Path.Combine(directory, LegacyKey(track) + ".json");
        await File.WriteAllTextAsync(path + ".tmp", JsonSerializer.Serialize(document), ct); ct.ThrowIfCancellationRequested(); File.Move(path + ".tmp", path, true);
    }
    static bool Matches(JsonElement item, Track track) => item.ValueKind==JsonValueKind.Object&&LyricsParser.Compatible(track.Title, track.Artist, track.DurationMs, S(item, "trackName") ?? "", S(item, "artistName") ?? "", item.TryGetProperty("duration", out var n) && n.TryGetDouble(out var seconds) ? seconds : 0);
    static string? S(JsonElement item, string key) => item.TryGetProperty(key, out var value) && value.ValueKind == JsonValueKind.String ? value.GetString() : null;
    static LyricsDocument? Parse(JsonElement item, Track track)
    {
        if (!Matches(item, track)) return null;
        bool instrumental = item.TryGetProperty("instrumental", out var flag) && flag.ValueKind == JsonValueKind.True;
        var synced = S(item, "syncedLyrics"); var plain = S(item, "plainLyrics");
        var lines=synced==null?new List<LyricLine>():LyricsParser.Parse(synced);
        var yaml=S(item,"lyricsfile");
        if(yaml!=null)try{var rich=LyricsfileReader.Parse(yaml);if(rich.Count>0)
            {
                if(lines.Count==0)lines=rich;
                else lines=lines.Select(line=>{var same=rich.FirstOrDefault(r=>r.TimeMs==line.TimeMs&&r.Text==line.Text);return same?.Words is{Count:>0}?line with{Words=same.Words,EndMs=same.EndMs}:line;}).ToList();
            }}catch(Exception ex)when(ex is FormatException or YamlDotNet.Core.YamlException){}
        if (!instrumental && lines.Count == 0 && string.IsNullOrWhiteSpace(plain)) return null;
        return new(track.Title, track.Artist, lines, plain, instrumental, "LRCLIB");
    }
    async Task<JsonDocument?> GetJsonAsync(string path, CancellationToken ct)
    {
        await requests.WaitAsync(ct);
        try
        {
            var wait = nextRequest - DateTime.UtcNow; if (wait > TimeSpan.Zero) await Task.Delay(wait, ct);
            using var response = await http.GetAsync("https://lrclib.net/api/" + path, HttpCompletionOption.ResponseHeadersRead, ct); nextRequest = DateTime.UtcNow + spacing;
            if (response.StatusCode == HttpStatusCode.NotFound) return null;
            if (response.StatusCode is HttpStatusCode.TooManyRequests or HttpStatusCode.ServiceUnavailable)
            { nextRequest = DateTime.UtcNow.AddSeconds(Math.Clamp(response.Headers.RetryAfter?.Delta?.TotalSeconds ?? 10, 1, 120)); throw new HttpRequestException("O serviço de letras está ocupado. Tente novamente em instantes."); }
            response.EnsureSuccessStatusCode();
            if (response.Content.Headers.ContentLength > 1024 * 1024) throw new FormatException("A resposta de letras excede o limite de leitura.");
            if (response.Content.Headers.ContentType?.MediaType?.Contains("json", StringComparison.OrdinalIgnoreCase) != true) throw new FormatException("O serviço de letras retornou uma resposta inesperada.");
            await using var stream = await response.Content.ReadAsStreamAsync(ct); using var limited = new MemoryStream(); var bytes = new byte[8192]; int read;
            while ((read = await stream.ReadAsync(bytes, ct)) > 0) { if (limited.Length + read > 1024 * 1024) throw new FormatException("A resposta de letras excede o limite de leitura."); await limited.WriteAsync(bytes.AsMemory(0, read), ct); }
            limited.Position = 0; return await JsonDocument.ParseAsync(limited, cancellationToken: ct);
        }
        finally { requests.Release(); }
    }
    public void Dispose() => http.Dispose();
}
